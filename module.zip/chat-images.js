const xe = (l) => $(l), ot = (l, g) => l.before(g), te = (l, g) => g ? g.find(l) : $(l), Te = (l, g) => l.append(g), ke = (l, g, b) => l.on(g, b), Ht = (l, g) => l.trigger(g), Ot = (l, g) => l.removeClass(g), Xe = (l, g) => l.addClass(g), Je = (l) => l.remove(), Lt = (l, g, b) => b ? l.attr(g, b) : l.attr(g), Dt = (l, g) => l.removeAttr(g), Bt = (l) => l.focus(), Be = "data", be = (l) => {
  var g;
  return ((g = game == null ? void 0 : game.i18n) == null ? void 0 : g.localize(`CI.${l}`)) || "";
}, gt = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15), pt = (l = !1) => {
  var e, t, c, a;
  const g = (e = game == null ? void 0 : game.user) == null ? void 0 : e.role, b = (t = game == null ? void 0 : game.permissions) == null ? void 0 : t.FILES_UPLOAD;
  if (!g || !b)
    return l || (c = ui.notifications) == null || c.warn(be("uploadPermissions")), !1;
  const o = b.includes(g);
  return !o && !l && ((a = ui.notifications) == null || a.warn(be("uploadPermissions"))), o;
}, Qt = () => game == null ? void 0 : game.version, Fe = () => Number(Qt()) >= 13, Qe = () => Fe() ? foundry.applications.apps.FilePicker.implementation : FilePicker, Nt = () => Fe() ? foundry.applications.apps.ImagePopout : ImagePopout;
function zt(l, g) {
  return g.forEach(function(b) {
    b && typeof b != "string" && !Array.isArray(b) && Object.keys(b).forEach(function(o) {
      if (o !== "default" && !(o in l)) {
        var e = Object.getOwnPropertyDescriptor(b, o);
        Object.defineProperty(l, o, e.get ? e : { enumerable: !0, get: function() {
          return b[o];
        } });
      }
    });
  }), Object.freeze(l);
}
function mt(l, g) {
  return new Promise(function(b, o) {
    let e;
    return $t(l).then(function(t) {
      try {
        return e = t, b(new Blob([g.slice(0, 2), e, g.slice(2)], { type: "image/jpeg" }));
      } catch (c) {
        return o(c);
      }
    }, o);
  });
}
const $t = (l) => new Promise((g, b) => {
  const o = new FileReader();
  o.addEventListener("load", ({ target: { result: e } }) => {
    const t = new DataView(e);
    let c = 0;
    if (t.getUint16(c) !== 65496)
      return b("not a valid JPEG");
    for (c += 2; ; ) {
      const a = t.getUint16(c);
      if (a === 65498)
        break;
      const m = t.getUint16(c + 2);
      if (a === 65505 && t.getUint32(c + 4) === 1165519206) {
        const E = c + 10;
        let r;
        switch (t.getUint16(E)) {
          case 18761:
            r = !0;
            break;
          case 19789:
            r = !1;
            break;
          default:
            return b("TIFF header contains invalid endian");
        }
        if (t.getUint16(E + 2, r) !== 42)
          return b("TIFF header contains invalid version");
        const i = t.getUint32(E + 4, r), n = E + i + 2 + 12 * t.getUint16(E + i, r);
        for (let s = E + i + 2; s < n; s += 12)
          if (t.getUint16(s, r) == 274) {
            if (t.getUint16(s + 2, r) !== 3)
              return b("Orientation data type is invalid");
            if (t.getUint32(s + 4, r) !== 1)
              return b("Orientation data count is invalid");
            t.setUint16(s + 8, 1, r);
            break;
          }
        return g(e.slice(c, c + 2 + m));
      }
      c += 2 + m;
    }
    return g(new Blob());
  }), o.readAsArrayBuffer(l);
});
var ze = {}, Wt = { get exports() {
  return ze;
}, set exports(l) {
  ze = l;
} };
(function(l) {
  var g, b, o = {};
  Wt.exports = o, o.parse = function(e, t) {
    for (var c = o.bin.readUshort, a = o.bin.readUint, m = 0, E = {}, r = new Uint8Array(e), i = r.length - 4; a(r, i) != 101010256; )
      i--;
    m = i, m += 4;
    var n = c(r, m += 4);
    c(r, m += 2);
    var s = a(r, m += 2), p = a(r, m += 4);
    m += 4, m = p;
    for (var C = 0; C < n; C++) {
      a(r, m), m += 4, m += 4, m += 4, a(r, m += 4), s = a(r, m += 4);
      var T = a(r, m += 4), y = c(r, m += 4), L = c(r, m + 2), P = c(r, m + 4);
      m += 6;
      var M = a(r, m += 8);
      m += 4, m += y + L + P, o._readLocal(r, M, E, s, T, t);
    }
    return E;
  }, o._readLocal = function(e, t, c, a, m, E) {
    var r = o.bin.readUshort, i = o.bin.readUint;
    i(e, t), r(e, t += 4), r(e, t += 2);
    var n = r(e, t += 2);
    i(e, t += 2), i(e, t += 4), t += 4;
    var s = r(e, t += 8), p = r(e, t += 2);
    t += 2;
    var C = o.bin.readUTF8(e, t, s);
    if (t += s, t += p, E)
      c[C] = { size: m, csize: a };
    else {
      var T = new Uint8Array(e.buffer, t);
      if (n == 0)
        c[C] = new Uint8Array(T.buffer.slice(t, t + a));
      else {
        if (n != 8)
          throw "unknown compression method: " + n;
        var y = new Uint8Array(m);
        o.inflateRaw(T, y), c[C] = y;
      }
    }
  }, o.inflateRaw = function(e, t) {
    return o.F.inflate(e, t);
  }, o.inflate = function(e, t) {
    return e[0], e[1], o.inflateRaw(new Uint8Array(e.buffer, e.byteOffset + 2, e.length - 6), t);
  }, o.deflate = function(e, t) {
    t == null && (t = { level: 6 });
    var c = 0, a = new Uint8Array(50 + Math.floor(1.1 * e.length));
    a[c] = 120, a[c + 1] = 156, c += 2, c = o.F.deflateRaw(e, a, c, t.level);
    var m = o.adler(e, 0, e.length);
    return a[c + 0] = m >>> 24 & 255, a[c + 1] = m >>> 16 & 255, a[c + 2] = m >>> 8 & 255, a[c + 3] = m >>> 0 & 255, new Uint8Array(a.buffer, 0, c + 4);
  }, o.deflateRaw = function(e, t) {
    t == null && (t = { level: 6 });
    var c = new Uint8Array(50 + Math.floor(1.1 * e.length)), a = o.F.deflateRaw(e, c, a, t.level);
    return new Uint8Array(c.buffer, 0, a);
  }, o.encode = function(e, t) {
    t == null && (t = !1);
    var c = 0, a = o.bin.writeUint, m = o.bin.writeUshort, E = {};
    for (var r in e) {
      var i = !o._noNeed(r) && !t, n = e[r], s = o.crc.crc(n, 0, n.length);
      E[r] = { cpr: i, usize: n.length, crc: s, file: i ? o.deflateRaw(n) : n };
    }
    for (var r in E)
      c += E[r].file.length + 30 + 46 + 2 * o.bin.sizeUTF8(r);
    c += 22;
    var p = new Uint8Array(c), C = 0, T = [];
    for (var r in E) {
      var y = E[r];
      T.push(C), C = o._writeHeader(p, C, r, y, 0);
    }
    var L = 0, P = C;
    for (var r in E)
      y = E[r], T.push(C), C = o._writeHeader(p, C, r, y, 1, T[L++]);
    var M = C - P;
    return a(p, C, 101010256), C += 4, m(p, C += 4, L), m(p, C += 2, L), a(p, C += 2, M), a(p, C += 4, P), C += 4, C += 2, p.buffer;
  }, o._noNeed = function(e) {
    var t = e.split(".").pop().toLowerCase();
    return "png,jpg,jpeg,zip".indexOf(t) != -1;
  }, o._writeHeader = function(e, t, c, a, m, E) {
    var r = o.bin.writeUint, i = o.bin.writeUshort, n = a.file;
    return r(e, t, m == 0 ? 67324752 : 33639248), t += 4, m == 1 && (t += 2), i(e, t, 20), i(e, t += 2, 0), i(e, t += 2, a.cpr ? 8 : 0), r(e, t += 2, 0), r(e, t += 4, a.crc), r(e, t += 4, n.length), r(e, t += 4, a.usize), i(e, t += 4, o.bin.sizeUTF8(c)), i(e, t += 2, 0), t += 2, m == 1 && (t += 2, t += 2, r(e, t += 6, E), t += 4), t += o.bin.writeUTF8(e, t, c), m == 0 && (e.set(n, t), t += n.length), t;
  }, o.crc = { table: function() {
    for (var e = new Uint32Array(256), t = 0; t < 256; t++) {
      for (var c = t, a = 0; a < 8; a++)
        1 & c ? c = 3988292384 ^ c >>> 1 : c >>>= 1;
      e[t] = c;
    }
    return e;
  }(), update: function(e, t, c, a) {
    for (var m = 0; m < a; m++)
      e = o.crc.table[255 & (e ^ t[c + m])] ^ e >>> 8;
    return e;
  }, crc: function(e, t, c) {
    return 4294967295 ^ o.crc.update(4294967295, e, t, c);
  } }, o.adler = function(e, t, c) {
    for (var a = 1, m = 0, E = t, r = t + c; E < r; ) {
      for (var i = Math.min(E + 5552, r); E < i; )
        m += a += e[E++];
      a %= 65521, m %= 65521;
    }
    return m << 16 | a;
  }, o.bin = { readUshort: function(e, t) {
    return e[t] | e[t + 1] << 8;
  }, writeUshort: function(e, t, c) {
    e[t] = 255 & c, e[t + 1] = c >> 8 & 255;
  }, readUint: function(e, t) {
    return 16777216 * e[t + 3] + (e[t + 2] << 16 | e[t + 1] << 8 | e[t]);
  }, writeUint: function(e, t, c) {
    e[t] = 255 & c, e[t + 1] = c >> 8 & 255, e[t + 2] = c >> 16 & 255, e[t + 3] = c >> 24 & 255;
  }, readASCII: function(e, t, c) {
    for (var a = "", m = 0; m < c; m++)
      a += String.fromCharCode(e[t + m]);
    return a;
  }, writeASCII: function(e, t, c) {
    for (var a = 0; a < c.length; a++)
      e[t + a] = c.charCodeAt(a);
  }, pad: function(e) {
    return e.length < 2 ? "0" + e : e;
  }, readUTF8: function(e, t, c) {
    for (var a, m = "", E = 0; E < c; E++)
      m += "%" + o.bin.pad(e[t + E].toString(16));
    try {
      a = decodeURIComponent(m);
    } catch {
      return o.bin.readASCII(e, t, c);
    }
    return a;
  }, writeUTF8: function(e, t, c) {
    for (var a = c.length, m = 0, E = 0; E < a; E++) {
      var r = c.charCodeAt(E);
      if ((4294967168 & r) == 0)
        e[t + m] = r, m++;
      else if ((4294965248 & r) == 0)
        e[t + m] = 192 | r >> 6, e[t + m + 1] = 128 | r >> 0 & 63, m += 2;
      else if ((4294901760 & r) == 0)
        e[t + m] = 224 | r >> 12, e[t + m + 1] = 128 | r >> 6 & 63, e[t + m + 2] = 128 | r >> 0 & 63, m += 3;
      else {
        if ((4292870144 & r) != 0)
          throw "e";
        e[t + m] = 240 | r >> 18, e[t + m + 1] = 128 | r >> 12 & 63, e[t + m + 2] = 128 | r >> 6 & 63, e[t + m + 3] = 128 | r >> 0 & 63, m += 4;
      }
    }
    return m;
  }, sizeUTF8: function(e) {
    for (var t = e.length, c = 0, a = 0; a < t; a++) {
      var m = e.charCodeAt(a);
      if ((4294967168 & m) == 0)
        c++;
      else if ((4294965248 & m) == 0)
        c += 2;
      else if ((4294901760 & m) == 0)
        c += 3;
      else {
        if ((4292870144 & m) != 0)
          throw "e";
        c += 4;
      }
    }
    return c;
  } }, o.F = {}, o.F.deflateRaw = function(e, t, c, a) {
    var m = [[0, 0, 0, 0, 0], [4, 4, 8, 4, 0], [4, 5, 16, 8, 0], [4, 6, 16, 16, 0], [4, 10, 16, 32, 0], [8, 16, 32, 32, 0], [8, 16, 128, 128, 0], [8, 32, 128, 256, 0], [32, 128, 258, 1024, 1], [32, 258, 258, 4096, 1]][a], E = o.F.U, r = o.F._goodIndex;
    o.F._hash;
    var i = o.F._putsE, n = 0, s = c << 3, p = 0, C = e.length;
    if (a == 0) {
      for (; n < C; )
        i(t, s, n + (F = Math.min(65535, C - n)) == C ? 1 : 0), s = o.F._copyExact(e, n, F, t, s + 8), n += F;
      return s >>> 3;
    }
    var T = E.lits, y = E.strt, L = E.prev, P = 0, M = 0, H = 0, v = 0, k = 0, d = 0;
    for (C > 2 && (y[d = o.F._hash(e, 0)] = 0), n = 0; n < C; n++) {
      if (k = d, n + 1 < C - 2) {
        d = o.F._hash(e, n + 1);
        var u = n + 1 & 32767;
        L[u] = y[d], y[d] = u;
      }
      if (p <= n) {
        (P > 14e3 || M > 26697) && C - n > 100 && (p < n && (T[P] = n - p, P += 2, p = n), s = o.F._writeBlock(n == C - 1 || p == C ? 1 : 0, T, P, v, e, H, n - H, t, s), P = M = v = 0, H = n);
        var w = 0;
        n < C - 2 && (w = o.F._bestMatch(e, n, L, k, Math.min(m[2], C - n), m[3]));
        var F = w >>> 16, U = 65535 & w;
        if (w != 0) {
          U = 65535 & w;
          var I = r(F = w >>> 16, E.of0);
          E.lhst[257 + I]++;
          var A = r(U, E.df0);
          E.dhst[A]++, v += E.exb[I] + E.dxb[A], T[P] = F << 23 | n - p, T[P + 1] = U << 16 | I << 8 | A, P += 2, p = n + F;
        } else
          E.lhst[e[n]]++;
        M++;
      }
    }
    for (H == n && e.length != 0 || (p < n && (T[P] = n - p, P += 2, p = n), s = o.F._writeBlock(1, T, P, v, e, H, n - H, t, s), P = 0, M = 0, P = M = v = 0, H = n); (7 & s) != 0; )
      s++;
    return s >>> 3;
  }, o.F._bestMatch = function(e, t, c, a, m, E) {
    var r = 32767 & t, i = c[r], n = r - i + 32768 & 32767;
    if (i == r || a != o.F._hash(e, t - n))
      return 0;
    for (var s = 0, p = 0, C = Math.min(32767, t); n <= C && --E != 0 && i != r; ) {
      if (s == 0 || e[t + s] == e[t + s - n]) {
        var T = o.F._howLong(e, t, n);
        if (T > s) {
          if (p = n, (s = T) >= m)
            break;
          n + 2 < T && (T = n + 2);
          for (var y = 0, L = 0; L < T - 2; L++) {
            var P = t - n + L + 32768 & 32767, M = P - c[P] + 32768 & 32767;
            M > y && (y = M, i = P);
          }
        }
      }
      n += (r = i) - (i = c[r]) + 32768 & 32767;
    }
    return s << 16 | p;
  }, o.F._howLong = function(e, t, c) {
    if (e[t] != e[t - c] || e[t + 1] != e[t + 1 - c] || e[t + 2] != e[t + 2 - c])
      return 0;
    var a = t, m = Math.min(e.length, t + 258);
    for (t += 3; t < m && e[t] == e[t - c]; )
      t++;
    return t - a;
  }, o.F._hash = function(e, t) {
    return (e[t] << 8 | e[t + 1]) + (e[t + 2] << 4) & 65535;
  }, o.saved = 0, o.F._writeBlock = function(e, t, c, a, m, E, r, i, n) {
    var s, p, C, T, y, L, P, M, H, v = o.F.U, k = o.F._putsF, d = o.F._putsE;
    v.lhst[256]++, p = (s = o.F.getTrees())[0], C = s[1], T = s[2], y = s[3], L = s[4], P = s[5], M = s[6], H = s[7];
    var u = 32 + ((n + 3 & 7) == 0 ? 0 : 8 - (n + 3 & 7)) + (r << 3), w = a + o.F.contSize(v.fltree, v.lhst) + o.F.contSize(v.fdtree, v.dhst), F = a + o.F.contSize(v.ltree, v.lhst) + o.F.contSize(v.dtree, v.dhst);
    F += 14 + 3 * P + o.F.contSize(v.itree, v.ihst) + (2 * v.ihst[16] + 3 * v.ihst[17] + 7 * v.ihst[18]);
    for (var U = 0; U < 286; U++)
      v.lhst[U] = 0;
    for (U = 0; U < 30; U++)
      v.dhst[U] = 0;
    for (U = 0; U < 19; U++)
      v.ihst[U] = 0;
    var I = u < w && u < F ? 0 : w < F ? 1 : 2;
    if (k(i, n, e), k(i, n + 1, I), n += 3, I == 0) {
      for (; (7 & n) != 0; )
        n++;
      n = o.F._copyExact(m, E, r, i, n);
    } else {
      var A, S;
      if (I == 1 && (A = v.fltree, S = v.fdtree), I == 2) {
        o.F.makeCodes(v.ltree, p), o.F.revCodes(v.ltree, p), o.F.makeCodes(v.dtree, C), o.F.revCodes(v.dtree, C), o.F.makeCodes(v.itree, T), o.F.revCodes(v.itree, T), A = v.ltree, S = v.dtree, d(i, n, y - 257), d(i, n += 5, L - 1), d(i, n += 5, P - 4), n += 4;
        for (var h = 0; h < P; h++)
          d(i, n + 3 * h, v.itree[1 + (v.ordr[h] << 1)]);
        n += 3 * P, n = o.F._codeTiny(M, v.itree, i, n), n = o.F._codeTiny(H, v.itree, i, n);
      }
      for (var f = E, O = 0; O < c; O += 2) {
        for (var _ = t[O], x = _ >>> 23, N = f + (8388607 & _); f < N; )
          n = o.F._writeLit(m[f++], A, i, n);
        if (x != 0) {
          var B = t[O + 1], Q = B >> 16, D = B >> 8 & 255, R = 255 & B;
          d(i, n = o.F._writeLit(257 + D, A, i, n), x - v.of0[D]), n += v.exb[D], k(i, n = o.F._writeLit(R, S, i, n), Q - v.df0[R]), n += v.dxb[R], f += x;
        }
      }
      n = o.F._writeLit(256, A, i, n);
    }
    return n;
  }, o.F._copyExact = function(e, t, c, a, m) {
    var E = m >>> 3;
    return a[E] = c, a[E + 1] = c >>> 8, a[E + 2] = 255 - a[E], a[E + 3] = 255 - a[E + 1], E += 4, a.set(new Uint8Array(e.buffer, t, c), E), m + (c + 4 << 3);
  }, o.F.getTrees = function() {
    for (var e = o.F.U, t = o.F._hufTree(e.lhst, e.ltree, 15), c = o.F._hufTree(e.dhst, e.dtree, 15), a = [], m = o.F._lenCodes(e.ltree, a), E = [], r = o.F._lenCodes(e.dtree, E), i = 0; i < a.length; i += 2)
      e.ihst[a[i]]++;
    for (i = 0; i < E.length; i += 2)
      e.ihst[E[i]]++;
    for (var n = o.F._hufTree(e.ihst, e.itree, 7), s = 19; s > 4 && e.itree[1 + (e.ordr[s - 1] << 1)] == 0; )
      s--;
    return [t, c, n, m, r, s, a, E];
  }, o.F.getSecond = function(e) {
    for (var t = [], c = 0; c < e.length; c += 2)
      t.push(e[c + 1]);
    return t;
  }, o.F.nonZero = function(e) {
    for (var t = "", c = 0; c < e.length; c += 2)
      e[c + 1] != 0 && (t += (c >> 1) + ",");
    return t;
  }, o.F.contSize = function(e, t) {
    for (var c = 0, a = 0; a < t.length; a++)
      c += t[a] * e[1 + (a << 1)];
    return c;
  }, o.F._codeTiny = function(e, t, c, a) {
    for (var m = 0; m < e.length; m += 2) {
      var E = e[m], r = e[m + 1];
      a = o.F._writeLit(E, t, c, a);
      var i = E == 16 ? 2 : E == 17 ? 3 : 7;
      E > 15 && (o.F._putsE(c, a, r, i), a += i);
    }
    return a;
  }, o.F._lenCodes = function(e, t) {
    for (var c = e.length; c != 2 && e[c - 1] == 0; )
      c -= 2;
    for (var a = 0; a < c; a += 2) {
      var m = e[a + 1], E = a + 3 < c ? e[a + 3] : -1, r = a + 5 < c ? e[a + 5] : -1, i = a == 0 ? -1 : e[a - 1];
      if (m == 0 && E == m && r == m) {
        for (var n = a + 5; n + 2 < c && e[n + 2] == m; )
          n += 2;
        (s = Math.min(n + 1 - a >>> 1, 138)) < 11 ? t.push(17, s - 3) : t.push(18, s - 11), a += 2 * s - 2;
      } else if (m == i && E == m && r == m) {
        for (n = a + 5; n + 2 < c && e[n + 2] == m; )
          n += 2;
        var s = Math.min(n + 1 - a >>> 1, 6);
        t.push(16, s - 3), a += 2 * s - 2;
      } else
        t.push(m, 0);
    }
    return c >>> 1;
  }, o.F._hufTree = function(e, t, c) {
    var a = [], m = e.length, E = t.length, r = 0;
    for (r = 0; r < E; r += 2)
      t[r] = 0, t[r + 1] = 0;
    for (r = 0; r < m; r++)
      e[r] != 0 && a.push({ lit: r, f: e[r] });
    var i = a.length, n = a.slice(0);
    if (i == 0)
      return 0;
    if (i == 1) {
      var s = a[0].lit;
      return n = s == 0 ? 1 : 0, t[1 + (s << 1)] = 1, t[1 + (n << 1)] = 1, 1;
    }
    a.sort(function(M, H) {
      return M.f - H.f;
    });
    var p = a[0], C = a[1], T = 0, y = 1, L = 2;
    for (a[0] = { lit: -1, f: p.f + C.f, l: p, r: C, d: 0 }; y != i - 1; )
      p = T != y && (L == i || a[T].f < a[L].f) ? a[T++] : a[L++], C = T != y && (L == i || a[T].f < a[L].f) ? a[T++] : a[L++], a[y++] = { lit: -1, f: p.f + C.f, l: p, r: C };
    var P = o.F.setDepth(a[y - 1], 0);
    for (P > c && (o.F.restrictDepth(n, c, P), P = c), r = 0; r < i; r++)
      t[1 + (n[r].lit << 1)] = n[r].d;
    return P;
  }, o.F.setDepth = function(e, t) {
    return e.lit != -1 ? (e.d = t, t) : Math.max(o.F.setDepth(e.l, t + 1), o.F.setDepth(e.r, t + 1));
  }, o.F.restrictDepth = function(e, t, c) {
    var a = 0, m = 1 << c - t, E = 0;
    for (e.sort(function(i, n) {
      return n.d == i.d ? i.f - n.f : n.d - i.d;
    }), a = 0; a < e.length && e[a].d > t; a++) {
      var r = e[a].d;
      e[a].d = t, E += m - (1 << c - r);
    }
    for (E >>>= c - t; E > 0; )
      (r = e[a].d) < t ? (e[a].d++, E -= 1 << t - r - 1) : a++;
    for (; a >= 0; a--)
      e[a].d == t && E < 0 && (e[a].d--, E++);
    E != 0 && console.log("debt left");
  }, o.F._goodIndex = function(e, t) {
    var c = 0;
    return t[16 | c] <= e && (c |= 16), t[8 | c] <= e && (c |= 8), t[4 | c] <= e && (c |= 4), t[2 | c] <= e && (c |= 2), t[1 | c] <= e && (c |= 1), c;
  }, o.F._writeLit = function(e, t, c, a) {
    return o.F._putsF(c, a, t[e << 1]), a + t[1 + (e << 1)];
  }, o.F.inflate = function(e, t) {
    var c = Uint8Array;
    if (e[0] == 3 && e[1] == 0)
      return t || new c(0);
    var a = o.F, m = a._bitsF, E = a._bitsE, r = a._decodeTiny, i = a.makeCodes, n = a.codes2map, s = a._get17, p = a.U, C = t == null;
    C && (t = new c(e.length >>> 2 << 3));
    for (var T, y, L = 0, P = 0, M = 0, H = 0, v = 0, k = 0, d = 0, u = 0, w = 0; L == 0; )
      if (L = m(e, w, 1), P = m(e, w + 1, 2), w += 3, P != 0) {
        if (C && (t = o.F._check(t, u + (1 << 17))), P == 1 && (T = p.flmap, y = p.fdmap, k = 511, d = 31), P == 2) {
          M = E(e, w, 5) + 257, H = E(e, w + 5, 5) + 1, v = E(e, w + 10, 4) + 4, w += 14;
          for (var F = 0; F < 38; F += 2)
            p.itree[F] = 0, p.itree[F + 1] = 0;
          var U = 1;
          for (F = 0; F < v; F++) {
            var I = E(e, w + 3 * F, 3);
            p.itree[1 + (p.ordr[F] << 1)] = I, I > U && (U = I);
          }
          w += 3 * v, i(p.itree, U), n(p.itree, U, p.imap), T = p.lmap, y = p.dmap, w = r(p.imap, (1 << U) - 1, M + H, e, w, p.ttree);
          var A = a._copyOut(p.ttree, 0, M, p.ltree);
          k = (1 << A) - 1;
          var S = a._copyOut(p.ttree, M, H, p.dtree);
          d = (1 << S) - 1, i(p.ltree, A), n(p.ltree, A, T), i(p.dtree, S), n(p.dtree, S, y);
        }
        for (; ; ) {
          var h = T[s(e, w) & k];
          w += 15 & h;
          var f = h >>> 4;
          if (f >>> 8 == 0)
            t[u++] = f;
          else {
            if (f == 256)
              break;
            var O = u + f - 254;
            if (f > 264) {
              var _ = p.ldef[f - 257];
              O = u + (_ >>> 3) + E(e, w, 7 & _), w += 7 & _;
            }
            var x = y[s(e, w) & d];
            w += 15 & x;
            var N = x >>> 4, B = p.ddef[N], Q = (B >>> 4) + m(e, w, 15 & B);
            for (w += 15 & B, C && (t = o.F._check(t, u + (1 << 17))); u < O; )
              t[u] = t[u++ - Q], t[u] = t[u++ - Q], t[u] = t[u++ - Q], t[u] = t[u++ - Q];
            u = O;
          }
        }
      } else {
        (7 & w) != 0 && (w += 8 - (7 & w));
        var D = 4 + (w >>> 3), R = e[D - 4] | e[D - 3] << 8;
        C && (t = o.F._check(t, u + R)), t.set(new c(e.buffer, e.byteOffset + D, R), u), w = D + R << 3, u += R;
      }
    return t.length == u ? t : t.slice(0, u);
  }, o.F._check = function(e, t) {
    var c = e.length;
    if (t <= c)
      return e;
    var a = new Uint8Array(Math.max(c << 1, t));
    return a.set(e, 0), a;
  }, o.F._decodeTiny = function(e, t, c, a, m, E) {
    for (var r = o.F._bitsE, i = o.F._get17, n = 0; n < c; ) {
      var s = e[i(a, m) & t];
      m += 15 & s;
      var p = s >>> 4;
      if (p <= 15)
        E[n] = p, n++;
      else {
        var C = 0, T = 0;
        p == 16 ? (T = 3 + r(a, m, 2), m += 2, C = E[n - 1]) : p == 17 ? (T = 3 + r(a, m, 3), m += 3) : p == 18 && (T = 11 + r(a, m, 7), m += 7);
        for (var y = n + T; n < y; )
          E[n] = C, n++;
      }
    }
    return m;
  }, o.F._copyOut = function(e, t, c, a) {
    for (var m = 0, E = 0, r = a.length >>> 1; E < c; ) {
      var i = e[E + t];
      a[E << 1] = 0, a[1 + (E << 1)] = i, i > m && (m = i), E++;
    }
    for (; E < r; )
      a[E << 1] = 0, a[1 + (E << 1)] = 0, E++;
    return m;
  }, o.F.makeCodes = function(e, t) {
    for (var c, a, m, E, r = o.F.U, i = e.length, n = r.bl_count, s = 0; s <= t; s++)
      n[s] = 0;
    for (s = 1; s < i; s += 2)
      n[e[s]]++;
    var p = r.next_code;
    for (c = 0, n[0] = 0, a = 1; a <= t; a++)
      c = c + n[a - 1] << 1, p[a] = c;
    for (m = 0; m < i; m += 2)
      (E = e[m + 1]) != 0 && (e[m] = p[E], p[E]++);
  }, o.F.codes2map = function(e, t, c) {
    for (var a = e.length, m = o.F.U.rev15, E = 0; E < a; E += 2)
      if (e[E + 1] != 0)
        for (var r = E >> 1, i = e[E + 1], n = r << 4 | i, s = t - i, p = e[E] << s, C = p + (1 << s); p != C; )
          c[m[p] >>> 15 - t] = n, p++;
  }, o.F.revCodes = function(e, t) {
    for (var c = o.F.U.rev15, a = 15 - t, m = 0; m < e.length; m += 2) {
      var E = e[m] << t - e[m + 1];
      e[m] = c[E] >>> a;
    }
  }, o.F._putsE = function(e, t, c) {
    c <<= 7 & t;
    var a = t >>> 3;
    e[a] |= c, e[a + 1] |= c >>> 8;
  }, o.F._putsF = function(e, t, c) {
    c <<= 7 & t;
    var a = t >>> 3;
    e[a] |= c, e[a + 1] |= c >>> 8, e[a + 2] |= c >>> 16;
  }, o.F._bitsE = function(e, t, c) {
    return (e[t >>> 3] | e[1 + (t >>> 3)] << 8) >>> (7 & t) & (1 << c) - 1;
  }, o.F._bitsF = function(e, t, c) {
    return (e[t >>> 3] | e[1 + (t >>> 3)] << 8 | e[2 + (t >>> 3)] << 16) >>> (7 & t) & (1 << c) - 1;
  }, o.F._get17 = function(e, t) {
    return (e[t >>> 3] | e[1 + (t >>> 3)] << 8 | e[2 + (t >>> 3)] << 16) >>> (7 & t);
  }, o.F._get25 = function(e, t) {
    return (e[t >>> 3] | e[1 + (t >>> 3)] << 8 | e[2 + (t >>> 3)] << 16 | e[3 + (t >>> 3)] << 24) >>> (7 & t);
  }, o.F.U = (g = Uint16Array, b = Uint32Array, { next_code: new g(16), bl_count: new g(16), ordr: [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], of0: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 999, 999, 999], exb: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0], ldef: new g(32), df0: [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 65535, 65535], dxb: [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0], ddef: new b(32), flmap: new g(512), fltree: [], fdmap: new g(32), fdtree: [], lmap: new g(32768), ltree: [], ttree: [], dmap: new g(32768), dtree: [], imap: new g(512), itree: [], rev15: new g(32768), lhst: new b(286), dhst: new b(30), ihst: new b(19), lits: new b(15e3), strt: new g(65536), prev: new g(32768) }), function() {
    for (var e = o.F.U, t = 0; t < 32768; t++) {
      var c = t;
      c = (4278255360 & (c = (4042322160 & (c = (3435973836 & (c = (2863311530 & c) >>> 1 | (1431655765 & c) << 1)) >>> 2 | (858993459 & c) << 2)) >>> 4 | (252645135 & c) << 4)) >>> 8 | (16711935 & c) << 8, e.rev15[t] = (c >>> 16 | c << 16) >>> 17;
    }
    function a(m, E, r) {
      for (; E-- != 0; )
        m.push(0, r);
    }
    for (t = 0; t < 32; t++)
      e.ldef[t] = e.of0[t] << 3 | e.exb[t], e.ddef[t] = e.df0[t] << 4 | e.dxb[t];
    a(e.fltree, 144, 8), a(e.fltree, 112, 9), a(e.fltree, 24, 7), a(e.fltree, 8, 8), o.F.makeCodes(e.fltree, 9), o.F.codes2map(e.fltree, 9, e.flmap), o.F.revCodes(e.fltree, 9), a(e.fdtree, 32, 5), o.F.makeCodes(e.fdtree, 5), o.F.codes2map(e.fdtree, 5, e.fdmap), o.F.revCodes(e.fdtree, 5), a(e.itree, 19, 0), a(e.ltree, 286, 0), a(e.dtree, 30, 0), a(e.ttree, 320, 0);
  }();
})();
var jt = zt({ __proto__: null, default: ze }, [ze]);
const ge = function() {
  var l = { nextZero(r, i) {
    for (; r[i] != 0; )
      i++;
    return i;
  }, readUshort: (r, i) => r[i] << 8 | r[i + 1], writeUshort(r, i, n) {
    r[i] = n >> 8 & 255, r[i + 1] = 255 & n;
  }, readUint: (r, i) => 16777216 * r[i] + (r[i + 1] << 16 | r[i + 2] << 8 | r[i + 3]), writeUint(r, i, n) {
    r[i] = n >> 24 & 255, r[i + 1] = n >> 16 & 255, r[i + 2] = n >> 8 & 255, r[i + 3] = 255 & n;
  }, readASCII(r, i, n) {
    let s = "";
    for (let p = 0; p < n; p++)
      s += String.fromCharCode(r[i + p]);
    return s;
  }, writeASCII(r, i, n) {
    for (let s = 0; s < n.length; s++)
      r[i + s] = n.charCodeAt(s);
  }, readBytes(r, i, n) {
    const s = [];
    for (let p = 0; p < n; p++)
      s.push(r[i + p]);
    return s;
  }, pad: (r) => r.length < 2 ? `0${r}` : r, readUTF8(r, i, n) {
    let s, p = "";
    for (let C = 0; C < n; C++)
      p += `%${l.pad(r[i + C].toString(16))}`;
    try {
      s = decodeURIComponent(p);
    } catch {
      return l.readASCII(r, i, n);
    }
    return s;
  } };
  function g(r, i, n, s) {
    const p = i * n, C = t(s), T = Math.ceil(i * C / 8), y = new Uint8Array(4 * p), L = new Uint32Array(y.buffer), { ctype: P } = s, { depth: M } = s, H = l.readUshort;
    if (P == 6) {
      const _ = p << 2;
      if (M == 8)
        for (var v = 0; v < _; v += 4)
          y[v] = r[v], y[v + 1] = r[v + 1], y[v + 2] = r[v + 2], y[v + 3] = r[v + 3];
      if (M == 16)
        for (v = 0; v < _; v++)
          y[v] = r[v << 1];
    } else if (P == 2) {
      const _ = s.tabs.tRNS;
      if (_ == null) {
        if (M == 8)
          for (v = 0; v < p; v++) {
            var k = 3 * v;
            L[v] = 255 << 24 | r[k + 2] << 16 | r[k + 1] << 8 | r[k];
          }
        if (M == 16)
          for (v = 0; v < p; v++)
            k = 6 * v, L[v] = 255 << 24 | r[k + 4] << 16 | r[k + 2] << 8 | r[k];
      } else {
        var d = _[0];
        const x = _[1], N = _[2];
        if (M == 8)
          for (v = 0; v < p; v++) {
            var u = v << 2;
            k = 3 * v, L[v] = 255 << 24 | r[k + 2] << 16 | r[k + 1] << 8 | r[k], r[k] == d && r[k + 1] == x && r[k + 2] == N && (y[u + 3] = 0);
          }
        if (M == 16)
          for (v = 0; v < p; v++)
            u = v << 2, k = 6 * v, L[v] = 255 << 24 | r[k + 4] << 16 | r[k + 2] << 8 | r[k], H(r, k) == d && H(r, k + 2) == x && H(r, k + 4) == N && (y[u + 3] = 0);
      }
    } else if (P == 3) {
      const _ = s.tabs.PLTE, x = s.tabs.tRNS, N = x ? x.length : 0;
      if (M == 1)
        for (var w = 0; w < n; w++) {
          var F = w * T, U = w * i;
          for (v = 0; v < i; v++) {
            u = U + v << 2;
            var I = 3 * (A = r[F + (v >> 3)] >> 7 - ((7 & v) << 0) & 1);
            y[u] = _[I], y[u + 1] = _[I + 1], y[u + 2] = _[I + 2], y[u + 3] = A < N ? x[A] : 255;
          }
        }
      if (M == 2)
        for (w = 0; w < n; w++)
          for (F = w * T, U = w * i, v = 0; v < i; v++)
            u = U + v << 2, I = 3 * (A = r[F + (v >> 2)] >> 6 - ((3 & v) << 1) & 3), y[u] = _[I], y[u + 1] = _[I + 1], y[u + 2] = _[I + 2], y[u + 3] = A < N ? x[A] : 255;
      if (M == 4)
        for (w = 0; w < n; w++)
          for (F = w * T, U = w * i, v = 0; v < i; v++)
            u = U + v << 2, I = 3 * (A = r[F + (v >> 1)] >> 4 - ((1 & v) << 2) & 15), y[u] = _[I], y[u + 1] = _[I + 1], y[u + 2] = _[I + 2], y[u + 3] = A < N ? x[A] : 255;
      if (M == 8)
        for (v = 0; v < p; v++) {
          var A;
          u = v << 2, I = 3 * (A = r[v]), y[u] = _[I], y[u + 1] = _[I + 1], y[u + 2] = _[I + 2], y[u + 3] = A < N ? x[A] : 255;
        }
    } else if (P == 4) {
      if (M == 8)
        for (v = 0; v < p; v++) {
          u = v << 2;
          var S = r[h = v << 1];
          y[u] = S, y[u + 1] = S, y[u + 2] = S, y[u + 3] = r[h + 1];
        }
      if (M == 16)
        for (v = 0; v < p; v++) {
          var h;
          u = v << 2, S = r[h = v << 2], y[u] = S, y[u + 1] = S, y[u + 2] = S, y[u + 3] = r[h + 2];
        }
    } else if (P == 0)
      for (d = s.tabs.tRNS ? s.tabs.tRNS : -1, w = 0; w < n; w++) {
        const _ = w * T, x = w * i;
        if (M == 1)
          for (var f = 0; f < i; f++) {
            var O = (S = 255 * (r[_ + (f >>> 3)] >>> 7 - (7 & f) & 1)) == 255 * d ? 0 : 255;
            L[x + f] = O << 24 | S << 16 | S << 8 | S;
          }
        else if (M == 2)
          for (f = 0; f < i; f++)
            O = (S = 85 * (r[_ + (f >>> 2)] >>> 6 - ((3 & f) << 1) & 3)) == 85 * d ? 0 : 255, L[x + f] = O << 24 | S << 16 | S << 8 | S;
        else if (M == 4)
          for (f = 0; f < i; f++)
            O = (S = 17 * (r[_ + (f >>> 1)] >>> 4 - ((1 & f) << 2) & 15)) == 17 * d ? 0 : 255, L[x + f] = O << 24 | S << 16 | S << 8 | S;
        else if (M == 8)
          for (f = 0; f < i; f++)
            O = (S = r[_ + f]) == d ? 0 : 255, L[x + f] = O << 24 | S << 16 | S << 8 | S;
        else if (M == 16)
          for (f = 0; f < i; f++)
            S = r[_ + (f << 1)], O = H(r, _ + (f << 1)) == d ? 0 : 255, L[x + f] = O << 24 | S << 16 | S << 8 | S;
      }
    return y;
  }
  function b(r, i, n, s) {
    const p = t(r), C = Math.ceil(n * p / 8), T = new Uint8Array((C + 1 + r.interlace) * s);
    return i = r.tabs.CgBI ? e(i, T) : o(i, T), r.interlace == 0 ? i = c(i, r, 0, n, s) : r.interlace == 1 && (i = function(L, P) {
      const M = P.width, H = P.height, v = t(P), k = v >> 3, d = Math.ceil(M * v / 8), u = new Uint8Array(H * d);
      let w = 0;
      const F = [0, 0, 4, 0, 2, 0, 1], U = [0, 4, 0, 2, 0, 1, 0], I = [8, 8, 8, 4, 4, 2, 2], A = [8, 8, 4, 4, 2, 2, 1];
      let S = 0;
      for (; S < 7; ) {
        const f = I[S], O = A[S];
        let _ = 0, x = 0, N = F[S];
        for (; N < H; )
          N += f, x++;
        let B = U[S];
        for (; B < M; )
          B += O, _++;
        const Q = Math.ceil(_ * v / 8);
        c(L, P, w, _, x);
        let D = 0, R = F[S];
        for (; R < H; ) {
          let z = U[S], Z = w + D * Q << 3;
          for (; z < M; ) {
            var h;
            if (v == 1 && (h = (h = L[Z >> 3]) >> 7 - (7 & Z) & 1, u[R * d + (z >> 3)] |= h << 7 - ((7 & z) << 0)), v == 2 && (h = (h = L[Z >> 3]) >> 6 - (7 & Z) & 3, u[R * d + (z >> 2)] |= h << 6 - ((3 & z) << 1)), v == 4 && (h = (h = L[Z >> 3]) >> 4 - (7 & Z) & 15, u[R * d + (z >> 1)] |= h << 4 - ((1 & z) << 2)), v >= 8) {
              const j = R * d + z * k;
              for (let W = 0; W < k; W++)
                u[j + W] = L[(Z >> 3) + W];
            }
            Z += v, z += O;
          }
          D++, R += f;
        }
        _ * x != 0 && (w += x * (1 + Q)), S += 1;
      }
      return u;
    }(i, r)), i;
  }
  function o(r, i) {
    return e(new Uint8Array(r.buffer, 2, r.length - 6), i);
  }
  var e = function() {
    const r = { H: {} };
    return r.H.N = function(i, n) {
      const s = Uint8Array;
      let p, C, T = 0, y = 0, L = 0, P = 0, M = 0, H = 0, v = 0, k = 0, d = 0;
      if (i[0] == 3 && i[1] == 0)
        return n || new s(0);
      const u = r.H, w = u.b, F = u.e, U = u.R, I = u.n, A = u.A, S = u.Z, h = u.m, f = n == null;
      for (f && (n = new s(i.length >>> 2 << 5)); T == 0; )
        if (T = w(i, d, 1), y = w(i, d + 1, 2), d += 3, y != 0) {
          if (f && (n = r.H.W(n, k + (1 << 17))), y == 1 && (p = h.J, C = h.h, H = 511, v = 31), y == 2) {
            L = F(i, d, 5) + 257, P = F(i, d + 5, 5) + 1, M = F(i, d + 10, 4) + 4, d += 14;
            let _ = 1;
            for (var O = 0; O < 38; O += 2)
              h.Q[O] = 0, h.Q[O + 1] = 0;
            for (O = 0; O < M; O++) {
              const B = F(i, d + 3 * O, 3);
              h.Q[1 + (h.X[O] << 1)] = B, B > _ && (_ = B);
            }
            d += 3 * M, I(h.Q, _), A(h.Q, _, h.u), p = h.w, C = h.d, d = U(h.u, (1 << _) - 1, L + P, i, d, h.v);
            const x = u.V(h.v, 0, L, h.C);
            H = (1 << x) - 1;
            const N = u.V(h.v, L, P, h.D);
            v = (1 << N) - 1, I(h.C, x), A(h.C, x, p), I(h.D, N), A(h.D, N, C);
          }
          for (; ; ) {
            const _ = p[S(i, d) & H];
            d += 15 & _;
            const x = _ >>> 4;
            if (x >>> 8 == 0)
              n[k++] = x;
            else {
              if (x == 256)
                break;
              {
                let N = k + x - 254;
                if (x > 264) {
                  const z = h.q[x - 257];
                  N = k + (z >>> 3) + F(i, d, 7 & z), d += 7 & z;
                }
                const B = C[S(i, d) & v];
                d += 15 & B;
                const Q = B >>> 4, D = h.c[Q], R = (D >>> 4) + w(i, d, 15 & D);
                for (d += 15 & D; k < N; )
                  n[k] = n[k++ - R], n[k] = n[k++ - R], n[k] = n[k++ - R], n[k] = n[k++ - R];
                k = N;
              }
            }
          }
        } else {
          (7 & d) != 0 && (d += 8 - (7 & d));
          const _ = 4 + (d >>> 3), x = i[_ - 4] | i[_ - 3] << 8;
          f && (n = r.H.W(n, k + x)), n.set(new s(i.buffer, i.byteOffset + _, x), k), d = _ + x << 3, k += x;
        }
      return n.length == k ? n : n.slice(0, k);
    }, r.H.W = function(i, n) {
      const s = i.length;
      if (n <= s)
        return i;
      const p = new Uint8Array(s << 1);
      return p.set(i, 0), p;
    }, r.H.R = function(i, n, s, p, C, T) {
      const y = r.H.e, L = r.H.Z;
      let P = 0;
      for (; P < s; ) {
        const M = i[L(p, C) & n];
        C += 15 & M;
        const H = M >>> 4;
        if (H <= 15)
          T[P] = H, P++;
        else {
          let v = 0, k = 0;
          H == 16 ? (k = 3 + y(p, C, 2), C += 2, v = T[P - 1]) : H == 17 ? (k = 3 + y(p, C, 3), C += 3) : H == 18 && (k = 11 + y(p, C, 7), C += 7);
          const d = P + k;
          for (; P < d; )
            T[P] = v, P++;
        }
      }
      return C;
    }, r.H.V = function(i, n, s, p) {
      let C = 0, T = 0;
      const y = p.length >>> 1;
      for (; T < s; ) {
        const L = i[T + n];
        p[T << 1] = 0, p[1 + (T << 1)] = L, L > C && (C = L), T++;
      }
      for (; T < y; )
        p[T << 1] = 0, p[1 + (T << 1)] = 0, T++;
      return C;
    }, r.H.n = function(i, n) {
      const s = r.H.m, p = i.length;
      let C, T, y, L;
      const P = s.j;
      for (var M = 0; M <= n; M++)
        P[M] = 0;
      for (M = 1; M < p; M += 2)
        P[i[M]]++;
      const H = s.K;
      for (C = 0, P[0] = 0, T = 1; T <= n; T++)
        C = C + P[T - 1] << 1, H[T] = C;
      for (y = 0; y < p; y += 2)
        L = i[y + 1], L != 0 && (i[y] = H[L], H[L]++);
    }, r.H.A = function(i, n, s) {
      const p = i.length, C = r.H.m.r;
      for (let T = 0; T < p; T += 2)
        if (i[T + 1] != 0) {
          const y = T >> 1, L = i[T + 1], P = y << 4 | L, M = n - L;
          let H = i[T] << M;
          const v = H + (1 << M);
          for (; H != v; )
            s[C[H] >>> 15 - n] = P, H++;
        }
    }, r.H.l = function(i, n) {
      const s = r.H.m.r, p = 15 - n;
      for (let C = 0; C < i.length; C += 2) {
        const T = i[C] << n - i[C + 1];
        i[C] = s[T] >>> p;
      }
    }, r.H.M = function(i, n, s) {
      s <<= 7 & n;
      const p = n >>> 3;
      i[p] |= s, i[p + 1] |= s >>> 8;
    }, r.H.I = function(i, n, s) {
      s <<= 7 & n;
      const p = n >>> 3;
      i[p] |= s, i[p + 1] |= s >>> 8, i[p + 2] |= s >>> 16;
    }, r.H.e = function(i, n, s) {
      return (i[n >>> 3] | i[1 + (n >>> 3)] << 8) >>> (7 & n) & (1 << s) - 1;
    }, r.H.b = function(i, n, s) {
      return (i[n >>> 3] | i[1 + (n >>> 3)] << 8 | i[2 + (n >>> 3)] << 16) >>> (7 & n) & (1 << s) - 1;
    }, r.H.Z = function(i, n) {
      return (i[n >>> 3] | i[1 + (n >>> 3)] << 8 | i[2 + (n >>> 3)] << 16) >>> (7 & n);
    }, r.H.i = function(i, n) {
      return (i[n >>> 3] | i[1 + (n >>> 3)] << 8 | i[2 + (n >>> 3)] << 16 | i[3 + (n >>> 3)] << 24) >>> (7 & n);
    }, r.H.m = function() {
      const i = Uint16Array, n = Uint32Array;
      return { K: new i(16), j: new i(16), X: [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], S: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 999, 999, 999], T: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0], q: new i(32), p: [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 65535, 65535], z: [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0], c: new n(32), J: new i(512), _: [], h: new i(32), $: [], w: new i(32768), C: [], v: [], d: new i(32768), D: [], u: new i(512), Q: [], r: new i(32768), s: new n(286), Y: new n(30), a: new n(19), t: new n(15e3), k: new i(65536), g: new i(32768) };
    }(), function() {
      const i = r.H.m;
      for (var n = 0; n < 32768; n++) {
        let p = n;
        p = (2863311530 & p) >>> 1 | (1431655765 & p) << 1, p = (3435973836 & p) >>> 2 | (858993459 & p) << 2, p = (4042322160 & p) >>> 4 | (252645135 & p) << 4, p = (4278255360 & p) >>> 8 | (16711935 & p) << 8, i.r[n] = (p >>> 16 | p << 16) >>> 17;
      }
      function s(p, C, T) {
        for (; C-- != 0; )
          p.push(0, T);
      }
      for (n = 0; n < 32; n++)
        i.q[n] = i.S[n] << 3 | i.T[n], i.c[n] = i.p[n] << 4 | i.z[n];
      s(i._, 144, 8), s(i._, 112, 9), s(i._, 24, 7), s(i._, 8, 8), r.H.n(i._, 9), r.H.A(i._, 9, i.J), r.H.l(i._, 9), s(i.$, 32, 5), r.H.n(i.$, 5), r.H.A(i.$, 5, i.h), r.H.l(i.$, 5), s(i.Q, 19, 0), s(i.C, 286, 0), s(i.D, 30, 0), s(i.v, 320, 0);
    }(), r.H.N;
  }();
  function t(r) {
    return [1, null, 3, 1, 2, null, 4][r.ctype] * r.depth;
  }
  function c(r, i, n, s, p) {
    let C = t(i);
    const T = Math.ceil(s * C / 8);
    let y, L;
    C = Math.ceil(C / 8);
    let P = r[n], M = 0;
    if (P > 1 && (r[n] = [0, 0, 1][P - 2]), P == 3)
      for (M = C; M < T; M++)
        r[M + 1] = r[M + 1] + (r[M + 1 - C] >>> 1) & 255;
    for (let H = 0; H < p; H++)
      if (y = n + H * T, L = y + H + 1, P = r[L - 1], M = 0, P == 0)
        for (; M < T; M++)
          r[y + M] = r[L + M];
      else if (P == 1) {
        for (; M < C; M++)
          r[y + M] = r[L + M];
        for (; M < T; M++)
          r[y + M] = r[L + M] + r[y + M - C];
      } else if (P == 2)
        for (; M < T; M++)
          r[y + M] = r[L + M] + r[y + M - T];
      else if (P == 3) {
        for (; M < C; M++)
          r[y + M] = r[L + M] + (r[y + M - T] >>> 1);
        for (; M < T; M++)
          r[y + M] = r[L + M] + (r[y + M - T] + r[y + M - C] >>> 1);
      } else {
        for (; M < C; M++)
          r[y + M] = r[L + M] + a(0, r[y + M - T], 0);
        for (; M < T; M++)
          r[y + M] = r[L + M] + a(r[y + M - C], r[y + M - T], r[y + M - C - T]);
      }
    return r;
  }
  function a(r, i, n) {
    const s = r + i - n, p = s - r, C = s - i, T = s - n;
    return p * p <= C * C && p * p <= T * T ? r : C * C <= T * T ? i : n;
  }
  function m(r, i, n) {
    n.width = l.readUint(r, i), i += 4, n.height = l.readUint(r, i), i += 4, n.depth = r[i], i++, n.ctype = r[i], i++, n.compress = r[i], i++, n.filter = r[i], i++, n.interlace = r[i], i++;
  }
  function E(r, i, n, s, p, C, T, y, L) {
    const P = Math.min(i, p), M = Math.min(n, C);
    let H = 0, v = 0;
    for (let S = 0; S < M; S++)
      for (let h = 0; h < P; h++)
        if (T >= 0 && y >= 0 ? (H = S * i + h << 2, v = (y + S) * p + T + h << 2) : (H = (-y + S) * i - T + h << 2, v = S * p + h << 2), L == 0)
          s[v] = r[H], s[v + 1] = r[H + 1], s[v + 2] = r[H + 2], s[v + 3] = r[H + 3];
        else if (L == 1) {
          var k = r[H + 3] * 0.00392156862745098, d = r[H] * k, u = r[H + 1] * k, w = r[H + 2] * k, F = s[v + 3] * (1 / 255), U = s[v] * F, I = s[v + 1] * F, A = s[v + 2] * F;
          const f = 1 - k, O = k + F * f, _ = O == 0 ? 0 : 1 / O;
          s[v + 3] = 255 * O, s[v + 0] = (d + U * f) * _, s[v + 1] = (u + I * f) * _, s[v + 2] = (w + A * f) * _;
        } else if (L == 2)
          k = r[H + 3], d = r[H], u = r[H + 1], w = r[H + 2], F = s[v + 3], U = s[v], I = s[v + 1], A = s[v + 2], k == F && d == U && u == I && w == A ? (s[v] = 0, s[v + 1] = 0, s[v + 2] = 0, s[v + 3] = 0) : (s[v] = d, s[v + 1] = u, s[v + 2] = w, s[v + 3] = k);
        else if (L == 3) {
          if (k = r[H + 3], d = r[H], u = r[H + 1], w = r[H + 2], F = s[v + 3], U = s[v], I = s[v + 1], A = s[v + 2], k == F && d == U && u == I && w == A)
            continue;
          if (k < 220 && F > 20)
            return !1;
        }
    return !0;
  }
  return { decode: function(i) {
    const n = new Uint8Array(i);
    let s = 8;
    const p = l, C = p.readUshort, T = p.readUint, y = { tabs: {}, frames: [] }, L = new Uint8Array(n.length);
    let P, M = 0, H = 0;
    const v = [137, 80, 78, 71, 13, 10, 26, 10];
    for (var k = 0; k < 8; k++)
      if (n[k] != v[k])
        throw "The input is not a PNG file!";
    for (; s < n.length; ) {
      const S = p.readUint(n, s);
      s += 4;
      const h = p.readASCII(n, s, 4);
      if (s += 4, h == "IHDR")
        m(n, s, y);
      else if (h == "iCCP") {
        for (var d = s; n[d] != 0; )
          d++;
        p.readASCII(n, s, d - s), n[d + 1];
        const f = n.slice(d + 2, s + S);
        let O = null;
        try {
          O = o(f);
        } catch {
          O = e(f);
        }
        y.tabs[h] = O;
      } else if (h == "CgBI")
        y.tabs[h] = n.slice(s, s + 4);
      else if (h == "IDAT") {
        for (k = 0; k < S; k++)
          L[M + k] = n[s + k];
        M += S;
      } else if (h == "acTL")
        y.tabs[h] = { num_frames: T(n, s), num_plays: T(n, s + 4) }, P = new Uint8Array(n.length);
      else if (h == "fcTL") {
        H != 0 && ((A = y.frames[y.frames.length - 1]).data = b(y, P.slice(0, H), A.rect.width, A.rect.height), H = 0);
        const f = { x: T(n, s + 12), y: T(n, s + 16), width: T(n, s + 4), height: T(n, s + 8) };
        let O = C(n, s + 22);
        O = C(n, s + 20) / (O == 0 ? 100 : O);
        const _ = { rect: f, delay: Math.round(1e3 * O), dispose: n[s + 24], blend: n[s + 25] };
        y.frames.push(_);
      } else if (h == "fdAT") {
        for (k = 0; k < S - 4; k++)
          P[H + k] = n[s + k + 4];
        H += S - 4;
      } else if (h == "pHYs")
        y.tabs[h] = [p.readUint(n, s), p.readUint(n, s + 4), n[s + 8]];
      else if (h == "cHRM")
        for (y.tabs[h] = [], k = 0; k < 8; k++)
          y.tabs[h].push(p.readUint(n, s + 4 * k));
      else if (h == "tEXt" || h == "zTXt") {
        y.tabs[h] == null && (y.tabs[h] = {});
        var u = p.nextZero(n, s), w = p.readASCII(n, s, u - s), F = s + S - u - 1;
        if (h == "tEXt")
          I = p.readASCII(n, u + 1, F);
        else {
          var U = o(n.slice(u + 2, u + 2 + F));
          I = p.readUTF8(U, 0, U.length);
        }
        y.tabs[h][w] = I;
      } else if (h == "iTXt") {
        y.tabs[h] == null && (y.tabs[h] = {}), u = 0, d = s, u = p.nextZero(n, d), w = p.readASCII(n, d, u - d);
        const f = n[d = u + 1];
        var I;
        n[d + 1], d += 2, u = p.nextZero(n, d), p.readASCII(n, d, u - d), d = u + 1, u = p.nextZero(n, d), p.readUTF8(n, d, u - d), F = S - ((d = u + 1) - s), f == 0 ? I = p.readUTF8(n, d, F) : (U = o(n.slice(d, d + F)), I = p.readUTF8(U, 0, U.length)), y.tabs[h][w] = I;
      } else if (h == "PLTE")
        y.tabs[h] = p.readBytes(n, s, S);
      else if (h == "hIST") {
        const f = y.tabs.PLTE.length / 3;
        for (y.tabs[h] = [], k = 0; k < f; k++)
          y.tabs[h].push(C(n, s + 2 * k));
      } else if (h == "tRNS")
        y.ctype == 3 ? y.tabs[h] = p.readBytes(n, s, S) : y.ctype == 0 ? y.tabs[h] = C(n, s) : y.ctype == 2 && (y.tabs[h] = [C(n, s), C(n, s + 2), C(n, s + 4)]);
      else if (h == "gAMA")
        y.tabs[h] = p.readUint(n, s) / 1e5;
      else if (h == "sRGB")
        y.tabs[h] = n[s];
      else if (h == "bKGD")
        y.ctype == 0 || y.ctype == 4 ? y.tabs[h] = [C(n, s)] : y.ctype == 2 || y.ctype == 6 ? y.tabs[h] = [C(n, s), C(n, s + 2), C(n, s + 4)] : y.ctype == 3 && (y.tabs[h] = n[s]);
      else if (h == "IEND")
        break;
      s += S, p.readUint(n, s), s += 4;
    }
    var A;
    return H != 0 && ((A = y.frames[y.frames.length - 1]).data = b(y, P.slice(0, H), A.rect.width, A.rect.height)), y.data = b(y, L, y.width, y.height), delete y.compress, delete y.interlace, delete y.filter, y;
  }, toRGBA8: function(i) {
    const n = i.width, s = i.height;
    if (i.tabs.acTL == null)
      return [g(i.data, n, s, i).buffer];
    const p = [];
    i.frames[0].data == null && (i.frames[0].data = i.data);
    const C = n * s * 4, T = new Uint8Array(C), y = new Uint8Array(C), L = new Uint8Array(C);
    for (let M = 0; M < i.frames.length; M++) {
      const H = i.frames[M], v = H.rect.x, k = H.rect.y, d = H.rect.width, u = H.rect.height, w = g(H.data, d, u, i);
      if (M != 0)
        for (var P = 0; P < C; P++)
          L[P] = T[P];
      if (H.blend == 0 ? E(w, d, u, T, n, s, v, k, 0) : H.blend == 1 && E(w, d, u, T, n, s, v, k, 1), p.push(T.buffer.slice(0)), H.dispose != 0) {
        if (H.dispose == 1)
          E(y, d, u, T, n, s, v, k, 0);
        else if (H.dispose == 2)
          for (P = 0; P < C; P++)
            T[P] = L[P];
      }
    }
    return p;
  }, _paeth: a, _copyTile: E, _bin: l };
}();
(function() {
  const { _copyTile: l } = ge, { _bin: g } = ge, b = ge._paeth;
  var o = { table: function() {
    const d = new Uint32Array(256);
    for (let u = 0; u < 256; u++) {
      let w = u;
      for (let F = 0; F < 8; F++)
        1 & w ? w = 3988292384 ^ w >>> 1 : w >>>= 1;
      d[u] = w;
    }
    return d;
  }(), update(d, u, w, F) {
    for (let U = 0; U < F; U++)
      d = o.table[255 & (d ^ u[w + U])] ^ d >>> 8;
    return d;
  }, crc: (d, u, w) => 4294967295 ^ o.update(4294967295, d, u, w) };
  function e(d, u, w, F) {
    u[w] += d[0] * F >> 4, u[w + 1] += d[1] * F >> 4, u[w + 2] += d[2] * F >> 4, u[w + 3] += d[3] * F >> 4;
  }
  function t(d) {
    return Math.max(0, Math.min(255, d));
  }
  function c(d, u) {
    const w = d[0] - u[0], F = d[1] - u[1], U = d[2] - u[2], I = d[3] - u[3];
    return w * w + F * F + U * U + I * I;
  }
  function a(d, u, w, F, U, I, A) {
    A == null && (A = 1);
    const S = F.length, h = [];
    for (var f = 0; f < S; f++) {
      const R = F[f];
      h.push([R >>> 0 & 255, R >>> 8 & 255, R >>> 16 & 255, R >>> 24 & 255]);
    }
    for (f = 0; f < S; f++) {
      let R = 4294967295;
      for (var O = 0, _ = 0; _ < S; _++) {
        var x = c(h[f], h[_]);
        _ != f && x < R && (R = x, O = _);
      }
    }
    const N = new Uint32Array(U.buffer), B = new Int16Array(u * w * 4), Q = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    for (f = 0; f < Q.length; f++)
      Q[f] = 255 * ((Q[f] + 0.5) / 16 - 0.5);
    for (let R = 0; R < w; R++)
      for (let z = 0; z < u; z++) {
        var D;
        f = 4 * (R * u + z), A != 2 ? D = [t(d[f] + B[f]), t(d[f + 1] + B[f + 1]), t(d[f + 2] + B[f + 2]), t(d[f + 3] + B[f + 3])] : (x = Q[4 * (3 & R) + (3 & z)], D = [t(d[f] + x), t(d[f + 1] + x), t(d[f + 2] + x), t(d[f + 3] + x)]), O = 0;
        let Z = 16777215;
        for (_ = 0; _ < S; _++) {
          const q = c(D, h[_]);
          q < Z && (Z = q, O = _);
        }
        const j = h[O], W = [D[0] - j[0], D[1] - j[1], D[2] - j[2], D[3] - j[3]];
        A == 1 && (z != u - 1 && e(W, B, f + 4, 7), R != w - 1 && (z != 0 && e(W, B, f + 4 * u - 4, 3), e(W, B, f + 4 * u, 5), z != u - 1 && e(W, B, f + 4 * u + 4, 1))), I[f >> 2] = O, N[f >> 2] = F[O];
      }
  }
  function m(d, u, w, F, U) {
    U == null && (U = {});
    const { crc: I } = o, A = g.writeUint, S = g.writeUshort, h = g.writeASCII;
    let f = 8;
    const O = d.frames.length > 1;
    let _, x = !1, N = 33 + (O ? 20 : 0);
    if (U.sRGB != null && (N += 13), U.pHYs != null && (N += 21), U.iCCP != null && (_ = pako.deflate(U.iCCP), N += 21 + _.length + 4), d.ctype == 3) {
      for (var B = d.plte.length, Q = 0; Q < B; Q++)
        d.plte[Q] >>> 24 != 255 && (x = !0);
      N += 8 + 3 * B + 4 + (x ? 8 + 1 * B + 4 : 0);
    }
    for (var D = 0; D < d.frames.length; D++)
      O && (N += 38), N += (j = d.frames[D]).cimg.length + 12, D != 0 && (N += 4);
    N += 12;
    const R = new Uint8Array(N), z = [137, 80, 78, 71, 13, 10, 26, 10];
    for (Q = 0; Q < 8; Q++)
      R[Q] = z[Q];
    if (A(R, f, 13), f += 4, h(R, f, "IHDR"), f += 4, A(R, f, u), f += 4, A(R, f, w), f += 4, R[f] = d.depth, f++, R[f] = d.ctype, f++, R[f] = 0, f++, R[f] = 0, f++, R[f] = 0, f++, A(R, f, I(R, f - 17, 17)), f += 4, U.sRGB != null && (A(R, f, 1), f += 4, h(R, f, "sRGB"), f += 4, R[f] = U.sRGB, f++, A(R, f, I(R, f - 5, 5)), f += 4), U.iCCP != null) {
      const W = 13 + _.length;
      A(R, f, W), f += 4, h(R, f, "iCCP"), f += 4, h(R, f, "ICC profile"), f += 11, f += 2, R.set(_, f), f += _.length, A(R, f, I(R, f - (W + 4), W + 4)), f += 4;
    }
    if (U.pHYs != null && (A(R, f, 9), f += 4, h(R, f, "pHYs"), f += 4, A(R, f, U.pHYs[0]), f += 4, A(R, f, U.pHYs[1]), f += 4, R[f] = U.pHYs[2], f++, A(R, f, I(R, f - 13, 13)), f += 4), O && (A(R, f, 8), f += 4, h(R, f, "acTL"), f += 4, A(R, f, d.frames.length), f += 4, A(R, f, U.loop != null ? U.loop : 0), f += 4, A(R, f, I(R, f - 12, 12)), f += 4), d.ctype == 3) {
      for (A(R, f, 3 * (B = d.plte.length)), f += 4, h(R, f, "PLTE"), f += 4, Q = 0; Q < B; Q++) {
        const W = 3 * Q, q = d.plte[Q], J = 255 & q, ne = q >>> 8 & 255, Ce = q >>> 16 & 255;
        R[f + W + 0] = J, R[f + W + 1] = ne, R[f + W + 2] = Ce;
      }
      if (f += 3 * B, A(R, f, I(R, f - 3 * B - 4, 3 * B + 4)), f += 4, x) {
        for (A(R, f, B), f += 4, h(R, f, "tRNS"), f += 4, Q = 0; Q < B; Q++)
          R[f + Q] = d.plte[Q] >>> 24 & 255;
        f += B, A(R, f, I(R, f - B - 4, B + 4)), f += 4;
      }
    }
    let Z = 0;
    for (D = 0; D < d.frames.length; D++) {
      var j = d.frames[D];
      O && (A(R, f, 26), f += 4, h(R, f, "fcTL"), f += 4, A(R, f, Z++), f += 4, A(R, f, j.rect.width), f += 4, A(R, f, j.rect.height), f += 4, A(R, f, j.rect.x), f += 4, A(R, f, j.rect.y), f += 4, S(R, f, F[D]), f += 2, S(R, f, 1e3), f += 2, R[f] = j.dispose, f++, R[f] = j.blend, f++, A(R, f, I(R, f - 30, 30)), f += 4);
      const W = j.cimg;
      A(R, f, (B = W.length) + (D == 0 ? 0 : 4)), f += 4;
      const q = f;
      h(R, f, D == 0 ? "IDAT" : "fdAT"), f += 4, D != 0 && (A(R, f, Z++), f += 4), R.set(W, f), f += B, A(R, f, I(R, q, f - q)), f += 4;
    }
    return A(R, f, 0), f += 4, h(R, f, "IEND"), f += 4, A(R, f, I(R, f - 4, 4)), f += 4, R.buffer;
  }
  function E(d, u, w) {
    for (let F = 0; F < d.frames.length; F++) {
      const U = d.frames[F];
      U.rect.width;
      const I = U.rect.height, A = new Uint8Array(I * U.bpl + I);
      U.cimg = s(U.img, I, U.bpp, U.bpl, A, u, w);
    }
  }
  function r(d, u, w, F, U) {
    const I = U[0], A = U[1], S = U[2], h = U[3], f = U[4], O = U[5];
    let _ = 6, x = 8, N = 255;
    for (var B = 0; B < d.length; B++) {
      const ie = new Uint8Array(d[B]);
      for (var Q = ie.length, D = 0; D < Q; D += 4)
        N &= ie[D + 3];
    }
    const R = N != 255, z = function(Y, G, re, se, V, le) {
      const ee = [];
      for (var K = 0; K < Y.length; K++) {
        const fe = new Uint8Array(Y[K]), he = new Uint32Array(fe.buffer);
        var ue;
        let de = 0, Ae = 0, me = G, Se = re, Ge = se ? 1 : 0;
        if (K != 0) {
          const xt = le || se || K == 1 || ee[K - 2].dispose != 0 ? 1 : 2;
          let Ke = 0, rt = 1e9;
          for (let Oe = 0; Oe < xt; Oe++) {
            var ye = new Uint8Array(Y[K - 1 - Oe]);
            const Pt = new Uint32Array(Y[K - 1 - Oe]);
            let Ue = G, Ee = re, Pe = -1, Le = -1;
            for (let _e = 0; _e < re; _e++)
              for (let Me = 0; Me < G; Me++)
                he[oe = _e * G + Me] != Pt[oe] && (Me < Ue && (Ue = Me), Me > Pe && (Pe = Me), _e < Ee && (Ee = _e), _e > Le && (Le = _e));
            Pe == -1 && (Ue = Ee = Pe = Le = 0), V && ((1 & Ue) == 1 && Ue--, (1 & Ee) == 1 && Ee--);
            const it = (Pe - Ue + 1) * (Le - Ee + 1);
            it < rt && (rt = it, Ke = Oe, de = Ue, Ae = Ee, me = Pe - Ue + 1, Se = Le - Ee + 1);
          }
          ye = new Uint8Array(Y[K - 1 - Ke]), Ke == 1 && (ee[K - 1].dispose = 2), ue = new Uint8Array(me * Se * 4), l(ye, G, re, ue, me, Se, -de, -Ae, 0), Ge = l(fe, G, re, ue, me, Se, -de, -Ae, 3) ? 1 : 0, Ge == 1 ? n(fe, G, re, ue, { x: de, y: Ae, width: me, height: Se }) : l(fe, G, re, ue, me, Se, -de, -Ae, 0);
        } else
          ue = fe.slice(0);
        ee.push({ rect: { x: de, y: Ae, width: me, height: Se }, img: ue, blend: Ge, dispose: 0 });
      }
      if (se)
        for (K = 0; K < ee.length; K++) {
          if ((Ie = ee[K]).blend == 1)
            continue;
          const fe = Ie.rect, he = ee[K - 1].rect, de = Math.min(fe.x, he.x), Ae = Math.min(fe.y, he.y), me = { x: de, y: Ae, width: Math.max(fe.x + fe.width, he.x + he.width) - de, height: Math.max(fe.y + fe.height, he.y + he.height) - Ae };
          ee[K - 1].dispose = 1, K - 1 != 0 && i(Y, G, re, ee, K - 1, me, V), i(Y, G, re, ee, K, me, V);
        }
      let De = 0;
      if (Y.length != 1)
        for (var oe = 0; oe < ee.length; oe++) {
          var Ie;
          De += (Ie = ee[oe]).rect.width * Ie.rect.height;
        }
      return ee;
    }(d, u, w, I, A, S), Z = {}, j = [], W = [];
    if (F != 0) {
      const ie = [];
      for (D = 0; D < z.length; D++)
        ie.push(z[D].img.buffer);
      const Y = function(V) {
        let le = 0;
        for (var ee = 0; ee < V.length; ee++)
          le += V[ee].byteLength;
        const K = new Uint8Array(le);
        let ue = 0;
        for (ee = 0; ee < V.length; ee++) {
          const ye = new Uint8Array(V[ee]), De = ye.length;
          for (let oe = 0; oe < De; oe += 4) {
            let Ie = ye[oe], fe = ye[oe + 1], he = ye[oe + 2];
            const de = ye[oe + 3];
            de == 0 && (Ie = fe = he = 0), K[ue + oe] = Ie, K[ue + oe + 1] = fe, K[ue + oe + 2] = he, K[ue + oe + 3] = de;
          }
          ue += De;
        }
        return K.buffer;
      }(ie), G = C(Y, F);
      for (D = 0; D < G.plte.length; D++)
        j.push(G.plte[D].est.rgba);
      let re = 0;
      for (D = 0; D < z.length; D++) {
        const se = (J = z[D]).img.length;
        var q = new Uint8Array(G.inds.buffer, re >> 2, se >> 2);
        W.push(q);
        const V = new Uint8Array(G.abuf, re, se);
        O && a(J.img, J.rect.width, J.rect.height, j, V, q), J.img.set(V), re += se;
      }
    } else
      for (B = 0; B < z.length; B++) {
        var J = z[B];
        const ie = new Uint32Array(J.img.buffer);
        var ne = J.rect.width;
        for (Q = ie.length, q = new Uint8Array(Q), W.push(q), D = 0; D < Q; D++) {
          const Y = ie[D];
          if (D != 0 && Y == ie[D - 1])
            q[D] = q[D - 1];
          else if (D > ne && Y == ie[D - ne])
            q[D] = q[D - ne];
          else {
            let G = Z[Y];
            if (G == null && (Z[Y] = G = j.length, j.push(Y), j.length >= 300))
              break;
            q[D] = G;
          }
        }
      }
    const Ce = j.length;
    for (Ce <= 256 && f == 0 && (x = Ce <= 2 ? 1 : Ce <= 4 ? 2 : Ce <= 16 ? 4 : 8, x = Math.max(x, h)), B = 0; B < z.length; B++) {
      (J = z[B]).rect.x, J.rect.y, ne = J.rect.width;
      const ie = J.rect.height;
      let Y = J.img;
      new Uint32Array(Y.buffer);
      let G = 4 * ne, re = 4;
      if (Ce <= 256 && f == 0) {
        G = Math.ceil(x * ne / 8);
        var pe = new Uint8Array(G * ie);
        const se = W[B];
        for (let V = 0; V < ie; V++) {
          D = V * G;
          const le = V * ne;
          if (x == 8)
            for (var X = 0; X < ne; X++)
              pe[D + X] = se[le + X];
          else if (x == 4)
            for (X = 0; X < ne; X++)
              pe[D + (X >> 1)] |= se[le + X] << 4 - 4 * (1 & X);
          else if (x == 2)
            for (X = 0; X < ne; X++)
              pe[D + (X >> 2)] |= se[le + X] << 6 - 2 * (3 & X);
          else if (x == 1)
            for (X = 0; X < ne; X++)
              pe[D + (X >> 3)] |= se[le + X] << 7 - 1 * (7 & X);
        }
        Y = pe, _ = 3, re = 1;
      } else if (R == 0 && z.length == 1) {
        pe = new Uint8Array(ne * ie * 3);
        const se = ne * ie;
        for (D = 0; D < se; D++) {
          const V = 3 * D, le = 4 * D;
          pe[V] = Y[le], pe[V + 1] = Y[le + 1], pe[V + 2] = Y[le + 2];
        }
        Y = pe, _ = 2, re = 3, G = 3 * ne;
      }
      J.img = Y, J.bpl = G, J.bpp = re;
    }
    return { ctype: _, depth: x, plte: j, frames: z };
  }
  function i(d, u, w, F, U, I, A) {
    const S = Uint8Array, h = Uint32Array, f = new S(d[U - 1]), O = new h(d[U - 1]), _ = U + 1 < d.length ? new S(d[U + 1]) : null, x = new S(d[U]), N = new h(x.buffer);
    let B = u, Q = w, D = -1, R = -1;
    for (let Z = 0; Z < I.height; Z++)
      for (let j = 0; j < I.width; j++) {
        const W = I.x + j, q = I.y + Z, J = q * u + W, ne = N[J];
        ne == 0 || F[U - 1].dispose == 0 && O[J] == ne && (_ == null || _[4 * J + 3] != 0) || (W < B && (B = W), W > D && (D = W), q < Q && (Q = q), q > R && (R = q));
      }
    D == -1 && (B = Q = D = R = 0), A && ((1 & B) == 1 && B--, (1 & Q) == 1 && Q--), I = { x: B, y: Q, width: D - B + 1, height: R - Q + 1 };
    const z = F[U];
    z.rect = I, z.blend = 1, z.img = new Uint8Array(I.width * I.height * 4), F[U - 1].dispose == 0 ? (l(f, u, w, z.img, I.width, I.height, -I.x, -I.y, 0), n(x, u, w, z.img, I)) : l(x, u, w, z.img, I.width, I.height, -I.x, -I.y, 0);
  }
  function n(d, u, w, F, U) {
    l(d, u, w, F, U.width, U.height, -U.x, -U.y, 2);
  }
  function s(d, u, w, F, U, I, A) {
    const S = [];
    let h, f = [0, 1, 2, 3, 4];
    I != -1 ? f = [I] : (u * F > 5e5 || w == 1) && (f = [0]), A && (h = { level: 0 });
    const O = jt;
    for (var _ = 0; _ < f.length; _++) {
      for (let B = 0; B < u; B++)
        p(U, d, B, F, w, f[_]);
      S.push(O.deflate(U, h));
    }
    let x, N = 1e9;
    for (_ = 0; _ < S.length; _++)
      S[_].length < N && (x = _, N = S[_].length);
    return S[x];
  }
  function p(d, u, w, F, U, I) {
    const A = w * F;
    let S = A + w;
    if (d[S] = I, S++, I == 0)
      if (F < 500)
        for (var h = 0; h < F; h++)
          d[S + h] = u[A + h];
      else
        d.set(new Uint8Array(u.buffer, A, F), S);
    else if (I == 1) {
      for (h = 0; h < U; h++)
        d[S + h] = u[A + h];
      for (h = U; h < F; h++)
        d[S + h] = u[A + h] - u[A + h - U] + 256 & 255;
    } else if (w == 0) {
      for (h = 0; h < U; h++)
        d[S + h] = u[A + h];
      if (I == 2)
        for (h = U; h < F; h++)
          d[S + h] = u[A + h];
      if (I == 3)
        for (h = U; h < F; h++)
          d[S + h] = u[A + h] - (u[A + h - U] >> 1) + 256 & 255;
      if (I == 4)
        for (h = U; h < F; h++)
          d[S + h] = u[A + h] - b(u[A + h - U], 0, 0) + 256 & 255;
    } else {
      if (I == 2)
        for (h = 0; h < F; h++)
          d[S + h] = u[A + h] + 256 - u[A + h - F] & 255;
      if (I == 3) {
        for (h = 0; h < U; h++)
          d[S + h] = u[A + h] + 256 - (u[A + h - F] >> 1) & 255;
        for (h = U; h < F; h++)
          d[S + h] = u[A + h] + 256 - (u[A + h - F] + u[A + h - U] >> 1) & 255;
      }
      if (I == 4) {
        for (h = 0; h < U; h++)
          d[S + h] = u[A + h] + 256 - b(0, u[A + h - F], 0) & 255;
        for (h = U; h < F; h++)
          d[S + h] = u[A + h] + 256 - b(u[A + h - U], u[A + h - F], u[A + h - U - F]) & 255;
      }
    }
  }
  function C(d, u) {
    const w = new Uint8Array(d), F = w.slice(0), U = new Uint32Array(F.buffer), I = T(F, u), A = I[0], S = I[1], h = w.length, f = new Uint8Array(h >> 2);
    let O;
    if (w.length < 2e7)
      for (var _ = 0; _ < h; _ += 4)
        O = y(A, x = w[_] * (1 / 255), N = w[_ + 1] * (1 / 255), B = w[_ + 2] * (1 / 255), Q = w[_ + 3] * (1 / 255)), f[_ >> 2] = O.ind, U[_ >> 2] = O.est.rgba;
    else
      for (_ = 0; _ < h; _ += 4) {
        var x = w[_] * 0.00392156862745098, N = w[_ + 1] * (1 / 255), B = w[_ + 2] * (1 / 255), Q = w[_ + 3] * (1 / 255);
        for (O = A; O.left; )
          O = L(O.est, x, N, B, Q) <= 0 ? O.left : O.right;
        f[_ >> 2] = O.ind, U[_ >> 2] = O.est.rgba;
      }
    return { abuf: F.buffer, inds: f, plte: S };
  }
  function T(d, u, w) {
    w == null && (w = 1e-4);
    const F = new Uint32Array(d.buffer), U = { i0: 0, i1: d.length, bst: null, est: null, tdst: 0, left: null, right: null };
    U.bst = H(d, U.i0, U.i1), U.est = v(U.bst);
    const I = [U];
    for (; I.length < u; ) {
      let S = 0, h = 0;
      for (var A = 0; A < I.length; A++)
        I[A].est.L > S && (S = I[A].est.L, h = A);
      if (S < w)
        break;
      const f = I[h], O = P(d, F, f.i0, f.i1, f.est.e, f.est.eMq255);
      if (f.i0 >= O || f.i1 <= O) {
        f.est.L = 0;
        continue;
      }
      const _ = { i0: f.i0, i1: O, bst: null, est: null, tdst: 0, left: null, right: null };
      _.bst = H(d, _.i0, _.i1), _.est = v(_.bst);
      const x = { i0: O, i1: f.i1, bst: null, est: null, tdst: 0, left: null, right: null };
      for (x.bst = { R: [], m: [], N: f.bst.N - _.bst.N }, A = 0; A < 16; A++)
        x.bst.R[A] = f.bst.R[A] - _.bst.R[A];
      for (A = 0; A < 4; A++)
        x.bst.m[A] = f.bst.m[A] - _.bst.m[A];
      x.est = v(x.bst), f.left = _, f.right = x, I[h] = _, I.push(x);
    }
    for (I.sort((S, h) => h.bst.N - S.bst.N), A = 0; A < I.length; A++)
      I[A].ind = A;
    return [U, I];
  }
  function y(d, u, w, F, U) {
    if (d.left == null)
      return d.tdst = function(_, x, N, B, Q) {
        const D = x - _[0], R = N - _[1], z = B - _[2], Z = Q - _[3];
        return D * D + R * R + z * z + Z * Z;
      }(d.est.q, u, w, F, U), d;
    const I = L(d.est, u, w, F, U);
    let A = d.left, S = d.right;
    I > 0 && (A = d.right, S = d.left);
    const h = y(A, u, w, F, U);
    if (h.tdst <= I * I)
      return h;
    const f = y(S, u, w, F, U);
    return f.tdst < h.tdst ? f : h;
  }
  function L(d, u, w, F, U) {
    const { e: I } = d;
    return I[0] * u + I[1] * w + I[2] * F + I[3] * U - d.eMq;
  }
  function P(d, u, w, F, U, I) {
    for (F -= 4; w < F; ) {
      for (; M(d, w, U) <= I; )
        w += 4;
      for (; M(d, F, U) > I; )
        F -= 4;
      if (w >= F)
        break;
      const A = u[w >> 2];
      u[w >> 2] = u[F >> 2], u[F >> 2] = A, w += 4, F -= 4;
    }
    for (; M(d, w, U) > I; )
      w -= 4;
    return w + 4;
  }
  function M(d, u, w) {
    return d[u] * w[0] + d[u + 1] * w[1] + d[u + 2] * w[2] + d[u + 3] * w[3];
  }
  function H(d, u, w) {
    const F = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], U = [0, 0, 0, 0], I = w - u >> 2;
    for (let A = u; A < w; A += 4) {
      const S = d[A] * 0.00392156862745098, h = d[A + 1] * (1 / 255), f = d[A + 2] * (1 / 255), O = d[A + 3] * (1 / 255);
      U[0] += S, U[1] += h, U[2] += f, U[3] += O, F[0] += S * S, F[1] += S * h, F[2] += S * f, F[3] += S * O, F[5] += h * h, F[6] += h * f, F[7] += h * O, F[10] += f * f, F[11] += f * O, F[15] += O * O;
    }
    return F[4] = F[1], F[8] = F[2], F[9] = F[6], F[12] = F[3], F[13] = F[7], F[14] = F[11], { R: F, m: U, N: I };
  }
  function v(d) {
    const { R: u } = d, { m: w } = d, { N: F } = d, U = w[0], I = w[1], A = w[2], S = w[3], h = F == 0 ? 0 : 1 / F, f = [u[0] - U * U * h, u[1] - U * I * h, u[2] - U * A * h, u[3] - U * S * h, u[4] - I * U * h, u[5] - I * I * h, u[6] - I * A * h, u[7] - I * S * h, u[8] - A * U * h, u[9] - A * I * h, u[10] - A * A * h, u[11] - A * S * h, u[12] - S * U * h, u[13] - S * I * h, u[14] - S * A * h, u[15] - S * S * h], O = f, _ = k;
    let x = [Math.random(), Math.random(), Math.random(), Math.random()], N = 0, B = 0;
    if (F != 0)
      for (let D = 0; D < 16 && (x = _.multVec(O, x), B = Math.sqrt(_.dot(x, x)), x = _.sml(1 / B, x), !(D != 0 && Math.abs(B - N) < 1e-9)); D++)
        N = B;
    const Q = [U * h, I * h, A * h, S * h];
    return { Cov: f, q: Q, e: x, L: N, eMq255: _.dot(_.sml(255, Q), x), eMq: _.dot(x, Q), rgba: (Math.round(255 * Q[3]) << 24 | Math.round(255 * Q[2]) << 16 | Math.round(255 * Q[1]) << 8 | Math.round(255 * Q[0]) << 0) >>> 0 };
  }
  var k = { multVec: (d, u) => [d[0] * u[0] + d[1] * u[1] + d[2] * u[2] + d[3] * u[3], d[4] * u[0] + d[5] * u[1] + d[6] * u[2] + d[7] * u[3], d[8] * u[0] + d[9] * u[1] + d[10] * u[2] + d[11] * u[3], d[12] * u[0] + d[13] * u[1] + d[14] * u[2] + d[15] * u[3]], dot: (d, u) => d[0] * u[0] + d[1] * u[1] + d[2] * u[2] + d[3] * u[3], sml: (d, u) => [d * u[0], d * u[1], d * u[2], d * u[3]] };
  ge.encode = function(u, w, F, U, I, A, S) {
    U == null && (U = 0), S == null && (S = !1);
    const h = r(u, w, F, U, [!1, !1, !1, 0, S, !1]);
    return E(h, -1), m(h, w, F, I, A);
  }, ge.encodeLL = function(u, w, F, U, I, A, S, h) {
    const f = { ctype: 0 + (U == 1 ? 0 : 2) + (I == 0 ? 0 : 4), depth: A, frames: [] }, O = (U + I) * A, _ = O * w;
    for (let x = 0; x < u.length; x++)
      f.frames.push({ rect: { x: 0, y: 0, width: w, height: F }, img: new Uint8Array(u[x]), blend: 0, dispose: 1, bpp: Math.ceil(O / 8), bpl: Math.ceil(_ / 8) });
    return E(f, 0, !0), m(f, w, F, S, h);
  }, ge.encode.compress = r, ge.encode.dither = a, ge.quantize = C, ge.quantize.getKDtree = T, ge.quantize.getNearest = y;
})();
const vt = { toArrayBuffer(l, g) {
  const b = l.width, o = l.height, e = b << 2, t = l.getContext("2d").getImageData(0, 0, b, o), c = new Uint32Array(t.data.buffer), a = (32 * b + 31) / 32 << 2, m = a * o, E = 122 + m, r = new ArrayBuffer(E), i = new DataView(r), n = 1 << 20;
  let s, p, C, T, y = n, L = 0, P = 0, M = 0;
  function H(d) {
    i.setUint16(P, d, !0), P += 2;
  }
  function v(d) {
    i.setUint32(P, d, !0), P += 4;
  }
  function k(d) {
    P += d;
  }
  H(19778), v(E), k(4), v(122), v(108), v(b), v(-o >>> 0), H(1), H(32), v(3), v(m), v(2835), v(2835), k(8), v(16711680), v(65280), v(255), v(4278190080), v(1466527264), function d() {
    for (; L < o && y > 0; ) {
      for (T = 122 + L * a, s = 0; s < e; )
        y--, p = c[M++], C = p >>> 24, i.setUint32(T + s, p << 8 | C), s += 4;
      L++;
    }
    M < c.length ? (y = n, setTimeout(d, vt._dly)) : g(r);
  }();
}, toBlob(l, g) {
  this.toArrayBuffer(l, (b) => {
    g(new Blob([b], { type: "image/bmp" }));
  });
}, _dly: 9 };
var ce = { CHROME: "CHROME", FIREFOX: "FIREFOX", DESKTOP_SAFARI: "DESKTOP_SAFARI", IE: "IE", IOS: "IOS", ETC: "ETC" }, qt = { [ce.CHROME]: 16384, [ce.FIREFOX]: 11180, [ce.DESKTOP_SAFARI]: 16384, [ce.IE]: 8192, [ce.IOS]: 4096, [ce.ETC]: 8192 };
const Ve = typeof window < "u", bt = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope, $e = Ve && window.cordova && window.cordova.require && window.cordova.require("cordova/modulemapper"), Gt = (Ve || bt) && ($e && $e.getOriginalSymbol(window, "File") || typeof File < "u" && File), At = (Ve || bt) && ($e && $e.getOriginalSymbol(window, "FileReader") || typeof FileReader < "u" && FileReader);
function et(l, g, b = Date.now()) {
  return new Promise((o) => {
    const e = l.split(","), t = e[0].match(/:(.*?);/)[1], c = globalThis.atob(e[1]);
    let a = c.length;
    const m = new Uint8Array(a);
    for (; a--; )
      m[a] = c.charCodeAt(a);
    const E = new Blob([m], { type: t });
    E.name = g, E.lastModified = b, o(E);
  });
}
function wt(l) {
  return new Promise((g, b) => {
    const o = new At();
    o.onload = () => g(o.result), o.onerror = (e) => b(e), o.readAsDataURL(l);
  });
}
function yt(l) {
  return new Promise((g, b) => {
    const o = new Image();
    o.onload = () => g(o), o.onerror = (e) => b(e), o.src = l;
  });
}
function Re() {
  if (Re.cachedResult !== void 0)
    return Re.cachedResult;
  let l = ce.ETC;
  const { userAgent: g } = navigator;
  return /Chrom(e|ium)/i.test(g) ? l = ce.CHROME : /iP(ad|od|hone)/i.test(g) && /WebKit/i.test(g) ? l = ce.IOS : /Safari/i.test(g) ? l = ce.DESKTOP_SAFARI : /Firefox/i.test(g) ? l = ce.FIREFOX : (/MSIE/i.test(g) || !!document.documentMode) && (l = ce.IE), Re.cachedResult = l, Re.cachedResult;
}
function Ut(l, g) {
  const b = Re(), o = qt[b];
  let e = l, t = g, c = e * t;
  const a = e > t ? t / e : e / t;
  for (; c > o * o; ) {
    const m = (o + e) / 2, E = (o + t) / 2;
    m < E ? (t = E, e = E * a) : (t = m * a, e = m), c = e * t;
  }
  return { width: e, height: t };
}
function qe(l, g) {
  let b, o;
  try {
    if (b = new OffscreenCanvas(l, g), o = b.getContext("2d"), o === null)
      throw new Error("getContext of OffscreenCanvas returns null");
  } catch {
    b = document.createElement("canvas"), o = b.getContext("2d");
  }
  return b.width = l, b.height = g, [b, o];
}
function Et(l, g) {
  const { width: b, height: o } = Ut(l.width, l.height), [e, t] = qe(b, o);
  return g && /jpe?g/.test(g) && (t.fillStyle = "white", t.fillRect(0, 0, e.width, e.height)), t.drawImage(l, 0, 0, e.width, e.height), e;
}
function Ne() {
  return Ne.cachedResult !== void 0 || (Ne.cachedResult = ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || navigator.userAgent.includes("Mac") && typeof document < "u" && "ontouchend" in document), Ne.cachedResult;
}
function We(l, g = {}) {
  return new Promise(function(b, o) {
    let e, t;
    var c = function() {
      try {
        return t = Et(e, g.fileType || l.type), b([e, t]);
      } catch (m) {
        return o(m);
      }
    }, a = function(m) {
      try {
        var E = function(r) {
          try {
            throw r;
          } catch (i) {
            return o(i);
          }
        };
        try {
          let r;
          return wt(l).then(function(i) {
            try {
              return r = i, yt(r).then(function(n) {
                try {
                  return e = n, function() {
                    try {
                      return c();
                    } catch (s) {
                      return o(s);
                    }
                  }();
                } catch (s) {
                  return E(s);
                }
              }, E);
            } catch (n) {
              return E(n);
            }
          }, E);
        } catch (r) {
          E(r);
        }
      } catch (r) {
        return o(r);
      }
    };
    try {
      if (Ne() || [ce.DESKTOP_SAFARI, ce.MOBILE_SAFARI].includes(Re()))
        throw new Error("Skip createImageBitmap on IOS and Safari");
      return createImageBitmap(l).then(function(m) {
        try {
          return e = m, c();
        } catch {
          return a();
        }
      }, a);
    } catch {
      a();
    }
  });
}
function je(l, g, b, o, e = 1) {
  return new Promise(function(t, c) {
    let a;
    if (g === "image/png") {
      let i, n, s;
      return i = l.getContext("2d"), { data: n } = i.getImageData(0, 0, l.width, l.height), s = ge.encode([n.buffer], l.width, l.height, 4096 * e), a = new Blob([s], { type: g }), a.name = b, a.lastModified = o, m.call(this);
    }
    {
      let i = function() {
        return m.call(this);
      };
      var E = i;
      if (g === "image/bmp")
        return new Promise((n) => vt.toBlob(l, n)).then(function(n) {
          try {
            return a = n, a.name = b, a.lastModified = o, i.call(this);
          } catch (s) {
            return c(s);
          }
        }.bind(this), c);
      {
        let n = function() {
          return i.call(this);
        };
        var r = n;
        if (typeof OffscreenCanvas == "function" && l instanceof OffscreenCanvas)
          return l.convertToBlob({ type: g, quality: e }).then(function(s) {
            try {
              return a = s, a.name = b, a.lastModified = o, n.call(this);
            } catch (p) {
              return c(p);
            }
          }.bind(this), c);
        {
          let s;
          return s = l.toDataURL(g, e), et(s, b, o).then(function(p) {
            try {
              return a = p, n.call(this);
            } catch (C) {
              return c(C);
            }
          }.bind(this), c);
        }
      }
    }
    function m() {
      return t(a);
    }
  });
}
function ve(l) {
  l.width = 0, l.height = 0;
}
function He() {
  return new Promise(function(l, g) {
    let b, o, e, t;
    return He.cachedResult !== void 0 ? l(He.cachedResult) : et("data:image/jpeg;base64,/9j/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAYAAAAAAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIAAEAAgMBEQACEQEDEQH/xABKAAEAAAAAAAAAAAAAAAAAAAALEAEAAAAAAAAAAAAAAAAAAAAAAQEAAAAAAAAAAAAAAAAAAAAAEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwA/8H//2Q==", "test.jpg", Date.now()).then(function(c) {
      try {
        return b = c, We(b).then(function(a) {
          try {
            return o = a[1], je(o, b.type, b.name, b.lastModified).then(function(m) {
              try {
                return e = m, ve(o), We(e).then(function(E) {
                  try {
                    return t = E[0], He.cachedResult = t.width === 1 && t.height === 2, l(He.cachedResult);
                  } catch (r) {
                    return g(r);
                  }
                }, g);
              } catch (E) {
                return g(E);
              }
            }, g);
          } catch (m) {
            return g(m);
          }
        }, g);
      } catch (a) {
        return g(a);
      }
    }, g);
  });
}
function Ft(l) {
  return new Promise((g, b) => {
    const o = new At();
    o.onload = (e) => {
      const t = new DataView(e.target.result);
      if (t.getUint16(0, !1) != 65496)
        return g(-2);
      const c = t.byteLength;
      let a = 2;
      for (; a < c; ) {
        if (t.getUint16(a + 2, !1) <= 8)
          return g(-1);
        const m = t.getUint16(a, !1);
        if (a += 2, m == 65505) {
          if (t.getUint32(a += 2, !1) != 1165519206)
            return g(-1);
          const E = t.getUint16(a += 6, !1) == 18761;
          a += t.getUint32(a + 4, E);
          const r = t.getUint16(a, E);
          a += 2;
          for (let i = 0; i < r; i++)
            if (t.getUint16(a + 12 * i, E) == 274)
              return g(t.getUint16(a + 12 * i + 8, E));
        } else {
          if ((65280 & m) != 65280)
            break;
          a += t.getUint16(a, !1);
        }
      }
      return g(-1);
    }, o.onerror = (e) => b(e), o.readAsArrayBuffer(l);
  });
}
function Ct(l, g) {
  const { width: b } = l, { height: o } = l, { maxWidthOrHeight: e } = g;
  let t, c = l;
  return isFinite(e) && (b > e || o > e) && ([c, t] = qe(b, o), b > o ? (c.width = e, c.height = o / b * e) : (c.width = b / o * e, c.height = e), t.drawImage(l, 0, 0, c.width, c.height), ve(l)), c;
}
function It(l, g) {
  const { width: b } = l, { height: o } = l, [e, t] = qe(b, o);
  switch (g > 4 && g < 9 ? (e.width = o, e.height = b) : (e.width = b, e.height = o), g) {
    case 2:
      t.transform(-1, 0, 0, 1, b, 0);
      break;
    case 3:
      t.transform(-1, 0, 0, -1, b, o);
      break;
    case 4:
      t.transform(1, 0, 0, -1, 0, o);
      break;
    case 5:
      t.transform(0, 1, 1, 0, 0, 0);
      break;
    case 6:
      t.transform(0, 1, -1, 0, o, 0);
      break;
    case 7:
      t.transform(0, -1, -1, 0, o, b);
      break;
    case 8:
      t.transform(0, -1, 1, 0, 0, b);
  }
  return t.drawImage(l, 0, 0, b, o), ve(l), e;
}
function at(l, g, b = 0) {
  return new Promise(function(o, e) {
    let t, c, a, m, E, r, i, n, s, p, C, T, y, L, P, M, H, v, k, d;
    function u(F = 5) {
      if (g.signal && g.signal.aborted)
        throw g.signal.reason;
      t += F, g.onProgress(Math.min(t, 100));
    }
    function w(F) {
      if (g.signal && g.signal.aborted)
        throw g.signal.reason;
      t = Math.min(Math.max(F, t), 100), g.onProgress(t);
    }
    return t = b, c = g.maxIteration || 10, a = 1024 * g.maxSizeMB * 1024, u(), We(l, g).then(function(F) {
      try {
        return [, m] = F, u(), E = Ct(m, g), u(), new Promise(function(U, I) {
          var A;
          if (!(A = g.exifOrientation))
            return Ft(l).then(function(h) {
              try {
                return A = h, S.call(this);
              } catch (f) {
                return I(f);
              }
            }.bind(this), I);
          function S() {
            return U(A);
          }
          return S.call(this);
        }).then(function(U) {
          try {
            return r = U, u(), He().then(function(I) {
              try {
                return i = I ? E : It(E, r), u(), n = g.initialQuality || 1, s = g.fileType || l.type, je(i, s, l.name, l.lastModified, n).then(function(A) {
                  try {
                    {
                      let O = function() {
                        if (c-- && (P > a || P > y)) {
                          let x, N;
                          return x = d ? 0.95 * k.width : k.width, N = d ? 0.95 * k.height : k.height, [H, v] = qe(x, N), v.drawImage(k, 0, 0, x, N), n *= s === "image/png" ? 0.85 : 0.95, je(H, s, l.name, l.lastModified, n).then(function(B) {
                            try {
                              return M = B, ve(k), k = H, P = M.size, w(Math.min(99, Math.floor((L - P) / (L - a) * 100))), O;
                            } catch (Q) {
                              return e(Q);
                            }
                          }, e);
                        }
                        return [1];
                      }, _ = function() {
                        return ve(k), ve(H), ve(E), ve(i), ve(m), w(100), o(M);
                      };
                      var h = O, f = _;
                      if (p = A, u(), C = p.size > a, T = p.size > l.size, !C && !T)
                        return w(100), o(p);
                      var S;
                      return y = l.size, L = p.size, P = L, k = i, d = !g.alwaysKeepResolution && C, (S = function(x) {
                        for (; x; ) {
                          if (x.then)
                            return void x.then(S, e);
                          try {
                            if (x.pop) {
                              if (x.length)
                                return x.pop() ? _.call(this) : x;
                              x = O;
                            } else
                              x = x.call(this);
                          } catch (N) {
                            return e(N);
                          }
                        }
                      }.bind(this))(O);
                    }
                  } catch (O) {
                    return e(O);
                  }
                }.bind(this), e);
              } catch (A) {
                return e(A);
              }
            }.bind(this), e);
          } catch (I) {
            return e(I);
          }
        }.bind(this), e);
      } catch (U) {
        return e(U);
      }
    }.bind(this), e);
  });
}
const Kt = `
let scriptImported = false
self.addEventListener('message', async (e) => {
  const { file, id, imageCompressionLibUrl, options } = e.data
  options.onProgress = (progress) => self.postMessage({ progress, id })
  try {
    if (!scriptImported) {
      // console.log('[worker] importScripts', imageCompressionLibUrl)
      self.importScripts(imageCompressionLibUrl)
      scriptImported = true
    }
    // console.log('[worker] self', self)
    const compressedFile = await imageCompression(file, options)
    self.postMessage({ file: compressedFile, id })
  } catch (e) {
    // console.error('[worker] error', e)
    self.postMessage({ error: e.message + '\\n' + e.stack, id })
  }
})
`;
let Ze;
function Zt(l, g) {
  return new Promise((b, o) => {
    Ze || (Ze = function(c) {
      const a = [];
      return typeof c == "function" ? a.push(`(${c})()`) : a.push(c), URL.createObjectURL(new Blob(a));
    }(Kt));
    const e = new Worker(Ze);
    e.addEventListener("message", function(c) {
      if (g.signal && g.signal.aborted)
        e.terminate();
      else if (c.data.progress === void 0) {
        if (c.data.error)
          return o(new Error(c.data.error)), void e.terminate();
        b(c.data.file), e.terminate();
      } else
        g.onProgress(c.data.progress);
    }), e.addEventListener("error", o), g.signal && g.signal.addEventListener("abort", () => {
      o(g.signal.reason), e.terminate();
    }), e.postMessage({ file: l, imageCompressionLibUrl: g.libURL, options: { ...g, onProgress: void 0, signal: void 0 } });
  });
}
function ae(l, g) {
  return new Promise(function(b, o) {
    let e, t, c, a, m, E;
    if (e = { ...g }, c = 0, { onProgress: a } = e, e.maxSizeMB = e.maxSizeMB || Number.POSITIVE_INFINITY, m = typeof e.useWebWorker != "boolean" || e.useWebWorker, delete e.useWebWorker, e.onProgress = (s) => {
      c = s, typeof a == "function" && a(c);
    }, !(l instanceof Blob || l instanceof Gt))
      return o(new Error("The file given is not an instance of Blob or File"));
    if (!/^image/.test(l.type))
      return o(new Error("The file given is not an image"));
    if (E = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope, !m || typeof Worker != "function" || E)
      return at(l, e).then(function(s) {
        try {
          return t = s, n.call(this);
        } catch (p) {
          return o(p);
        }
      }.bind(this), o);
    var r = function() {
      try {
        return n.call(this);
      } catch (s) {
        return o(s);
      }
    }.bind(this), i = function(s) {
      try {
        return at(l, e).then(function(p) {
          try {
            return t = p, r();
          } catch (C) {
            return o(C);
          }
        }, o);
      } catch (p) {
        return o(p);
      }
    };
    try {
      return e.libURL = e.libURL || "https://cdn.jsdelivr.net/npm/browser-image-compression@2.0.2/dist/browser-image-compression.js", Zt(l, e).then(function(s) {
        try {
          return t = s, r();
        } catch {
          return i();
        }
      }, i);
    } catch {
      i();
    }
    function n() {
      try {
        t.name = l.name, t.lastModified = l.lastModified;
      } catch {
      }
      try {
        e.preserveExif && l.type === "image/jpeg" && (!e.fileType || e.fileType && e.fileType === l.type) && (t = mt(l, t));
      } catch {
      }
      return b(t);
    }
  });
}
ae.getDataUrlFromFile = wt, ae.getFilefromDataUrl = et, ae.loadImage = yt, ae.drawImageInCanvas = Et, ae.drawFileInCanvas = We, ae.canvasToFile = je, ae.getExifOrientation = Ft, ae.handleMaxWidthOrHeight = Ct, ae.followExifOrientation = It, ae.cleanupCanvasMemory = ve, ae.isAutoOrientationInBrowser = He, ae.approximateBelowMaximumCanvasSizeOfBrowser = Ut, ae.copyExifWithoutOrientation = mt, ae.getBrowserName = Re, ae.version = "2.0.2";
const St = async (l) => {
  const g = l || tt("uploadLocation");
  try {
    (await Qe().browse(Be, g)).target === "." && await Qe().createDirectory(Be, g, {});
  } catch {
    try {
      await Qe().createDirectory(Be, g, {});
    } catch {
    }
  }
}, Yt = (l, g) => game.settings.set("chat-images", l, g), Xt = () => [
  {
    key: "uploadButton",
    options: {
      name: be("uploadButton"),
      hint: be("uploadButtonHint"),
      type: Boolean,
      default: !0,
      config: !0,
      requiresReload: !0
    }
  },
  {
    key: "uploadLocation",
    options: {
      name: be("uploadLocation"),
      hint: be("uploadLocationHint"),
      type: String,
      default: "uploaded-chat-images",
      scope: "world",
      config: !0,
      restricted: !0,
      onChange: async (l) => {
        const g = "uploaded-chat-images";
        let b = l.trim(), o = !1;
        b || (b = g, o = !0), b = b.replace(/\s+/g, "-"), l !== b && (o = !0), await St(b), o && await Yt("uploadLocation", b);
      }
    }
  }
], Jt = (l) => game.settings.register("chat-images", l.key, l.options), tt = (l) => game.settings.get("chat-images", l), Vt = ["static.wikia"], en = new DOMParser();
let we = [];
const _t = (l) => l.type && l.type.startsWith("image/"), Mt = (l) => typeof l == "string" && l.startsWith("blob:"), nt = (l) => {
  if (!!Mt(l))
    try {
      URL.revokeObjectURL(l);
    } catch {
    }
}, tn = ({ imageSrc: l, id: g }) => xe(
  `<div id="${g}" class="ci-upload-area-image">
      <i class="ci-remove-image-icon fa-regular fa-circle-xmark"></i>
      <img class="ci-image-preview" src="${String(l)}" alt="${be("unableToLoadImage")}"/>
   </div>`
), nn = (l, g, b) => {
  ke(l, "click", () => {
    const e = te(`#${g.id}`, b);
    Je(e), g.file && nt(g.imageSrc), we = we.filter((t) => g.id !== t.id), !we.length && Xe(b, "hidden");
  });
}, rn = async (l) => {
  const g = (b) => {
    const { type: o, name: e, id: t } = b, c = (e == null ? void 0 : e.substring(e.lastIndexOf("."), e.length)) || (o == null ? void 0 : o.replace("image/", ".")) || ".jpeg";
    return `${t}${c}`;
  };
  try {
    const b = g(l), o = await ae(l.file, {
      maxSizeMB: 1.5,
      useWebWorker: !0,
      alwaysKeepResolution: !0
    }), e = new File([o], b, { type: l.type }), t = tt("uploadLocation"), a = await new Qe().upload(
      Be,
      t,
      e,
      {},
      { notify: !1 }
    );
    return !a || !(a != null && a.path) ? l.imageSrc : a.path;
  } catch {
    return l.imageSrc;
  }
}, Tt = async (l, g) => {
  const b = te("#ci-chat-upload-area", g);
  if (!b || !b[0])
    return;
  if (l.file) {
    if (!pt())
      return;
    l.imageSrc = URL.createObjectURL(l.file);
  }
  const o = tn(l);
  if (!o || !o[0])
    return;
  Ot(b, "hidden"), Te(b, o), we.push(l);
  const e = te(".ci-remove-image-icon", o);
  nn(e, l, b);
}, on = (l, g) => async (b) => {
  const o = { type: l.type, name: l.name, imageSrc: "", id: gt(), file: l };
  await Tt(o, g);
}, Rt = (l, g) => {
  for (let b = 0; b < l.length; b++) {
    const o = l[b];
    !_t(o) || on(o, g)(new Event("load"));
  }
}, an = (l, g) => {
  const b = (a) => {
    const m = a.getData("text/html");
    if (!m)
      return null;
    const E = en.parseFromString(m, "text/html").querySelectorAll("img");
    if (!E || !E.length)
      return null;
    const r = [...E].map((n) => n.src);
    return r.some((n) => Vt.some((s) => n.includes(s))) ? null : r;
  }, o = async (a) => {
    for (let m = 0; m < a.length; m++) {
      const r = { imageSrc: a[m], id: gt() };
      await Tt(r, g);
    }
  }, t = ((a) => {
    const m = a.items, E = [];
    for (let r = 0; r < m.length; r++) {
      const i = m[r];
      if (!_t(i))
        continue;
      const n = i.getAsFile();
      !n || E.push(n);
    }
    return E;
  })(l);
  if (t && t.length)
    return Rt(t, g);
  const c = b(l);
  if (c && c.length)
    return void o(c);
}, sn = () => we, fn = async (l) => {
  for (let g = 0; g < we.length; g++) {
    const b = we[g];
    if (!b.file)
      continue;
    const o = b.imageSrc;
    if (!Mt(o))
      continue;
    const e = await rn(b);
    b.imageSrc = e, nt(o);
  }
}, kt = (l) => {
  for (; we.length; ) {
    const b = we.pop();
    if (!b)
      continue;
    b.file && nt(b.imageSrc);
    const o = te(`#${b.id}`, l);
    Je(o);
  }
  const g = te("#ci-chat-upload-area", l);
  Xe(g, "hidden");
}, cn = () => xe(`
    <div id="ci-chat-upload-area" class="hidden">
      <div class="ci-upload-area-images"></div>
      <i class="ci-clear-all fa-solid fa-trash"></i>
    </div>`), st = (l) => {
  const g = cn(), b = te("#chat-message", l);
  if (b && b[0])
    ot(b, g);
  else {
    const e = Fe() ? ".chat-controls" : "#chat-controls";
    let t = te(e, l);
    (!t || !t[0]) && (t = te(e)), t && t[0] && ot(t, g);
  }
  const o = te(".ci-clear-all", g);
  ke(o, "click", () => kt(l));
}, ln = () => xe(`<a id="ci-upload-image" title="${be("uploadButtonTitle")}"><i class="fas fa-images"></i></a>`), un = () => xe('<input type="file" multiple accept="image/*" id="ci-upload-image-hidden-input">'), dn = (l, g, b) => {
  const o = (t) => {
    const c = t.currentTarget, a = c.files;
    !a || (Rt(a, b), c.value = "");
  }, e = (t) => {
    t.preventDefault(), Ht(g, "click");
  };
  ke(g, "change", o), ke(l, "click", e);
}, hn = (l) => {
  if (!tt("uploadButton"))
    return;
  const g = te(".control-buttons", l), b = ln(), o = un();
  if (!!pt(!0)) {
    if (g[0])
      Xe(g, "ci-control-buttons-gm"), Te(g, b), Te(g, o);
    else {
      const e = te("#chat-controls", l), t = xe('<div class="ci-control-buttons-p"></div>');
      Te(t, b), Te(t, o), Te(e, t);
    }
    dn(b, o, l);
  }
}, ft = (l, g) => {
  if (!g) {
    Lt(l, "disabled", !0);
    return;
  }
  Dt(l, "disabled"), Bt(l);
}, ct = (l, g) => {
  const b = "ci-spinner", o = te(`#${b}`, l);
  if (!g && o[0]) {
    Je(o);
    return;
  }
  if (g && !o[0]) {
    const e = xe(`<div id="${b}"></div>`);
    Te(l, e);
  }
}, gn = (l) => {
  const g = Fe() ? ".chat-form" : "#chat-form", b = te(g, l), o = te("#chat-message", l);
  return {
    on() {
      ft(o, !1), ct(b, !0);
    },
    off() {
      ft(o, !0), ct(b, !1);
    }
  };
};
let Ye = !1;
const pn = (l) => `<div class="ci-message-image"><img src="${l.imageSrc}" alt="${l.name || be("unableToLoadImage")}"></div>`, lt = (l) => `<div class="ci-message">${l.map((b) => pn(b)).join("")}</div>`, mn = () => {
  const l = Fe() ? CONST.CHAT_MESSAGE_STYLES.OOC : CONST.CHAT_MESSAGE_TYPES.OOC;
  return typeof l < "u" ? l : 1;
}, vn = (l) => (g) => {
  const b = g.originalEvent, o = b.clipboardData || b.dataTransfer;
  !o || an(o, l);
}, bn = (l) => async (g) => {
  var e;
  if (Ye)
    return;
  const b = sn();
  if (!b.length)
    return;
  g.preventDefault(), g.stopPropagation(), Ye = !0;
  const o = gn(l);
  o.on();
  try {
    await fn(l);
    const t = te("#chat-message", l), c = t != null && t.val ? String((e = t.val()) != null ? e : "") : "", a = c ? `${lt(b)}<div class="ci-notes">${c}</div>` : lt(b);
    await ChatMessage.create({
      content: a,
      type: mn(),
      user: game.user
    }), t != null && t.val && t.val(""), kt(l);
  } finally {
    o.off(), Ye = !1;
  }
}, An = (l) => !!te("#ci-chat-upload-area", l).length, ut = (l) => {
  ke(l, "paste drop", vn(l));
  const g = Fe() ? ".chat-form" : "#chat-form", b = te(g, l);
  ke(b, "submit", bn(l));
}, dt = (l) => {
  const g = te(".ci-message-image img", l);
  if (!g[0])
    return;
  ke(g, "click", (o) => {
    const e = o.target.src, t = Nt();
    Fe() ? new t({ src: e, editable: !1, shareable: !0 }).render(!0) : new t(e, { editable: !1, shareable: !0 }).render(!0);
  });
}, ht = /!\s*ci\s*\|\s*(.+?)\s*!/gi, wn = /\w+\.(gif|png|jpg|jpeg|webp|svg|psd|bmp|tif)/gi, yn = (l) => `<div class="ci-message-image"><img src="${l}" alt="${be("unableToLoadImage")}"></div>`, Un = (l) => l.match(ht) ? l.replaceAll(ht, (g, b) => b.match(wn) ? yn(b) : g) : l, En = () => {
  Xt().forEach((g) => Jt(g));
};
Hooks.once("init", async () => {
  En(), Fn(), await St();
});
const Fn = () => {
  if (Fe()) {
    Hooks.on("renderChatMessageHTML", (g, b) => {
      const o = xe(b);
      !te(".ci-message-image", o)[0] || dt(o);
    });
    const l = (g) => {
      An(g) || (st(g), ut(g));
    };
    Hooks.on("collapseSidebar", (g, b) => {
      if (!g || b)
        return;
      const o = g.element;
      if (!o || !o.querySelector("#chat-message"))
        return;
      const t = $(o);
      l(t);
    }), Hooks.on("activateChatLog", (g) => {
      if (!g)
        return;
      const b = g.element;
      if (!b || !b.querySelector("#chat-message"))
        return;
      const e = $(b);
      l(e);
    });
  } else
    Hooks.on("renderChatMessage", (l, g) => {
      !te(".ci-message-image", g)[0] || dt(g);
    }), Hooks.on("renderSidebarTab", (l, g) => {
      const b = g[0];
      !b || !b.querySelector("#chat-message") || (st(g), hn(g), ut(g));
    });
  Hooks.on("preCreateChatMessage", (l, g, b) => {
    const o = Un(l.content);
    l.content !== o && (l.content = o, l._source.content = o, b.chatBubble = !1);
  });
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1pbWFnZXMuanMiLCJzb3VyY2VzIjpbIi4uL3NyYy9zY3JpcHRzL3V0aWxzL0pxdWVyeVdyYXBwZXJzLnRzIiwiLi4vc3JjL3NjcmlwdHMvdXRpbHMvVXRpbHMudHMiLCIuLi9ub2RlX21vZHVsZXMvYnJvd3Nlci1pbWFnZS1jb21wcmVzc2lvbi9kaXN0L2Jyb3dzZXItaW1hZ2UtY29tcHJlc3Npb24ubWpzIiwiLi4vc3JjL3NjcmlwdHMvdXRpbHMvU2V0dGluZ3MudHMiLCIuLi9zcmMvc2NyaXB0cy9wcm9jZXNzb3JzL0ZpbGVQcm9jZXNzb3IudHMiLCIuLi9zcmMvc2NyaXB0cy9jb21wb25lbnRzL1VwbG9hZEFyZWEudHMiLCIuLi9zcmMvc2NyaXB0cy9jb21wb25lbnRzL1VwbG9hZEJ1dHRvbi50cyIsIi4uL3NyYy9zY3JpcHRzL2NvbXBvbmVudHMvTG9hZGVyLnRzIiwiLi4vc3JjL3NjcmlwdHMvY29tcG9uZW50cy9DaGF0U2lkZWJhci50cyIsIi4uL3NyYy9zY3JpcHRzL2NvbXBvbmVudHMvQ2hhdE1lc3NhZ2UudHMiLCIuLi9zcmMvc2NyaXB0cy9wcm9jZXNzb3JzL01lc3NhZ2VQcm9jZXNzb3IudHMiLCIuLi9zcmMvY2hhdC1pbWFnZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHRzLWlnbm9yZVxyXG5leHBvcnQgY29uc3QgY3JlYXRlID0gKGh0bWw6IHN0cmluZyB8IEhUTUxFbGVtZW50KTogSlF1ZXJ5ID0+ICQoaHRtbClcclxuZXhwb3J0IGNvbnN0IGJlZm9yZSA9IChyZWZlcmVuY2VOb2RlOiBKUXVlcnksIG5ld05vZGU6IEpRdWVyeSk6IEpRdWVyeSA9PiByZWZlcmVuY2VOb2RlLmJlZm9yZShuZXdOb2RlKVxyXG5leHBvcnQgY29uc3QgYWZ0ZXIgPSAocmVmZXJlbmNlTm9kZTogSlF1ZXJ5LCBuZXdOb2RlOiBKUXVlcnkpOiBKUXVlcnkgPT4gcmVmZXJlbmNlTm9kZS5hZnRlcihuZXdOb2RlKVxyXG5leHBvcnQgY29uc3QgZmluZCA9IChzZWxlY3Rvcjogc3RyaW5nLCBwYXJlbnROb2RlPzogSlF1ZXJ5KTogSlF1ZXJ5ID0+IHBhcmVudE5vZGUgPyBwYXJlbnROb2RlLmZpbmQoc2VsZWN0b3IpIDogJChzZWxlY3RvcilcclxuZXhwb3J0IGNvbnN0IGFwcGVuZCA9IChwYXJlbnROb2RlOiBKUXVlcnksIG5ld05vZGU6IEpRdWVyeSk6IEpRdWVyeSA9PiBwYXJlbnROb2RlLmFwcGVuZChuZXdOb2RlKVxyXG4vLyBAdHMtaWdub3JlXHJcbmV4cG9ydCBjb25zdCBvbiA9IChwYXJlbnROb2RlOiBKUXVlcnksIGV2ZW50VHlwZTogc3RyaW5nLCBldmVudEZ1bmN0aW9uOiBGdW5jdGlvbik6IEpRdWVyeSA9PiBwYXJlbnROb2RlLm9uKGV2ZW50VHlwZSwgZXZlbnRGdW5jdGlvbilcclxuZXhwb3J0IGNvbnN0IHRyaWdnZXIgPSAocGFyZW50Tm9kZTogSlF1ZXJ5LCBldmVudFR5cGU6IHN0cmluZyk6IEpRdWVyeSA9PiBwYXJlbnROb2RlLnRyaWdnZXIoZXZlbnRUeXBlKVxyXG5leHBvcnQgY29uc3QgcmVtb3ZlQ2xhc3MgPSAocGFyZW50Tm9kZTogSlF1ZXJ5LCBjbGFzc1N0cmluZzogc3RyaW5nKTogSlF1ZXJ5ID0+IHBhcmVudE5vZGUucmVtb3ZlQ2xhc3MoY2xhc3NTdHJpbmcpXHJcbmV4cG9ydCBjb25zdCBhZGRDbGFzcyA9IChwYXJlbnROb2RlOiBKUXVlcnksIGNsYXNzU3RyaW5nOiBzdHJpbmcpOiBKUXVlcnkgPT4gcGFyZW50Tm9kZS5hZGRDbGFzcyhjbGFzc1N0cmluZylcclxuZXhwb3J0IGNvbnN0IHJlbW92ZSA9IChub2RlOiBKUXVlcnkpOiBKUXVlcnkgPT4gbm9kZS5yZW1vdmUoKVxyXG5leHBvcnQgY29uc3QgYXR0ciA9IChub2RlOiBKUXVlcnksIGF0dHJJZDogc3RyaW5nLCBhdHRyVmFsdWU/OiBhbnkpOiBzdHJpbmcgfCBKUXVlcnkgfCB1bmRlZmluZWQgPT4gYXR0clZhbHVlID8gbm9kZS5hdHRyKGF0dHJJZCwgYXR0clZhbHVlKSA6IG5vZGUuYXR0cihhdHRySWQpXHJcbmV4cG9ydCBjb25zdCByZW1vdmVBdHRyID0gKG5vZGU6IEpRdWVyeSwgYXR0cklkOiBzdHJpbmcpOiBKUXVlcnkgPT4gbm9kZS5yZW1vdmVBdHRyKGF0dHJJZClcclxuZXhwb3J0IGNvbnN0IGZvY3VzID0gKG5vZGU6IEpRdWVyeSk6IEpRdWVyeSA9PiBub2RlLmZvY3VzKClcclxuZXhwb3J0IGNvbnN0IHNjcm9sbEJvdHRvbSA9IChub2RlOiBKUXVlcnkpOiBKUXVlcnkgPT4gbm9kZS5hbmltYXRlKHsgc2Nyb2xsVG9wOiBub2RlLmhlaWdodCgpIH0pXHJcbi8vIEB0cy1pZ25vcmVcclxuZXhwb3J0IGNvbnN0IGVhY2ggPSAobm9kZTogSlF1ZXJ5LCBoYW5kbGVyOiBGdW5jdGlvbik6IEpRdWVyeSA9PiBub2RlLmVhY2goaGFuZGxlcikiLCJleHBvcnQgY29uc3QgT1JJR0lOX0ZPTERFUiA9ICdkYXRhJ1xyXG5leHBvcnQgY29uc3QgdCA9ICh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcgPT4gKGdhbWUgYXMgR2FtZSk/LmkxOG4/LmxvY2FsaXplKGBDSS4ke3RleHR9YCkgfHwgJydcclxuZXhwb3J0IGNvbnN0IHJhbmRvbVN0cmluZyA9ICgpOiBzdHJpbmcgPT4gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDIsIDE1KSArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyLCAxNSlcclxuZXhwb3J0IGNvbnN0IHVzZXJDYW5VcGxvYWQgPSAoc2lsZW50ID0gZmFsc2UpOiBib29sZWFuID0+IHtcclxuICBjb25zdCB1c2VyUm9sZSA9IChnYW1lIGFzIEdhbWUpPy51c2VyPy5yb2xlXHJcbiAgY29uc3QgZmlsZVVwbG9hZFBlcm1pc3Npb25zID0gKGdhbWUgYXMgR2FtZSk/LnBlcm1pc3Npb25zPy5GSUxFU19VUExPQURcclxuXHJcbiAgaWYgKCF1c2VyUm9sZSB8fCAhZmlsZVVwbG9hZFBlcm1pc3Npb25zKSB7XHJcbiAgICBpZiAoIXNpbGVudCkgdWkubm90aWZpY2F0aW9ucz8ud2Fybih0KCd1cGxvYWRQZXJtaXNzaW9ucycpKVxyXG4gICAgcmV0dXJuIGZhbHNlXHJcbiAgfVxyXG5cclxuICBjb25zdCB1cGxvYWRQZXJtaXNzaW9uID0gZmlsZVVwbG9hZFBlcm1pc3Npb25zLmluY2x1ZGVzKHVzZXJSb2xlKVxyXG4gIGlmICghdXBsb2FkUGVybWlzc2lvbiAmJiAhc2lsZW50KSB1aS5ub3RpZmljYXRpb25zPy53YXJuKHQoJ3VwbG9hZFBlcm1pc3Npb25zJykpXHJcblxyXG4gIHJldHVybiB1cGxvYWRQZXJtaXNzaW9uXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBnZXRGb3VuZHJ5VmVyc2lvbiA9ICgpID0+IChnYW1lIGFzIEdhbWUpPy52ZXJzaW9uXHJcblxyXG5leHBvcnQgY29uc3QgaXNWZXJpb3NuQWZ0ZXIxMyA9ICgpID0+IE51bWJlcihnZXRGb3VuZHJ5VmVyc2lvbigpKSA+PSAxM1xyXG5cclxuZXhwb3J0IGNvbnN0IEZpbGVQaWNrZXJJbXBsZW1lbnRhdGlvbiA9ICgpID0+IGlzVmVyaW9zbkFmdGVyMTMoKVxyXG4gID8gZm91bmRyeS5hcHBsaWNhdGlvbnMuYXBwcy5GaWxlUGlja2VyLmltcGxlbWVudGF0aW9uXHJcbiAgOiBGaWxlUGlja2VyXHJcblxyXG5leHBvcnQgY29uc3QgSW1hZ2VQb3BvdXRJbXBsZW1lbnRhdGlvbiA9ICgpID0+IGlzVmVyaW9zbkFmdGVyMTMoKVxyXG4gID8gZm91bmRyeS5hcHBsaWNhdGlvbnMuYXBwcy5JbWFnZVBvcG91dFxyXG4gIDogSW1hZ2VQb3BvdXQiLCIvKipcbiAqIEJyb3dzZXIgSW1hZ2UgQ29tcHJlc3Npb25cbiAqIHYyLjAuMlxuICogYnkgRG9uYWxkIDxkb25hbGRjd2xAZ21haWwuY29tPlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RvbmFsZGN3bC9icm93c2VyLWltYWdlLWNvbXByZXNzaW9uXG4gKi9cblxuZnVuY3Rpb24gX21lcmdlTmFtZXNwYWNlcyhlLHQpe3JldHVybiB0LmZvckVhY2goKGZ1bmN0aW9uKHQpe3QmJlwic3RyaW5nXCIhPXR5cGVvZiB0JiYhQXJyYXkuaXNBcnJheSh0KSYmT2JqZWN0LmtleXModCkuZm9yRWFjaCgoZnVuY3Rpb24ocil7aWYoXCJkZWZhdWx0XCIhPT1yJiYhKHIgaW4gZSkpe3ZhciBpPU9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCxyKTtPYmplY3QuZGVmaW5lUHJvcGVydHkoZSxyLGkuZ2V0P2k6e2VudW1lcmFibGU6ITAsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIHRbcl19fSl9fSkpfSkpLE9iamVjdC5mcmVlemUoZSl9ZnVuY3Rpb24gY29weUV4aWZXaXRob3V0T3JpZW50YXRpb24oZSx0KXtyZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uKHIsaSl7bGV0IG87cmV0dXJuIGdldEFwcDFTZWdtZW50KGUpLnRoZW4oKGZ1bmN0aW9uKGUpe3RyeXtyZXR1cm4gbz1lLHIobmV3IEJsb2IoW3Quc2xpY2UoMCwyKSxvLHQuc2xpY2UoMildLHt0eXBlOlwiaW1hZ2UvanBlZ1wifSkpfWNhdGNoKGUpe3JldHVybiBpKGUpfX0pLGkpfSkpfWNvbnN0IGdldEFwcDFTZWdtZW50PWU9Pm5ldyBQcm9taXNlKCgodCxyKT0+e2NvbnN0IGk9bmV3IEZpbGVSZWFkZXI7aS5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCgoe3RhcmdldDp7cmVzdWx0OmV9fSk9Pntjb25zdCBpPW5ldyBEYXRhVmlldyhlKTtsZXQgbz0wO2lmKDY1NDk2IT09aS5nZXRVaW50MTYobykpcmV0dXJuIHIoXCJub3QgYSB2YWxpZCBKUEVHXCIpO2ZvcihvKz0yOzspe2NvbnN0IGE9aS5nZXRVaW50MTYobyk7aWYoNjU0OTg9PT1hKWJyZWFrO2NvbnN0IHM9aS5nZXRVaW50MTYobysyKTtpZig2NTUwNT09PWEmJjExNjU1MTkyMDY9PT1pLmdldFVpbnQzMihvKzQpKXtjb25zdCBhPW8rMTA7bGV0IGY7c3dpdGNoKGkuZ2V0VWludDE2KGEpKXtjYXNlIDE4NzYxOmY9ITA7YnJlYWs7Y2FzZSAxOTc4OTpmPSExO2JyZWFrO2RlZmF1bHQ6cmV0dXJuIHIoXCJUSUZGIGhlYWRlciBjb250YWlucyBpbnZhbGlkIGVuZGlhblwiKX1pZig0MiE9PWkuZ2V0VWludDE2KGErMixmKSlyZXR1cm4gcihcIlRJRkYgaGVhZGVyIGNvbnRhaW5zIGludmFsaWQgdmVyc2lvblwiKTtjb25zdCBsPWkuZ2V0VWludDMyKGErNCxmKSxjPWErbCsyKzEyKmkuZ2V0VWludDE2KGErbCxmKTtmb3IobGV0IGU9YStsKzI7ZTxjO2UrPTEyKXtpZigyNzQ9PWkuZ2V0VWludDE2KGUsZikpe2lmKDMhPT1pLmdldFVpbnQxNihlKzIsZikpcmV0dXJuIHIoXCJPcmllbnRhdGlvbiBkYXRhIHR5cGUgaXMgaW52YWxpZFwiKTtpZigxIT09aS5nZXRVaW50MzIoZSs0LGYpKXJldHVybiByKFwiT3JpZW50YXRpb24gZGF0YSBjb3VudCBpcyBpbnZhbGlkXCIpO2kuc2V0VWludDE2KGUrOCwxLGYpO2JyZWFrfX1yZXR1cm4gdChlLnNsaWNlKG8sbysyK3MpKX1vKz0yK3N9cmV0dXJuIHQobmV3IEJsb2IpfSkpLGkucmVhZEFzQXJyYXlCdWZmZXIoZSl9KSk7dmFyIGU9e30sdD17Z2V0IGV4cG9ydHMoKXtyZXR1cm4gZX0sc2V0IGV4cG9ydHModCl7ZT10fX07IWZ1bmN0aW9uKGUpe3ZhciByLGksVVpJUD17fTt0LmV4cG9ydHM9VVpJUCxVWklQLnBhcnNlPWZ1bmN0aW9uKGUsdCl7Zm9yKHZhciByPVVaSVAuYmluLnJlYWRVc2hvcnQsaT1VWklQLmJpbi5yZWFkVWludCxvPTAsYT17fSxzPW5ldyBVaW50OEFycmF5KGUpLGY9cy5sZW5ndGgtNDsxMDEwMTAyNTYhPWkocyxmKTspZi0tO289ZjtvKz00O3ZhciBsPXIocyxvKz00KTtyKHMsbys9Mik7dmFyIGM9aShzLG8rPTIpLHU9aShzLG8rPTQpO28rPTQsbz11O2Zvcih2YXIgaD0wO2g8bDtoKyspe2kocyxvKSxvKz00LG8rPTQsbys9NCxpKHMsbys9NCk7Yz1pKHMsbys9NCk7dmFyIGQ9aShzLG8rPTQpLEE9cihzLG8rPTQpLGc9cihzLG8rMikscD1yKHMsbys0KTtvKz02O3ZhciBtPWkocyxvKz04KTtvKz00LG8rPUErZytwLFVaSVAuX3JlYWRMb2NhbChzLG0sYSxjLGQsdCl9cmV0dXJuIGF9LFVaSVAuX3JlYWRMb2NhbD1mdW5jdGlvbihlLHQscixpLG8sYSl7dmFyIHM9VVpJUC5iaW4ucmVhZFVzaG9ydCxmPVVaSVAuYmluLnJlYWRVaW50O2YoZSx0KSxzKGUsdCs9NCkscyhlLHQrPTIpO3ZhciBsPXMoZSx0Kz0yKTtmKGUsdCs9MiksZihlLHQrPTQpLHQrPTQ7dmFyIGM9cyhlLHQrPTgpLHU9cyhlLHQrPTIpO3QrPTI7dmFyIGg9VVpJUC5iaW4ucmVhZFVURjgoZSx0LGMpO2lmKHQrPWMsdCs9dSxhKXJbaF09e3NpemU6byxjc2l6ZTppfTtlbHNle3ZhciBkPW5ldyBVaW50OEFycmF5KGUuYnVmZmVyLHQpO2lmKDA9PWwpcltoXT1uZXcgVWludDhBcnJheShkLmJ1ZmZlci5zbGljZSh0LHQraSkpO2Vsc2V7aWYoOCE9bCl0aHJvd1widW5rbm93biBjb21wcmVzc2lvbiBtZXRob2Q6IFwiK2w7dmFyIEE9bmV3IFVpbnQ4QXJyYXkobyk7VVpJUC5pbmZsYXRlUmF3KGQsQSkscltoXT1BfX19LFVaSVAuaW5mbGF0ZVJhdz1mdW5jdGlvbihlLHQpe3JldHVybiBVWklQLkYuaW5mbGF0ZShlLHQpfSxVWklQLmluZmxhdGU9ZnVuY3Rpb24oZSx0KXtyZXR1cm4gZVswXSxlWzFdLFVaSVAuaW5mbGF0ZVJhdyhuZXcgVWludDhBcnJheShlLmJ1ZmZlcixlLmJ5dGVPZmZzZXQrMixlLmxlbmd0aC02KSx0KX0sVVpJUC5kZWZsYXRlPWZ1bmN0aW9uKGUsdCl7bnVsbD09dCYmKHQ9e2xldmVsOjZ9KTt2YXIgcj0wLGk9bmV3IFVpbnQ4QXJyYXkoNTArTWF0aC5mbG9vcigxLjEqZS5sZW5ndGgpKTtpW3JdPTEyMCxpW3IrMV09MTU2LHIrPTIscj1VWklQLkYuZGVmbGF0ZVJhdyhlLGkscix0LmxldmVsKTt2YXIgbz1VWklQLmFkbGVyKGUsMCxlLmxlbmd0aCk7cmV0dXJuIGlbciswXT1vPj4+MjQmMjU1LGlbcisxXT1vPj4+MTYmMjU1LGlbcisyXT1vPj4+OCYyNTUsaVtyKzNdPW8+Pj4wJjI1NSxuZXcgVWludDhBcnJheShpLmJ1ZmZlciwwLHIrNCl9LFVaSVAuZGVmbGF0ZVJhdz1mdW5jdGlvbihlLHQpe251bGw9PXQmJih0PXtsZXZlbDo2fSk7dmFyIHI9bmV3IFVpbnQ4QXJyYXkoNTArTWF0aC5mbG9vcigxLjEqZS5sZW5ndGgpKSxpPVVaSVAuRi5kZWZsYXRlUmF3KGUscixpLHQubGV2ZWwpO3JldHVybiBuZXcgVWludDhBcnJheShyLmJ1ZmZlciwwLGkpfSxVWklQLmVuY29kZT1mdW5jdGlvbihlLHQpe251bGw9PXQmJih0PSExKTt2YXIgcj0wLGk9VVpJUC5iaW4ud3JpdGVVaW50LG89VVpJUC5iaW4ud3JpdGVVc2hvcnQsYT17fTtmb3IodmFyIHMgaW4gZSl7dmFyIGY9IVVaSVAuX25vTmVlZChzKSYmIXQsbD1lW3NdLGM9VVpJUC5jcmMuY3JjKGwsMCxsLmxlbmd0aCk7YVtzXT17Y3ByOmYsdXNpemU6bC5sZW5ndGgsY3JjOmMsZmlsZTpmP1VaSVAuZGVmbGF0ZVJhdyhsKTpsfX1mb3IodmFyIHMgaW4gYSlyKz1hW3NdLmZpbGUubGVuZ3RoKzMwKzQ2KzIqVVpJUC5iaW4uc2l6ZVVURjgocyk7cis9MjI7dmFyIHU9bmV3IFVpbnQ4QXJyYXkociksaD0wLGQ9W107Zm9yKHZhciBzIGluIGEpe3ZhciBBPWFbc107ZC5wdXNoKGgpLGg9VVpJUC5fd3JpdGVIZWFkZXIodSxoLHMsQSwwKX12YXIgZz0wLHA9aDtmb3IodmFyIHMgaW4gYSl7QT1hW3NdO2QucHVzaChoKSxoPVVaSVAuX3dyaXRlSGVhZGVyKHUsaCxzLEEsMSxkW2crK10pfXZhciBtPWgtcDtyZXR1cm4gaSh1LGgsMTAxMDEwMjU2KSxoKz00LG8odSxoKz00LGcpLG8odSxoKz0yLGcpLGkodSxoKz0yLG0pLGkodSxoKz00LHApLGgrPTQsaCs9Mix1LmJ1ZmZlcn0sVVpJUC5fbm9OZWVkPWZ1bmN0aW9uKGUpe3ZhciB0PWUuc3BsaXQoXCIuXCIpLnBvcCgpLnRvTG93ZXJDYXNlKCk7cmV0dXJuLTEhPVwicG5nLGpwZyxqcGVnLHppcFwiLmluZGV4T2YodCl9LFVaSVAuX3dyaXRlSGVhZGVyPWZ1bmN0aW9uKGUsdCxyLGksbyxhKXt2YXIgcz1VWklQLmJpbi53cml0ZVVpbnQsZj1VWklQLmJpbi53cml0ZVVzaG9ydCxsPWkuZmlsZTtyZXR1cm4gcyhlLHQsMD09bz82NzMyNDc1MjozMzYzOTI0OCksdCs9NCwxPT1vJiYodCs9MiksZihlLHQsMjApLGYoZSx0Kz0yLDApLGYoZSx0Kz0yLGkuY3ByPzg6MCkscyhlLHQrPTIsMCkscyhlLHQrPTQsaS5jcmMpLHMoZSx0Kz00LGwubGVuZ3RoKSxzKGUsdCs9NCxpLnVzaXplKSxmKGUsdCs9NCxVWklQLmJpbi5zaXplVVRGOChyKSksZihlLHQrPTIsMCksdCs9MiwxPT1vJiYodCs9Mix0Kz0yLHMoZSx0Kz02LGEpLHQrPTQpLHQrPVVaSVAuYmluLndyaXRlVVRGOChlLHQsciksMD09byYmKGUuc2V0KGwsdCksdCs9bC5sZW5ndGgpLHR9LFVaSVAuY3JjPXt0YWJsZTpmdW5jdGlvbigpe2Zvcih2YXIgZT1uZXcgVWludDMyQXJyYXkoMjU2KSx0PTA7dDwyNTY7dCsrKXtmb3IodmFyIHI9dCxpPTA7aTw4O2krKykxJnI/cj0zOTg4MjkyMzg0XnI+Pj4xOnI+Pj49MTtlW3RdPXJ9cmV0dXJuIGV9KCksdXBkYXRlOmZ1bmN0aW9uKGUsdCxyLGkpe2Zvcih2YXIgbz0wO288aTtvKyspZT1VWklQLmNyYy50YWJsZVsyNTUmKGVedFtyK29dKV1eZT4+Pjg7cmV0dXJuIGV9LGNyYzpmdW5jdGlvbihlLHQscil7cmV0dXJuIDQyOTQ5NjcyOTVeVVpJUC5jcmMudXBkYXRlKDQyOTQ5NjcyOTUsZSx0LHIpfX0sVVpJUC5hZGxlcj1mdW5jdGlvbihlLHQscil7Zm9yKHZhciBpPTEsbz0wLGE9dCxzPXQrcjthPHM7KXtmb3IodmFyIGY9TWF0aC5taW4oYSs1NTUyLHMpO2E8Zjspbys9aSs9ZVthKytdO2klPTY1NTIxLG8lPTY1NTIxfXJldHVybiBvPDwxNnxpfSxVWklQLmJpbj17cmVhZFVzaG9ydDpmdW5jdGlvbihlLHQpe3JldHVybiBlW3RdfGVbdCsxXTw8OH0sd3JpdGVVc2hvcnQ6ZnVuY3Rpb24oZSx0LHIpe2VbdF09MjU1JnIsZVt0KzFdPXI+PjgmMjU1fSxyZWFkVWludDpmdW5jdGlvbihlLHQpe3JldHVybiAxNjc3NzIxNiplW3QrM10rKGVbdCsyXTw8MTZ8ZVt0KzFdPDw4fGVbdF0pfSx3cml0ZVVpbnQ6ZnVuY3Rpb24oZSx0LHIpe2VbdF09MjU1JnIsZVt0KzFdPXI+PjgmMjU1LGVbdCsyXT1yPj4xNiYyNTUsZVt0KzNdPXI+PjI0JjI1NX0scmVhZEFTQ0lJOmZ1bmN0aW9uKGUsdCxyKXtmb3IodmFyIGk9XCJcIixvPTA7bzxyO28rKylpKz1TdHJpbmcuZnJvbUNoYXJDb2RlKGVbdCtvXSk7cmV0dXJuIGl9LHdyaXRlQVNDSUk6ZnVuY3Rpb24oZSx0LHIpe2Zvcih2YXIgaT0wO2k8ci5sZW5ndGg7aSsrKWVbdCtpXT1yLmNoYXJDb2RlQXQoaSl9LHBhZDpmdW5jdGlvbihlKXtyZXR1cm4gZS5sZW5ndGg8Mj9cIjBcIitlOmV9LHJlYWRVVEY4OmZ1bmN0aW9uKGUsdCxyKXtmb3IodmFyIGksbz1cIlwiLGE9MDthPHI7YSsrKW8rPVwiJVwiK1VaSVAuYmluLnBhZChlW3QrYV0udG9TdHJpbmcoMTYpKTt0cnl7aT1kZWNvZGVVUklDb21wb25lbnQobyl9Y2F0Y2goaSl7cmV0dXJuIFVaSVAuYmluLnJlYWRBU0NJSShlLHQscil9cmV0dXJuIGl9LHdyaXRlVVRGODpmdW5jdGlvbihlLHQscil7Zm9yKHZhciBpPXIubGVuZ3RoLG89MCxhPTA7YTxpO2ErKyl7dmFyIHM9ci5jaGFyQ29kZUF0KGEpO2lmKDA9PSg0Mjk0OTY3MTY4JnMpKWVbdCtvXT1zLG8rKztlbHNlIGlmKDA9PSg0Mjk0OTY1MjQ4JnMpKWVbdCtvXT0xOTJ8cz4+NixlW3QrbysxXT0xMjh8cz4+MCY2MyxvKz0yO2Vsc2UgaWYoMD09KDQyOTQ5MDE3NjAmcykpZVt0K29dPTIyNHxzPj4xMixlW3QrbysxXT0xMjh8cz4+NiY2MyxlW3QrbysyXT0xMjh8cz4+MCY2MyxvKz0zO2Vsc2V7aWYoMCE9KDQyOTI4NzAxNDQmcykpdGhyb3dcImVcIjtlW3Qrb109MjQwfHM+PjE4LGVbdCtvKzFdPTEyOHxzPj4xMiY2MyxlW3QrbysyXT0xMjh8cz4+NiY2MyxlW3QrbyszXT0xMjh8cz4+MCY2MyxvKz00fX1yZXR1cm4gb30sc2l6ZVVURjg6ZnVuY3Rpb24oZSl7Zm9yKHZhciB0PWUubGVuZ3RoLHI9MCxpPTA7aTx0O2krKyl7dmFyIG89ZS5jaGFyQ29kZUF0KGkpO2lmKDA9PSg0Mjk0OTY3MTY4Jm8pKXIrKztlbHNlIGlmKDA9PSg0Mjk0OTY1MjQ4Jm8pKXIrPTI7ZWxzZSBpZigwPT0oNDI5NDkwMTc2MCZvKSlyKz0zO2Vsc2V7aWYoMCE9KDQyOTI4NzAxNDQmbykpdGhyb3dcImVcIjtyKz00fX1yZXR1cm4gcn19LFVaSVAuRj17fSxVWklQLkYuZGVmbGF0ZVJhdz1mdW5jdGlvbihlLHQscixpKXt2YXIgbz1bWzAsMCwwLDAsMF0sWzQsNCw4LDQsMF0sWzQsNSwxNiw4LDBdLFs0LDYsMTYsMTYsMF0sWzQsMTAsMTYsMzIsMF0sWzgsMTYsMzIsMzIsMF0sWzgsMTYsMTI4LDEyOCwwXSxbOCwzMiwxMjgsMjU2LDBdLFszMiwxMjgsMjU4LDEwMjQsMV0sWzMyLDI1OCwyNTgsNDA5NiwxXV1baV0sYT1VWklQLkYuVSxzPVVaSVAuRi5fZ29vZEluZGV4O1VaSVAuRi5faGFzaDt2YXIgZj1VWklQLkYuX3B1dHNFLGw9MCxjPXI8PDMsdT0wLGg9ZS5sZW5ndGg7aWYoMD09aSl7Zm9yKDtsPGg7KXtmKHQsYyxsKyhfPU1hdGgubWluKDY1NTM1LGgtbCkpPT1oPzE6MCksYz1VWklQLkYuX2NvcHlFeGFjdChlLGwsXyx0LGMrOCksbCs9X31yZXR1cm4gYz4+PjN9dmFyIGQ9YS5saXRzLEE9YS5zdHJ0LGc9YS5wcmV2LHA9MCxtPTAsdz0wLHY9MCxiPTAseT0wO2ZvcihoPjImJihBW3k9VVpJUC5GLl9oYXNoKGUsMCldPTApLGw9MDtsPGg7bCsrKXtpZihiPXksbCsxPGgtMil7eT1VWklQLkYuX2hhc2goZSxsKzEpO3ZhciBFPWwrMSYzMjc2NztnW0VdPUFbeV0sQVt5XT1FfWlmKHU8PWwpeyhwPjE0ZTN8fG0+MjY2OTcpJiZoLWw+MTAwJiYodTxsJiYoZFtwXT1sLXUscCs9Mix1PWwpLGM9VVpJUC5GLl93cml0ZUJsb2NrKGw9PWgtMXx8dT09aD8xOjAsZCxwLHYsZSx3LGwtdyx0LGMpLHA9bT12PTAsdz1sKTt2YXIgRj0wO2w8aC0yJiYoRj1VWklQLkYuX2Jlc3RNYXRjaChlLGwsZyxiLE1hdGgubWluKG9bMl0saC1sKSxvWzNdKSk7dmFyIF89Rj4+PjE2LEI9NjU1MzUmRjtpZigwIT1GKXtCPTY1NTM1JkY7dmFyIFU9cyhfPUY+Pj4xNixhLm9mMCk7YS5saHN0WzI1NytVXSsrO3ZhciBDPXMoQixhLmRmMCk7YS5kaHN0W0NdKyssdis9YS5leGJbVV0rYS5keGJbQ10sZFtwXT1fPDwyM3xsLXUsZFtwKzFdPUI8PDE2fFU8PDh8QyxwKz0yLHU9bCtffWVsc2UgYS5saHN0W2VbbF1dKys7bSsrfX1mb3Iodz09bCYmMCE9ZS5sZW5ndGh8fCh1PGwmJihkW3BdPWwtdSxwKz0yLHU9bCksYz1VWklQLkYuX3dyaXRlQmxvY2soMSxkLHAsdixlLHcsbC13LHQsYykscD0wLG09MCxwPW09dj0wLHc9bCk7MCE9KDcmYyk7KWMrKztyZXR1cm4gYz4+PjN9LFVaSVAuRi5fYmVzdE1hdGNoPWZ1bmN0aW9uKGUsdCxyLGksbyxhKXt2YXIgcz0zMjc2NyZ0LGY9cltzXSxsPXMtZiszMjc2OCYzMjc2NztpZihmPT1zfHxpIT1VWklQLkYuX2hhc2goZSx0LWwpKXJldHVybiAwO2Zvcih2YXIgYz0wLHU9MCxoPU1hdGgubWluKDMyNzY3LHQpO2w8PWgmJjAhPS0tYSYmZiE9czspe2lmKDA9PWN8fGVbdCtjXT09ZVt0K2MtbF0pe3ZhciBkPVVaSVAuRi5faG93TG9uZyhlLHQsbCk7aWYoZD5jKXtpZih1PWwsKGM9ZCk+PW8pYnJlYWs7bCsyPGQmJihkPWwrMik7Zm9yKHZhciBBPTAsZz0wO2c8ZC0yO2crKyl7dmFyIHA9dC1sK2crMzI3NjgmMzI3NjcsbT1wLXJbcF0rMzI3NjgmMzI3Njc7bT5BJiYoQT1tLGY9cCl9fX1sKz0ocz1mKS0oZj1yW3NdKSszMjc2OCYzMjc2N31yZXR1cm4gYzw8MTZ8dX0sVVpJUC5GLl9ob3dMb25nPWZ1bmN0aW9uKGUsdCxyKXtpZihlW3RdIT1lW3Qtcl18fGVbdCsxXSE9ZVt0KzEtcl18fGVbdCsyXSE9ZVt0KzItcl0pcmV0dXJuIDA7dmFyIGk9dCxvPU1hdGgubWluKGUubGVuZ3RoLHQrMjU4KTtmb3IodCs9Mzt0PG8mJmVbdF09PWVbdC1yXTspdCsrO3JldHVybiB0LWl9LFVaSVAuRi5faGFzaD1mdW5jdGlvbihlLHQpe3JldHVybihlW3RdPDw4fGVbdCsxXSkrKGVbdCsyXTw8NCkmNjU1MzV9LFVaSVAuc2F2ZWQ9MCxVWklQLkYuX3dyaXRlQmxvY2s9ZnVuY3Rpb24oZSx0LHIsaSxvLGEscyxmLGwpe3ZhciBjLHUsaCxkLEEsZyxwLG0sdyx2PVVaSVAuRi5VLGI9VVpJUC5GLl9wdXRzRix5PVVaSVAuRi5fcHV0c0U7di5saHN0WzI1Nl0rKyx1PShjPVVaSVAuRi5nZXRUcmVlcygpKVswXSxoPWNbMV0sZD1jWzJdLEE9Y1szXSxnPWNbNF0scD1jWzVdLG09Y1s2XSx3PWNbN107dmFyIEU9MzIrKDA9PShsKzMmNyk/MDo4LShsKzMmNykpKyhzPDwzKSxGPWkrVVpJUC5GLmNvbnRTaXplKHYuZmx0cmVlLHYubGhzdCkrVVpJUC5GLmNvbnRTaXplKHYuZmR0cmVlLHYuZGhzdCksXz1pK1VaSVAuRi5jb250U2l6ZSh2Lmx0cmVlLHYubGhzdCkrVVpJUC5GLmNvbnRTaXplKHYuZHRyZWUsdi5kaHN0KTtfKz0xNCszKnArVVpJUC5GLmNvbnRTaXplKHYuaXRyZWUsdi5paHN0KSsoMip2Lmloc3RbMTZdKzMqdi5paHN0WzE3XSs3KnYuaWhzdFsxOF0pO2Zvcih2YXIgQj0wO0I8Mjg2O0IrKyl2Lmxoc3RbQl09MDtmb3IoQj0wO0I8MzA7QisrKXYuZGhzdFtCXT0wO2ZvcihCPTA7QjwxOTtCKyspdi5paHN0W0JdPTA7dmFyIFU9RTxGJiZFPF8/MDpGPF8/MToyO2lmKGIoZixsLGUpLGIoZixsKzEsVSksbCs9MywwPT1VKXtmb3IoOzAhPSg3JmwpOylsKys7bD1VWklQLkYuX2NvcHlFeGFjdChvLGEscyxmLGwpfWVsc2V7dmFyIEMsSTtpZigxPT1VJiYoQz12LmZsdHJlZSxJPXYuZmR0cmVlKSwyPT1VKXtVWklQLkYubWFrZUNvZGVzKHYubHRyZWUsdSksVVpJUC5GLnJldkNvZGVzKHYubHRyZWUsdSksVVpJUC5GLm1ha2VDb2Rlcyh2LmR0cmVlLGgpLFVaSVAuRi5yZXZDb2Rlcyh2LmR0cmVlLGgpLFVaSVAuRi5tYWtlQ29kZXModi5pdHJlZSxkKSxVWklQLkYucmV2Q29kZXModi5pdHJlZSxkKSxDPXYubHRyZWUsST12LmR0cmVlLHkoZixsLEEtMjU3KSx5KGYsbCs9NSxnLTEpLHkoZixsKz01LHAtNCksbCs9NDtmb3IodmFyIFE9MDtRPHA7USsrKXkoZixsKzMqUSx2Lml0cmVlWzErKHYub3JkcltRXTw8MSldKTtsKz0zKnAsbD1VWklQLkYuX2NvZGVUaW55KG0sdi5pdHJlZSxmLGwpLGw9VVpJUC5GLl9jb2RlVGlueSh3LHYuaXRyZWUsZixsKX1mb3IodmFyIE09YSx4PTA7eDxyO3grPTIpe2Zvcih2YXIgUz10W3hdLFI9Uz4+PjIzLFQ9TSsoODM4ODYwNyZTKTtNPFQ7KWw9VVpJUC5GLl93cml0ZUxpdChvW00rK10sQyxmLGwpO2lmKDAhPVIpe3ZhciBPPXRbeCsxXSxQPU8+PjE2LEg9Tz4+OCYyNTUsTD0yNTUmTzt5KGYsbD1VWklQLkYuX3dyaXRlTGl0KDI1NytILEMsZixsKSxSLXYub2YwW0hdKSxsKz12LmV4YltIXSxiKGYsbD1VWklQLkYuX3dyaXRlTGl0KEwsSSxmLGwpLFAtdi5kZjBbTF0pLGwrPXYuZHhiW0xdLE0rPVJ9fWw9VVpJUC5GLl93cml0ZUxpdCgyNTYsQyxmLGwpfXJldHVybiBsfSxVWklQLkYuX2NvcHlFeGFjdD1mdW5jdGlvbihlLHQscixpLG8pe3ZhciBhPW8+Pj4zO3JldHVybiBpW2FdPXIsaVthKzFdPXI+Pj44LGlbYSsyXT0yNTUtaVthXSxpW2ErM109MjU1LWlbYSsxXSxhKz00LGkuc2V0KG5ldyBVaW50OEFycmF5KGUuYnVmZmVyLHQsciksYSksbysocis0PDwzKX0sVVpJUC5GLmdldFRyZWVzPWZ1bmN0aW9uKCl7Zm9yKHZhciBlPVVaSVAuRi5VLHQ9VVpJUC5GLl9odWZUcmVlKGUubGhzdCxlLmx0cmVlLDE1KSxyPVVaSVAuRi5faHVmVHJlZShlLmRoc3QsZS5kdHJlZSwxNSksaT1bXSxvPVVaSVAuRi5fbGVuQ29kZXMoZS5sdHJlZSxpKSxhPVtdLHM9VVpJUC5GLl9sZW5Db2RlcyhlLmR0cmVlLGEpLGY9MDtmPGkubGVuZ3RoO2YrPTIpZS5paHN0W2lbZl1dKys7Zm9yKGY9MDtmPGEubGVuZ3RoO2YrPTIpZS5paHN0W2FbZl1dKys7Zm9yKHZhciBsPVVaSVAuRi5faHVmVHJlZShlLmloc3QsZS5pdHJlZSw3KSxjPTE5O2M+NCYmMD09ZS5pdHJlZVsxKyhlLm9yZHJbYy0xXTw8MSldOyljLS07cmV0dXJuW3QscixsLG8scyxjLGksYV19LFVaSVAuRi5nZXRTZWNvbmQ9ZnVuY3Rpb24oZSl7Zm9yKHZhciB0PVtdLHI9MDtyPGUubGVuZ3RoO3IrPTIpdC5wdXNoKGVbcisxXSk7cmV0dXJuIHR9LFVaSVAuRi5ub25aZXJvPWZ1bmN0aW9uKGUpe2Zvcih2YXIgdD1cIlwiLHI9MDtyPGUubGVuZ3RoO3IrPTIpMCE9ZVtyKzFdJiYodCs9KHI+PjEpK1wiLFwiKTtyZXR1cm4gdH0sVVpJUC5GLmNvbnRTaXplPWZ1bmN0aW9uKGUsdCl7Zm9yKHZhciByPTAsaT0wO2k8dC5sZW5ndGg7aSsrKXIrPXRbaV0qZVsxKyhpPDwxKV07cmV0dXJuIHJ9LFVaSVAuRi5fY29kZVRpbnk9ZnVuY3Rpb24oZSx0LHIsaSl7Zm9yKHZhciBvPTA7bzxlLmxlbmd0aDtvKz0yKXt2YXIgYT1lW29dLHM9ZVtvKzFdO2k9VVpJUC5GLl93cml0ZUxpdChhLHQscixpKTt2YXIgZj0xNj09YT8yOjE3PT1hPzM6NzthPjE1JiYoVVpJUC5GLl9wdXRzRShyLGkscyxmKSxpKz1mKX1yZXR1cm4gaX0sVVpJUC5GLl9sZW5Db2Rlcz1mdW5jdGlvbihlLHQpe2Zvcih2YXIgcj1lLmxlbmd0aDsyIT1yJiYwPT1lW3ItMV07KXItPTI7Zm9yKHZhciBpPTA7aTxyO2krPTIpe3ZhciBvPWVbaSsxXSxhPWkrMzxyP2VbaSszXTotMSxzPWkrNTxyP2VbaSs1XTotMSxmPTA9PWk/LTE6ZVtpLTFdO2lmKDA9PW8mJmE9PW8mJnM9PW8pe2Zvcih2YXIgbD1pKzU7bCsyPHImJmVbbCsyXT09bzspbCs9MjsoYz1NYXRoLm1pbihsKzEtaT4+PjEsMTM4KSk8MTE/dC5wdXNoKDE3LGMtMyk6dC5wdXNoKDE4LGMtMTEpLGkrPTIqYy0yfWVsc2UgaWYobz09ZiYmYT09byYmcz09byl7Zm9yKGw9aSs1O2wrMjxyJiZlW2wrMl09PW87KWwrPTI7dmFyIGM9TWF0aC5taW4obCsxLWk+Pj4xLDYpO3QucHVzaCgxNixjLTMpLGkrPTIqYy0yfWVsc2UgdC5wdXNoKG8sMCl9cmV0dXJuIHI+Pj4xfSxVWklQLkYuX2h1ZlRyZWU9ZnVuY3Rpb24oZSx0LHIpe3ZhciBpPVtdLG89ZS5sZW5ndGgsYT10Lmxlbmd0aCxzPTA7Zm9yKHM9MDtzPGE7cys9Mil0W3NdPTAsdFtzKzFdPTA7Zm9yKHM9MDtzPG87cysrKTAhPWVbc10mJmkucHVzaCh7bGl0OnMsZjplW3NdfSk7dmFyIGY9aS5sZW5ndGgsbD1pLnNsaWNlKDApO2lmKDA9PWYpcmV0dXJuIDA7aWYoMT09Zil7dmFyIGM9aVswXS5saXQ7bD0wPT1jPzE6MDtyZXR1cm4gdFsxKyhjPDwxKV09MSx0WzErKGw8PDEpXT0xLDF9aS5zb3J0KChmdW5jdGlvbihlLHQpe3JldHVybiBlLmYtdC5mfSkpO3ZhciB1PWlbMF0saD1pWzFdLGQ9MCxBPTEsZz0yO2ZvcihpWzBdPXtsaXQ6LTEsZjp1LmYraC5mLGw6dSxyOmgsZDowfTtBIT1mLTE7KXU9ZCE9QSYmKGc9PWZ8fGlbZF0uZjxpW2ddLmYpP2lbZCsrXTppW2crK10saD1kIT1BJiYoZz09Znx8aVtkXS5mPGlbZ10uZik/aVtkKytdOmlbZysrXSxpW0ErK109e2xpdDotMSxmOnUuZitoLmYsbDp1LHI6aH07dmFyIHA9VVpJUC5GLnNldERlcHRoKGlbQS0xXSwwKTtmb3IocD5yJiYoVVpJUC5GLnJlc3RyaWN0RGVwdGgobCxyLHApLHA9cikscz0wO3M8ZjtzKyspdFsxKyhsW3NdLmxpdDw8MSldPWxbc10uZDtyZXR1cm4gcH0sVVpJUC5GLnNldERlcHRoPWZ1bmN0aW9uKGUsdCl7cmV0dXJuLTEhPWUubGl0PyhlLmQ9dCx0KTpNYXRoLm1heChVWklQLkYuc2V0RGVwdGgoZS5sLHQrMSksVVpJUC5GLnNldERlcHRoKGUucix0KzEpKX0sVVpJUC5GLnJlc3RyaWN0RGVwdGg9ZnVuY3Rpb24oZSx0LHIpe3ZhciBpPTAsbz0xPDxyLXQsYT0wO2ZvcihlLnNvcnQoKGZ1bmN0aW9uKGUsdCl7cmV0dXJuIHQuZD09ZS5kP2UuZi10LmY6dC5kLWUuZH0pKSxpPTA7aTxlLmxlbmd0aCYmZVtpXS5kPnQ7aSsrKXt2YXIgcz1lW2ldLmQ7ZVtpXS5kPXQsYSs9by0oMTw8ci1zKX1mb3IoYT4+Pj1yLXQ7YT4wOyl7KHM9ZVtpXS5kKTx0PyhlW2ldLmQrKyxhLT0xPDx0LXMtMSk6aSsrfWZvcig7aT49MDtpLS0pZVtpXS5kPT10JiZhPDAmJihlW2ldLmQtLSxhKyspOzAhPWEmJmNvbnNvbGUubG9nKFwiZGVidCBsZWZ0XCIpfSxVWklQLkYuX2dvb2RJbmRleD1mdW5jdGlvbihlLHQpe3ZhciByPTA7cmV0dXJuIHRbMTZ8cl08PWUmJihyfD0xNiksdFs4fHJdPD1lJiYocnw9OCksdFs0fHJdPD1lJiYocnw9NCksdFsyfHJdPD1lJiYocnw9MiksdFsxfHJdPD1lJiYocnw9MSkscn0sVVpJUC5GLl93cml0ZUxpdD1mdW5jdGlvbihlLHQscixpKXtyZXR1cm4gVVpJUC5GLl9wdXRzRihyLGksdFtlPDwxXSksaSt0WzErKGU8PDEpXX0sVVpJUC5GLmluZmxhdGU9ZnVuY3Rpb24oZSx0KXt2YXIgcj1VaW50OEFycmF5O2lmKDM9PWVbMF0mJjA9PWVbMV0pcmV0dXJuIHR8fG5ldyByKDApO3ZhciBpPVVaSVAuRixvPWkuX2JpdHNGLGE9aS5fYml0c0Uscz1pLl9kZWNvZGVUaW55LGY9aS5tYWtlQ29kZXMsbD1pLmNvZGVzMm1hcCxjPWkuX2dldDE3LHU9aS5VLGg9bnVsbD09dDtoJiYodD1uZXcgcihlLmxlbmd0aD4+PjI8PDMpKTtmb3IodmFyIGQsQSxnPTAscD0wLG09MCx3PTAsdj0wLGI9MCx5PTAsRT0wLEY9MDswPT1nOylpZihnPW8oZSxGLDEpLHA9byhlLEYrMSwyKSxGKz0zLDAhPXApe2lmKGgmJih0PVVaSVAuRi5fY2hlY2sodCxFKygxPDwxNykpKSwxPT1wJiYoZD11LmZsbWFwLEE9dS5mZG1hcCxiPTUxMSx5PTMxKSwyPT1wKXttPWEoZSxGLDUpKzI1Nyx3PWEoZSxGKzUsNSkrMSx2PWEoZSxGKzEwLDQpKzQsRis9MTQ7Zm9yKHZhciBfPTA7XzwzODtfKz0yKXUuaXRyZWVbX109MCx1Lml0cmVlW18rMV09MDt2YXIgQj0xO2ZvcihfPTA7Xzx2O18rKyl7dmFyIFU9YShlLEYrMypfLDMpO3UuaXRyZWVbMSsodS5vcmRyW19dPDwxKV09VSxVPkImJihCPVUpfUYrPTMqdixmKHUuaXRyZWUsQiksbCh1Lml0cmVlLEIsdS5pbWFwKSxkPXUubG1hcCxBPXUuZG1hcCxGPXModS5pbWFwLCgxPDxCKS0xLG0rdyxlLEYsdS50dHJlZSk7dmFyIEM9aS5fY29weU91dCh1LnR0cmVlLDAsbSx1Lmx0cmVlKTtiPSgxPDxDKS0xO3ZhciBJPWkuX2NvcHlPdXQodS50dHJlZSxtLHcsdS5kdHJlZSk7eT0oMTw8SSktMSxmKHUubHRyZWUsQyksbCh1Lmx0cmVlLEMsZCksZih1LmR0cmVlLEkpLGwodS5kdHJlZSxJLEEpfWZvcig7Oyl7dmFyIFE9ZFtjKGUsRikmYl07Ris9MTUmUTt2YXIgTT1RPj4+NDtpZihNPj4+OD09MCl0W0UrK109TTtlbHNle2lmKDI1Nj09TSlicmVhazt2YXIgeD1FK00tMjU0O2lmKE0+MjY0KXt2YXIgUz11LmxkZWZbTS0yNTddO3g9RSsoUz4+PjMpK2EoZSxGLDcmUyksRis9NyZTfXZhciBSPUFbYyhlLEYpJnldO0YrPTE1JlI7dmFyIFQ9Uj4+PjQsTz11LmRkZWZbVF0sUD0oTz4+PjQpK28oZSxGLDE1Jk8pO2ZvcihGKz0xNSZPLGgmJih0PVVaSVAuRi5fY2hlY2sodCxFKygxPDwxNykpKTtFPHg7KXRbRV09dFtFKystUF0sdFtFXT10W0UrKy1QXSx0W0VdPXRbRSsrLVBdLHRbRV09dFtFKystUF07RT14fX19ZWxzZXswIT0oNyZGKSYmKEYrPTgtKDcmRikpO3ZhciBIPTQrKEY+Pj4zKSxMPWVbSC00XXxlW0gtM108PDg7aCYmKHQ9VVpJUC5GLl9jaGVjayh0LEUrTCkpLHQuc2V0KG5ldyByKGUuYnVmZmVyLGUuYnl0ZU9mZnNldCtILEwpLEUpLEY9SCtMPDwzLEUrPUx9cmV0dXJuIHQubGVuZ3RoPT1FP3Q6dC5zbGljZSgwLEUpfSxVWklQLkYuX2NoZWNrPWZ1bmN0aW9uKGUsdCl7dmFyIHI9ZS5sZW5ndGg7aWYodDw9cilyZXR1cm4gZTt2YXIgaT1uZXcgVWludDhBcnJheShNYXRoLm1heChyPDwxLHQpKTtyZXR1cm4gaS5zZXQoZSwwKSxpfSxVWklQLkYuX2RlY29kZVRpbnk9ZnVuY3Rpb24oZSx0LHIsaSxvLGEpe2Zvcih2YXIgcz1VWklQLkYuX2JpdHNFLGY9VVpJUC5GLl9nZXQxNyxsPTA7bDxyOyl7dmFyIGM9ZVtmKGksbykmdF07bys9MTUmYzt2YXIgdT1jPj4+NDtpZih1PD0xNSlhW2xdPXUsbCsrO2Vsc2V7dmFyIGg9MCxkPTA7MTY9PXU/KGQ9MytzKGksbywyKSxvKz0yLGg9YVtsLTFdKToxNz09dT8oZD0zK3MoaSxvLDMpLG8rPTMpOjE4PT11JiYoZD0xMStzKGksbyw3KSxvKz03KTtmb3IodmFyIEE9bCtkO2w8QTspYVtsXT1oLGwrK319cmV0dXJuIG99LFVaSVAuRi5fY29weU91dD1mdW5jdGlvbihlLHQscixpKXtmb3IodmFyIG89MCxhPTAscz1pLmxlbmd0aD4+PjE7YTxyOyl7dmFyIGY9ZVthK3RdO2lbYTw8MV09MCxpWzErKGE8PDEpXT1mLGY+byYmKG89ZiksYSsrfWZvcig7YTxzOylpW2E8PDFdPTAsaVsxKyhhPDwxKV09MCxhKys7cmV0dXJuIG99LFVaSVAuRi5tYWtlQ29kZXM9ZnVuY3Rpb24oZSx0KXtmb3IodmFyIHIsaSxvLGEscz1VWklQLkYuVSxmPWUubGVuZ3RoLGw9cy5ibF9jb3VudCxjPTA7Yzw9dDtjKyspbFtjXT0wO2ZvcihjPTE7YzxmO2MrPTIpbFtlW2NdXSsrO3ZhciB1PXMubmV4dF9jb2RlO2ZvcihyPTAsbFswXT0wLGk9MTtpPD10O2krKylyPXIrbFtpLTFdPDwxLHVbaV09cjtmb3Iobz0wO288ZjtvKz0yKTAhPShhPWVbbysxXSkmJihlW29dPXVbYV0sdVthXSsrKX0sVVpJUC5GLmNvZGVzMm1hcD1mdW5jdGlvbihlLHQscil7Zm9yKHZhciBpPWUubGVuZ3RoLG89VVpJUC5GLlUucmV2MTUsYT0wO2E8aTthKz0yKWlmKDAhPWVbYSsxXSlmb3IodmFyIHM9YT4+MSxmPWVbYSsxXSxsPXM8PDR8ZixjPXQtZix1PWVbYV08PGMsaD11KygxPDxjKTt1IT1oOyl7cltvW3VdPj4+MTUtdF09bCx1Kyt9fSxVWklQLkYucmV2Q29kZXM9ZnVuY3Rpb24oZSx0KXtmb3IodmFyIHI9VVpJUC5GLlUucmV2MTUsaT0xNS10LG89MDtvPGUubGVuZ3RoO28rPTIpe3ZhciBhPWVbb108PHQtZVtvKzFdO2Vbb109clthXT4+Pml9fSxVWklQLkYuX3B1dHNFPWZ1bmN0aW9uKGUsdCxyKXtyPDw9NyZ0O3ZhciBpPXQ+Pj4zO2VbaV18PXIsZVtpKzFdfD1yPj4+OH0sVVpJUC5GLl9wdXRzRj1mdW5jdGlvbihlLHQscil7cjw8PTcmdDt2YXIgaT10Pj4+MztlW2ldfD1yLGVbaSsxXXw9cj4+PjgsZVtpKzJdfD1yPj4+MTZ9LFVaSVAuRi5fYml0c0U9ZnVuY3Rpb24oZSx0LHIpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDgpPj4+KDcmdCkmKDE8PHIpLTF9LFVaSVAuRi5fYml0c0Y9ZnVuY3Rpb24oZSx0LHIpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDh8ZVsyKyh0Pj4+MyldPDwxNik+Pj4oNyZ0KSYoMTw8ciktMX0sVVpJUC5GLl9nZXQxNz1mdW5jdGlvbihlLHQpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDh8ZVsyKyh0Pj4+MyldPDwxNik+Pj4oNyZ0KX0sVVpJUC5GLl9nZXQyNT1mdW5jdGlvbihlLHQpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDh8ZVsyKyh0Pj4+MyldPDwxNnxlWzMrKHQ+Pj4zKV08PDI0KT4+Pig3JnQpfSxVWklQLkYuVT0ocj1VaW50MTZBcnJheSxpPVVpbnQzMkFycmF5LHtuZXh0X2NvZGU6bmV3IHIoMTYpLGJsX2NvdW50Om5ldyByKDE2KSxvcmRyOlsxNiwxNywxOCwwLDgsNyw5LDYsMTAsNSwxMSw0LDEyLDMsMTMsMiwxNCwxLDE1XSxvZjA6WzMsNCw1LDYsNyw4LDksMTAsMTEsMTMsMTUsMTcsMTksMjMsMjcsMzEsMzUsNDMsNTEsNTksNjcsODMsOTksMTE1LDEzMSwxNjMsMTk1LDIyNywyNTgsOTk5LDk5OSw5OTldLGV4YjpbMCwwLDAsMCwwLDAsMCwwLDEsMSwxLDEsMiwyLDIsMiwzLDMsMywzLDQsNCw0LDQsNSw1LDUsNSwwLDAsMCwwXSxsZGVmOm5ldyByKDMyKSxkZjA6WzEsMiwzLDQsNSw3LDksMTMsMTcsMjUsMzMsNDksNjUsOTcsMTI5LDE5MywyNTcsMzg1LDUxMyw3NjksMTAyNSwxNTM3LDIwNDksMzA3Myw0MDk3LDYxNDUsODE5MywxMjI4OSwxNjM4NSwyNDU3Nyw2NTUzNSw2NTUzNV0sZHhiOlswLDAsMCwwLDEsMSwyLDIsMywzLDQsNCw1LDUsNiw2LDcsNyw4LDgsOSw5LDEwLDEwLDExLDExLDEyLDEyLDEzLDEzLDAsMF0sZGRlZjpuZXcgaSgzMiksZmxtYXA6bmV3IHIoNTEyKSxmbHRyZWU6W10sZmRtYXA6bmV3IHIoMzIpLGZkdHJlZTpbXSxsbWFwOm5ldyByKDMyNzY4KSxsdHJlZTpbXSx0dHJlZTpbXSxkbWFwOm5ldyByKDMyNzY4KSxkdHJlZTpbXSxpbWFwOm5ldyByKDUxMiksaXRyZWU6W10scmV2MTU6bmV3IHIoMzI3NjgpLGxoc3Q6bmV3IGkoMjg2KSxkaHN0Om5ldyBpKDMwKSxpaHN0Om5ldyBpKDE5KSxsaXRzOm5ldyBpKDE1ZTMpLHN0cnQ6bmV3IHIoNjU1MzYpLHByZXY6bmV3IHIoMzI3NjgpfSksZnVuY3Rpb24oKXtmb3IodmFyIGU9VVpJUC5GLlUsdD0wO3Q8MzI3Njg7dCsrKXt2YXIgcj10O3I9KDQyNzgyNTUzNjAmKHI9KDQwNDIzMjIxNjAmKHI9KDM0MzU5NzM4MzYmKHI9KDI4NjMzMTE1MzAmcik+Pj4xfCgxNDMxNjU1NzY1JnIpPDwxKSk+Pj4yfCg4NTg5OTM0NTkmcik8PDIpKT4+PjR8KDI1MjY0NTEzNSZyKTw8NCkpPj4+OHwoMTY3MTE5MzUmcik8PDgsZS5yZXYxNVt0XT0ocj4+PjE2fHI8PDE2KT4+PjE3fWZ1bmN0aW9uIHB1c2hWKGUsdCxyKXtmb3IoOzAhPXQtLTspZS5wdXNoKDAscil9Zm9yKHQ9MDt0PDMyO3QrKyllLmxkZWZbdF09ZS5vZjBbdF08PDN8ZS5leGJbdF0sZS5kZGVmW3RdPWUuZGYwW3RdPDw0fGUuZHhiW3RdO3B1c2hWKGUuZmx0cmVlLDE0NCw4KSxwdXNoVihlLmZsdHJlZSwxMTIsOSkscHVzaFYoZS5mbHRyZWUsMjQsNykscHVzaFYoZS5mbHRyZWUsOCw4KSxVWklQLkYubWFrZUNvZGVzKGUuZmx0cmVlLDkpLFVaSVAuRi5jb2RlczJtYXAoZS5mbHRyZWUsOSxlLmZsbWFwKSxVWklQLkYucmV2Q29kZXMoZS5mbHRyZWUsOSkscHVzaFYoZS5mZHRyZWUsMzIsNSksVVpJUC5GLm1ha2VDb2RlcyhlLmZkdHJlZSw1KSxVWklQLkYuY29kZXMybWFwKGUuZmR0cmVlLDUsZS5mZG1hcCksVVpJUC5GLnJldkNvZGVzKGUuZmR0cmVlLDUpLHB1c2hWKGUuaXRyZWUsMTksMCkscHVzaFYoZS5sdHJlZSwyODYsMCkscHVzaFYoZS5kdHJlZSwzMCwwKSxwdXNoVihlLnR0cmVlLDMyMCwwKX0oKX0oKTt2YXIgVVpJUD1fbWVyZ2VOYW1lc3BhY2VzKHtfX3Byb3RvX186bnVsbCxkZWZhdWx0OmV9LFtlXSk7Y29uc3QgVVBORz1mdW5jdGlvbigpe3ZhciBlPXtuZXh0WmVybyhlLHQpe2Zvcig7MCE9ZVt0XTspdCsrO3JldHVybiB0fSxyZWFkVXNob3J0OihlLHQpPT5lW3RdPDw4fGVbdCsxXSx3cml0ZVVzaG9ydChlLHQscil7ZVt0XT1yPj44JjI1NSxlW3QrMV09MjU1JnJ9LHJlYWRVaW50OihlLHQpPT4xNjc3NzIxNiplW3RdKyhlW3QrMV08PDE2fGVbdCsyXTw8OHxlW3QrM10pLHdyaXRlVWludChlLHQscil7ZVt0XT1yPj4yNCYyNTUsZVt0KzFdPXI+PjE2JjI1NSxlW3QrMl09cj4+OCYyNTUsZVt0KzNdPTI1NSZyfSxyZWFkQVNDSUkoZSx0LHIpe2xldCBpPVwiXCI7Zm9yKGxldCBvPTA7bzxyO28rKylpKz1TdHJpbmcuZnJvbUNoYXJDb2RlKGVbdCtvXSk7cmV0dXJuIGl9LHdyaXRlQVNDSUkoZSx0LHIpe2ZvcihsZXQgaT0wO2k8ci5sZW5ndGg7aSsrKWVbdCtpXT1yLmNoYXJDb2RlQXQoaSl9LHJlYWRCeXRlcyhlLHQscil7Y29uc3QgaT1bXTtmb3IobGV0IG89MDtvPHI7bysrKWkucHVzaChlW3Qrb10pO3JldHVybiBpfSxwYWQ6ZT0+ZS5sZW5ndGg8Mj9gMCR7ZX1gOmUscmVhZFVURjgodCxyLGkpe2xldCBvLGE9XCJcIjtmb3IobGV0IG89MDtvPGk7bysrKWErPWAlJHtlLnBhZCh0W3Irb10udG9TdHJpbmcoMTYpKX1gO3RyeXtvPWRlY29kZVVSSUNvbXBvbmVudChhKX1jYXRjaChvKXtyZXR1cm4gZS5yZWFkQVNDSUkodCxyLGkpfXJldHVybiBvfX07ZnVuY3Rpb24gZGVjb2RlSW1hZ2UodCxyLGksbyl7Y29uc3QgYT1yKmkscz1fZ2V0QlBQKG8pLGY9TWF0aC5jZWlsKHIqcy84KSxsPW5ldyBVaW50OEFycmF5KDQqYSksYz1uZXcgVWludDMyQXJyYXkobC5idWZmZXIpLHtjdHlwZTp1fT1vLHtkZXB0aDpofT1vLGQ9ZS5yZWFkVXNob3J0O2lmKDY9PXUpe2NvbnN0IGU9YTw8MjtpZig4PT1oKWZvcih2YXIgQT0wO0E8ZTtBKz00KWxbQV09dFtBXSxsW0ErMV09dFtBKzFdLGxbQSsyXT10W0ErMl0sbFtBKzNdPXRbQSszXTtpZigxNj09aClmb3IoQT0wO0E8ZTtBKyspbFtBXT10W0E8PDFdfWVsc2UgaWYoMj09dSl7Y29uc3QgZT1vLnRhYnMudFJOUztpZihudWxsPT1lKXtpZig4PT1oKWZvcihBPTA7QTxhO0ErKyl7dmFyIGc9MypBO2NbQV09MjU1PDwyNHx0W2crMl08PDE2fHRbZysxXTw8OHx0W2ddfWlmKDE2PT1oKWZvcihBPTA7QTxhO0ErKyl7Zz02KkE7Y1tBXT0yNTU8PDI0fHRbZys0XTw8MTZ8dFtnKzJdPDw4fHRbZ119fWVsc2V7dmFyIHA9ZVswXTtjb25zdCByPWVbMV0saT1lWzJdO2lmKDg9PWgpZm9yKEE9MDtBPGE7QSsrKXt2YXIgbT1BPDwyO2c9MypBO2NbQV09MjU1PDwyNHx0W2crMl08PDE2fHRbZysxXTw8OHx0W2ddLHRbZ109PXAmJnRbZysxXT09ciYmdFtnKzJdPT1pJiYobFttKzNdPTApfWlmKDE2PT1oKWZvcihBPTA7QTxhO0ErKyl7bT1BPDwyLGc9NipBO2NbQV09MjU1PDwyNHx0W2crNF08PDE2fHRbZysyXTw8OHx0W2ddLGQodCxnKT09cCYmZCh0LGcrMik9PXImJmQodCxnKzQpPT1pJiYobFttKzNdPTApfX19ZWxzZSBpZigzPT11KXtjb25zdCBlPW8udGFicy5QTFRFLHM9by50YWJzLnRSTlMsYz1zP3MubGVuZ3RoOjA7aWYoMT09aClmb3IodmFyIHc9MDt3PGk7dysrKXt2YXIgdj13KmYsYj13KnI7Zm9yKEE9MDtBPHI7QSsrKXttPWIrQTw8Mjt2YXIgeT0zKihFPXRbdisoQT4+MyldPj43LSgoNyZBKTw8MCkmMSk7bFttXT1lW3ldLGxbbSsxXT1lW3krMV0sbFttKzJdPWVbeSsyXSxsW20rM109RTxjP3NbRV06MjU1fX1pZigyPT1oKWZvcih3PTA7dzxpO3crKylmb3Iodj13KmYsYj13KnIsQT0wO0E8cjtBKyspe209YitBPDwyLHk9MyooRT10W3YrKEE+PjIpXT4+Ni0oKDMmQSk8PDEpJjMpO2xbbV09ZVt5XSxsW20rMV09ZVt5KzFdLGxbbSsyXT1lW3krMl0sbFttKzNdPUU8Yz9zW0VdOjI1NX1pZig0PT1oKWZvcih3PTA7dzxpO3crKylmb3Iodj13KmYsYj13KnIsQT0wO0E8cjtBKyspe209YitBPDwyLHk9MyooRT10W3YrKEE+PjEpXT4+NC0oKDEmQSk8PDIpJjE1KTtsW21dPWVbeV0sbFttKzFdPWVbeSsxXSxsW20rMl09ZVt5KzJdLGxbbSszXT1FPGM/c1tFXToyNTV9aWYoOD09aClmb3IoQT0wO0E8YTtBKyspe3ZhciBFO209QTw8Mix5PTMqKEU9dFtBXSk7bFttXT1lW3ldLGxbbSsxXT1lW3krMV0sbFttKzJdPWVbeSsyXSxsW20rM109RTxjP3NbRV06MjU1fX1lbHNlIGlmKDQ9PXUpe2lmKDg9PWgpZm9yKEE9MDtBPGE7QSsrKXttPUE8PDI7dmFyIEY9dFtfPUE8PDFdO2xbbV09RixsW20rMV09RixsW20rMl09RixsW20rM109dFtfKzFdfWlmKDE2PT1oKWZvcihBPTA7QTxhO0ErKyl7dmFyIF87bT1BPDwyLEY9dFtfPUE8PDJdO2xbbV09RixsW20rMV09RixsW20rMl09RixsW20rM109dFtfKzJdfX1lbHNlIGlmKDA9PXUpZm9yKHA9by50YWJzLnRSTlM/by50YWJzLnRSTlM6LTEsdz0wO3c8aTt3Kyspe2NvbnN0IGU9dypmLGk9dypyO2lmKDE9PWgpZm9yKHZhciBCPTA7QjxyO0IrKyl7dmFyIFU9KEY9MjU1Kih0W2UrKEI+Pj4zKV0+Pj43LSg3JkIpJjEpKT09MjU1KnA/MDoyNTU7Y1tpK0JdPVU8PDI0fEY8PDE2fEY8PDh8Rn1lbHNlIGlmKDI9PWgpZm9yKEI9MDtCPHI7QisrKXtVPShGPTg1Kih0W2UrKEI+Pj4yKV0+Pj42LSgoMyZCKTw8MSkmMykpPT04NSpwPzA6MjU1O2NbaStCXT1VPDwyNHxGPDwxNnxGPDw4fEZ9ZWxzZSBpZig0PT1oKWZvcihCPTA7QjxyO0IrKyl7VT0oRj0xNyoodFtlKyhCPj4+MSldPj4+NC0oKDEmQik8PDIpJjE1KSk9PTE3KnA/MDoyNTU7Y1tpK0JdPVU8PDI0fEY8PDE2fEY8PDh8Rn1lbHNlIGlmKDg9PWgpZm9yKEI9MDtCPHI7QisrKXtVPShGPXRbZStCXSk9PXA/MDoyNTU7Y1tpK0JdPVU8PDI0fEY8PDE2fEY8PDh8Rn1lbHNlIGlmKDE2PT1oKWZvcihCPTA7QjxyO0IrKyl7Rj10W2UrKEI8PDEpXSxVPWQodCxlKyhCPDwxKSk9PXA/MDoyNTU7Y1tpK0JdPVU8PDI0fEY8PDE2fEY8PDh8Rn19cmV0dXJuIGx9ZnVuY3Rpb24gX2RlY29tcHJlc3MoZSxyLGksbyl7Y29uc3QgYT1fZ2V0QlBQKGUpLHM9TWF0aC5jZWlsKGkqYS84KSxmPW5ldyBVaW50OEFycmF5KChzKzErZS5pbnRlcmxhY2UpKm8pO3JldHVybiByPWUudGFicy5DZ0JJP3QocixmKTpfaW5mbGF0ZShyLGYpLDA9PWUuaW50ZXJsYWNlP3I9X2ZpbHRlclplcm8ocixlLDAsaSxvKToxPT1lLmludGVybGFjZSYmKHI9ZnVuY3Rpb24gX3JlYWRJbnRlcmxhY2UoZSx0KXtjb25zdCByPXQud2lkdGgsaT10LmhlaWdodCxvPV9nZXRCUFAodCksYT1vPj4zLHM9TWF0aC5jZWlsKHIqby84KSxmPW5ldyBVaW50OEFycmF5KGkqcyk7bGV0IGw9MDtjb25zdCBjPVswLDAsNCwwLDIsMCwxXSx1PVswLDQsMCwyLDAsMSwwXSxoPVs4LDgsOCw0LDQsMiwyXSxkPVs4LDgsNCw0LDIsMiwxXTtsZXQgQT0wO2Zvcig7QTw3Oyl7Y29uc3QgcD1oW0FdLG09ZFtBXTtsZXQgdz0wLHY9MCxiPWNbQV07Zm9yKDtiPGk7KWIrPXAsdisrO2xldCB5PXVbQV07Zm9yKDt5PHI7KXkrPW0sdysrO2NvbnN0IEU9TWF0aC5jZWlsKHcqby84KTtfZmlsdGVyWmVybyhlLHQsbCx3LHYpO2xldCBGPTAsXz1jW0FdO2Zvcig7XzxpOyl7bGV0IHQ9dVtBXSxpPWwrRipFPDwzO2Zvcig7dDxyOyl7dmFyIGc7aWYoMT09bylnPShnPWVbaT4+M10pPj43LSg3JmkpJjEsZltfKnMrKHQ+PjMpXXw9Zzw8Ny0oKDcmdCk8PDApO2lmKDI9PW8pZz0oZz1lW2k+PjNdKT4+Ni0oNyZpKSYzLGZbXypzKyh0Pj4yKV18PWc8PDYtKCgzJnQpPDwxKTtpZig0PT1vKWc9KGc9ZVtpPj4zXSk+PjQtKDcmaSkmMTUsZltfKnMrKHQ+PjEpXXw9Zzw8NC0oKDEmdCk8PDIpO2lmKG8+PTgpe2NvbnN0IHI9XypzK3QqYTtmb3IobGV0IHQ9MDt0PGE7dCsrKWZbcit0XT1lWyhpPj4zKSt0XX1pKz1vLHQrPW19RisrLF8rPXB9dyp2IT0wJiYobCs9diooMStFKSksQSs9MX1yZXR1cm4gZn0ocixlKSkscn1mdW5jdGlvbiBfaW5mbGF0ZShlLHIpe3JldHVybiB0KG5ldyBVaW50OEFycmF5KGUuYnVmZmVyLDIsZS5sZW5ndGgtNikscil9dmFyIHQ9ZnVuY3Rpb24oKXtjb25zdCBlPXtIOnt9fTtyZXR1cm4gZS5ILk49ZnVuY3Rpb24odCxyKXtjb25zdCBpPVVpbnQ4QXJyYXk7bGV0IG8sYSxzPTAsZj0wLGw9MCxjPTAsdT0wLGg9MCxkPTAsQT0wLGc9MDtpZigzPT10WzBdJiYwPT10WzFdKXJldHVybiByfHxuZXcgaSgwKTtjb25zdCBwPWUuSCxtPXAuYix3PXAuZSx2PXAuUixiPXAubix5PXAuQSxFPXAuWixGPXAubSxfPW51bGw9PXI7Zm9yKF8mJihyPW5ldyBpKHQubGVuZ3RoPj4+Mjw8NSkpOzA9PXM7KWlmKHM9bSh0LGcsMSksZj1tKHQsZysxLDIpLGcrPTMsMCE9Zil7aWYoXyYmKHI9ZS5ILlcocixBKygxPDwxNykpKSwxPT1mJiYobz1GLkosYT1GLmgsaD01MTEsZD0zMSksMj09Zil7bD13KHQsZyw1KSsyNTcsYz13KHQsZys1LDUpKzEsdT13KHQsZysxMCw0KSs0LGcrPTE0O2xldCBlPTE7Zm9yKHZhciBCPTA7QjwzODtCKz0yKUYuUVtCXT0wLEYuUVtCKzFdPTA7Zm9yKEI9MDtCPHU7QisrKXtjb25zdCByPXcodCxnKzMqQiwzKTtGLlFbMSsoRi5YW0JdPDwxKV09cixyPmUmJihlPXIpfWcrPTMqdSxiKEYuUSxlKSx5KEYuUSxlLEYudSksbz1GLncsYT1GLmQsZz12KEYudSwoMTw8ZSktMSxsK2MsdCxnLEYudik7Y29uc3Qgcj1wLlYoRi52LDAsbCxGLkMpO2g9KDE8PHIpLTE7Y29uc3QgaT1wLlYoRi52LGwsYyxGLkQpO2Q9KDE8PGkpLTEsYihGLkMscikseShGLkMscixvKSxiKEYuRCxpKSx5KEYuRCxpLGEpfWZvcig7Oyl7Y29uc3QgZT1vW0UodCxnKSZoXTtnKz0xNSZlO2NvbnN0IGk9ZT4+PjQ7aWYoaT4+Pjg9PTApcltBKytdPWk7ZWxzZXtpZigyNTY9PWkpYnJlYWs7e2xldCBlPUEraS0yNTQ7aWYoaT4yNjQpe2NvbnN0IHI9Ri5xW2ktMjU3XTtlPUErKHI+Pj4zKSt3KHQsZyw3JnIpLGcrPTcmcn1jb25zdCBvPWFbRSh0LGcpJmRdO2crPTE1Jm87Y29uc3Qgcz1vPj4+NCxmPUYuY1tzXSxsPShmPj4+NCkrbSh0LGcsMTUmZik7Zm9yKGcrPTE1JmY7QTxlOylyW0FdPXJbQSsrLWxdLHJbQV09cltBKystbF0scltBXT1yW0ErKy1sXSxyW0FdPXJbQSsrLWxdO0E9ZX19fX1lbHNlezAhPSg3JmcpJiYoZys9OC0oNyZnKSk7Y29uc3Qgbz00KyhnPj4+MyksYT10W28tNF18dFtvLTNdPDw4O18mJihyPWUuSC5XKHIsQSthKSksci5zZXQobmV3IGkodC5idWZmZXIsdC5ieXRlT2Zmc2V0K28sYSksQSksZz1vK2E8PDMsQSs9YX1yZXR1cm4gci5sZW5ndGg9PUE/cjpyLnNsaWNlKDAsQSl9LGUuSC5XPWZ1bmN0aW9uKGUsdCl7Y29uc3Qgcj1lLmxlbmd0aDtpZih0PD1yKXJldHVybiBlO2NvbnN0IGk9bmV3IFVpbnQ4QXJyYXkocjw8MSk7cmV0dXJuIGkuc2V0KGUsMCksaX0sZS5ILlI9ZnVuY3Rpb24odCxyLGksbyxhLHMpe2NvbnN0IGY9ZS5ILmUsbD1lLkguWjtsZXQgYz0wO2Zvcig7YzxpOyl7Y29uc3QgZT10W2wobyxhKSZyXTthKz0xNSZlO2NvbnN0IGk9ZT4+PjQ7aWYoaTw9MTUpc1tjXT1pLGMrKztlbHNle2xldCBlPTAsdD0wOzE2PT1pPyh0PTMrZihvLGEsMiksYSs9MixlPXNbYy0xXSk6MTc9PWk/KHQ9MytmKG8sYSwzKSxhKz0zKToxOD09aSYmKHQ9MTErZihvLGEsNyksYSs9Nyk7Y29uc3Qgcj1jK3Q7Zm9yKDtjPHI7KXNbY109ZSxjKyt9fXJldHVybiBhfSxlLkguVj1mdW5jdGlvbihlLHQscixpKXtsZXQgbz0wLGE9MDtjb25zdCBzPWkubGVuZ3RoPj4+MTtmb3IoO2E8cjspe2NvbnN0IHI9ZVthK3RdO2lbYTw8MV09MCxpWzErKGE8PDEpXT1yLHI+byYmKG89ciksYSsrfWZvcig7YTxzOylpW2E8PDFdPTAsaVsxKyhhPDwxKV09MCxhKys7cmV0dXJuIG99LGUuSC5uPWZ1bmN0aW9uKHQscil7Y29uc3QgaT1lLkgubSxvPXQubGVuZ3RoO2xldCBhLHMsZjtsZXQgbDtjb25zdCBjPWkuajtmb3IodmFyIHU9MDt1PD1yO3UrKyljW3VdPTA7Zm9yKHU9MTt1PG87dSs9MiljW3RbdV1dKys7Y29uc3QgaD1pLks7Zm9yKGE9MCxjWzBdPTAscz0xO3M8PXI7cysrKWE9YStjW3MtMV08PDEsaFtzXT1hO2ZvcihmPTA7ZjxvO2YrPTIpbD10W2YrMV0sMCE9bCYmKHRbZl09aFtsXSxoW2xdKyspfSxlLkguQT1mdW5jdGlvbih0LHIsaSl7Y29uc3Qgbz10Lmxlbmd0aCxhPWUuSC5tLnI7Zm9yKGxldCBlPTA7ZTxvO2UrPTIpaWYoMCE9dFtlKzFdKXtjb25zdCBvPWU+PjEscz10W2UrMV0sZj1vPDw0fHMsbD1yLXM7bGV0IGM9dFtlXTw8bDtjb25zdCB1PWMrKDE8PGwpO2Zvcig7YyE9dTspe2lbYVtjXT4+PjE1LXJdPWYsYysrfX19LGUuSC5sPWZ1bmN0aW9uKHQscil7Y29uc3QgaT1lLkgubS5yLG89MTUtcjtmb3IobGV0IGU9MDtlPHQubGVuZ3RoO2UrPTIpe2NvbnN0IGE9dFtlXTw8ci10W2UrMV07dFtlXT1pW2FdPj4+b319LGUuSC5NPWZ1bmN0aW9uKGUsdCxyKXtyPDw9NyZ0O2NvbnN0IGk9dD4+PjM7ZVtpXXw9cixlW2krMV18PXI+Pj44fSxlLkguST1mdW5jdGlvbihlLHQscil7cjw8PTcmdDtjb25zdCBpPXQ+Pj4zO2VbaV18PXIsZVtpKzFdfD1yPj4+OCxlW2krMl18PXI+Pj4xNn0sZS5ILmU9ZnVuY3Rpb24oZSx0LHIpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDgpPj4+KDcmdCkmKDE8PHIpLTF9LGUuSC5iPWZ1bmN0aW9uKGUsdCxyKXtyZXR1cm4oZVt0Pj4+M118ZVsxKyh0Pj4+MyldPDw4fGVbMisodD4+PjMpXTw8MTYpPj4+KDcmdCkmKDE8PHIpLTF9LGUuSC5aPWZ1bmN0aW9uKGUsdCl7cmV0dXJuKGVbdD4+PjNdfGVbMSsodD4+PjMpXTw8OHxlWzIrKHQ+Pj4zKV08PDE2KT4+Pig3JnQpfSxlLkguaT1mdW5jdGlvbihlLHQpe3JldHVybihlW3Q+Pj4zXXxlWzErKHQ+Pj4zKV08PDh8ZVsyKyh0Pj4+MyldPDwxNnxlWzMrKHQ+Pj4zKV08PDI0KT4+Pig3JnQpfSxlLkgubT1mdW5jdGlvbigpe2NvbnN0IGU9VWludDE2QXJyYXksdD1VaW50MzJBcnJheTtyZXR1cm57SzpuZXcgZSgxNiksajpuZXcgZSgxNiksWDpbMTYsMTcsMTgsMCw4LDcsOSw2LDEwLDUsMTEsNCwxMiwzLDEzLDIsMTQsMSwxNV0sUzpbMyw0LDUsNiw3LDgsOSwxMCwxMSwxMywxNSwxNywxOSwyMywyNywzMSwzNSw0Myw1MSw1OSw2Nyw4Myw5OSwxMTUsMTMxLDE2MywxOTUsMjI3LDI1OCw5OTksOTk5LDk5OV0sVDpbMCwwLDAsMCwwLDAsMCwwLDEsMSwxLDEsMiwyLDIsMiwzLDMsMywzLDQsNCw0LDQsNSw1LDUsNSwwLDAsMCwwXSxxOm5ldyBlKDMyKSxwOlsxLDIsMyw0LDUsNyw5LDEzLDE3LDI1LDMzLDQ5LDY1LDk3LDEyOSwxOTMsMjU3LDM4NSw1MTMsNzY5LDEwMjUsMTUzNywyMDQ5LDMwNzMsNDA5Nyw2MTQ1LDgxOTMsMTIyODksMTYzODUsMjQ1NzcsNjU1MzUsNjU1MzVdLHo6WzAsMCwwLDAsMSwxLDIsMiwzLDMsNCw0LDUsNSw2LDYsNyw3LDgsOCw5LDksMTAsMTAsMTEsMTEsMTIsMTIsMTMsMTMsMCwwXSxjOm5ldyB0KDMyKSxKOm5ldyBlKDUxMiksXzpbXSxoOm5ldyBlKDMyKSwkOltdLHc6bmV3IGUoMzI3NjgpLEM6W10sdjpbXSxkOm5ldyBlKDMyNzY4KSxEOltdLHU6bmV3IGUoNTEyKSxROltdLHI6bmV3IGUoMzI3NjgpLHM6bmV3IHQoMjg2KSxZOm5ldyB0KDMwKSxhOm5ldyB0KDE5KSx0Om5ldyB0KDE1ZTMpLGs6bmV3IGUoNjU1MzYpLGc6bmV3IGUoMzI3NjgpfX0oKSxmdW5jdGlvbigpe2NvbnN0IHQ9ZS5ILm07Zm9yKHZhciByPTA7cjwzMjc2ODtyKyspe2xldCBlPXI7ZT0oMjg2MzMxMTUzMCZlKT4+PjF8KDE0MzE2NTU3NjUmZSk8PDEsZT0oMzQzNTk3MzgzNiZlKT4+PjJ8KDg1ODk5MzQ1OSZlKTw8MixlPSg0MDQyMzIyMTYwJmUpPj4+NHwoMjUyNjQ1MTM1JmUpPDw0LGU9KDQyNzgyNTUzNjAmZSk+Pj44fCgxNjcxMTkzNSZlKTw8OCx0LnJbcl09KGU+Pj4xNnxlPDwxNik+Pj4xN31mdW5jdGlvbiBuKGUsdCxyKXtmb3IoOzAhPXQtLTspZS5wdXNoKDAscil9Zm9yKHI9MDtyPDMyO3IrKyl0LnFbcl09dC5TW3JdPDwzfHQuVFtyXSx0LmNbcl09dC5wW3JdPDw0fHQueltyXTtuKHQuXywxNDQsOCksbih0Ll8sMTEyLDkpLG4odC5fLDI0LDcpLG4odC5fLDgsOCksZS5ILm4odC5fLDkpLGUuSC5BKHQuXyw5LHQuSiksZS5ILmwodC5fLDkpLG4odC4kLDMyLDUpLGUuSC5uKHQuJCw1KSxlLkguQSh0LiQsNSx0LmgpLGUuSC5sKHQuJCw1KSxuKHQuUSwxOSwwKSxuKHQuQywyODYsMCksbih0LkQsMzAsMCksbih0LnYsMzIwLDApfSgpLGUuSC5OfSgpO2Z1bmN0aW9uIF9nZXRCUFAoZSl7cmV0dXJuWzEsbnVsbCwzLDEsMixudWxsLDRdW2UuY3R5cGVdKmUuZGVwdGh9ZnVuY3Rpb24gX2ZpbHRlclplcm8oZSx0LHIsaSxvKXtsZXQgYT1fZ2V0QlBQKHQpO2NvbnN0IHM9TWF0aC5jZWlsKGkqYS84KTtsZXQgZixsO2E9TWF0aC5jZWlsKGEvOCk7bGV0IGM9ZVtyXSx1PTA7aWYoYz4xJiYoZVtyXT1bMCwwLDFdW2MtMl0pLDM9PWMpZm9yKHU9YTt1PHM7dSsrKWVbdSsxXT1lW3UrMV0rKGVbdSsxLWFdPj4+MSkmMjU1O2ZvcihsZXQgdD0wO3Q8bzt0KyspaWYoZj1yK3QqcyxsPWYrdCsxLGM9ZVtsLTFdLHU9MCwwPT1jKWZvcig7dTxzO3UrKyllW2YrdV09ZVtsK3VdO2Vsc2UgaWYoMT09Yyl7Zm9yKDt1PGE7dSsrKWVbZit1XT1lW2wrdV07Zm9yKDt1PHM7dSsrKWVbZit1XT1lW2wrdV0rZVtmK3UtYV19ZWxzZSBpZigyPT1jKWZvcig7dTxzO3UrKyllW2YrdV09ZVtsK3VdK2VbZit1LXNdO2Vsc2UgaWYoMz09Yyl7Zm9yKDt1PGE7dSsrKWVbZit1XT1lW2wrdV0rKGVbZit1LXNdPj4+MSk7Zm9yKDt1PHM7dSsrKWVbZit1XT1lW2wrdV0rKGVbZit1LXNdK2VbZit1LWFdPj4+MSl9ZWxzZXtmb3IoO3U8YTt1KyspZVtmK3VdPWVbbCt1XStfcGFldGgoMCxlW2YrdS1zXSwwKTtmb3IoO3U8czt1KyspZVtmK3VdPWVbbCt1XStfcGFldGgoZVtmK3UtYV0sZVtmK3Utc10sZVtmK3UtYS1zXSl9cmV0dXJuIGV9ZnVuY3Rpb24gX3BhZXRoKGUsdCxyKXtjb25zdCBpPWUrdC1yLG89aS1lLGE9aS10LHM9aS1yO3JldHVybiBvKm88PWEqYSYmbypvPD1zKnM/ZTphKmE8PXMqcz90OnJ9ZnVuY3Rpb24gX0lIRFIodCxyLGkpe2kud2lkdGg9ZS5yZWFkVWludCh0LHIpLHIrPTQsaS5oZWlnaHQ9ZS5yZWFkVWludCh0LHIpLHIrPTQsaS5kZXB0aD10W3JdLHIrKyxpLmN0eXBlPXRbcl0scisrLGkuY29tcHJlc3M9dFtyXSxyKyssaS5maWx0ZXI9dFtyXSxyKyssaS5pbnRlcmxhY2U9dFtyXSxyKyt9ZnVuY3Rpb24gX2NvcHlUaWxlKGUsdCxyLGksbyxhLHMsZixsKXtjb25zdCBjPU1hdGgubWluKHQsbyksdT1NYXRoLm1pbihyLGEpO2xldCBoPTAsZD0wO2ZvcihsZXQgcj0wO3I8dTtyKyspZm9yKGxldCBhPTA7YTxjO2ErKylpZihzPj0wJiZmPj0wPyhoPXIqdCthPDwyLGQ9KGYrcikqbytzK2E8PDIpOihoPSgtZityKSp0LXMrYTw8MixkPXIqbythPDwyKSwwPT1sKWlbZF09ZVtoXSxpW2QrMV09ZVtoKzFdLGlbZCsyXT1lW2grMl0saVtkKzNdPWVbaCszXTtlbHNlIGlmKDE9PWwpe3ZhciBBPWVbaCszXSooMS8yNTUpLGc9ZVtoXSpBLHA9ZVtoKzFdKkEsbT1lW2grMl0qQSx3PWlbZCszXSooMS8yNTUpLHY9aVtkXSp3LGI9aVtkKzFdKncseT1pW2QrMl0qdztjb25zdCB0PTEtQSxyPUErdyp0LG89MD09cj8wOjEvcjtpW2QrM109MjU1KnIsaVtkKzBdPShnK3YqdCkqbyxpW2QrMV09KHArYip0KSpvLGlbZCsyXT0obSt5KnQpKm99ZWxzZSBpZigyPT1sKXtBPWVbaCszXSxnPWVbaF0scD1lW2grMV0sbT1lW2grMl0sdz1pW2QrM10sdj1pW2RdLGI9aVtkKzFdLHk9aVtkKzJdO0E9PXcmJmc9PXYmJnA9PWImJm09PXk/KGlbZF09MCxpW2QrMV09MCxpW2QrMl09MCxpW2QrM109MCk6KGlbZF09ZyxpW2QrMV09cCxpW2QrMl09bSxpW2QrM109QSl9ZWxzZSBpZigzPT1sKXtBPWVbaCszXSxnPWVbaF0scD1lW2grMV0sbT1lW2grMl0sdz1pW2QrM10sdj1pW2RdLGI9aVtkKzFdLHk9aVtkKzJdO2lmKEE9PXcmJmc9PXYmJnA9PWImJm09PXkpY29udGludWU7aWYoQTwyMjAmJnc+MjApcmV0dXJuITF9cmV0dXJuITB9cmV0dXJue2RlY29kZTpmdW5jdGlvbiBkZWNvZGUocil7Y29uc3QgaT1uZXcgVWludDhBcnJheShyKTtsZXQgbz04O2NvbnN0IGE9ZSxzPWEucmVhZFVzaG9ydCxmPWEucmVhZFVpbnQsbD17dGFiczp7fSxmcmFtZXM6W119LGM9bmV3IFVpbnQ4QXJyYXkoaS5sZW5ndGgpO2xldCB1LGg9MCxkPTA7Y29uc3QgQT1bMTM3LDgwLDc4LDcxLDEzLDEwLDI2LDEwXTtmb3IodmFyIGc9MDtnPDg7ZysrKWlmKGlbZ10hPUFbZ10pdGhyb3dcIlRoZSBpbnB1dCBpcyBub3QgYSBQTkcgZmlsZSFcIjtmb3IoO288aS5sZW5ndGg7KXtjb25zdCBlPWEucmVhZFVpbnQoaSxvKTtvKz00O2NvbnN0IHI9YS5yZWFkQVNDSUkoaSxvLDQpO2lmKG8rPTQsXCJJSERSXCI9PXIpX0lIRFIoaSxvLGwpO2Vsc2UgaWYoXCJpQ0NQXCI9PXIpe2Zvcih2YXIgcD1vOzAhPWlbcF07KXArKzthLnJlYWRBU0NJSShpLG8scC1vKSxpW3ArMV07Y29uc3Qgcz1pLnNsaWNlKHArMixvK2UpO2xldCBmPW51bGw7dHJ5e2Y9X2luZmxhdGUocyl9Y2F0Y2goZSl7Zj10KHMpfWwudGFic1tyXT1mfWVsc2UgaWYoXCJDZ0JJXCI9PXIpbC50YWJzW3JdPWkuc2xpY2UobyxvKzQpO2Vsc2UgaWYoXCJJREFUXCI9PXIpe2ZvcihnPTA7ZzxlO2crKyljW2grZ109aVtvK2ddO2grPWV9ZWxzZSBpZihcImFjVExcIj09cilsLnRhYnNbcl09e251bV9mcmFtZXM6ZihpLG8pLG51bV9wbGF5czpmKGksbys0KX0sdT1uZXcgVWludDhBcnJheShpLmxlbmd0aCk7ZWxzZSBpZihcImZjVExcIj09cil7aWYoMCE9ZCkoRT1sLmZyYW1lc1tsLmZyYW1lcy5sZW5ndGgtMV0pLmRhdGE9X2RlY29tcHJlc3MobCx1LnNsaWNlKDAsZCksRS5yZWN0LndpZHRoLEUucmVjdC5oZWlnaHQpLGQ9MDtjb25zdCBlPXt4OmYoaSxvKzEyKSx5OmYoaSxvKzE2KSx3aWR0aDpmKGksbys0KSxoZWlnaHQ6ZihpLG8rOCl9O2xldCB0PXMoaSxvKzIyKTt0PXMoaSxvKzIwKS8oMD09dD8xMDA6dCk7Y29uc3Qgcj17cmVjdDplLGRlbGF5Ok1hdGgucm91bmQoMWUzKnQpLGRpc3Bvc2U6aVtvKzI0XSxibGVuZDppW28rMjVdfTtsLmZyYW1lcy5wdXNoKHIpfWVsc2UgaWYoXCJmZEFUXCI9PXIpe2ZvcihnPTA7ZzxlLTQ7ZysrKXVbZCtnXT1pW28rZys0XTtkKz1lLTR9ZWxzZSBpZihcInBIWXNcIj09cilsLnRhYnNbcl09W2EucmVhZFVpbnQoaSxvKSxhLnJlYWRVaW50KGksbys0KSxpW28rOF1dO2Vsc2UgaWYoXCJjSFJNXCI9PXIpe2wudGFic1tyXT1bXTtmb3IoZz0wO2c8ODtnKyspbC50YWJzW3JdLnB1c2goYS5yZWFkVWludChpLG8rNCpnKSl9ZWxzZSBpZihcInRFWHRcIj09cnx8XCJ6VFh0XCI9PXIpe251bGw9PWwudGFic1tyXSYmKGwudGFic1tyXT17fSk7dmFyIG09YS5uZXh0WmVybyhpLG8pLHc9YS5yZWFkQVNDSUkoaSxvLG0tbyksdj1vK2UtbS0xO2lmKFwidEVYdFwiPT1yKXk9YS5yZWFkQVNDSUkoaSxtKzEsdik7ZWxzZXt2YXIgYj1faW5mbGF0ZShpLnNsaWNlKG0rMixtKzIrdikpO3k9YS5yZWFkVVRGOChiLDAsYi5sZW5ndGgpfWwudGFic1tyXVt3XT15fWVsc2UgaWYoXCJpVFh0XCI9PXIpe251bGw9PWwudGFic1tyXSYmKGwudGFic1tyXT17fSk7bT0wLHA9bzttPWEubmV4dFplcm8oaSxwKTt3PWEucmVhZEFTQ0lJKGkscCxtLXApO2NvbnN0IHQ9aVtwPW0rMV07dmFyIHk7aVtwKzFdLHArPTIsbT1hLm5leHRaZXJvKGkscCksYS5yZWFkQVNDSUkoaSxwLG0tcCkscD1tKzEsbT1hLm5leHRaZXJvKGkscCksYS5yZWFkVVRGOChpLHAsbS1wKTt2PWUtKChwPW0rMSktbyk7aWYoMD09dCl5PWEucmVhZFVURjgoaSxwLHYpO2Vsc2V7Yj1faW5mbGF0ZShpLnNsaWNlKHAscCt2KSk7eT1hLnJlYWRVVEY4KGIsMCxiLmxlbmd0aCl9bC50YWJzW3JdW3ddPXl9ZWxzZSBpZihcIlBMVEVcIj09cilsLnRhYnNbcl09YS5yZWFkQnl0ZXMoaSxvLGUpO2Vsc2UgaWYoXCJoSVNUXCI9PXIpe2NvbnN0IGU9bC50YWJzLlBMVEUubGVuZ3RoLzM7bC50YWJzW3JdPVtdO2ZvcihnPTA7ZzxlO2crKylsLnRhYnNbcl0ucHVzaChzKGksbysyKmcpKX1lbHNlIGlmKFwidFJOU1wiPT1yKTM9PWwuY3R5cGU/bC50YWJzW3JdPWEucmVhZEJ5dGVzKGksbyxlKTowPT1sLmN0eXBlP2wudGFic1tyXT1zKGksbyk6Mj09bC5jdHlwZSYmKGwudGFic1tyXT1bcyhpLG8pLHMoaSxvKzIpLHMoaSxvKzQpXSk7ZWxzZSBpZihcImdBTUFcIj09cilsLnRhYnNbcl09YS5yZWFkVWludChpLG8pLzFlNTtlbHNlIGlmKFwic1JHQlwiPT1yKWwudGFic1tyXT1pW29dO2Vsc2UgaWYoXCJiS0dEXCI9PXIpMD09bC5jdHlwZXx8ND09bC5jdHlwZT9sLnRhYnNbcl09W3MoaSxvKV06Mj09bC5jdHlwZXx8Nj09bC5jdHlwZT9sLnRhYnNbcl09W3MoaSxvKSxzKGksbysyKSxzKGksbys0KV06Mz09bC5jdHlwZSYmKGwudGFic1tyXT1pW29dKTtlbHNlIGlmKFwiSUVORFwiPT1yKWJyZWFrO28rPWUsYS5yZWFkVWludChpLG8pLG8rPTR9dmFyIEU7cmV0dXJuIDAhPWQmJigoRT1sLmZyYW1lc1tsLmZyYW1lcy5sZW5ndGgtMV0pLmRhdGE9X2RlY29tcHJlc3MobCx1LnNsaWNlKDAsZCksRS5yZWN0LndpZHRoLEUucmVjdC5oZWlnaHQpKSxsLmRhdGE9X2RlY29tcHJlc3MobCxjLGwud2lkdGgsbC5oZWlnaHQpLGRlbGV0ZSBsLmNvbXByZXNzLGRlbGV0ZSBsLmludGVybGFjZSxkZWxldGUgbC5maWx0ZXIsbH0sdG9SR0JBODpmdW5jdGlvbiB0b1JHQkE4KGUpe2NvbnN0IHQ9ZS53aWR0aCxyPWUuaGVpZ2h0O2lmKG51bGw9PWUudGFicy5hY1RMKXJldHVybltkZWNvZGVJbWFnZShlLmRhdGEsdCxyLGUpLmJ1ZmZlcl07Y29uc3QgaT1bXTtudWxsPT1lLmZyYW1lc1swXS5kYXRhJiYoZS5mcmFtZXNbMF0uZGF0YT1lLmRhdGEpO2NvbnN0IG89dCpyKjQsYT1uZXcgVWludDhBcnJheShvKSxzPW5ldyBVaW50OEFycmF5KG8pLGY9bmV3IFVpbnQ4QXJyYXkobyk7Zm9yKGxldCBjPTA7YzxlLmZyYW1lcy5sZW5ndGg7YysrKXtjb25zdCB1PWUuZnJhbWVzW2NdLGg9dS5yZWN0LngsZD11LnJlY3QueSxBPXUucmVjdC53aWR0aCxnPXUucmVjdC5oZWlnaHQscD1kZWNvZGVJbWFnZSh1LmRhdGEsQSxnLGUpO2lmKDAhPWMpZm9yKHZhciBsPTA7bDxvO2wrKylmW2xdPWFbbF07aWYoMD09dS5ibGVuZD9fY29weVRpbGUocCxBLGcsYSx0LHIsaCxkLDApOjE9PXUuYmxlbmQmJl9jb3B5VGlsZShwLEEsZyxhLHQscixoLGQsMSksaS5wdXNoKGEuYnVmZmVyLnNsaWNlKDApKSwwPT11LmRpc3Bvc2UpO2Vsc2UgaWYoMT09dS5kaXNwb3NlKV9jb3B5VGlsZShzLEEsZyxhLHQscixoLGQsMCk7ZWxzZSBpZigyPT11LmRpc3Bvc2UpZm9yKGw9MDtsPG87bCsrKWFbbF09ZltsXX1yZXR1cm4gaX0sX3BhZXRoOl9wYWV0aCxfY29weVRpbGU6X2NvcHlUaWxlLF9iaW46ZX19KCk7IWZ1bmN0aW9uKCl7Y29uc3R7X2NvcHlUaWxlOmV9PVVQTkcse19iaW46dH09VVBORyxyPVVQTkcuX3BhZXRoO3ZhciBpPXt0YWJsZTpmdW5jdGlvbigpe2NvbnN0IGU9bmV3IFVpbnQzMkFycmF5KDI1Nik7Zm9yKGxldCB0PTA7dDwyNTY7dCsrKXtsZXQgcj10O2ZvcihsZXQgZT0wO2U8ODtlKyspMSZyP3I9Mzk4ODI5MjM4NF5yPj4+MTpyPj4+PTE7ZVt0XT1yfXJldHVybiBlfSgpLHVwZGF0ZShlLHQscixvKXtmb3IobGV0IGE9MDthPG87YSsrKWU9aS50YWJsZVsyNTUmKGVedFtyK2FdKV1eZT4+Pjg7cmV0dXJuIGV9LGNyYzooZSx0LHIpPT40Mjk0OTY3Mjk1XmkudXBkYXRlKDQyOTQ5NjcyOTUsZSx0LHIpfTtmdW5jdGlvbiBhZGRFcnIoZSx0LHIsaSl7dFtyXSs9ZVswXSppPj40LHRbcisxXSs9ZVsxXSppPj40LHRbcisyXSs9ZVsyXSppPj40LHRbciszXSs9ZVszXSppPj40fWZ1bmN0aW9uIE4oZSl7cmV0dXJuIE1hdGgubWF4KDAsTWF0aC5taW4oMjU1LGUpKX1mdW5jdGlvbiBEKGUsdCl7Y29uc3Qgcj1lWzBdLXRbMF0saT1lWzFdLXRbMV0sbz1lWzJdLXRbMl0sYT1lWzNdLXRbM107cmV0dXJuIHIqcitpKmkrbypvK2EqYX1mdW5jdGlvbiBkaXRoZXIoZSx0LHIsaSxvLGEscyl7bnVsbD09cyYmKHM9MSk7Y29uc3QgZj1pLmxlbmd0aCxsPVtdO2Zvcih2YXIgYz0wO2M8ZjtjKyspe2NvbnN0IGU9aVtjXTtsLnB1c2goW2U+Pj4wJjI1NSxlPj4+OCYyNTUsZT4+PjE2JjI1NSxlPj4+MjQmMjU1XSl9Zm9yKGM9MDtjPGY7YysrKXtsZXQgZT00Mjk0OTY3Mjk1O2Zvcih2YXIgdT0wLGg9MDtoPGY7aCsrKXt2YXIgZD1EKGxbY10sbFtoXSk7aCE9YyYmZDxlJiYoZT1kLHU9aCl9fWNvbnN0IEE9bmV3IFVpbnQzMkFycmF5KG8uYnVmZmVyKSxnPW5ldyBJbnQxNkFycmF5KHQqcio0KSxwPVswLDgsMiwxMCwxMiw0LDE0LDYsMywxMSwxLDksMTUsNywxMyw1XTtmb3IoYz0wO2M8cC5sZW5ndGg7YysrKXBbY109MjU1KigocFtjXSsuNSkvMTYtLjUpO2ZvcihsZXQgbz0wO288cjtvKyspZm9yKGxldCB3PTA7dzx0O3crKyl7dmFyIG07Yz00KihvKnQrdyk7aWYoMiE9cyltPVtOKGVbY10rZ1tjXSksTihlW2MrMV0rZ1tjKzFdKSxOKGVbYysyXStnW2MrMl0pLE4oZVtjKzNdK2dbYyszXSldO2Vsc2V7ZD1wWzQqKDMmbykrKDMmdyldO209W04oZVtjXStkKSxOKGVbYysxXStkKSxOKGVbYysyXStkKSxOKGVbYyszXStkKV19dT0wO2xldCB2PTE2Nzc3MjE1O2ZvcihoPTA7aDxmO2grKyl7Y29uc3QgZT1EKG0sbFtoXSk7ZTx2JiYodj1lLHU9aCl9Y29uc3QgYj1sW3VdLHk9W21bMF0tYlswXSxtWzFdLWJbMV0sbVsyXS1iWzJdLG1bM10tYlszXV07MT09cyYmKHchPXQtMSYmYWRkRXJyKHksZyxjKzQsNyksbyE9ci0xJiYoMCE9dyYmYWRkRXJyKHksZyxjKzQqdC00LDMpLGFkZEVycih5LGcsYys0KnQsNSksdyE9dC0xJiZhZGRFcnIoeSxnLGMrNCp0KzQsMSkpKSxhW2M+PjJdPXUsQVtjPj4yXT1pW3VdfX1mdW5jdGlvbiBfbWFpbihlLHIsbyxhLHMpe251bGw9PXMmJihzPXt9KTtjb25zdHtjcmM6Zn09aSxsPXQud3JpdGVVaW50LGM9dC53cml0ZVVzaG9ydCx1PXQud3JpdGVBU0NJSTtsZXQgaD04O2NvbnN0IGQ9ZS5mcmFtZXMubGVuZ3RoPjE7bGV0IEEsZz0hMSxwPTMzKyhkPzIwOjApO2lmKG51bGwhPXMuc1JHQiYmKHArPTEzKSxudWxsIT1zLnBIWXMmJihwKz0yMSksbnVsbCE9cy5pQ0NQJiYoQT1wYWtvLmRlZmxhdGUocy5pQ0NQKSxwKz0yMStBLmxlbmd0aCs0KSwzPT1lLmN0eXBlKXtmb3IodmFyIG09ZS5wbHRlLmxlbmd0aCx3PTA7dzxtO3crKyllLnBsdGVbd10+Pj4yNCE9MjU1JiYoZz0hMCk7cCs9OCszKm0rNCsoZz84KzEqbSs0OjApfWZvcih2YXIgdj0wO3Y8ZS5mcmFtZXMubGVuZ3RoO3YrKyl7ZCYmKHArPTM4KSxwKz0oRj1lLmZyYW1lc1t2XSkuY2ltZy5sZW5ndGgrMTIsMCE9diYmKHArPTQpfXArPTEyO2NvbnN0IGI9bmV3IFVpbnQ4QXJyYXkocCkseT1bMTM3LDgwLDc4LDcxLDEzLDEwLDI2LDEwXTtmb3Iodz0wO3c8ODt3KyspYlt3XT15W3ddO2lmKGwoYixoLDEzKSxoKz00LHUoYixoLFwiSUhEUlwiKSxoKz00LGwoYixoLHIpLGgrPTQsbChiLGgsbyksaCs9NCxiW2hdPWUuZGVwdGgsaCsrLGJbaF09ZS5jdHlwZSxoKyssYltoXT0wLGgrKyxiW2hdPTAsaCsrLGJbaF09MCxoKyssbChiLGgsZihiLGgtMTcsMTcpKSxoKz00LG51bGwhPXMuc1JHQiYmKGwoYixoLDEpLGgrPTQsdShiLGgsXCJzUkdCXCIpLGgrPTQsYltoXT1zLnNSR0IsaCsrLGwoYixoLGYoYixoLTUsNSkpLGgrPTQpLG51bGwhPXMuaUNDUCl7Y29uc3QgZT0xMytBLmxlbmd0aDtsKGIsaCxlKSxoKz00LHUoYixoLFwiaUNDUFwiKSxoKz00LHUoYixoLFwiSUNDIHByb2ZpbGVcIiksaCs9MTEsaCs9MixiLnNldChBLGgpLGgrPUEubGVuZ3RoLGwoYixoLGYoYixoLShlKzQpLGUrNCkpLGgrPTR9aWYobnVsbCE9cy5wSFlzJiYobChiLGgsOSksaCs9NCx1KGIsaCxcInBIWXNcIiksaCs9NCxsKGIsaCxzLnBIWXNbMF0pLGgrPTQsbChiLGgscy5wSFlzWzFdKSxoKz00LGJbaF09cy5wSFlzWzJdLGgrKyxsKGIsaCxmKGIsaC0xMywxMykpLGgrPTQpLGQmJihsKGIsaCw4KSxoKz00LHUoYixoLFwiYWNUTFwiKSxoKz00LGwoYixoLGUuZnJhbWVzLmxlbmd0aCksaCs9NCxsKGIsaCxudWxsIT1zLmxvb3A/cy5sb29wOjApLGgrPTQsbChiLGgsZihiLGgtMTIsMTIpKSxoKz00KSwzPT1lLmN0eXBlKXtsKGIsaCwzKihtPWUucGx0ZS5sZW5ndGgpKSxoKz00LHUoYixoLFwiUExURVwiKSxoKz00O2Zvcih3PTA7dzxtO3crKyl7Y29uc3QgdD0zKncscj1lLnBsdGVbd10saT0yNTUmcixvPXI+Pj44JjI1NSxhPXI+Pj4xNiYyNTU7YltoK3QrMF09aSxiW2grdCsxXT1vLGJbaCt0KzJdPWF9aWYoaCs9MyptLGwoYixoLGYoYixoLTMqbS00LDMqbSs0KSksaCs9NCxnKXtsKGIsaCxtKSxoKz00LHUoYixoLFwidFJOU1wiKSxoKz00O2Zvcih3PTA7dzxtO3crKyliW2grd109ZS5wbHRlW3ddPj4+MjQmMjU1O2grPW0sbChiLGgsZihiLGgtbS00LG0rNCkpLGgrPTR9fWxldCBFPTA7Zm9yKHY9MDt2PGUuZnJhbWVzLmxlbmd0aDt2Kyspe3ZhciBGPWUuZnJhbWVzW3ZdO2QmJihsKGIsaCwyNiksaCs9NCx1KGIsaCxcImZjVExcIiksaCs9NCxsKGIsaCxFKyspLGgrPTQsbChiLGgsRi5yZWN0LndpZHRoKSxoKz00LGwoYixoLEYucmVjdC5oZWlnaHQpLGgrPTQsbChiLGgsRi5yZWN0LngpLGgrPTQsbChiLGgsRi5yZWN0LnkpLGgrPTQsYyhiLGgsYVt2XSksaCs9MixjKGIsaCwxZTMpLGgrPTIsYltoXT1GLmRpc3Bvc2UsaCsrLGJbaF09Ri5ibGVuZCxoKyssbChiLGgsZihiLGgtMzAsMzApKSxoKz00KTtjb25zdCB0PUYuY2ltZztsKGIsaCwobT10Lmxlbmd0aCkrKDA9PXY/MDo0KSksaCs9NDtjb25zdCByPWg7dShiLGgsMD09dj9cIklEQVRcIjpcImZkQVRcIiksaCs9NCwwIT12JiYobChiLGgsRSsrKSxoKz00KSxiLnNldCh0LGgpLGgrPW0sbChiLGgsZihiLHIsaC1yKSksaCs9NH1yZXR1cm4gbChiLGgsMCksaCs9NCx1KGIsaCxcIklFTkRcIiksaCs9NCxsKGIsaCxmKGIsaC00LDQpKSxoKz00LGIuYnVmZmVyfWZ1bmN0aW9uIGNvbXByZXNzUE5HKGUsdCxyKXtmb3IobGV0IGk9MDtpPGUuZnJhbWVzLmxlbmd0aDtpKyspe2NvbnN0IG89ZS5mcmFtZXNbaV07by5yZWN0LndpZHRoO2NvbnN0IGE9by5yZWN0LmhlaWdodCxzPW5ldyBVaW50OEFycmF5KGEqby5icGwrYSk7by5jaW1nPV9maWx0ZXJaZXJvKG8uaW1nLGEsby5icHAsby5icGwscyx0LHIpfX1mdW5jdGlvbiBjb21wcmVzcyh0LHIsaSxvLGEpe2NvbnN0IHM9YVswXSxmPWFbMV0sbD1hWzJdLGM9YVszXSx1PWFbNF0saD1hWzVdO2xldCBkPTYsQT04LGc9MjU1O2Zvcih2YXIgcD0wO3A8dC5sZW5ndGg7cCsrKXtjb25zdCBlPW5ldyBVaW50OEFycmF5KHRbcF0pO2Zvcih2YXIgbT1lLmxlbmd0aCx3PTA7dzxtO3crPTQpZyY9ZVt3KzNdfWNvbnN0IHY9MjU1IT1nLGI9ZnVuY3Rpb24gZnJhbWl6ZSh0LHIsaSxvLGEscyl7Y29uc3QgZj1bXTtmb3IodmFyIGw9MDtsPHQubGVuZ3RoO2wrKyl7Y29uc3QgaD1uZXcgVWludDhBcnJheSh0W2xdKSxBPW5ldyBVaW50MzJBcnJheShoLmJ1ZmZlcik7dmFyIGM7bGV0IGc9MCxwPTAsbT1yLHc9aSx2PW8/MTowO2lmKDAhPWwpe2NvbnN0IGI9c3x8b3x8MT09bHx8MCE9ZltsLTJdLmRpc3Bvc2U/MToyO2xldCB5PTAsRT0xZTk7Zm9yKGxldCBlPTA7ZTxiO2UrKyl7dmFyIHU9bmV3IFVpbnQ4QXJyYXkodFtsLTEtZV0pO2NvbnN0IG89bmV3IFVpbnQzMkFycmF5KHRbbC0xLWVdKTtsZXQgcz1yLGY9aSxjPS0xLGg9LTE7Zm9yKGxldCBlPTA7ZTxpO2UrKylmb3IobGV0IHQ9MDt0PHI7dCsrKXtBW2Q9ZSpyK3RdIT1vW2RdJiYodDxzJiYocz10KSx0PmMmJihjPXQpLGU8ZiYmKGY9ZSksZT5oJiYoaD1lKSl9LTE9PWMmJihzPWY9Yz1oPTApLGEmJigxPT0oMSZzKSYmcy0tLDE9PSgxJmYpJiZmLS0pO2NvbnN0IHY9KGMtcysxKSooaC1mKzEpO3Y8RSYmKEU9dix5PWUsZz1zLHA9ZixtPWMtcysxLHc9aC1mKzEpfXU9bmV3IFVpbnQ4QXJyYXkodFtsLTEteV0pOzE9PXkmJihmW2wtMV0uZGlzcG9zZT0yKSxjPW5ldyBVaW50OEFycmF5KG0qdyo0KSxlKHUscixpLGMsbSx3LC1nLC1wLDApLHY9ZShoLHIsaSxjLG0sdywtZywtcCwzKT8xOjAsMT09dj9fcHJlcGFyZURpZmYoaCxyLGksYyx7eDpnLHk6cCx3aWR0aDptLGhlaWdodDp3fSk6ZShoLHIsaSxjLG0sdywtZywtcCwwKX1lbHNlIGM9aC5zbGljZSgwKTtmLnB1c2goe3JlY3Q6e3g6Zyx5OnAsd2lkdGg6bSxoZWlnaHQ6d30saW1nOmMsYmxlbmQ6dixkaXNwb3NlOjB9KX1pZihvKWZvcihsPTA7bDxmLmxlbmd0aDtsKyspe2lmKDE9PShBPWZbbF0pLmJsZW5kKWNvbnRpbnVlO2NvbnN0IGU9QS5yZWN0LG89ZltsLTFdLnJlY3Qscz1NYXRoLm1pbihlLngsby54KSxjPU1hdGgubWluKGUueSxvLnkpLHU9e3g6cyx5OmMsd2lkdGg6TWF0aC5tYXgoZS54K2Uud2lkdGgsby54K28ud2lkdGgpLXMsaGVpZ2h0Ok1hdGgubWF4KGUueStlLmhlaWdodCxvLnkrby5oZWlnaHQpLWN9O2ZbbC0xXS5kaXNwb3NlPTEsbC0xIT0wJiZfdXBkYXRlRnJhbWUodCxyLGksZixsLTEsdSxhKSxfdXBkYXRlRnJhbWUodCxyLGksZixsLHUsYSl9bGV0IGg9MDtpZigxIT10Lmxlbmd0aClmb3IodmFyIGQ9MDtkPGYubGVuZ3RoO2QrKyl7dmFyIEE7aCs9KEE9ZltkXSkucmVjdC53aWR0aCpBLnJlY3QuaGVpZ2h0fXJldHVybiBmfSh0LHIsaSxzLGYsbCkseT17fSxFPVtdLEY9W107aWYoMCE9byl7Y29uc3QgZT1bXTtmb3Iodz0wO3c8Yi5sZW5ndGg7dysrKWUucHVzaChiW3ddLmltZy5idWZmZXIpO2NvbnN0IHQ9ZnVuY3Rpb24gY29uY2F0UkdCQShlKXtsZXQgdD0wO2Zvcih2YXIgcj0wO3I8ZS5sZW5ndGg7cisrKXQrPWVbcl0uYnl0ZUxlbmd0aDtjb25zdCBpPW5ldyBVaW50OEFycmF5KHQpO2xldCBvPTA7Zm9yKHI9MDtyPGUubGVuZ3RoO3IrKyl7Y29uc3QgdD1uZXcgVWludDhBcnJheShlW3JdKSxhPXQubGVuZ3RoO2ZvcihsZXQgZT0wO2U8YTtlKz00KXtsZXQgcj10W2VdLGE9dFtlKzFdLHM9dFtlKzJdO2NvbnN0IGY9dFtlKzNdOzA9PWYmJihyPWE9cz0wKSxpW28rZV09cixpW28rZSsxXT1hLGlbbytlKzJdPXMsaVtvK2UrM109Zn1vKz1hfXJldHVybiBpLmJ1ZmZlcn0oZSkscj1xdWFudGl6ZSh0LG8pO2Zvcih3PTA7dzxyLnBsdGUubGVuZ3RoO3crKylFLnB1c2goci5wbHRlW3ddLmVzdC5yZ2JhKTtsZXQgaT0wO2Zvcih3PTA7dzxiLmxlbmd0aDt3Kyspe2NvbnN0IGU9KEI9Ylt3XSkuaW1nLmxlbmd0aDt2YXIgXz1uZXcgVWludDhBcnJheShyLmluZHMuYnVmZmVyLGk+PjIsZT4+Mik7Ri5wdXNoKF8pO2NvbnN0IHQ9bmV3IFVpbnQ4QXJyYXkoci5hYnVmLGksZSk7aCYmZGl0aGVyKEIuaW1nLEIucmVjdC53aWR0aCxCLnJlY3QuaGVpZ2h0LEUsdCxfKSxCLmltZy5zZXQodCksaSs9ZX19ZWxzZSBmb3IocD0wO3A8Yi5sZW5ndGg7cCsrKXt2YXIgQj1iW3BdO2NvbnN0IGU9bmV3IFVpbnQzMkFycmF5KEIuaW1nLmJ1ZmZlcik7dmFyIFU9Qi5yZWN0LndpZHRoO209ZS5sZW5ndGgsXz1uZXcgVWludDhBcnJheShtKTtGLnB1c2goXyk7Zm9yKHc9MDt3PG07dysrKXtjb25zdCB0PWVbd107aWYoMCE9dyYmdD09ZVt3LTFdKV9bd109X1t3LTFdO2Vsc2UgaWYodz5VJiZ0PT1lW3ctVV0pX1t3XT1fW3ctVV07ZWxzZXtsZXQgZT15W3RdO2lmKG51bGw9PWUmJih5W3RdPWU9RS5sZW5ndGgsRS5wdXNoKHQpLEUubGVuZ3RoPj0zMDApKWJyZWFrO19bd109ZX19fWNvbnN0IEM9RS5sZW5ndGg7Qzw9MjU2JiYwPT11JiYoQT1DPD0yPzE6Qzw9ND8yOkM8PTE2PzQ6OCxBPU1hdGgubWF4KEEsYykpO2ZvcihwPTA7cDxiLmxlbmd0aDtwKyspeyhCPWJbcF0pLnJlY3QueCxCLnJlY3QueTtVPUIucmVjdC53aWR0aDtjb25zdCBlPUIucmVjdC5oZWlnaHQ7bGV0IHQ9Qi5pbWc7bmV3IFVpbnQzMkFycmF5KHQuYnVmZmVyKTtsZXQgcj00KlUsaT00O2lmKEM8PTI1NiYmMD09dSl7cj1NYXRoLmNlaWwoQSpVLzgpO3ZhciBJPW5ldyBVaW50OEFycmF5KHIqZSk7Y29uc3Qgbz1GW3BdO2ZvcihsZXQgdD0wO3Q8ZTt0Kyspe3c9dCpyO2NvbnN0IGU9dCpVO2lmKDg9PUEpZm9yKHZhciBRPTA7UTxVO1ErKylJW3crUV09b1tlK1FdO2Vsc2UgaWYoND09QSlmb3IoUT0wO1E8VTtRKyspSVt3KyhRPj4xKV18PW9bZStRXTw8NC00KigxJlEpO2Vsc2UgaWYoMj09QSlmb3IoUT0wO1E8VTtRKyspSVt3KyhRPj4yKV18PW9bZStRXTw8Ni0yKigzJlEpO2Vsc2UgaWYoMT09QSlmb3IoUT0wO1E8VTtRKyspSVt3KyhRPj4zKV18PW9bZStRXTw8Ny0xKig3JlEpfXQ9SSxkPTMsaT0xfWVsc2UgaWYoMD09diYmMT09Yi5sZW5ndGgpe0k9bmV3IFVpbnQ4QXJyYXkoVSplKjMpO2NvbnN0IG89VSplO2Zvcih3PTA7dzxvO3crKyl7Y29uc3QgZT0zKncscj00Knc7SVtlXT10W3JdLElbZSsxXT10W3IrMV0sSVtlKzJdPXRbcisyXX10PUksZD0yLGk9MyxyPTMqVX1CLmltZz10LEIuYnBsPXIsQi5icHA9aX1yZXR1cm57Y3R5cGU6ZCxkZXB0aDpBLHBsdGU6RSxmcmFtZXM6Yn19ZnVuY3Rpb24gX3VwZGF0ZUZyYW1lKHQscixpLG8sYSxzLGYpe2NvbnN0IGw9VWludDhBcnJheSxjPVVpbnQzMkFycmF5LHU9bmV3IGwodFthLTFdKSxoPW5ldyBjKHRbYS0xXSksZD1hKzE8dC5sZW5ndGg/bmV3IGwodFthKzFdKTpudWxsLEE9bmV3IGwodFthXSksZz1uZXcgYyhBLmJ1ZmZlcik7bGV0IHA9cixtPWksdz0tMSx2PS0xO2ZvcihsZXQgZT0wO2U8cy5oZWlnaHQ7ZSsrKWZvcihsZXQgdD0wO3Q8cy53aWR0aDt0Kyspe2NvbnN0IGk9cy54K3QsZj1zLnkrZSxsPWYqcitpLGM9Z1tsXTswPT1jfHwwPT1vW2EtMV0uZGlzcG9zZSYmaFtsXT09YyYmKG51bGw9PWR8fDAhPWRbNCpsKzNdKXx8KGk8cCYmKHA9aSksaT53JiYodz1pKSxmPG0mJihtPWYpLGY+diYmKHY9ZikpfS0xPT13JiYocD1tPXc9dj0wKSxmJiYoMT09KDEmcCkmJnAtLSwxPT0oMSZtKSYmbS0tKSxzPXt4OnAseTptLHdpZHRoOnctcCsxLGhlaWdodDp2LW0rMX07Y29uc3QgYj1vW2FdO2IucmVjdD1zLGIuYmxlbmQ9MSxiLmltZz1uZXcgVWludDhBcnJheShzLndpZHRoKnMuaGVpZ2h0KjQpLDA9PW9bYS0xXS5kaXNwb3NlPyhlKHUscixpLGIuaW1nLHMud2lkdGgscy5oZWlnaHQsLXMueCwtcy55LDApLF9wcmVwYXJlRGlmZihBLHIsaSxiLmltZyxzKSk6ZShBLHIsaSxiLmltZyxzLndpZHRoLHMuaGVpZ2h0LC1zLngsLXMueSwwKX1mdW5jdGlvbiBfcHJlcGFyZURpZmYodCxyLGksbyxhKXtlKHQscixpLG8sYS53aWR0aCxhLmhlaWdodCwtYS54LC1hLnksMil9ZnVuY3Rpb24gX2ZpbHRlclplcm8oZSx0LHIsaSxvLGEscyl7Y29uc3QgZj1bXTtsZXQgbCxjPVswLDEsMiwzLDRdOy0xIT1hP2M9W2FdOih0Kmk+NWU1fHwxPT1yKSYmKGM9WzBdKSxzJiYobD17bGV2ZWw6MH0pO2NvbnN0IHU9VVpJUDtmb3IodmFyIGg9MDtoPGMubGVuZ3RoO2grKyl7Zm9yKGxldCBhPTA7YTx0O2ErKylfZmlsdGVyTGluZShvLGUsYSxpLHIsY1toXSk7Zi5wdXNoKHUuZGVmbGF0ZShvLGwpKX1sZXQgZCxBPTFlOTtmb3IoaD0wO2g8Zi5sZW5ndGg7aCsrKWZbaF0ubGVuZ3RoPEEmJihkPWgsQT1mW2hdLmxlbmd0aCk7cmV0dXJuIGZbZF19ZnVuY3Rpb24gX2ZpbHRlckxpbmUoZSx0LGksbyxhLHMpe2NvbnN0IGY9aSpvO2xldCBsPWYraTtpZihlW2xdPXMsbCsrLDA9PXMpaWYobzw1MDApZm9yKHZhciBjPTA7YzxvO2MrKyllW2wrY109dFtmK2NdO2Vsc2UgZS5zZXQobmV3IFVpbnQ4QXJyYXkodC5idWZmZXIsZixvKSxsKTtlbHNlIGlmKDE9PXMpe2ZvcihjPTA7YzxhO2MrKyllW2wrY109dFtmK2NdO2ZvcihjPWE7YzxvO2MrKyllW2wrY109dFtmK2NdLXRbZitjLWFdKzI1NiYyNTV9ZWxzZSBpZigwPT1pKXtmb3IoYz0wO2M8YTtjKyspZVtsK2NdPXRbZitjXTtpZigyPT1zKWZvcihjPWE7YzxvO2MrKyllW2wrY109dFtmK2NdO2lmKDM9PXMpZm9yKGM9YTtjPG87YysrKWVbbCtjXT10W2YrY10tKHRbZitjLWFdPj4xKSsyNTYmMjU1O2lmKDQ9PXMpZm9yKGM9YTtjPG87YysrKWVbbCtjXT10W2YrY10tcih0W2YrYy1hXSwwLDApKzI1NiYyNTV9ZWxzZXtpZigyPT1zKWZvcihjPTA7YzxvO2MrKyllW2wrY109dFtmK2NdKzI1Ni10W2YrYy1vXSYyNTU7aWYoMz09cyl7Zm9yKGM9MDtjPGE7YysrKWVbbCtjXT10W2YrY10rMjU2LSh0W2YrYy1vXT4+MSkmMjU1O2ZvcihjPWE7YzxvO2MrKyllW2wrY109dFtmK2NdKzI1Ni0odFtmK2Mtb10rdFtmK2MtYV0+PjEpJjI1NX1pZig0PT1zKXtmb3IoYz0wO2M8YTtjKyspZVtsK2NdPXRbZitjXSsyNTYtcigwLHRbZitjLW9dLDApJjI1NTtmb3IoYz1hO2M8bztjKyspZVtsK2NdPXRbZitjXSsyNTYtcih0W2YrYy1hXSx0W2YrYy1vXSx0W2YrYy1hLW9dKSYyNTV9fX1mdW5jdGlvbiBxdWFudGl6ZShlLHQpe2NvbnN0IHI9bmV3IFVpbnQ4QXJyYXkoZSksaT1yLnNsaWNlKDApLG89bmV3IFVpbnQzMkFycmF5KGkuYnVmZmVyKSxhPWdldEtEdHJlZShpLHQpLHM9YVswXSxmPWFbMV0sbD1yLmxlbmd0aCxjPW5ldyBVaW50OEFycmF5KGw+PjIpO2xldCB1O2lmKHIubGVuZ3RoPDJlNylmb3IodmFyIGg9MDtoPGw7aCs9NCl7dT1nZXROZWFyZXN0KHMsZD1yW2hdKigxLzI1NSksQT1yW2grMV0qKDEvMjU1KSxnPXJbaCsyXSooMS8yNTUpLHA9cltoKzNdKigxLzI1NSkpLGNbaD4+Ml09dS5pbmQsb1toPj4yXT11LmVzdC5yZ2JhfWVsc2UgZm9yKGg9MDtoPGw7aCs9NCl7dmFyIGQ9cltoXSooMS8yNTUpLEE9cltoKzFdKigxLzI1NSksZz1yW2grMl0qKDEvMjU1KSxwPXJbaCszXSooMS8yNTUpO2Zvcih1PXM7dS5sZWZ0Oyl1PXBsYW5lRHN0KHUuZXN0LGQsQSxnLHApPD0wP3UubGVmdDp1LnJpZ2h0O2NbaD4+Ml09dS5pbmQsb1toPj4yXT11LmVzdC5yZ2JhfXJldHVybnthYnVmOmkuYnVmZmVyLGluZHM6YyxwbHRlOmZ9fWZ1bmN0aW9uIGdldEtEdHJlZShlLHQscil7bnVsbD09ciYmKHI9MWUtNCk7Y29uc3QgaT1uZXcgVWludDMyQXJyYXkoZS5idWZmZXIpLG89e2kwOjAsaTE6ZS5sZW5ndGgsYnN0Om51bGwsZXN0Om51bGwsdGRzdDowLGxlZnQ6bnVsbCxyaWdodDpudWxsfTtvLmJzdD1zdGF0cyhlLG8uaTAsby5pMSksby5lc3Q9ZXN0YXRzKG8uYnN0KTtjb25zdCBhPVtvXTtmb3IoO2EubGVuZ3RoPHQ7KXtsZXQgdD0wLG89MDtmb3IodmFyIHM9MDtzPGEubGVuZ3RoO3MrKylhW3NdLmVzdC5MPnQmJih0PWFbc10uZXN0Lkwsbz1zKTtpZih0PHIpYnJlYWs7Y29uc3QgZj1hW29dLGw9c3BsaXRQaXhlbHMoZSxpLGYuaTAsZi5pMSxmLmVzdC5lLGYuZXN0LmVNcTI1NSk7aWYoZi5pMD49bHx8Zi5pMTw9bCl7Zi5lc3QuTD0wO2NvbnRpbnVlfWNvbnN0IGM9e2kwOmYuaTAsaTE6bCxic3Q6bnVsbCxlc3Q6bnVsbCx0ZHN0OjAsbGVmdDpudWxsLHJpZ2h0Om51bGx9O2MuYnN0PXN0YXRzKGUsYy5pMCxjLmkxKSxjLmVzdD1lc3RhdHMoYy5ic3QpO2NvbnN0IHU9e2kwOmwsaTE6Zi5pMSxic3Q6bnVsbCxlc3Q6bnVsbCx0ZHN0OjAsbGVmdDpudWxsLHJpZ2h0Om51bGx9O3UuYnN0PXtSOltdLG06W10sTjpmLmJzdC5OLWMuYnN0Lk59O2ZvcihzPTA7czwxNjtzKyspdS5ic3QuUltzXT1mLmJzdC5SW3NdLWMuYnN0LlJbc107Zm9yKHM9MDtzPDQ7cysrKXUuYnN0Lm1bc109Zi5ic3QubVtzXS1jLmJzdC5tW3NdO3UuZXN0PWVzdGF0cyh1LmJzdCksZi5sZWZ0PWMsZi5yaWdodD11LGFbb109YyxhLnB1c2godSl9YS5zb3J0KCgoZSx0KT0+dC5ic3QuTi1lLmJzdC5OKSk7Zm9yKHM9MDtzPGEubGVuZ3RoO3MrKylhW3NdLmluZD1zO3JldHVybltvLGFdfWZ1bmN0aW9uIGdldE5lYXJlc3QoZSx0LHIsaSxvKXtpZihudWxsPT1lLmxlZnQpcmV0dXJuIGUudGRzdD1mdW5jdGlvbiBkaXN0KGUsdCxyLGksbyl7Y29uc3QgYT10LWVbMF0scz1yLWVbMV0sZj1pLWVbMl0sbD1vLWVbM107cmV0dXJuIGEqYStzKnMrZipmK2wqbH0oZS5lc3QucSx0LHIsaSxvKSxlO2NvbnN0IGE9cGxhbmVEc3QoZS5lc3QsdCxyLGksbyk7bGV0IHM9ZS5sZWZ0LGY9ZS5yaWdodDthPjAmJihzPWUucmlnaHQsZj1lLmxlZnQpO2NvbnN0IGw9Z2V0TmVhcmVzdChzLHQscixpLG8pO2lmKGwudGRzdDw9YSphKXJldHVybiBsO2NvbnN0IGM9Z2V0TmVhcmVzdChmLHQscixpLG8pO3JldHVybiBjLnRkc3Q8bC50ZHN0P2M6bH1mdW5jdGlvbiBwbGFuZURzdChlLHQscixpLG8pe2NvbnN0e2U6YX09ZTtyZXR1cm4gYVswXSp0K2FbMV0qcithWzJdKmkrYVszXSpvLWUuZU1xfWZ1bmN0aW9uIHNwbGl0UGl4ZWxzKGUsdCxyLGksbyxhKXtmb3IoaS09NDtyPGk7KXtmb3IoO3ZlY0RvdChlLHIsbyk8PWE7KXIrPTQ7Zm9yKDt2ZWNEb3QoZSxpLG8pPmE7KWktPTQ7aWYocj49aSlicmVhaztjb25zdCBzPXRbcj4+Ml07dFtyPj4yXT10W2k+PjJdLHRbaT4+Ml09cyxyKz00LGktPTR9Zm9yKDt2ZWNEb3QoZSxyLG8pPmE7KXItPTQ7cmV0dXJuIHIrNH1mdW5jdGlvbiB2ZWNEb3QoZSx0LHIpe3JldHVybiBlW3RdKnJbMF0rZVt0KzFdKnJbMV0rZVt0KzJdKnJbMl0rZVt0KzNdKnJbM119ZnVuY3Rpb24gc3RhdHMoZSx0LHIpe2NvbnN0IGk9WzAsMCwwLDAsMCwwLDAsMCwwLDAsMCwwLDAsMCwwLDBdLG89WzAsMCwwLDBdLGE9ci10Pj4yO2ZvcihsZXQgYT10O2E8cjthKz00KXtjb25zdCB0PWVbYV0qKDEvMjU1KSxyPWVbYSsxXSooMS8yNTUpLHM9ZVthKzJdKigxLzI1NSksZj1lW2ErM10qKDEvMjU1KTtvWzBdKz10LG9bMV0rPXIsb1syXSs9cyxvWzNdKz1mLGlbMF0rPXQqdCxpWzFdKz10KnIsaVsyXSs9dCpzLGlbM10rPXQqZixpWzVdKz1yKnIsaVs2XSs9cipzLGlbN10rPXIqZixpWzEwXSs9cypzLGlbMTFdKz1zKmYsaVsxNV0rPWYqZn1yZXR1cm4gaVs0XT1pWzFdLGlbOF09aVsyXSxpWzldPWlbNl0saVsxMl09aVszXSxpWzEzXT1pWzddLGlbMTRdPWlbMTFdLHtSOmksbTpvLE46YX19ZnVuY3Rpb24gZXN0YXRzKGUpe2NvbnN0e1I6dH09ZSx7bTpyfT1lLHtOOml9PWUsYT1yWzBdLHM9clsxXSxmPXJbMl0sbD1yWzNdLGM9MD09aT8wOjEvaSx1PVt0WzBdLWEqYSpjLHRbMV0tYSpzKmMsdFsyXS1hKmYqYyx0WzNdLWEqbCpjLHRbNF0tcyphKmMsdFs1XS1zKnMqYyx0WzZdLXMqZipjLHRbN10tcypsKmMsdFs4XS1mKmEqYyx0WzldLWYqcypjLHRbMTBdLWYqZipjLHRbMTFdLWYqbCpjLHRbMTJdLWwqYSpjLHRbMTNdLWwqcypjLHRbMTRdLWwqZipjLHRbMTVdLWwqbCpjXSxoPXUsZD1vO2xldCBBPVtNYXRoLnJhbmRvbSgpLE1hdGgucmFuZG9tKCksTWF0aC5yYW5kb20oKSxNYXRoLnJhbmRvbSgpXSxnPTAscD0wO2lmKDAhPWkpZm9yKGxldCBlPTA7ZTwxNiYmKEE9ZC5tdWx0VmVjKGgsQSkscD1NYXRoLnNxcnQoZC5kb3QoQSxBKSksQT1kLnNtbCgxL3AsQSksISgwIT1lJiZNYXRoLmFicyhwLWcpPDFlLTkpKTtlKyspZz1wO2NvbnN0IG09W2EqYyxzKmMsZipjLGwqY107cmV0dXJue0Nvdjp1LHE6bSxlOkEsTDpnLGVNcTI1NTpkLmRvdChkLnNtbCgyNTUsbSksQSksZU1xOmQuZG90KEEsbSkscmdiYTooTWF0aC5yb3VuZCgyNTUqbVszXSk8PDI0fE1hdGgucm91bmQoMjU1Km1bMl0pPDwxNnxNYXRoLnJvdW5kKDI1NSptWzFdKTw8OHxNYXRoLnJvdW5kKDI1NSptWzBdKTw8MCk+Pj4wfX12YXIgbz17bXVsdFZlYzooZSx0KT0+W2VbMF0qdFswXStlWzFdKnRbMV0rZVsyXSp0WzJdK2VbM10qdFszXSxlWzRdKnRbMF0rZVs1XSp0WzFdK2VbNl0qdFsyXStlWzddKnRbM10sZVs4XSp0WzBdK2VbOV0qdFsxXStlWzEwXSp0WzJdK2VbMTFdKnRbM10sZVsxMl0qdFswXStlWzEzXSp0WzFdK2VbMTRdKnRbMl0rZVsxNV0qdFszXV0sZG90OihlLHQpPT5lWzBdKnRbMF0rZVsxXSp0WzFdK2VbMl0qdFsyXStlWzNdKnRbM10sc21sOihlLHQpPT5bZSp0WzBdLGUqdFsxXSxlKnRbMl0sZSp0WzNdXX07VVBORy5lbmNvZGU9ZnVuY3Rpb24gZW5jb2RlKGUsdCxyLGksbyxhLHMpe251bGw9PWkmJihpPTApLG51bGw9PXMmJihzPSExKTtjb25zdCBmPWNvbXByZXNzKGUsdCxyLGksWyExLCExLCExLDAscywhMV0pO3JldHVybiBjb21wcmVzc1BORyhmLC0xKSxfbWFpbihmLHQscixvLGEpfSxVUE5HLmVuY29kZUxMPWZ1bmN0aW9uIGVuY29kZUxMKGUsdCxyLGksbyxhLHMsZil7Y29uc3QgbD17Y3R5cGU6MCsoMT09aT8wOjIpKygwPT1vPzA6NCksZGVwdGg6YSxmcmFtZXM6W119LGM9KGkrbykqYSx1PWMqdDtmb3IobGV0IGk9MDtpPGUubGVuZ3RoO2krKylsLmZyYW1lcy5wdXNoKHtyZWN0Ont4OjAseTowLHdpZHRoOnQsaGVpZ2h0OnJ9LGltZzpuZXcgVWludDhBcnJheShlW2ldKSxibGVuZDowLGRpc3Bvc2U6MSxicHA6TWF0aC5jZWlsKGMvOCksYnBsOk1hdGguY2VpbCh1LzgpfSk7cmV0dXJuIGNvbXByZXNzUE5HKGwsMCwhMCksX21haW4obCx0LHIscyxmKX0sVVBORy5lbmNvZGUuY29tcHJlc3M9Y29tcHJlc3MsVVBORy5lbmNvZGUuZGl0aGVyPWRpdGhlcixVUE5HLnF1YW50aXplPXF1YW50aXplLFVQTkcucXVhbnRpemUuZ2V0S0R0cmVlPWdldEtEdHJlZSxVUE5HLnF1YW50aXplLmdldE5lYXJlc3Q9Z2V0TmVhcmVzdH0oKTtjb25zdCByPXt0b0FycmF5QnVmZmVyKGUsdCl7Y29uc3QgaT1lLndpZHRoLG89ZS5oZWlnaHQsYT1pPDwyLHM9ZS5nZXRDb250ZXh0KFwiMmRcIikuZ2V0SW1hZ2VEYXRhKDAsMCxpLG8pLGY9bmV3IFVpbnQzMkFycmF5KHMuZGF0YS5idWZmZXIpLGw9KDMyKmkrMzEpLzMyPDwyLGM9bCpvLHU9MTIyK2MsaD1uZXcgQXJyYXlCdWZmZXIodSksZD1uZXcgRGF0YVZpZXcoaCksQT0xPDwyMDtsZXQgZyxwLG0sdyx2PUEsYj0wLHk9MCxFPTA7ZnVuY3Rpb24gc2V0MTYoZSl7ZC5zZXRVaW50MTYoeSxlLCEwKSx5Kz0yfWZ1bmN0aW9uIHNldDMyKGUpe2Quc2V0VWludDMyKHksZSwhMCkseSs9NH1mdW5jdGlvbiBzZWVrKGUpe3krPWV9c2V0MTYoMTk3NzgpLHNldDMyKHUpLHNlZWsoNCksc2V0MzIoMTIyKSxzZXQzMigxMDgpLHNldDMyKGkpLHNldDMyKC1vPj4+MCksc2V0MTYoMSksc2V0MTYoMzIpLHNldDMyKDMpLHNldDMyKGMpLHNldDMyKDI4MzUpLHNldDMyKDI4MzUpLHNlZWsoOCksc2V0MzIoMTY3MTE2ODApLHNldDMyKDY1MjgwKSxzZXQzMigyNTUpLHNldDMyKDQyNzgxOTAwODApLHNldDMyKDE0NjY1MjcyNjQpLGZ1bmN0aW9uIGNvbnZlcnQoKXtmb3IoO2I8byYmdj4wOyl7Zm9yKHc9MTIyK2IqbCxnPTA7ZzxhOyl2LS0scD1mW0UrK10sbT1wPj4+MjQsZC5zZXRVaW50MzIodytnLHA8PDh8bSksZys9NDtiKyt9RTxmLmxlbmd0aD8odj1BLHNldFRpbWVvdXQoY29udmVydCxyLl9kbHkpKTp0KGgpfSgpfSx0b0Jsb2IoZSx0KXt0aGlzLnRvQXJyYXlCdWZmZXIoZSwoZT0+e3QobmV3IEJsb2IoW2VdLHt0eXBlOlwiaW1hZ2UvYm1wXCJ9KSl9KSl9LF9kbHk6OX07dmFyIGk9e0NIUk9NRTpcIkNIUk9NRVwiLEZJUkVGT1g6XCJGSVJFRk9YXCIsREVTS1RPUF9TQUZBUkk6XCJERVNLVE9QX1NBRkFSSVwiLElFOlwiSUVcIixJT1M6XCJJT1NcIixFVEM6XCJFVENcIn0sbz17W2kuQ0hST01FXToxNjM4NCxbaS5GSVJFRk9YXToxMTE4MCxbaS5ERVNLVE9QX1NBRkFSSV06MTYzODQsW2kuSUVdOjgxOTIsW2kuSU9TXTo0MDk2LFtpLkVUQ106ODE5Mn07Y29uc3QgYT1cInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93LHM9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIFdvcmtlckdsb2JhbFNjb3BlJiZzZWxmIGluc3RhbmNlb2YgV29ya2VyR2xvYmFsU2NvcGUsZj1hJiZ3aW5kb3cuY29yZG92YSYmd2luZG93LmNvcmRvdmEucmVxdWlyZSYmd2luZG93LmNvcmRvdmEucmVxdWlyZShcImNvcmRvdmEvbW9kdWxlbWFwcGVyXCIpLEN1c3RvbUZpbGU9KGF8fHMpJiYoZiYmZi5nZXRPcmlnaW5hbFN5bWJvbCh3aW5kb3csXCJGaWxlXCIpfHxcInVuZGVmaW5lZFwiIT10eXBlb2YgRmlsZSYmRmlsZSksQ3VzdG9tRmlsZVJlYWRlcj0oYXx8cykmJihmJiZmLmdldE9yaWdpbmFsU3ltYm9sKHdpbmRvdyxcIkZpbGVSZWFkZXJcIil8fFwidW5kZWZpbmVkXCIhPXR5cGVvZiBGaWxlUmVhZGVyJiZGaWxlUmVhZGVyKTtmdW5jdGlvbiBnZXRGaWxlZnJvbURhdGFVcmwoZSx0LHI9RGF0ZS5ub3coKSl7cmV0dXJuIG5ldyBQcm9taXNlKChpPT57Y29uc3Qgbz1lLnNwbGl0KFwiLFwiKSxhPW9bMF0ubWF0Y2goLzooLio/KTsvKVsxXSxzPWdsb2JhbFRoaXMuYXRvYihvWzFdKTtsZXQgZj1zLmxlbmd0aDtjb25zdCBsPW5ldyBVaW50OEFycmF5KGYpO2Zvcig7Zi0tOylsW2ZdPXMuY2hhckNvZGVBdChmKTtjb25zdCBjPW5ldyBCbG9iKFtsXSx7dHlwZTphfSk7Yy5uYW1lPXQsYy5sYXN0TW9kaWZpZWQ9cixpKGMpfSkpfWZ1bmN0aW9uIGdldERhdGFVcmxGcm9tRmlsZShlKXtyZXR1cm4gbmV3IFByb21pc2UoKCh0LHIpPT57Y29uc3QgaT1uZXcgQ3VzdG9tRmlsZVJlYWRlcjtpLm9ubG9hZD0oKT0+dChpLnJlc3VsdCksaS5vbmVycm9yPWU9PnIoZSksaS5yZWFkQXNEYXRhVVJMKGUpfSkpfWZ1bmN0aW9uIGxvYWRJbWFnZShlKXtyZXR1cm4gbmV3IFByb21pc2UoKCh0LHIpPT57Y29uc3QgaT1uZXcgSW1hZ2U7aS5vbmxvYWQ9KCk9PnQoaSksaS5vbmVycm9yPWU9PnIoZSksaS5zcmM9ZX0pKX1mdW5jdGlvbiBnZXRCcm93c2VyTmFtZSgpe2lmKHZvaWQgMCE9PWdldEJyb3dzZXJOYW1lLmNhY2hlZFJlc3VsdClyZXR1cm4gZ2V0QnJvd3Nlck5hbWUuY2FjaGVkUmVzdWx0O2xldCBlPWkuRVRDO2NvbnN0e3VzZXJBZ2VudDp0fT1uYXZpZ2F0b3I7cmV0dXJuL0Nocm9tKGV8aXVtKS9pLnRlc3QodCk/ZT1pLkNIUk9NRTovaVAoYWR8b2R8aG9uZSkvaS50ZXN0KHQpJiYvV2ViS2l0L2kudGVzdCh0KT9lPWkuSU9TOi9TYWZhcmkvaS50ZXN0KHQpP2U9aS5ERVNLVE9QX1NBRkFSSTovRmlyZWZveC9pLnRlc3QodCk/ZT1pLkZJUkVGT1g6KC9NU0lFL2kudGVzdCh0KXx8ITA9PSEhZG9jdW1lbnQuZG9jdW1lbnRNb2RlKSYmKGU9aS5JRSksZ2V0QnJvd3Nlck5hbWUuY2FjaGVkUmVzdWx0PWUsZ2V0QnJvd3Nlck5hbWUuY2FjaGVkUmVzdWx0fWZ1bmN0aW9uIGFwcHJveGltYXRlQmVsb3dNYXhpbXVtQ2FudmFzU2l6ZU9mQnJvd3NlcihlLHQpe2NvbnN0IHI9Z2V0QnJvd3Nlck5hbWUoKSxpPW9bcl07bGV0IGE9ZSxzPXQsZj1hKnM7Y29uc3QgbD1hPnM/cy9hOmEvcztmb3IoO2Y+aSppOyl7Y29uc3QgZT0oaSthKS8yLHQ9KGkrcykvMjtlPHQ/KHM9dCxhPXQqbCk6KHM9ZSpsLGE9ZSksZj1hKnN9cmV0dXJue3dpZHRoOmEsaGVpZ2h0OnN9fWZ1bmN0aW9uIGdldE5ld0NhbnZhc0FuZEN0eChlLHQpe2xldCByLGk7dHJ5e2lmKHI9bmV3IE9mZnNjcmVlbkNhbnZhcyhlLHQpLGk9ci5nZXRDb250ZXh0KFwiMmRcIiksbnVsbD09PWkpdGhyb3cgbmV3IEVycm9yKFwiZ2V0Q29udGV4dCBvZiBPZmZzY3JlZW5DYW52YXMgcmV0dXJucyBudWxsXCIpfWNhdGNoKGUpe3I9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKSxpPXIuZ2V0Q29udGV4dChcIjJkXCIpfXJldHVybiByLndpZHRoPWUsci5oZWlnaHQ9dCxbcixpXX1mdW5jdGlvbiBkcmF3SW1hZ2VJbkNhbnZhcyhlLHQpe2NvbnN0e3dpZHRoOnIsaGVpZ2h0Oml9PWFwcHJveGltYXRlQmVsb3dNYXhpbXVtQ2FudmFzU2l6ZU9mQnJvd3NlcihlLndpZHRoLGUuaGVpZ2h0KSxbbyxhXT1nZXROZXdDYW52YXNBbmRDdHgocixpKTtyZXR1cm4gdCYmL2pwZT9nLy50ZXN0KHQpJiYoYS5maWxsU3R5bGU9XCJ3aGl0ZVwiLGEuZmlsbFJlY3QoMCwwLG8ud2lkdGgsby5oZWlnaHQpKSxhLmRyYXdJbWFnZShlLDAsMCxvLndpZHRoLG8uaGVpZ2h0KSxvfWZ1bmN0aW9uIGlzSU9TKCl7cmV0dXJuIHZvaWQgMCE9PWlzSU9TLmNhY2hlZFJlc3VsdHx8KGlzSU9TLmNhY2hlZFJlc3VsdD1bXCJpUGFkIFNpbXVsYXRvclwiLFwiaVBob25lIFNpbXVsYXRvclwiLFwiaVBvZCBTaW11bGF0b3JcIixcImlQYWRcIixcImlQaG9uZVwiLFwiaVBvZFwiXS5pbmNsdWRlcyhuYXZpZ2F0b3IucGxhdGZvcm0pfHxuYXZpZ2F0b3IudXNlckFnZW50LmluY2x1ZGVzKFwiTWFjXCIpJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgZG9jdW1lbnQmJlwib250b3VjaGVuZFwiaW4gZG9jdW1lbnQpLGlzSU9TLmNhY2hlZFJlc3VsdH1mdW5jdGlvbiBkcmF3RmlsZUluQ2FudmFzKGUsdD17fSl7cmV0dXJuIG5ldyBQcm9taXNlKChmdW5jdGlvbihyLG8pe2xldCBhLHM7dmFyICRUcnlfMl9Qb3N0PWZ1bmN0aW9uKCl7dHJ5e3JldHVybiBzPWRyYXdJbWFnZUluQ2FudmFzKGEsdC5maWxlVHlwZXx8ZS50eXBlKSxyKFthLHNdKX1jYXRjaChlKXtyZXR1cm4gbyhlKX19LCRUcnlfMl9DYXRjaD1mdW5jdGlvbih0KXt0cnl7MDt2YXIgJFRyeV8zX0NhdGNoPWZ1bmN0aW9uKGUpe3RyeXt0aHJvdyBlfWNhdGNoKGUpe3JldHVybiBvKGUpfX07dHJ5e2xldCB0O3JldHVybiBnZXREYXRhVXJsRnJvbUZpbGUoZSkudGhlbigoZnVuY3Rpb24oZSl7dHJ5e3JldHVybiB0PWUsbG9hZEltYWdlKHQpLnRoZW4oKGZ1bmN0aW9uKGUpe3RyeXtyZXR1cm4gYT1lLGZ1bmN0aW9uKCl7dHJ5e3JldHVybiAkVHJ5XzJfUG9zdCgpfWNhdGNoKGUpe3JldHVybiBvKGUpfX0oKX1jYXRjaChlKXtyZXR1cm4gJFRyeV8zX0NhdGNoKGUpfX0pLCRUcnlfM19DYXRjaCl9Y2F0Y2goZSl7cmV0dXJuICRUcnlfM19DYXRjaChlKX19KSwkVHJ5XzNfQ2F0Y2gpfWNhdGNoKGUpeyRUcnlfM19DYXRjaChlKX19Y2F0Y2goZSl7cmV0dXJuIG8oZSl9fTt0cnl7aWYoaXNJT1MoKXx8W2kuREVTS1RPUF9TQUZBUkksaS5NT0JJTEVfU0FGQVJJXS5pbmNsdWRlcyhnZXRCcm93c2VyTmFtZSgpKSl0aHJvdyBuZXcgRXJyb3IoXCJTa2lwIGNyZWF0ZUltYWdlQml0bWFwIG9uIElPUyBhbmQgU2FmYXJpXCIpO3JldHVybiBjcmVhdGVJbWFnZUJpdG1hcChlKS50aGVuKChmdW5jdGlvbihlKXt0cnl7cmV0dXJuIGE9ZSwkVHJ5XzJfUG9zdCgpfWNhdGNoKGUpe3JldHVybiAkVHJ5XzJfQ2F0Y2goKX19KSwkVHJ5XzJfQ2F0Y2gpfWNhdGNoKGUpeyRUcnlfMl9DYXRjaCgpfX0pKX1mdW5jdGlvbiBjYW52YXNUb0ZpbGUoZSx0LGksbyxhPTEpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24ocyxmKXtsZXQgbDtpZihcImltYWdlL3BuZ1wiPT09dCl7bGV0IGMsdSxoO3JldHVybiBjPWUuZ2V0Q29udGV4dChcIjJkXCIpLCh7ZGF0YTp1fT1jLmdldEltYWdlRGF0YSgwLDAsZS53aWR0aCxlLmhlaWdodCkpLGg9VVBORy5lbmNvZGUoW3UuYnVmZmVyXSxlLndpZHRoLGUuaGVpZ2h0LDQwOTYqYSksbD1uZXcgQmxvYihbaF0se3R5cGU6dH0pLGwubmFtZT1pLGwubGFzdE1vZGlmaWVkPW8sJElmXzQuY2FsbCh0aGlzKX17aWYoXCJpbWFnZS9ibXBcIj09PXQpcmV0dXJuIG5ldyBQcm9taXNlKCh0PT5yLnRvQmxvYihlLHQpKSkudGhlbihmdW5jdGlvbihlKXt0cnl7cmV0dXJuIGw9ZSxsLm5hbWU9aSxsLmxhc3RNb2RpZmllZD1vLCRJZl81LmNhbGwodGhpcyl9Y2F0Y2goZSl7cmV0dXJuIGYoZSl9fS5iaW5kKHRoaXMpLGYpO3tpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiBPZmZzY3JlZW5DYW52YXMmJmUgaW5zdGFuY2VvZiBPZmZzY3JlZW5DYW52YXMpcmV0dXJuIGUuY29udmVydFRvQmxvYih7dHlwZTp0LHF1YWxpdHk6YX0pLnRoZW4oZnVuY3Rpb24oZSl7dHJ5e3JldHVybiBsPWUsbC5uYW1lPWksbC5sYXN0TW9kaWZpZWQ9bywkSWZfNi5jYWxsKHRoaXMpfWNhdGNoKGUpe3JldHVybiBmKGUpfX0uYmluZCh0aGlzKSxmKTt7bGV0IGQ7cmV0dXJuIGQ9ZS50b0RhdGFVUkwodCxhKSxnZXRGaWxlZnJvbURhdGFVcmwoZCxpLG8pLnRoZW4oZnVuY3Rpb24oZSl7dHJ5e3JldHVybiBsPWUsJElmXzYuY2FsbCh0aGlzKX1jYXRjaChlKXtyZXR1cm4gZihlKX19LmJpbmQodGhpcyksZil9ZnVuY3Rpb24gJElmXzYoKXtyZXR1cm4gJElmXzUuY2FsbCh0aGlzKX19ZnVuY3Rpb24gJElmXzUoKXtyZXR1cm4gJElmXzQuY2FsbCh0aGlzKX19ZnVuY3Rpb24gJElmXzQoKXtyZXR1cm4gcyhsKX19KSl9ZnVuY3Rpb24gY2xlYW51cENhbnZhc01lbW9yeShlKXtlLndpZHRoPTAsZS5oZWlnaHQ9MH1mdW5jdGlvbiBpc0F1dG9PcmllbnRhdGlvbkluQnJvd3Nlcigpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24oZSx0KXtsZXQgcixpLG8sYSxzO3JldHVybiB2b2lkIDAhPT1pc0F1dG9PcmllbnRhdGlvbkluQnJvd3Nlci5jYWNoZWRSZXN1bHQ/ZShpc0F1dG9PcmllbnRhdGlvbkluQnJvd3Nlci5jYWNoZWRSZXN1bHQpOihyPVwiZGF0YTppbWFnZS9qcGVnO2Jhc2U2NCwvOWovNFFBaVJYaHBaZ0FBVFUwQUtnQUFBQWdBQVFFU0FBTUFBQUFCQUFZQUFBQUFBQUQvMndDRUFBRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBZi9BQUJFSUFBRUFBZ01CRVFBQ0VRRURFUUgveEFCS0FBRUFBQUFBQUFBQUFBQUFBQUFBQUFBTEVBRUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFRRUFBQUFBQUFBQUFBQUFBQUFBQUFBQUVRRUFBQUFBQUFBQUFBQUFBQUFBQUFBQS85b0FEQU1CQUFJUkF4RUFQd0EvOEgvLzJRPT1cIixnZXRGaWxlZnJvbURhdGFVcmwoXCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0LC85ai80UUFpUlhocFpnQUFUVTBBS2dBQUFBZ0FBUUVTQUFNQUFBQUJBQVlBQUFBQUFBRC8yd0NFQUFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFRRUJBUUVCQVFFQkFmL0FBQkVJQUFFQUFnTUJFUUFDRVFFREVRSC94QUJLQUFFQUFBQUFBQUFBQUFBQUFBQUFBQUFMRUFFQUFBQUFBQUFBQUFBQUFBQUFBQUFBQVFFQUFBQUFBQUFBQUFBQUFBQUFBQUFBRVFFQUFBQUFBQUFBQUFBQUFBQUFBQUFBLzlvQURBTUJBQUlSQXhFQVB3QS84SC8vMlE9PVwiLFwidGVzdC5qcGdcIixEYXRlLm5vdygpKS50aGVuKChmdW5jdGlvbihyKXt0cnl7cmV0dXJuIGk9cixkcmF3RmlsZUluQ2FudmFzKGkpLnRoZW4oKGZ1bmN0aW9uKHIpe3RyeXtyZXR1cm4gbz1yWzFdLGNhbnZhc1RvRmlsZShvLGkudHlwZSxpLm5hbWUsaS5sYXN0TW9kaWZpZWQpLnRoZW4oKGZ1bmN0aW9uKHIpe3RyeXtyZXR1cm4gYT1yLGNsZWFudXBDYW52YXNNZW1vcnkobyksZHJhd0ZpbGVJbkNhbnZhcyhhKS50aGVuKChmdW5jdGlvbihyKXt0cnl7cmV0dXJuIHM9clswXSxpc0F1dG9PcmllbnRhdGlvbkluQnJvd3Nlci5jYWNoZWRSZXN1bHQ9MT09PXMud2lkdGgmJjI9PT1zLmhlaWdodCxlKGlzQXV0b09yaWVudGF0aW9uSW5Ccm93c2VyLmNhY2hlZFJlc3VsdCl9Y2F0Y2goZSl7cmV0dXJuIHQoZSl9fSksdCl9Y2F0Y2goZSl7cmV0dXJuIHQoZSl9fSksdCl9Y2F0Y2goZSl7cmV0dXJuIHQoZSl9fSksdCl9Y2F0Y2goZSl7cmV0dXJuIHQoZSl9fSksdCkpfSkpfWZ1bmN0aW9uIGdldEV4aWZPcmllbnRhdGlvbihlKXtyZXR1cm4gbmV3IFByb21pc2UoKCh0LHIpPT57Y29uc3QgaT1uZXcgQ3VzdG9tRmlsZVJlYWRlcjtpLm9ubG9hZD1lPT57Y29uc3Qgcj1uZXcgRGF0YVZpZXcoZS50YXJnZXQucmVzdWx0KTtpZig2NTQ5NiE9ci5nZXRVaW50MTYoMCwhMSkpcmV0dXJuIHQoLTIpO2NvbnN0IGk9ci5ieXRlTGVuZ3RoO2xldCBvPTI7Zm9yKDtvPGk7KXtpZihyLmdldFVpbnQxNihvKzIsITEpPD04KXJldHVybiB0KC0xKTtjb25zdCBlPXIuZ2V0VWludDE2KG8sITEpO2lmKG8rPTIsNjU1MDU9PWUpe2lmKDExNjU1MTkyMDYhPXIuZ2V0VWludDMyKG8rPTIsITEpKXJldHVybiB0KC0xKTtjb25zdCBlPTE4NzYxPT1yLmdldFVpbnQxNihvKz02LCExKTtvKz1yLmdldFVpbnQzMihvKzQsZSk7Y29uc3QgaT1yLmdldFVpbnQxNihvLGUpO28rPTI7Zm9yKGxldCBhPTA7YTxpO2ErKylpZigyNzQ9PXIuZ2V0VWludDE2KG8rMTIqYSxlKSlyZXR1cm4gdChyLmdldFVpbnQxNihvKzEyKmErOCxlKSl9ZWxzZXtpZig2NTI4MCE9KDY1MjgwJmUpKWJyZWFrO28rPXIuZ2V0VWludDE2KG8sITEpfX1yZXR1cm4gdCgtMSl9LGkub25lcnJvcj1lPT5yKGUpLGkucmVhZEFzQXJyYXlCdWZmZXIoZSl9KSl9ZnVuY3Rpb24gaGFuZGxlTWF4V2lkdGhPckhlaWdodChlLHQpe2NvbnN0e3dpZHRoOnJ9PWUse2hlaWdodDppfT1lLHttYXhXaWR0aE9ySGVpZ2h0Om99PXQ7bGV0IGEscz1lO3JldHVybiBpc0Zpbml0ZShvKSYmKHI+b3x8aT5vKSYmKFtzLGFdPWdldE5ld0NhbnZhc0FuZEN0eChyLGkpLHI+aT8ocy53aWR0aD1vLHMuaGVpZ2h0PWkvcipvKToocy53aWR0aD1yL2kqbyxzLmhlaWdodD1vKSxhLmRyYXdJbWFnZShlLDAsMCxzLndpZHRoLHMuaGVpZ2h0KSxjbGVhbnVwQ2FudmFzTWVtb3J5KGUpKSxzfWZ1bmN0aW9uIGZvbGxvd0V4aWZPcmllbnRhdGlvbihlLHQpe2NvbnN0e3dpZHRoOnJ9PWUse2hlaWdodDppfT1lLFtvLGFdPWdldE5ld0NhbnZhc0FuZEN0eChyLGkpO3N3aXRjaCh0PjQmJnQ8OT8oby53aWR0aD1pLG8uaGVpZ2h0PXIpOihvLndpZHRoPXIsby5oZWlnaHQ9aSksdCl7Y2FzZSAyOmEudHJhbnNmb3JtKC0xLDAsMCwxLHIsMCk7YnJlYWs7Y2FzZSAzOmEudHJhbnNmb3JtKC0xLDAsMCwtMSxyLGkpO2JyZWFrO2Nhc2UgNDphLnRyYW5zZm9ybSgxLDAsMCwtMSwwLGkpO2JyZWFrO2Nhc2UgNTphLnRyYW5zZm9ybSgwLDEsMSwwLDAsMCk7YnJlYWs7Y2FzZSA2OmEudHJhbnNmb3JtKDAsMSwtMSwwLGksMCk7YnJlYWs7Y2FzZSA3OmEudHJhbnNmb3JtKDAsLTEsLTEsMCxpLHIpO2JyZWFrO2Nhc2UgODphLnRyYW5zZm9ybSgwLC0xLDEsMCwwLHIpfXJldHVybiBhLmRyYXdJbWFnZShlLDAsMCxyLGkpLGNsZWFudXBDYW52YXNNZW1vcnkoZSksb31mdW5jdGlvbiBjb21wcmVzcyhlLHQscj0wKXtyZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uKGksbyl7bGV0IGEscyxmLGwsYyx1LGgsZCxBLGcscCxtLHcsdixiLHksRSxGLF8sQjtmdW5jdGlvbiBpbmNQcm9ncmVzcyhlPTUpe2lmKHQuc2lnbmFsJiZ0LnNpZ25hbC5hYm9ydGVkKXRocm93IHQuc2lnbmFsLnJlYXNvbjthKz1lLHQub25Qcm9ncmVzcyhNYXRoLm1pbihhLDEwMCkpfWZ1bmN0aW9uIHNldFByb2dyZXNzKGUpe2lmKHQuc2lnbmFsJiZ0LnNpZ25hbC5hYm9ydGVkKXRocm93IHQuc2lnbmFsLnJlYXNvbjthPU1hdGgubWluKE1hdGgubWF4KGUsYSksMTAwKSx0Lm9uUHJvZ3Jlc3MoYSl9cmV0dXJuIGE9cixzPXQubWF4SXRlcmF0aW9ufHwxMCxmPTEwMjQqdC5tYXhTaXplTUIqMTAyNCxpbmNQcm9ncmVzcygpLGRyYXdGaWxlSW5DYW52YXMoZSx0KS50aGVuKGZ1bmN0aW9uKHIpe3RyeXtyZXR1cm5bLGxdPXIsaW5jUHJvZ3Jlc3MoKSxjPWhhbmRsZU1heFdpZHRoT3JIZWlnaHQobCx0KSxpbmNQcm9ncmVzcygpLG5ldyBQcm9taXNlKChmdW5jdGlvbihyLGkpe3ZhciBvO2lmKCEobz10LmV4aWZPcmllbnRhdGlvbikpcmV0dXJuIGdldEV4aWZPcmllbnRhdGlvbihlKS50aGVuKGZ1bmN0aW9uKGUpe3RyeXtyZXR1cm4gbz1lLCRJZl8yLmNhbGwodGhpcyl9Y2F0Y2goZSl7cmV0dXJuIGkoZSl9fS5iaW5kKHRoaXMpLGkpO2Z1bmN0aW9uICRJZl8yKCl7cmV0dXJuIHIobyl9cmV0dXJuICRJZl8yLmNhbGwodGhpcyl9KSkudGhlbihmdW5jdGlvbihyKXt0cnl7cmV0dXJuIHU9cixpbmNQcm9ncmVzcygpLGlzQXV0b09yaWVudGF0aW9uSW5Ccm93c2VyKCkudGhlbihmdW5jdGlvbihyKXt0cnl7cmV0dXJuIGg9cj9jOmZvbGxvd0V4aWZPcmllbnRhdGlvbihjLHUpLGluY1Byb2dyZXNzKCksZD10LmluaXRpYWxRdWFsaXR5fHwxLEE9dC5maWxlVHlwZXx8ZS50eXBlLGNhbnZhc1RvRmlsZShoLEEsZS5uYW1lLGUubGFzdE1vZGlmaWVkLGQpLnRoZW4oZnVuY3Rpb24ocil7dHJ5e3tpZihnPXIsaW5jUHJvZ3Jlc3MoKSxwPWcuc2l6ZT5mLG09Zy5zaXplPmUuc2l6ZSwhcCYmIW0pcmV0dXJuIHNldFByb2dyZXNzKDEwMCksaShnKTt2YXIgYTtmdW5jdGlvbiAkTG9vcF8zKCl7aWYocy0tJiYoYj5mfHxiPncpKXtsZXQgdCxyO3JldHVybiB0PUI/Ljk1Kl8ud2lkdGg6Xy53aWR0aCxyPUI/Ljk1Kl8uaGVpZ2h0Ol8uaGVpZ2h0LFtFLEZdPWdldE5ld0NhbnZhc0FuZEN0eCh0LHIpLEYuZHJhd0ltYWdlKF8sMCwwLHQsciksZCo9XCJpbWFnZS9wbmdcIj09PUE/Ljg1Oi45NSxjYW52YXNUb0ZpbGUoRSxBLGUubmFtZSxlLmxhc3RNb2RpZmllZCxkKS50aGVuKChmdW5jdGlvbihlKXt0cnl7cmV0dXJuIHk9ZSxjbGVhbnVwQ2FudmFzTWVtb3J5KF8pLF89RSxiPXkuc2l6ZSxzZXRQcm9ncmVzcyhNYXRoLm1pbig5OSxNYXRoLmZsb29yKCh2LWIpLyh2LWYpKjEwMCkpKSwkTG9vcF8zfWNhdGNoKGUpe3JldHVybiBvKGUpfX0pLG8pfXJldHVyblsxXX1yZXR1cm4gdz1lLnNpemUsdj1nLnNpemUsYj12LF89aCxCPSF0LmFsd2F5c0tlZXBSZXNvbHV0aW9uJiZwLChhPWZ1bmN0aW9uKGUpe2Zvcig7ZTspe2lmKGUudGhlbilyZXR1cm4gdm9pZCBlLnRoZW4oYSxvKTt0cnl7aWYoZS5wb3Ape2lmKGUubGVuZ3RoKXJldHVybiBlLnBvcCgpPyRMb29wXzNfZXhpdC5jYWxsKHRoaXMpOmU7ZT0kTG9vcF8zfWVsc2UgZT1lLmNhbGwodGhpcyl9Y2F0Y2goZSl7cmV0dXJuIG8oZSl9fX0uYmluZCh0aGlzKSkoJExvb3BfMyk7ZnVuY3Rpb24gJExvb3BfM19leGl0KCl7cmV0dXJuIGNsZWFudXBDYW52YXNNZW1vcnkoXyksY2xlYW51cENhbnZhc01lbW9yeShFKSxjbGVhbnVwQ2FudmFzTWVtb3J5KGMpLGNsZWFudXBDYW52YXNNZW1vcnkoaCksY2xlYW51cENhbnZhc01lbW9yeShsKSxzZXRQcm9ncmVzcygxMDApLGkoeSl9fX1jYXRjaCh1KXtyZXR1cm4gbyh1KX19LmJpbmQodGhpcyksbyl9Y2F0Y2goZSl7cmV0dXJuIG8oZSl9fS5iaW5kKHRoaXMpLG8pfWNhdGNoKGUpe3JldHVybiBvKGUpfX0uYmluZCh0aGlzKSxvKX1jYXRjaChlKXtyZXR1cm4gbyhlKX19LmJpbmQodGhpcyksbyl9KSl9Y29uc3QgbD1cIlxcbmxldCBzY3JpcHRJbXBvcnRlZCA9IGZhbHNlXFxuc2VsZi5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgYXN5bmMgKGUpID0+IHtcXG4gIGNvbnN0IHsgZmlsZSwgaWQsIGltYWdlQ29tcHJlc3Npb25MaWJVcmwsIG9wdGlvbnMgfSA9IGUuZGF0YVxcbiAgb3B0aW9ucy5vblByb2dyZXNzID0gKHByb2dyZXNzKSA9PiBzZWxmLnBvc3RNZXNzYWdlKHsgcHJvZ3Jlc3MsIGlkIH0pXFxuICB0cnkge1xcbiAgICBpZiAoIXNjcmlwdEltcG9ydGVkKSB7XFxuICAgICAgLy8gY29uc29sZS5sb2coJ1t3b3JrZXJdIGltcG9ydFNjcmlwdHMnLCBpbWFnZUNvbXByZXNzaW9uTGliVXJsKVxcbiAgICAgIHNlbGYuaW1wb3J0U2NyaXB0cyhpbWFnZUNvbXByZXNzaW9uTGliVXJsKVxcbiAgICAgIHNjcmlwdEltcG9ydGVkID0gdHJ1ZVxcbiAgICB9XFxuICAgIC8vIGNvbnNvbGUubG9nKCdbd29ya2VyXSBzZWxmJywgc2VsZilcXG4gICAgY29uc3QgY29tcHJlc3NlZEZpbGUgPSBhd2FpdCBpbWFnZUNvbXByZXNzaW9uKGZpbGUsIG9wdGlvbnMpXFxuICAgIHNlbGYucG9zdE1lc3NhZ2UoeyBmaWxlOiBjb21wcmVzc2VkRmlsZSwgaWQgfSlcXG4gIH0gY2F0Y2ggKGUpIHtcXG4gICAgLy8gY29uc29sZS5lcnJvcignW3dvcmtlcl0gZXJyb3InLCBlKVxcbiAgICBzZWxmLnBvc3RNZXNzYWdlKHsgZXJyb3I6IGUubWVzc2FnZSArICdcXFxcbicgKyBlLnN0YWNrLCBpZCB9KVxcbiAgfVxcbn0pXFxuXCI7bGV0IGM7ZnVuY3Rpb24gY29tcHJlc3NPbldlYldvcmtlcihlLHQpe3JldHVybiBuZXcgUHJvbWlzZSgoKHIsaSk9PntjfHwoYz1mdW5jdGlvbiBjcmVhdGVXb3JrZXJTY3JpcHRVUkwoZSl7Y29uc3QgdD1bXTtyZXR1cm5cImZ1bmN0aW9uXCI9PXR5cGVvZiBlP3QucHVzaChgKCR7ZX0pKClgKTp0LnB1c2goZSksVVJMLmNyZWF0ZU9iamVjdFVSTChuZXcgQmxvYih0KSl9KGwpKTtjb25zdCBvPW5ldyBXb3JrZXIoYyk7by5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLChmdW5jdGlvbiBoYW5kbGVyKGUpe2lmKHQuc2lnbmFsJiZ0LnNpZ25hbC5hYm9ydGVkKW8udGVybWluYXRlKCk7ZWxzZSBpZih2b2lkIDA9PT1lLmRhdGEucHJvZ3Jlc3Mpe2lmKGUuZGF0YS5lcnJvcilyZXR1cm4gaShuZXcgRXJyb3IoZS5kYXRhLmVycm9yKSksdm9pZCBvLnRlcm1pbmF0ZSgpO3IoZS5kYXRhLmZpbGUpLG8udGVybWluYXRlKCl9ZWxzZSB0Lm9uUHJvZ3Jlc3MoZS5kYXRhLnByb2dyZXNzKX0pKSxvLmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLGkpLHQuc2lnbmFsJiZ0LnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwoKCk9PntpKHQuc2lnbmFsLnJlYXNvbiksby50ZXJtaW5hdGUoKX0pKSxvLnBvc3RNZXNzYWdlKHtmaWxlOmUsaW1hZ2VDb21wcmVzc2lvbkxpYlVybDp0LmxpYlVSTCxvcHRpb25zOnsuLi50LG9uUHJvZ3Jlc3M6dm9pZCAwLHNpZ25hbDp2b2lkIDB9fSl9KSl9ZnVuY3Rpb24gaW1hZ2VDb21wcmVzc2lvbihlLHQpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24ocixpKXtsZXQgbyxhLHMsZixsLGM7aWYobz17Li4udH0scz0wLCh7b25Qcm9ncmVzczpmfT1vKSxvLm1heFNpemVNQj1vLm1heFNpemVNQnx8TnVtYmVyLlBPU0lUSVZFX0lORklOSVRZLGw9XCJib29sZWFuXCIhPXR5cGVvZiBvLnVzZVdlYldvcmtlcnx8by51c2VXZWJXb3JrZXIsZGVsZXRlIG8udXNlV2ViV29ya2VyLG8ub25Qcm9ncmVzcz1lPT57cz1lLFwiZnVuY3Rpb25cIj09dHlwZW9mIGYmJmYocyl9LCEoZSBpbnN0YW5jZW9mIEJsb2J8fGUgaW5zdGFuY2VvZiBDdXN0b21GaWxlKSlyZXR1cm4gaShuZXcgRXJyb3IoXCJUaGUgZmlsZSBnaXZlbiBpcyBub3QgYW4gaW5zdGFuY2Ugb2YgQmxvYiBvciBGaWxlXCIpKTtpZighL15pbWFnZS8udGVzdChlLnR5cGUpKXJldHVybiBpKG5ldyBFcnJvcihcIlRoZSBmaWxlIGdpdmVuIGlzIG5vdCBhbiBpbWFnZVwiKSk7aWYoYz1cInVuZGVmaW5lZFwiIT10eXBlb2YgV29ya2VyR2xvYmFsU2NvcGUmJnNlbGYgaW5zdGFuY2VvZiBXb3JrZXJHbG9iYWxTY29wZSwhbHx8XCJmdW5jdGlvblwiIT10eXBlb2YgV29ya2VyfHxjKXJldHVybiBjb21wcmVzcyhlLG8pLnRoZW4oZnVuY3Rpb24oZSl7dHJ5e3JldHVybiBhPWUsJElmXzQuY2FsbCh0aGlzKX1jYXRjaChlKXtyZXR1cm4gaShlKX19LmJpbmQodGhpcyksaSk7dmFyIHU9ZnVuY3Rpb24oKXt0cnl7cmV0dXJuICRJZl80LmNhbGwodGhpcyl9Y2F0Y2goZSl7cmV0dXJuIGkoZSl9fS5iaW5kKHRoaXMpLCRUcnlfMV9DYXRjaD1mdW5jdGlvbih0KXt0cnl7cmV0dXJuIGNvbXByZXNzKGUsbykudGhlbigoZnVuY3Rpb24oZSl7dHJ5e3JldHVybiBhPWUsdSgpfWNhdGNoKGUpe3JldHVybiBpKGUpfX0pLGkpfWNhdGNoKGUpe3JldHVybiBpKGUpfX07dHJ5e3JldHVybiBvLmxpYlVSTD1vLmxpYlVSTHx8XCJodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL2Jyb3dzZXItaW1hZ2UtY29tcHJlc3Npb25AMi4wLjIvZGlzdC9icm93c2VyLWltYWdlLWNvbXByZXNzaW9uLmpzXCIsY29tcHJlc3NPbldlYldvcmtlcihlLG8pLnRoZW4oKGZ1bmN0aW9uKGUpe3RyeXtyZXR1cm4gYT1lLHUoKX1jYXRjaChlKXtyZXR1cm4gJFRyeV8xX0NhdGNoKCl9fSksJFRyeV8xX0NhdGNoKX1jYXRjaChlKXskVHJ5XzFfQ2F0Y2goKX1mdW5jdGlvbiAkSWZfNCgpe3RyeXthLm5hbWU9ZS5uYW1lLGEubGFzdE1vZGlmaWVkPWUubGFzdE1vZGlmaWVkfWNhdGNoKGUpe310cnl7by5wcmVzZXJ2ZUV4aWYmJlwiaW1hZ2UvanBlZ1wiPT09ZS50eXBlJiYoIW8uZmlsZVR5cGV8fG8uZmlsZVR5cGUmJm8uZmlsZVR5cGU9PT1lLnR5cGUpJiYoYT1jb3B5RXhpZldpdGhvdXRPcmllbnRhdGlvbihlLGEpKX1jYXRjaChlKXt9cmV0dXJuIHIoYSl9fSkpfWltYWdlQ29tcHJlc3Npb24uZ2V0RGF0YVVybEZyb21GaWxlPWdldERhdGFVcmxGcm9tRmlsZSxpbWFnZUNvbXByZXNzaW9uLmdldEZpbGVmcm9tRGF0YVVybD1nZXRGaWxlZnJvbURhdGFVcmwsaW1hZ2VDb21wcmVzc2lvbi5sb2FkSW1hZ2U9bG9hZEltYWdlLGltYWdlQ29tcHJlc3Npb24uZHJhd0ltYWdlSW5DYW52YXM9ZHJhd0ltYWdlSW5DYW52YXMsaW1hZ2VDb21wcmVzc2lvbi5kcmF3RmlsZUluQ2FudmFzPWRyYXdGaWxlSW5DYW52YXMsaW1hZ2VDb21wcmVzc2lvbi5jYW52YXNUb0ZpbGU9Y2FudmFzVG9GaWxlLGltYWdlQ29tcHJlc3Npb24uZ2V0RXhpZk9yaWVudGF0aW9uPWdldEV4aWZPcmllbnRhdGlvbixpbWFnZUNvbXByZXNzaW9uLmhhbmRsZU1heFdpZHRoT3JIZWlnaHQ9aGFuZGxlTWF4V2lkdGhPckhlaWdodCxpbWFnZUNvbXByZXNzaW9uLmZvbGxvd0V4aWZPcmllbnRhdGlvbj1mb2xsb3dFeGlmT3JpZW50YXRpb24saW1hZ2VDb21wcmVzc2lvbi5jbGVhbnVwQ2FudmFzTWVtb3J5PWNsZWFudXBDYW52YXNNZW1vcnksaW1hZ2VDb21wcmVzc2lvbi5pc0F1dG9PcmllbnRhdGlvbkluQnJvd3Nlcj1pc0F1dG9PcmllbnRhdGlvbkluQnJvd3NlcixpbWFnZUNvbXByZXNzaW9uLmFwcHJveGltYXRlQmVsb3dNYXhpbXVtQ2FudmFzU2l6ZU9mQnJvd3Nlcj1hcHByb3hpbWF0ZUJlbG93TWF4aW11bUNhbnZhc1NpemVPZkJyb3dzZXIsaW1hZ2VDb21wcmVzc2lvbi5jb3B5RXhpZldpdGhvdXRPcmllbnRhdGlvbj1jb3B5RXhpZldpdGhvdXRPcmllbnRhdGlvbixpbWFnZUNvbXByZXNzaW9uLmdldEJyb3dzZXJOYW1lPWdldEJyb3dzZXJOYW1lLGltYWdlQ29tcHJlc3Npb24udmVyc2lvbj1cIjIuMC4yXCI7ZXhwb3J0e2ltYWdlQ29tcHJlc3Npb24gYXMgZGVmYXVsdH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1icm93c2VyLWltYWdlLWNvbXByZXNzaW9uLm1qcy5tYXBcbiIsImltcG9ydCB7IE9SSUdJTl9GT0xERVIsIHQsIEZpbGVQaWNrZXJJbXBsZW1lbnRhdGlvbiB9IGZyb20gJy4vVXRpbHMnXHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IGNyZWF0ZVVwbG9hZEZvbGRlciA9IGFzeW5jICh1cGxvYWRMb2NhdGlvbj86IHN0cmluZykgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXBsb2FkTG9jYXRpb24gfHwgZ2V0U2V0dGluZygndXBsb2FkTG9jYXRpb24nKVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBmb2xkZXJMb2NhdGlvbiA9IGF3YWl0IEZpbGVQaWNrZXJJbXBsZW1lbnRhdGlvbigpLmJyb3dzZShPUklHSU5fRk9MREVSLCBsb2NhdGlvbilcclxuICAgIGlmIChmb2xkZXJMb2NhdGlvbi50YXJnZXQgPT09ICcuJykgYXdhaXQgRmlsZVBpY2tlckltcGxlbWVudGF0aW9uKCkuY3JlYXRlRGlyZWN0b3J5KE9SSUdJTl9GT0xERVIsIGxvY2F0aW9uLCB7fSlcclxuICB9IGNhdGNoIChlKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBGaWxlUGlja2VySW1wbGVtZW50YXRpb24oKS5jcmVhdGVEaXJlY3RvcnkoT1JJR0lOX0ZPTERFUiwgbG9jYXRpb24sIHt9KVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIC8vIFRoZSBGaWxlUGlja2VyIHRob3J3cyBhbiBlcnJvciB3aGVuIHlvdSBoYXZlIGEgdXNlciB3aXRob3V0IHVwbG9hZCBwZXJtaXNzaW9uc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHNldFNldHRpbmcgPSAoa2V5OiBzdHJpbmcsIHZhbHVlOiBhbnkpID0+IHtcclxuICAvLyBAdHMtaWdub3JlXHJcbiAgcmV0dXJuIChnYW1lIGFzIEdhbWUpLnNldHRpbmdzLnNldCgnY2hhdC1pbWFnZXMnLCBrZXksIHZhbHVlKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0U2V0dGluZ3MgPSAoKSA9PiBbXHJcbiAge1xyXG4gICAga2V5OiAndXBsb2FkQnV0dG9uJyxcclxuICAgIG9wdGlvbnM6IHtcclxuICAgICAgbmFtZTogdCgndXBsb2FkQnV0dG9uJyksXHJcbiAgICAgIGhpbnQ6IHQoJ3VwbG9hZEJ1dHRvbkhpbnQnKSxcclxuICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgZGVmYXVsdDogdHJ1ZSxcclxuICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICByZXF1aXJlc1JlbG9hZDogdHJ1ZSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6ICd1cGxvYWRMb2NhdGlvbicsXHJcbiAgICBvcHRpb25zOiB7XHJcbiAgICAgIG5hbWU6IHQoJ3VwbG9hZExvY2F0aW9uJyksXHJcbiAgICAgIGhpbnQ6IHQoJ3VwbG9hZExvY2F0aW9uSGludCcpLFxyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGRlZmF1bHQ6ICd1cGxvYWRlZC1jaGF0LWltYWdlcycsXHJcbiAgICAgIHNjb3BlOiAnd29ybGQnLFxyXG4gICAgICBjb25maWc6IHRydWUsXHJcbiAgICAgIHJlc3RyaWN0ZWQ6IHRydWUsXHJcbiAgICAgIG9uQ2hhbmdlOiBhc3luYyAobmV3VXBsb2FkTG9jYXRpb246IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGRlZmF1bHRMb2NhdGlvbiA9ICd1cGxvYWRlZC1jaGF0LWltYWdlcydcclxuICAgICAgICBsZXQgbG9jYXRpb24gPSBuZXdVcGxvYWRMb2NhdGlvbi50cmltKClcclxuICAgICAgICBsZXQgc2hvdWxkQ2hhbmdlTG9jYXRpb24gPSBmYWxzZVxyXG5cclxuICAgICAgICBpZiAoIWxvY2F0aW9uKSB7XHJcbiAgICAgICAgICBsb2NhdGlvbiA9IGRlZmF1bHRMb2NhdGlvblxyXG4gICAgICAgICAgc2hvdWxkQ2hhbmdlTG9jYXRpb24gPSB0cnVlXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsb2NhdGlvbiA9IGxvY2F0aW9uLnJlcGxhY2UoL1xccysvZywgJy0nKVxyXG4gICAgICAgIGlmIChuZXdVcGxvYWRMb2NhdGlvbiAhPT0gbG9jYXRpb24pIHNob3VsZENoYW5nZUxvY2F0aW9uID0gdHJ1ZVxyXG5cclxuICAgICAgICBhd2FpdCBjcmVhdGVVcGxvYWRGb2xkZXIobG9jYXRpb24pXHJcbiAgICAgICAgaWYgKHNob3VsZENoYW5nZUxvY2F0aW9uKSBhd2FpdCBzZXRTZXR0aW5nKCd1cGxvYWRMb2NhdGlvbicsIGxvY2F0aW9uKVxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG5dXHJcblxyXG5leHBvcnQgY29uc3QgcmVnaXN0ZXJTZXR0aW5nID0gKHNldHRpbmc6IHsga2V5OiBzdHJpbmcsIG9wdGlvbnM6IGFueSB9KSA9PiB7XHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIHJldHVybiAoZ2FtZSBhcyBHYW1lKS5zZXR0aW5ncy5yZWdpc3RlcignY2hhdC1pbWFnZXMnLCBzZXR0aW5nLmtleSwgc2V0dGluZy5vcHRpb25zKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0U2V0dGluZyA9IChrZXk6IHN0cmluZyk6IGFueSA9PiB7XHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIHJldHVybiAoZ2FtZSBhcyBHYW1lKS5zZXR0aW5ncy5nZXQoJ2NoYXQtaW1hZ2VzJywga2V5KVxyXG59XHJcbiIsImltcG9ydCB7RmlsZVBpY2tlckltcGxlbWVudGF0aW9uLCBPUklHSU5fRk9MREVSLCByYW5kb21TdHJpbmcsIHQsIHVzZXJDYW5VcGxvYWR9IGZyb20gJy4uL3V0aWxzL1V0aWxzJ1xyXG5pbXBvcnQge2FkZENsYXNzLCBhcHBlbmQsIGNyZWF0ZSwgZmluZCwgb24sIHJlbW92ZSwgcmVtb3ZlQ2xhc3N9IGZyb20gJy4uL3V0aWxzL0pxdWVyeVdyYXBwZXJzJ1xyXG5pbXBvcnQgaW1hZ2VDb21wcmVzc2lvbiBmcm9tICdicm93c2VyLWltYWdlLWNvbXByZXNzaW9uJ1xyXG5pbXBvcnQge2dldFNldHRpbmd9IGZyb20gJy4uL3V0aWxzL1NldHRpbmdzJ1xyXG5cclxuZXhwb3J0IHR5cGUgU2F2ZVZhbHVlVHlwZSA9IHtcclxuICB0eXBlPzogc3RyaW5nLFxyXG4gIG5hbWU/OiBzdHJpbmcsXHJcbiAgZmlsZT86IEZpbGUsXHJcbiAgaW1hZ2VTcmM6IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgbnVsbCxcclxuICBpZDogc3RyaW5nLFxyXG59XHJcblxyXG5jb25zdCBSRVNUUklDVEVEX0RPTUFJTlMgPSBbJ3N0YXRpYy53aWtpYSddXHJcbmNvbnN0IGRvbVBhcnNlciA9IG5ldyBET01QYXJzZXIoKVxyXG5cclxubGV0IGltYWdlUXVldWU6IFNhdmVWYWx1ZVR5cGVbXSA9IFtdXHJcblxyXG5jb25zdCBpc0ZpbGVJbWFnZSA9IChmaWxlOiBGaWxlIHwgRGF0YVRyYW5zZmVySXRlbSkgPT4gZmlsZS50eXBlICYmIGZpbGUudHlwZS5zdGFydHNXaXRoKCdpbWFnZS8nKVxyXG5cclxuY29uc3QgaXNCbG9iVXJsID0gKHNyYzogdW5rbm93bik6IHNyYyBpcyBzdHJpbmcgPT4gdHlwZW9mIHNyYyA9PT0gJ3N0cmluZycgJiYgc3JjLnN0YXJ0c1dpdGgoJ2Jsb2I6JylcclxuXHJcbmNvbnN0IHNhZmVSZXZva2VPYmplY3RVcmwgPSAoc3JjOiB1bmtub3duKSA9PiB7XHJcbiAgaWYgKCFpc0Jsb2JVcmwoc3JjKSkgcmV0dXJuXHJcbiAgdHJ5IHtcclxuICAgIFVSTC5yZXZva2VPYmplY3RVUkwoc3JjKVxyXG4gIH0gY2F0Y2ggKF8pIHsvKiBpZ25vcmUgKi99XHJcbn1cclxuXHJcbmNvbnN0IGNyZWF0ZUltYWdlUHJldmlldyA9ICh7aW1hZ2VTcmMsIGlkfTogU2F2ZVZhbHVlVHlwZSk6IEpRdWVyeSA9PiBjcmVhdGUoXHJcbiAgICBgPGRpdiBpZD1cIiR7aWR9XCIgY2xhc3M9XCJjaS11cGxvYWQtYXJlYS1pbWFnZVwiPlxyXG4gICAgICA8aSBjbGFzcz1cImNpLXJlbW92ZS1pbWFnZS1pY29uIGZhLXJlZ3VsYXIgZmEtY2lyY2xlLXhtYXJrXCI+PC9pPlxyXG4gICAgICA8aW1nIGNsYXNzPVwiY2ktaW1hZ2UtcHJldmlld1wiIHNyYz1cIiR7U3RyaW5nKGltYWdlU3JjKX1cIiBhbHQ9XCIke3QoJ3VuYWJsZVRvTG9hZEltYWdlJyl9XCIvPlxyXG4gICA8L2Rpdj5gXHJcbilcclxuXHJcbmNvbnN0IGFkZEV2ZW50VG9SZW1vdmVCdXR0b24gPSAocmVtb3ZlQnV0dG9uOiBKUXVlcnksIHNhdmVWYWx1ZTogU2F2ZVZhbHVlVHlwZSwgdXBsb2FkQXJlYTogSlF1ZXJ5KSA9PiB7XHJcbiAgY29uc3QgcmVtb3ZlRXZlbnRIYW5kbGVyID0gKCkgPT4ge1xyXG4gICAgY29uc3QgaW1hZ2UgPSBmaW5kKGAjJHtzYXZlVmFsdWUuaWR9YCwgdXBsb2FkQXJlYSlcclxuICAgIHJlbW92ZShpbWFnZSlcclxuXHJcbiAgICAvLyByZXZva2UgYmxvYiB1cmwgdG8gYXZvaWQgbWVtb3J5IGxlYWtcclxuICAgIGlmIChzYXZlVmFsdWUuZmlsZSkgc2FmZVJldm9rZU9iamVjdFVybChzYXZlVmFsdWUuaW1hZ2VTcmMpXHJcblxyXG4gICAgaW1hZ2VRdWV1ZSA9IGltYWdlUXVldWUuZmlsdGVyKChpbWdEYXRhOiBTYXZlVmFsdWVUeXBlKSA9PiBzYXZlVmFsdWUuaWQgIT09IGltZ0RhdGEuaWQpXHJcbiAgICBpZiAoaW1hZ2VRdWV1ZS5sZW5ndGgpIHJldHVyblxyXG5cclxuICAgIGFkZENsYXNzKHVwbG9hZEFyZWEsICdoaWRkZW4nKVxyXG4gIH1cclxuICBvbihyZW1vdmVCdXR0b24sICdjbGljaycsIHJlbW92ZUV2ZW50SGFuZGxlcilcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwbG9hZCBhIEZpbGUtYmFzZWQgcXVldWUgaXRlbSB0byBGb3VuZHJ5IGFuZCByZXR1cm4gaXRzIHN0b3JlZCBwYXRoLlxyXG4gKiBOT1RFOiBGaWxlUGlja2VySW1wbGVtZW50YXRpb24gaXMgYSBjbGFzcyAoZXNsaW50IG5ldy1jYXApIHNvIHdlIGluc3RhbnRpYXRlIGl0LlxyXG4gKi9cclxuY29uc3QgdXBsb2FkSW1hZ2UgPSBhc3luYyAoc2F2ZVZhbHVlOiBTYXZlVmFsdWVUeXBlKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcclxuICBjb25zdCBnZW5lcmF0ZUZpbGVOYW1lID0gKHN2OiBTYXZlVmFsdWVUeXBlKSA9PiB7XHJcbiAgICBjb25zdCB7dHlwZSwgbmFtZSwgaWR9ID0gc3ZcclxuICAgIGNvbnN0IGZpbGVFeHRlbnNpb246IHN0cmluZyA9XHJcbiAgICAgICAgbmFtZT8uc3Vic3RyaW5nKG5hbWUubGFzdEluZGV4T2YoJy4nKSwgbmFtZS5sZW5ndGgpIHx8XHJcbiAgICAgICAgdHlwZT8ucmVwbGFjZSgnaW1hZ2UvJywgJy4nKSB8fFxyXG4gICAgICAgICcuanBlZydcclxuICAgIHJldHVybiBgJHtpZH0ke2ZpbGVFeHRlbnNpb259YFxyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IG5ld05hbWUgPSBnZW5lcmF0ZUZpbGVOYW1lKHNhdmVWYWx1ZSlcclxuXHJcbiAgICBjb25zdCBjb21wcmVzc2VkSW1hZ2UgPSBhd2FpdCBpbWFnZUNvbXByZXNzaW9uKHNhdmVWYWx1ZS5maWxlIGFzIEZpbGUsIHtcclxuICAgICAgbWF4U2l6ZU1COiAxLjUsXHJcbiAgICAgIHVzZVdlYldvcmtlcjogdHJ1ZSxcclxuICAgICAgYWx3YXlzS2VlcFJlc29sdXRpb246IHRydWUsXHJcbiAgICB9KVxyXG5cclxuICAgIGNvbnN0IG5ld0ltYWdlID0gbmV3IEZpbGUoW2NvbXByZXNzZWRJbWFnZSBhcyBGaWxlXSwgbmV3TmFtZSwge3R5cGU6IHNhdmVWYWx1ZS50eXBlfSlcclxuXHJcbiAgICBjb25zdCB1cGxvYWRMb2NhdGlvbiA9IGdldFNldHRpbmcoJ3VwbG9hZExvY2F0aW9uJylcclxuXHJcbiAgICAvLyBAdHMtaWdub3JlXHJcbiAgICBjb25zdCBmaWxlUGlja2VyID0gbmV3IChGaWxlUGlja2VySW1wbGVtZW50YXRpb24gYXMgYW55KSgpXHJcblxyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgY29uc3QgaW1hZ2VMb2NhdGlvbiA9IGF3YWl0IGZpbGVQaWNrZXIudXBsb2FkKFxyXG4gICAgICAgIE9SSUdJTl9GT0xERVIsXHJcbiAgICAgICAgdXBsb2FkTG9jYXRpb24sXHJcbiAgICAgICAgbmV3SW1hZ2UsXHJcbiAgICAgICAge30sXHJcbiAgICAgICAge25vdGlmeTogZmFsc2V9LFxyXG4gICAgKVxyXG5cclxuICAgIGlmICghaW1hZ2VMb2NhdGlvbiB8fCAhKGltYWdlTG9jYXRpb24gYXMgRmlsZVBpY2tlci5VcGxvYWRSZXR1cm4pPy5wYXRoKSB7XHJcbiAgICAgIC8vIGZhbGxiYWNrOiBrZWVwIGN1cnJlbnQgc3JjXHJcbiAgICAgIHJldHVybiBzYXZlVmFsdWUuaW1hZ2VTcmMgYXMgc3RyaW5nXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKGltYWdlTG9jYXRpb24gYXMgRmlsZVBpY2tlci5VcGxvYWRSZXR1cm4pLnBhdGhcclxuICB9IGNhdGNoIChlKSB7XHJcbiAgICByZXR1cm4gc2F2ZVZhbHVlLmltYWdlU3JjIGFzIHN0cmluZ1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIExBWlk6IGp1c3QgYWRkIHByZXZpZXcgYW5kIHF1ZXVlLiBObyB1cGxvYWQgaGVyZS5cclxuICovXHJcbmNvbnN0IGFkZEltYWdlVG9RdWV1ZSA9IGFzeW5jIChzYXZlVmFsdWU6IFNhdmVWYWx1ZVR5cGUsIHNpZGViYXI6IEpRdWVyeSkgPT4ge1xyXG4gIGNvbnN0IHVwbG9hZEFyZWE6IEpRdWVyeSA9IGZpbmQoJyNjaS1jaGF0LXVwbG9hZC1hcmVhJywgc2lkZWJhcilcclxuICBpZiAoIXVwbG9hZEFyZWEgfHwgIXVwbG9hZEFyZWFbMF0pIHJldHVyblxyXG5cclxuICAvLyBzaG93IHByZXZpZXcgZnJvbSBibG9iIHVybCAoZmFzdCkgaWYgaXQgaXMgYSBGaWxlXHJcbiAgaWYgKHNhdmVWYWx1ZS5maWxlKSB7XHJcbiAgICBpZiAoIXVzZXJDYW5VcGxvYWQoKSkgcmV0dXJuXHJcblxyXG4gICAgLy8gVXNlIG9iamVjdCBVUkwgdG8gYXZvaWQgYmFzZTY0IG1lbW9yeSBzcGlrZSBpbiBVSVxyXG4gICAgc2F2ZVZhbHVlLmltYWdlU3JjID0gVVJMLmNyZWF0ZU9iamVjdFVSTChzYXZlVmFsdWUuZmlsZSlcclxuICB9XHJcblxyXG4gIGNvbnN0IGltYWdlUHJldmlldyA9IGNyZWF0ZUltYWdlUHJldmlldyhzYXZlVmFsdWUpXHJcbiAgaWYgKCFpbWFnZVByZXZpZXcgfHwgIWltYWdlUHJldmlld1swXSkgcmV0dXJuXHJcblxyXG4gIHJlbW92ZUNsYXNzKHVwbG9hZEFyZWEsICdoaWRkZW4nKVxyXG4gIGFwcGVuZCh1cGxvYWRBcmVhLCBpbWFnZVByZXZpZXcpXHJcbiAgaW1hZ2VRdWV1ZS5wdXNoKHNhdmVWYWx1ZSlcclxuXHJcbiAgY29uc3QgcmVtb3ZlQnV0dG9uID0gZmluZCgnLmNpLXJlbW92ZS1pbWFnZS1pY29uJywgaW1hZ2VQcmV2aWV3KVxyXG4gIGFkZEV2ZW50VG9SZW1vdmVCdXR0b24ocmVtb3ZlQnV0dG9uLCBzYXZlVmFsdWUsIHVwbG9hZEFyZWEpXHJcbn1cclxuXHJcbmNvbnN0IGltYWdlc0ZpbGVSZWFkZXJIYW5kbGVyID0gKGZpbGU6IEZpbGUsIHNpZGViYXI6IEpRdWVyeSkgPT4gYXN5bmMgKF9ldnQ6IEV2ZW50KSA9PiB7XHJcbiAgLy8gV2Ugbm8gbG9uZ2VyIG5lZWQgRmlsZVJlYWRlciByZXN1bHQgZm9yIHByZXZpZXc7IGJsb2IgVVJMIHdpbGwgYmUgdXNlZC5cclxuICBjb25zdCBzYXZlVmFsdWU6IFNhdmVWYWx1ZVR5cGUgPSB7dHlwZTogZmlsZS50eXBlLCBuYW1lOiBmaWxlLm5hbWUsIGltYWdlU3JjOiAnJywgaWQ6IHJhbmRvbVN0cmluZygpLCBmaWxlfVxyXG4gIGF3YWl0IGFkZEltYWdlVG9RdWV1ZShzYXZlVmFsdWUsIHNpZGViYXIpXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBwcm9jZXNzSW1hZ2VGaWxlcyA9IChmaWxlczogRmlsZUxpc3QgfCBGaWxlW10sIHNpZGViYXI6IEpRdWVyeSkgPT4ge1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZmlsZXMubGVuZ3RoOyBpKyspIHtcclxuICAgIGNvbnN0IGZpbGU6IEZpbGUgPSBmaWxlc1tpXVxyXG4gICAgaWYgKCFpc0ZpbGVJbWFnZShmaWxlKSkgY29udGludWVcclxuXHJcbiAgICAvLyBubyBEYXRhVVJMIHJlYWQ7IGp1c3QgcXVldWVcclxuICAgIHZvaWQgaW1hZ2VzRmlsZVJlYWRlckhhbmRsZXIoZmlsZSwgc2lkZWJhcikobmV3IEV2ZW50KCdsb2FkJykpXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgcHJvY2Vzc0Ryb3BBbmRQYXN0ZUltYWdlcyA9IChldmVudERhdGE6IERhdGFUcmFuc2Zlciwgc2lkZWJhcjogSlF1ZXJ5KSA9PiB7XHJcbiAgY29uc3QgZXh0cmFjdFVybEZyb21FdmVudERhdGEgPSAoZWQ6IERhdGFUcmFuc2Zlcik6IHN0cmluZ1tdIHwgbnVsbCA9PiB7XHJcbiAgICBjb25zdCBodG1sID0gZWQuZ2V0RGF0YSgndGV4dC9odG1sJylcclxuICAgIGlmICghaHRtbCkgcmV0dXJuIG51bGxcclxuXHJcbiAgICBjb25zdCBpbWFnZXMgPSBkb21QYXJzZXIucGFyc2VGcm9tU3RyaW5nKGh0bWwsICd0ZXh0L2h0bWwnKS5xdWVyeVNlbGVjdG9yQWxsKCdpbWcnKVxyXG4gICAgaWYgKCFpbWFnZXMgfHwgIWltYWdlcy5sZW5ndGgpIHJldHVybiBudWxsXHJcblxyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgY29uc3QgaW1hZ2VVcmxzID0gWy4uLmltYWdlc10ubWFwKChpbWcpID0+IGltZy5zcmMgYXMgc3RyaW5nKVxyXG4gICAgY29uc3QgaGFzUmVzdHJpY3RlZCA9IGltYWdlVXJscy5zb21lKChpdSkgPT4gUkVTVFJJQ1RFRF9ET01BSU5TLnNvbWUoKHJkKSA9PiBpdS5pbmNsdWRlcyhyZCkpKVxyXG4gICAgcmV0dXJuIGhhc1Jlc3RyaWN0ZWQgPyBudWxsIDogaW1hZ2VVcmxzXHJcbiAgfVxyXG5cclxuICBjb25zdCB1cmxzRnJvbUV2ZW50RGF0YUhhbmRsZXIgPSBhc3luYyAodXJsczogc3RyaW5nW10pID0+IHtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdXJscy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBjb25zdCB1cmwgPSB1cmxzW2ldXHJcbiAgICAgIGNvbnN0IHNhdmVWYWx1ZTogU2F2ZVZhbHVlVHlwZSA9IHtpbWFnZVNyYzogdXJsLCBpZDogcmFuZG9tU3RyaW5nKCl9XHJcbiAgICAgIGF3YWl0IGFkZEltYWdlVG9RdWV1ZShzYXZlVmFsdWUsIHNpZGViYXIpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyAxKSB0cnkgZmlsZXMgZmlyc3QgKGJldHRlciBVWClcclxuICBjb25zdCBleHRyYWN0RmlsZXNGcm9tRXZlbnREYXRhID0gKGVkOiBEYXRhVHJhbnNmZXIpOiBGaWxlW10gPT4ge1xyXG4gICAgY29uc3QgaXRlbXM6IERhdGFUcmFuc2Zlckl0ZW1MaXN0ID0gZWQuaXRlbXNcclxuICAgIGNvbnN0IGZpbGVzOiBGaWxlW10gPSBbXVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBjb25zdCBpdGVtOiBEYXRhVHJhbnNmZXJJdGVtID0gaXRlbXNbaV1cclxuICAgICAgaWYgKCFpc0ZpbGVJbWFnZShpdGVtKSkgY29udGludWVcclxuICAgICAgY29uc3QgZmlsZSA9IGl0ZW0uZ2V0QXNGaWxlKClcclxuICAgICAgaWYgKCFmaWxlKSBjb250aW51ZVxyXG4gICAgICBmaWxlcy5wdXNoKGZpbGUpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmlsZXNcclxuICB9XHJcblxyXG4gIGNvbnN0IGZpbGVzOiBGaWxlW10gPSBleHRyYWN0RmlsZXNGcm9tRXZlbnREYXRhKGV2ZW50RGF0YSlcclxuICBpZiAoZmlsZXMgJiYgZmlsZXMubGVuZ3RoKSByZXR1cm4gcHJvY2Vzc0ltYWdlRmlsZXMoZmlsZXMsIHNpZGViYXIpXHJcblxyXG4gIC8vIDIpIGZhbGxiYWNrIHRvIFVSTHMgZnJvbSBIVE1MXHJcbiAgY29uc3QgdXJsczogc3RyaW5nW10gfCBudWxsID0gZXh0cmFjdFVybEZyb21FdmVudERhdGEoZXZlbnREYXRhKVxyXG4gIGlmICh1cmxzICYmIHVybHMubGVuZ3RoKSByZXR1cm4gdm9pZCB1cmxzRnJvbUV2ZW50RGF0YUhhbmRsZXIodXJscylcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGdldEltYWdlUXVldWUgPSAoKTogU2F2ZVZhbHVlVHlwZVtdID0+IGltYWdlUXVldWVcclxuXHJcbi8qKlxyXG4gKiBVcGxvYWQgYWxsIHF1ZXVlZCBGaWxlIGl0ZW1zIGFuZCBtdXRhdGUgcXVldWUgaW1hZ2VTcmMgLT4gc3RvcmVkIHBhdGguXHJcbiAqIE11c3QgYmUgYXdhaXRlZCBCRUZPUkUgY3JlYXRpbmcgQ2hhdE1lc3NhZ2UuXHJcbiAqL1xyXG5leHBvcnQgY29uc3QgZW5zdXJlVXBsb2FkZWRRdWV1ZSA9IGFzeW5jIChzaWRlYmFyOiBKUXVlcnkpID0+IHtcclxuICAvLyB1cGxvYWQgc2VxdWVudGlhbGx5IHRvIGF2b2lkIGhhbW1lcmluZyBGaWxlUGlja2VyXHJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbWFnZVF1ZXVlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICBjb25zdCBpdGVtID0gaW1hZ2VRdWV1ZVtpXVxyXG4gICAgaWYgKCFpdGVtLmZpbGUpIGNvbnRpbnVlIC8vIFVSTC1iYXNlZCBpdGVtXHJcbiAgICBjb25zdCBvbGRTcmMgPSBpdGVtLmltYWdlU3JjXHJcblxyXG4gICAgLy8gaWYgYWxyZWFkeSB1cGxvYWRlZCAocGF0aCkgc2tpcDsgd2UgdHJlYXQgYmxvYjogYXMgbm90IHVwbG9hZGVkXHJcbiAgICBpZiAoIWlzQmxvYlVybChvbGRTcmMpKSBjb250aW51ZVxyXG5cclxuICAgIGNvbnN0IHVwbG9hZGVkUGF0aCA9IGF3YWl0IHVwbG9hZEltYWdlKGl0ZW0pXHJcbiAgICBpdGVtLmltYWdlU3JjID0gdXBsb2FkZWRQYXRoXHJcblxyXG4gICAgLy8gY2xlYW4gYmxvYiB1cmxcclxuICAgIHNhZmVSZXZva2VPYmplY3RVcmwob2xkU3JjKVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHJlbW92ZUFsbEZyb21RdWV1ZSA9IChzaWRlYmFyOiBKUXVlcnkpID0+IHtcclxuICB3aGlsZSAoaW1hZ2VRdWV1ZS5sZW5ndGgpIHtcclxuICAgIGNvbnN0IGltYWdlRGF0YTogU2F2ZVZhbHVlVHlwZSB8IHVuZGVmaW5lZCA9IGltYWdlUXVldWUucG9wKClcclxuICAgIGlmICghaW1hZ2VEYXRhKSBjb250aW51ZVxyXG5cclxuICAgIGlmIChpbWFnZURhdGEuZmlsZSkgc2FmZVJldm9rZU9iamVjdFVybChpbWFnZURhdGEuaW1hZ2VTcmMpXHJcblxyXG4gICAgY29uc3QgaW1hZ2VFbGVtZW50ID0gZmluZChgIyR7aW1hZ2VEYXRhLmlkfWAsIHNpZGViYXIpXHJcbiAgICByZW1vdmUoaW1hZ2VFbGVtZW50KVxyXG4gIH1cclxuXHJcbiAgY29uc3QgdXBsb2FkQXJlYTogSlF1ZXJ5ID0gZmluZCgnI2NpLWNoYXQtdXBsb2FkLWFyZWEnLCBzaWRlYmFyKVxyXG4gIGFkZENsYXNzKHVwbG9hZEFyZWEsICdoaWRkZW4nKVxyXG59XHJcbiIsIlxyXG5pbXBvcnQge2JlZm9yZSwgY3JlYXRlLCBmaW5kLCBvbn0gZnJvbSAnLi4vdXRpbHMvSnF1ZXJ5V3JhcHBlcnMnXHJcbmltcG9ydCB7aXNWZXJpb3NuQWZ0ZXIxM30gZnJvbSAnLi4vdXRpbHMvVXRpbHMnXHJcbmltcG9ydCB7cmVtb3ZlQWxsRnJvbVF1ZXVlfSBmcm9tICcuLi9wcm9jZXNzb3JzL0ZpbGVQcm9jZXNzb3InXHJcblxyXG5jb25zdCBjcmVhdGVVcGxvYWRBcmVhID0gKCk6IEpRdWVyeSA9PlxyXG4gIGNyZWF0ZShgXHJcbiAgICA8ZGl2IGlkPVwiY2ktY2hhdC11cGxvYWQtYXJlYVwiIGNsYXNzPVwiaGlkZGVuXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJjaS11cGxvYWQtYXJlYS1pbWFnZXNcIj48L2Rpdj5cclxuICAgICAgPGkgY2xhc3M9XCJjaS1jbGVhci1hbGwgZmEtc29saWQgZmEtdHJhc2hcIj48L2k+XHJcbiAgICA8L2Rpdj5gKVxyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBpbml0VXBsb2FkQXJlYSA9IChzaWRlYmFyOiBKUXVlcnkpID0+IHtcclxuICBjb25zdCB1cGxvYWRBcmVhID0gY3JlYXRlVXBsb2FkQXJlYSgpXHJcblxyXG4gIC8vIDEuINCf0YvRgtCw0LXQvNGB0Y8g0LLRgdGC0LDQstC40YLRjCDQv9C10YDQtdC0INC/0L7Qu9C10Lwg0LLQstC+0LTQsCDRgdC+0L7QsdGJ0LXQvdC40LkgKCNjaGF0LW1lc3NhZ2UpXHJcbiAgY29uc3QgY2hhdE1lc3NhZ2U6IEpRdWVyeSA9IGZpbmQoJyNjaGF0LW1lc3NhZ2UnLCBzaWRlYmFyKVxyXG4gIGlmIChjaGF0TWVzc2FnZSAmJiBjaGF0TWVzc2FnZVswXSkge1xyXG4gICAgYmVmb3JlKGNoYXRNZXNzYWdlLCB1cGxvYWRBcmVhKVxyXG4gIH0gZWxzZSB7XHJcbiAgICAvLyAyLiDQl9Cw0YLQtdC8INC/0YvRgtCw0LXQvNGB0Y8g0L3QsNC50YLQuCDQsdC70L7QuiBjaGF04oCRY29udHJvbHMg0LLQvdGD0YLRgNC4INGB0LDQudC00LHQsNGA0LBcclxuICAgIGNvbnN0IHNlbGVjdG9yID0gaXNWZXJpb3NuQWZ0ZXIxMygpID8gJy5jaGF0LWNvbnRyb2xzJyA6ICcjY2hhdC1jb250cm9scydcclxuICAgIGxldCBjaGF0Q29udHJvbHMgPSBmaW5kKHNlbGVjdG9yLCBzaWRlYmFyKVxyXG5cclxuICAgIC8vIDMuINCV0YHQu9C4INC4INCyINGB0LDQudC00LHQsNGA0LUg0L3QtSDQvdCw0YjQu9C4LCDQuNGJ0LXQvCDQs9C70L7QsdCw0LvRjNC90L5cclxuICAgIGlmICghY2hhdENvbnRyb2xzIHx8ICFjaGF0Q29udHJvbHNbMF0pIHtcclxuICAgICAgY2hhdENvbnRyb2xzID0gZmluZChzZWxlY3RvcilcclxuICAgIH1cclxuICAgIGlmIChjaGF0Q29udHJvbHMgJiYgY2hhdENvbnRyb2xzWzBdKSB7XHJcbiAgICAgIGJlZm9yZShjaGF0Q29udHJvbHMsIHVwbG9hZEFyZWEpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyA0LiDQndCw0LLQtdGI0LjQstCw0LXQvCDQvtCx0YDQsNCx0L7RgtGH0LjQuiDQvdCwINC60L3QvtC/0LrRgyDCq9C+0YfQuNGB0YLQuNGC0YzCu1xyXG4gIGNvbnN0IGNsZWFyQnRuID0gZmluZCgnLmNpLWNsZWFyLWFsbCcsIHVwbG9hZEFyZWEpXHJcbiAgb24oY2xlYXJCdG4sICdjbGljaycsICgpID0+IHJlbW92ZUFsbEZyb21RdWV1ZShzaWRlYmFyKSlcclxufVxyXG4iLCJpbXBvcnQge2FkZENsYXNzLCBhcHBlbmQsIGNyZWF0ZSwgZmluZCwgb24sIHRyaWdnZXJ9IGZyb20gJy4uL3V0aWxzL0pxdWVyeVdyYXBwZXJzJ1xyXG5pbXBvcnQge3QsIHVzZXJDYW5VcGxvYWR9IGZyb20gJy4uL3V0aWxzL1V0aWxzJ1xyXG5pbXBvcnQge3Byb2Nlc3NJbWFnZUZpbGVzfSBmcm9tICcuLi9wcm9jZXNzb3JzL0ZpbGVQcm9jZXNzb3InXHJcbmltcG9ydCB7Z2V0U2V0dGluZ30gZnJvbSAnLi4vdXRpbHMvU2V0dGluZ3MnXHJcblxyXG5jb25zdCBjcmVhdGVVcGxvYWRCdXR0b24gPSAoKTogSlF1ZXJ5ID0+IGNyZWF0ZShgPGEgaWQ9XCJjaS11cGxvYWQtaW1hZ2VcIiB0aXRsZT1cIiR7dCgndXBsb2FkQnV0dG9uVGl0bGUnKX1cIj48aSBjbGFzcz1cImZhcyBmYS1pbWFnZXNcIj48L2k+PC9hPmApXHJcblxyXG5jb25zdCBjcmVhdGVIaWRkZW5VcGxvYWRJbnB1dCA9ICgpOiBKUXVlcnkgPT4gY3JlYXRlKGA8aW5wdXQgdHlwZT1cImZpbGVcIiBtdWx0aXBsZSBhY2NlcHQ9XCJpbWFnZS8qXCIgaWQ9XCJjaS11cGxvYWQtaW1hZ2UtaGlkZGVuLWlucHV0XCI+YClcclxuXHJcbmNvbnN0IHNldHVwRXZlbnRzID0gKHVwbG9hZEJ1dHRvbjogSlF1ZXJ5LCBoaWRkZW5VcGxvYWRJbnB1dDogSlF1ZXJ5LCBzaWRlYmFyOiBKUXVlcnkpID0+IHtcclxuICBjb25zdCBoaWRkZW5VcGxvYWRJbnB1dENoYW5nZUV2ZW50SGFuZGxlciA9IChldnQ6IEV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCBjdXJyZW50VGFyZ2V0OiBIVE1MSW5wdXRFbGVtZW50ID0gZXZ0LmN1cnJlbnRUYXJnZXQgYXMgSFRNTElucHV0RWxlbWVudFxyXG4gICAgY29uc3QgZmlsZXM6IEZpbGVMaXN0IHwgbnVsbCA9IGN1cnJlbnRUYXJnZXQuZmlsZXNcclxuICAgIGlmICghZmlsZXMpIHJldHVyblxyXG5cclxuICAgIHByb2Nlc3NJbWFnZUZpbGVzKGZpbGVzLCBzaWRlYmFyKVxyXG4gICAgY3VycmVudFRhcmdldC52YWx1ZSA9ICcnXHJcbiAgfVxyXG4gIGNvbnN0IHVwbG9hZEJ1dHRvbkNsaWNrRXZlbnRIYW5kbGVyID0gKGV2dDogRXZlbnQpID0+IHtcclxuICAgIGV2dC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB0cmlnZ2VyKGhpZGRlblVwbG9hZElucHV0LCAnY2xpY2snKVxyXG4gIH1cclxuXHJcbiAgb24oaGlkZGVuVXBsb2FkSW5wdXQsICdjaGFuZ2UnLCBoaWRkZW5VcGxvYWRJbnB1dENoYW5nZUV2ZW50SGFuZGxlcilcclxuICBvbih1cGxvYWRCdXR0b24sICdjbGljaycsIHVwbG9hZEJ1dHRvbkNsaWNrRXZlbnRIYW5kbGVyKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgaW5pdFVwbG9hZEJ1dHRvbiA9IChzaWRlYmFyOiBKUXVlcnkpID0+IHtcclxuICBpZiAoIWdldFNldHRpbmcoJ3VwbG9hZEJ1dHRvbicpKSByZXR1cm5cclxuXHJcbiAgY29uc3QgY29udHJvbEJ1dHRvbnM6IEpRdWVyeSA9IGZpbmQoJy5jb250cm9sLWJ1dHRvbnMnLCBzaWRlYmFyKVxyXG4gIGNvbnN0IHVwbG9hZEJ1dHRvbjogSlF1ZXJ5ID0gY3JlYXRlVXBsb2FkQnV0dG9uKClcclxuICBjb25zdCBoaWRkZW5VcGxvYWRJbnB1dDogSlF1ZXJ5ID0gY3JlYXRlSGlkZGVuVXBsb2FkSW5wdXQoKVxyXG5cclxuICBpZiAoIXVzZXJDYW5VcGxvYWQodHJ1ZSkpIHJldHVyblxyXG5cclxuICBpZiAoY29udHJvbEJ1dHRvbnNbMF0pIHtcclxuICAgIGFkZENsYXNzKGNvbnRyb2xCdXR0b25zLCAnY2ktY29udHJvbC1idXR0b25zLWdtJylcclxuICAgIGFwcGVuZChjb250cm9sQnV0dG9ucywgdXBsb2FkQnV0dG9uKVxyXG4gICAgYXBwZW5kKGNvbnRyb2xCdXR0b25zLCBoaWRkZW5VcGxvYWRJbnB1dClcclxuICB9IGVsc2Uge1xyXG4gICAgLy8gUGxheWVycyBkb24ndCBoYXZlIGJ1dHRvbnNcclxuICAgIGNvbnN0IGNoYXRDb250cm9sczogSlF1ZXJ5ID0gZmluZCgnI2NoYXQtY29udHJvbHMnLCBzaWRlYmFyKVxyXG4gICAgY29uc3QgbmV3Q29udHJvbEJ1dHRvbnMgPSBjcmVhdGUoJzxkaXYgY2xhc3M9XCJjaS1jb250cm9sLWJ1dHRvbnMtcFwiPjwvZGl2PicpXHJcblxyXG4gICAgYXBwZW5kKG5ld0NvbnRyb2xCdXR0b25zLCB1cGxvYWRCdXR0b24pXHJcbiAgICBhcHBlbmQobmV3Q29udHJvbEJ1dHRvbnMsIGhpZGRlblVwbG9hZElucHV0KVxyXG4gICAgYXBwZW5kKGNoYXRDb250cm9scywgbmV3Q29udHJvbEJ1dHRvbnMpXHJcbiAgfVxyXG5cclxuICBzZXR1cEV2ZW50cyh1cGxvYWRCdXR0b24sIGhpZGRlblVwbG9hZElucHV0LCBzaWRlYmFyKVxyXG59XHJcblxyXG4iLCJpbXBvcnQgeyBhcHBlbmQsIGF0dHIsIGNyZWF0ZSwgZmluZCwgZm9jdXMsIHJlbW92ZSwgcmVtb3ZlQXR0ciB9IGZyb20gJy4uL3V0aWxzL0pxdWVyeVdyYXBwZXJzJ1xyXG5pbXBvcnQgeyBpc1Zlcmlvc25BZnRlcjEzIH0gZnJvbSAnLi4vdXRpbHMvVXRpbHMnXHJcblxyXG5jb25zdCB0b2dnbGVDaGF0ID0gKGNoYXQ6IEpRdWVyeSwgdG9nZ2xlOiBib29sZWFuKSA9PiB7XHJcbiAgaWYgKCF0b2dnbGUpIHtcclxuICAgIGF0dHIoY2hhdCwgJ2Rpc2FibGVkJywgdHJ1ZSlcclxuICAgIHJldHVyblxyXG4gIH1cclxuICByZW1vdmVBdHRyKGNoYXQsICdkaXNhYmxlZCcpXHJcbiAgZm9jdXMoY2hhdClcclxufVxyXG5cclxuY29uc3QgdG9nZ2xlU3Bpbm5lciA9IChjaGF0Rm9ybTogSlF1ZXJ5LCB0b2dnbGU6IGJvb2xlYW4pID0+IHtcclxuICBjb25zdCBzcGlubmVySWQgPSAnY2ktc3Bpbm5lcidcclxuICBjb25zdCBzcGlubmVyID0gZmluZChgIyR7c3Bpbm5lcklkfWAsIGNoYXRGb3JtKVxyXG5cclxuICBpZiAoIXRvZ2dsZSAmJiBzcGlubmVyWzBdKSB7XHJcbiAgICByZW1vdmUoc3Bpbm5lcilcclxuICAgIHJldHVyblxyXG4gIH1cclxuXHJcbiAgaWYgKHRvZ2dsZSAmJiAhc3Bpbm5lclswXSkge1xyXG4gICAgY29uc3QgbmV3U3Bpbm5lciA9IGNyZWF0ZShgPGRpdiBpZD1cIiR7c3Bpbm5lcklkfVwiPjwvZGl2PmApXHJcbiAgICBhcHBlbmQoY2hhdEZvcm0sIG5ld1NwaW5uZXIpXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0VXBsb2FkaW5nU3RhdGVzID0gKHNpZGViYXI6IEpRdWVyeSkgPT4ge1xyXG4gIGNvbnN0IGNoYXRGb3JtUXVlcnkgPSBpc1Zlcmlvc25BZnRlcjEzKCkgPyAnLmNoYXQtZm9ybScgOiAnI2NoYXQtZm9ybSdcclxuICBjb25zdCBjaGF0Rm9ybSA9IGZpbmQoY2hhdEZvcm1RdWVyeSwgc2lkZWJhcilcclxuICBjb25zdCBjaGF0ID0gZmluZCgnI2NoYXQtbWVzc2FnZScsIHNpZGViYXIpXHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBvbigpIHtcclxuICAgICAgdG9nZ2xlQ2hhdChjaGF0LCBmYWxzZSlcclxuICAgICAgdG9nZ2xlU3Bpbm5lcihjaGF0Rm9ybSwgdHJ1ZSlcclxuICAgIH0sXHJcbiAgICBvZmYoKSB7XHJcbiAgICAgIHRvZ2dsZUNoYXQoY2hhdCwgdHJ1ZSlcclxuICAgICAgdG9nZ2xlU3Bpbm5lcihjaGF0Rm9ybSwgZmFsc2UpXHJcbiAgICB9LFxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQge2ZpbmQsIG9ufSBmcm9tICcuLi91dGlscy9KcXVlcnlXcmFwcGVycydcclxuaW1wb3J0IHtlbnN1cmVVcGxvYWRlZFF1ZXVlLCBnZXRJbWFnZVF1ZXVlLCBwcm9jZXNzRHJvcEFuZFBhc3RlSW1hZ2VzLCByZW1vdmVBbGxGcm9tUXVldWUsIFNhdmVWYWx1ZVR5cGV9IGZyb20gJy4uL3Byb2Nlc3NvcnMvRmlsZVByb2Nlc3NvcidcclxuaW1wb3J0IHtpc1Zlcmlvc25BZnRlcjEzLCB0fSBmcm9tICcuLi91dGlscy9VdGlscydcclxuaW1wb3J0IHtnZXRVcGxvYWRpbmdTdGF0ZXN9IGZyb20gJy4vTG9hZGVyJ1xyXG5cclxubGV0IGlzU2VuZGluZyA9IGZhbHNlXHJcblxyXG5jb25zdCBpbWFnZVRlbXBsYXRlID0gKGltYWdlUHJvcHM6IFNhdmVWYWx1ZVR5cGUpOiBzdHJpbmcgPT4gYDxkaXYgY2xhc3M9XCJjaS1tZXNzYWdlLWltYWdlXCI+PGltZyBzcmM9XCIke2ltYWdlUHJvcHMuaW1hZ2VTcmN9XCIgYWx0PVwiJHtpbWFnZVByb3BzLm5hbWUgfHwgdCgndW5hYmxlVG9Mb2FkSW1hZ2UnKX1cIj48L2Rpdj5gXHJcblxyXG5jb25zdCBtZXNzYWdlVGVtcGxhdGUgPSAoaW1hZ2VRdWV1ZTogU2F2ZVZhbHVlVHlwZVtdKSA9PiB7XHJcbiAgY29uc3QgaW1hZ2VUZW1wbGF0ZXM6IHN0cmluZ1tdID0gaW1hZ2VRdWV1ZS5tYXAoKGltYWdlUHJvcHM6IFNhdmVWYWx1ZVR5cGUpOiBzdHJpbmcgPT4gaW1hZ2VUZW1wbGF0ZShpbWFnZVByb3BzKSlcclxuICByZXR1cm4gYDxkaXYgY2xhc3M9XCJjaS1tZXNzYWdlXCI+JHtpbWFnZVRlbXBsYXRlcy5qb2luKCcnKX08L2Rpdj5gXHJcbn1cclxuXHJcbmNvbnN0IGdldENoYXRNZXNzYWdlVHlwZSA9ICgpID0+IHtcclxuICBjb25zdCBjaGF0TWVzc2FnZVR5cGUgPSBpc1Zlcmlvc25BZnRlcjEzKCkgP1xyXG4gICAgICBDT05TVC5DSEFUX01FU1NBR0VfU1RZTEVTLk9PQyA6XHJcbiAgICAgIENPTlNULkNIQVRfTUVTU0FHRV9UWVBFUy5PT0NcclxuICByZXR1cm4gdHlwZW9mIGNoYXRNZXNzYWdlVHlwZSAhPT0gJ3VuZGVmaW5lZCcgPyBjaGF0TWVzc2FnZVR5cGUgOiAxXHJcbn1cclxuXHJcbmNvbnN0IHBhc3RlQW5kRHJvcEV2ZW50SGFuZGxlciA9IChzaWRlYmFyOiBKUXVlcnkpID0+IChldnQ6IGFueSkgPT4ge1xyXG4gIGNvbnN0IG9yaWdpbmFsRXZlbnQ6IENsaXBib2FyZEV2ZW50IHwgRHJhZ0V2ZW50ID0gZXZ0Lm9yaWdpbmFsRXZlbnRcclxuICBjb25zdCBldmVudERhdGE6IERhdGFUcmFuc2ZlciB8IG51bGwgPSAob3JpZ2luYWxFdmVudCBhcyBDbGlwYm9hcmRFdmVudCkuY2xpcGJvYXJkRGF0YSB8fCAob3JpZ2luYWxFdmVudCBhcyBEcmFnRXZlbnQpLmRhdGFUcmFuc2ZlclxyXG4gIGlmICghZXZlbnREYXRhKSByZXR1cm5cclxuXHJcbiAgcHJvY2Vzc0Ryb3BBbmRQYXN0ZUltYWdlcyhldmVudERhdGEsIHNpZGViYXIpXHJcbn1cclxuXHJcbmNvbnN0IHN1Ym1pdEhhbmRsZXIgPSAoc2lkZWJhcjogSlF1ZXJ5KSA9PiBhc3luYyAoZXZ0OiBhbnkpID0+IHtcclxuICBpZiAoaXNTZW5kaW5nKSByZXR1cm5cclxuXHJcbiAgY29uc3QgaW1hZ2VRdWV1ZSA9IGdldEltYWdlUXVldWUoKVxyXG4gIGlmICghaW1hZ2VRdWV1ZS5sZW5ndGgpIHJldHVybiAvLyDQv9GD0YHRgtGMIEZvdW5kcnkg0L7RgtC/0YDQsNCy0LvRj9C10YIg0L7QsdGL0YfQvdC+0LUg0YHQvtC+0LHRidC10L3QuNC1XHJcblxyXG4gIC8vINCc0Ysg0L7RgtC/0YDQsNCy0LvRj9C10Lwg0YHQsNC80LhcclxuICBldnQucHJldmVudERlZmF1bHQoKVxyXG4gIGV2dC5zdG9wUHJvcGFnYXRpb24oKVxyXG5cclxuICBpc1NlbmRpbmcgPSB0cnVlXHJcbiAgY29uc3QgdXBsb2FkU3RhdGUgPSBnZXRVcGxvYWRpbmdTdGF0ZXMoc2lkZWJhcilcclxuICB1cGxvYWRTdGF0ZS5vbigpXHJcblxyXG4gIHRyeSB7XHJcbiAgICAvLyDQtNC+0LbQtNCw0YLRjNGB0Y8g0LfQsNCz0YDRg9C30LrQuCDQstGB0LXRhSBGaWxlLdGN0LvQtdC80LXQvdGC0L7QsiDQvtGH0LXRgNC10LTQuFxyXG4gICAgYXdhaXQgZW5zdXJlVXBsb2FkZWRRdWV1ZShzaWRlYmFyKVxyXG5cclxuICAgIGNvbnN0IGlucHV0ID0gZmluZCgnI2NoYXQtbWVzc2FnZScsIHNpZGViYXIpIGFzIGFueVxyXG4gICAgY29uc3QgdGV4dDogc3RyaW5nID0gaW5wdXQ/LnZhbCA/IFN0cmluZyhpbnB1dC52YWwoKSA/PyAnJykgOiAnJ1xyXG4gICAgY29uc3QgY29udGVudCA9IHRleHQgP1xyXG4gICAgICAgIGAke21lc3NhZ2VUZW1wbGF0ZShpbWFnZVF1ZXVlKX08ZGl2IGNsYXNzPVwiY2ktbm90ZXNcIj4ke3RleHR9PC9kaXY+YCA6XHJcbiAgICAgICAgbWVzc2FnZVRlbXBsYXRlKGltYWdlUXVldWUpXHJcblxyXG4gICAgYXdhaXQgQ2hhdE1lc3NhZ2UuY3JlYXRlKHtcclxuICAgICAgY29udGVudCxcclxuICAgICAgdHlwZTogZ2V0Q2hhdE1lc3NhZ2VUeXBlKCksXHJcbiAgICAgIHVzZXI6IChnYW1lIGFzIEdhbWUpLnVzZXIsXHJcbiAgICB9KVxyXG5cclxuICAgIC8vINC+0YfQuNGB0YLQuNGC0Ywg0L/QvtC70LUg0LLQstC+0LTQsFxyXG4gICAgaWYgKGlucHV0Py52YWwpIGlucHV0LnZhbCgnJylcclxuXHJcbiAgICByZW1vdmVBbGxGcm9tUXVldWUoc2lkZWJhcilcclxuICB9IGZpbmFsbHkge1xyXG4gICAgdXBsb2FkU3RhdGUub2ZmKClcclxuICAgIGlzU2VuZGluZyA9IGZhbHNlXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgaXNVcGxvYWRBcmVhUmVuZGVyZWQgPSAoc2lkZWJhcjogSlF1ZXJ5KTogYm9vbGVhbiA9PiB7XHJcbiAgY29uc3QgdXBsb2FkQXJlYSA9IGZpbmQoJyNjaS1jaGF0LXVwbG9hZC1hcmVhJywgc2lkZWJhcilcclxuICByZXR1cm4gISF1cGxvYWRBcmVhLmxlbmd0aFxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgaW5pdENoYXRTaWRlYmFyID0gKHNpZGViYXI6IEpRdWVyeSkgPT4ge1xyXG4gIC8vIHBhc3RlL2Ryb3BcclxuICBvbihzaWRlYmFyLCAncGFzdGUgZHJvcCcsIHBhc3RlQW5kRHJvcEV2ZW50SGFuZGxlcihzaWRlYmFyKSlcclxuXHJcbiAgLy8gc3VibWl0ICjQutC90L7Qv9C60LAvZW50ZXIpXHJcbiAgY29uc3QgY2hhdEZvcm1RdWVyeSA9IGlzVmVyaW9zbkFmdGVyMTMoKSA/ICcuY2hhdC1mb3JtJyA6ICcjY2hhdC1mb3JtJ1xyXG4gIGNvbnN0IGNoYXRGb3JtID0gZmluZChjaGF0Rm9ybVF1ZXJ5LCBzaWRlYmFyKVxyXG4gIG9uKGNoYXRGb3JtLCAnc3VibWl0Jywgc3VibWl0SGFuZGxlcihzaWRlYmFyKSlcclxufVxyXG4iLCJpbXBvcnQgeyBmaW5kLCBvbiB9IGZyb20gJy4uL3V0aWxzL0pxdWVyeVdyYXBwZXJzJ1xyXG5pbXBvcnQgeyBJbWFnZVBvcG91dEltcGxlbWVudGF0aW9uLCBpc1Zlcmlvc25BZnRlcjEzIH0gZnJvbSAnLi4vdXRpbHMvVXRpbHMnXHJcblxyXG5leHBvcnQgY29uc3QgaW5pdENoYXRNZXNzYWdlID0gKGNoYXRNZXNzYWdlOiBKUXVlcnkpID0+IHtcclxuICBjb25zdCBpbWFnZXMgPSBmaW5kKCcuY2ktbWVzc2FnZS1pbWFnZSBpbWcnLCBjaGF0TWVzc2FnZSlcclxuICBpZiAoIWltYWdlc1swXSkgcmV0dXJuXHJcblxyXG4gIGNvbnN0IGNsaWNrSW1hZ2VIYW5kbGUgPSAoZXZ0OiBFdmVudCkgPT4ge1xyXG4gICAgY29uc3Qgc3JjID0gKGV2dC50YXJnZXQgYXMgSFRNTEltYWdlRWxlbWVudCkuc3JjXHJcbiAgICBjb25zdCBpbWFnZVBvcHVwID0gSW1hZ2VQb3BvdXRJbXBsZW1lbnRhdGlvbigpXHJcblxyXG4gICAgaWYgKGlzVmVyaW9zbkFmdGVyMTMoKSkge1xyXG4gICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgIG5ldyBpbWFnZVBvcHVwKHsgc3JjLCBlZGl0YWJsZTogZmFsc2UsIHNoYXJlYWJsZTogdHJ1ZSB9KS5yZW5kZXIodHJ1ZSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgbmV3IGltYWdlUG9wdXAoc3JjLCB7IGVkaXRhYmxlOiBmYWxzZSwgc2hhcmVhYmxlOiB0cnVlIH0pLnJlbmRlcih0cnVlKVxyXG4gICAgfVxyXG4gIH1cclxuICBvbihpbWFnZXMsICdjbGljaycsIGNsaWNrSW1hZ2VIYW5kbGUpXHJcbn1cclxuIiwiaW1wb3J0IHt0fSBmcm9tICcuLi91dGlscy9VdGlscydcclxuXHJcbmNvbnN0IGltYWdlTWFya2Rvd25SZWcgPSAvIVxccypjaVxccypcXHxcXHMqKC4rPylcXHMqIS9naVxyXG5jb25zdCBpbWFnZVJlZyA9IC9cXHcrXFwuKGdpZnxwbmd8anBnfGpwZWd8d2VicHxzdmd8cHNkfGJtcHx0aWYpL2dpXHJcblxyXG5jb25zdCBpbWFnZVRlbXBsYXRlID0gKHNyYzogc3RyaW5nKTogc3RyaW5nID0+IGA8ZGl2IGNsYXNzPVwiY2ktbWVzc2FnZS1pbWFnZVwiPjxpbWcgc3JjPVwiJHtzcmN9XCIgYWx0PVwiJHt0KCd1bmFibGVUb0xvYWRJbWFnZScpfVwiPjwvZGl2PmBcclxuXHJcbmV4cG9ydCBjb25zdCBwcm9jZXNzTWVzc2FnZSA9IChtZXNzYWdlOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xyXG4gIGlmICghbWVzc2FnZS5tYXRjaChpbWFnZU1hcmtkb3duUmVnKSkgcmV0dXJuIG1lc3NhZ2VcclxuXHJcbiAgcmV0dXJuIG1lc3NhZ2UucmVwbGFjZUFsbChpbWFnZU1hcmtkb3duUmVnLCAobTogc3RyaW5nLCBzcmM6IHN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFzcmMubWF0Y2goaW1hZ2VSZWcpKSByZXR1cm4gbVxyXG4gICAgcmV0dXJuIGltYWdlVGVtcGxhdGUoc3JjKVxyXG4gIH0pXHJcbn1cclxuIiwiaW1wb3J0ICcuL3N0eWxlcy9jaGF0LWltYWdlcy5zY3NzJ1xyXG5pbXBvcnQgeyBpbml0VXBsb2FkQXJlYSB9IGZyb20gJy4vc2NyaXB0cy9jb21wb25lbnRzL1VwbG9hZEFyZWEnXHJcbmltcG9ydCB7IGluaXRVcGxvYWRCdXR0b24gfSBmcm9tICcuL3NjcmlwdHMvY29tcG9uZW50cy9VcGxvYWRCdXR0b24nXHJcbmltcG9ydCB7IGluaXRDaGF0U2lkZWJhciwgaXNVcGxvYWRBcmVhUmVuZGVyZWQgfSBmcm9tICcuL3NjcmlwdHMvY29tcG9uZW50cy9DaGF0U2lkZWJhcidcclxuaW1wb3J0IHsgaW5pdENoYXRNZXNzYWdlIH0gZnJvbSAnLi9zY3JpcHRzL2NvbXBvbmVudHMvQ2hhdE1lc3NhZ2UnXHJcbmltcG9ydCB7IGNyZWF0ZSwgZmluZCB9IGZyb20gJy4vc2NyaXB0cy91dGlscy9KcXVlcnlXcmFwcGVycydcclxuaW1wb3J0IHsgcHJvY2Vzc01lc3NhZ2UgfSBmcm9tICcuL3NjcmlwdHMvcHJvY2Vzc29ycy9NZXNzYWdlUHJvY2Vzc29yJ1xyXG5pbXBvcnQgeyBjcmVhdGVVcGxvYWRGb2xkZXIsIGdldFNldHRpbmdzLCByZWdpc3RlclNldHRpbmcgfSBmcm9tICcuL3NjcmlwdHMvdXRpbHMvU2V0dGluZ3MnXHJcbmltcG9ydCB7IGlzVmVyaW9zbkFmdGVyMTMgfSBmcm9tICcuL3NjcmlwdHMvdXRpbHMvVXRpbHMnXHJcblxyXG5jb25zdCByZWdpc3RlclNldHRpbmdzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHNldHRpbmdzID0gZ2V0U2V0dGluZ3MoKVxyXG4gIHNldHRpbmdzLmZvckVhY2goKHNldHRpbmcpID0+IHJlZ2lzdGVyU2V0dGluZyhzZXR0aW5nKSlcclxufVxyXG5cclxuSG9va3Mub25jZSgnaW5pdCcsIGFzeW5jICgpID0+IHtcclxuICByZWdpc3RlclNldHRpbmdzKClcclxuICByZWdpc3Rlckhvb2tzKClcclxuXHJcbiAgYXdhaXQgY3JlYXRlVXBsb2FkRm9sZGVyKClcclxufSlcclxuXHJcbmNvbnN0IHJlZ2lzdGVySG9va3MgPSAoKSA9PiB7XHJcbiAgaWYgKGlzVmVyaW9zbkFmdGVyMTMoKSkge1xyXG4gICAgSG9va3Mub24oJ3JlbmRlckNoYXRNZXNzYWdlSFRNTCcsIChfMDogbmV2ZXIsIGNoYXRNZXNzYWdlRWxlbWVudDogSFRNTEVsZW1lbnQpID0+IHtcclxuICAgICAgY29uc3QgY2hhdE1lc3NhZ2UgPSBjcmVhdGUoY2hhdE1lc3NhZ2VFbGVtZW50KVxyXG5cclxuICAgICAgY29uc3QgY2lNZXNzYWdlID0gZmluZCgnLmNpLW1lc3NhZ2UtaW1hZ2UnLCBjaGF0TWVzc2FnZSlcclxuICAgICAgaWYgKCFjaU1lc3NhZ2VbMF0pIHJldHVyblxyXG5cclxuICAgICAgaW5pdENoYXRNZXNzYWdlKGNoYXRNZXNzYWdlKVxyXG4gICAgfSlcclxuXHJcbiAgICBjb25zdCBpbml0RXZlbnRzID0gKHNpZGViYXI6IEpRdWVyeSkgPT4ge1xyXG4gICAgICAvLyBQcmV2ZW50IGFkZGluZyBldmVudHMgbXVsdGlwbGUgdGltZXNcclxuICAgICAgaWYgKGlzVXBsb2FkQXJlYVJlbmRlcmVkKHNpZGViYXIpKSByZXR1cm5cclxuXHJcbiAgICAgIGluaXRVcGxvYWRBcmVhKHNpZGViYXIpXHJcbiAgICAgIC8vIFJlbW92ZWQgaW4gdmVyc2lvbiAxMyBcclxuICAgICAgLy8gaW5pdFVwbG9hZEJ1dHRvbihzaWRlYmFyKVxyXG4gICAgICBpbml0Q2hhdFNpZGViYXIoc2lkZWJhcilcclxuICAgIH1cclxuXHJcbiAgICBIb29rcy5vbignY29sbGFwc2VTaWRlYmFyJywgKHNpZGViYXI6IGFueSwgY29sbGFwc2VkOiBib29sZWFuKSA9PiB7XHJcbiAgICAgIGlmICghc2lkZWJhciB8fCBjb2xsYXBzZWQpIHJldHVyblxyXG5cclxuICAgICAgY29uc3Qgc2lkZWJhckVsZW1lbnQgPSBzaWRlYmFyLmVsZW1lbnRcclxuICAgICAgaWYgKCFzaWRlYmFyRWxlbWVudCkgcmV0dXJuXHJcblxyXG4gICAgICBjb25zdCBoYXNDaGF0RWxlbWVudCA9IHNpZGViYXJFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNjaGF0LW1lc3NhZ2UnKVxyXG4gICAgICBpZiAoIWhhc0NoYXRFbGVtZW50KSByZXR1cm5cclxuXHJcbiAgICAgIGNvbnN0IHNpZGViYXJKcSA9ICQoc2lkZWJhckVsZW1lbnQpXHJcbiAgICAgIGluaXRFdmVudHMoc2lkZWJhckpxKVxyXG4gICAgfSlcclxuXHJcbiAgICBIb29rcy5vbignYWN0aXZhdGVDaGF0TG9nJywgKGNoYXRMb2c6IGFueSkgPT4ge1xyXG4gICAgICBpZiAoIWNoYXRMb2cpIHJldHVyblxyXG5cclxuICAgICAgY29uc3QgY2hhdExvZ0VsZW1lbnQgPSBjaGF0TG9nLmVsZW1lbnRcclxuICAgICAgaWYgKCFjaGF0TG9nRWxlbWVudCkgcmV0dXJuXHJcblxyXG4gICAgICBjb25zdCBoYXNDaGF0RWxlbWVudCA9IGNoYXRMb2dFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNjaGF0LW1lc3NhZ2UnKVxyXG4gICAgICBpZiAoIWhhc0NoYXRFbGVtZW50KSByZXR1cm5cclxuXHJcbiAgICAgIGNvbnN0IGNoYXRMb2dKcSA9ICQoY2hhdExvZ0VsZW1lbnQpXHJcbiAgICAgIGluaXRFdmVudHMoY2hhdExvZ0pxKVxyXG4gICAgfSlcclxuICB9IGVsc2Uge1xyXG4gICAgSG9va3Mub24oJ3JlbmRlckNoYXRNZXNzYWdlJywgKF8wOiBuZXZlciwgY2hhdE1lc3NhZ2U6IEpRdWVyeSkgPT4ge1xyXG4gICAgICBjb25zdCBjaU1lc3NhZ2UgPSBmaW5kKCcuY2ktbWVzc2FnZS1pbWFnZScsIGNoYXRNZXNzYWdlKVxyXG4gICAgICBpZiAoIWNpTWVzc2FnZVswXSkgcmV0dXJuXHJcblxyXG4gICAgICBpbml0Q2hhdE1lc3NhZ2UoY2hhdE1lc3NhZ2UpXHJcbiAgICB9KVxyXG5cclxuICAgIEhvb2tzLm9uKCdyZW5kZXJTaWRlYmFyVGFiJywgKF8wOiBuZXZlciwgc2lkZWJhcjogSlF1ZXJ5KSA9PiB7XHJcbiAgICAgIGNvbnN0IHNpZGViYXJFbGVtZW50OiBIVE1MRWxlbWVudCB8IG51bGwgPSBzaWRlYmFyWzBdXHJcbiAgICAgIGlmICghc2lkZWJhckVsZW1lbnQpIHJldHVyblxyXG5cclxuICAgICAgY29uc3QgaGFzQ2hhdEVsZW1lbnQgPSBzaWRlYmFyRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjY2hhdC1tZXNzYWdlJylcclxuICAgICAgaWYgKCFoYXNDaGF0RWxlbWVudCkgcmV0dXJuXHJcblxyXG4gICAgICBpbml0VXBsb2FkQXJlYShzaWRlYmFyKVxyXG4gICAgICBpbml0VXBsb2FkQnV0dG9uKHNpZGViYXIpXHJcbiAgICAgIGluaXRDaGF0U2lkZWJhcihzaWRlYmFyKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIEhvb2tzLm9uKCdwcmVDcmVhdGVDaGF0TWVzc2FnZScsIChjaGF0TWVzc2FnZTogYW55LCB1c2VyT3B0aW9uczogbmV2ZXIsIG1lc3NhZ2VPcHRpb25zOiBhbnkpID0+IHtcclxuICAgIGNvbnN0IHByb2Nlc3NlZE1lc3NhZ2U6IHN0cmluZyA9IHByb2Nlc3NNZXNzYWdlKGNoYXRNZXNzYWdlLmNvbnRlbnQpXHJcbiAgICBpZiAoY2hhdE1lc3NhZ2UuY29udGVudCA9PT0gcHJvY2Vzc2VkTWVzc2FnZSkgcmV0dXJuXHJcblxyXG4gICAgY2hhdE1lc3NhZ2UuY29udGVudCA9IHByb2Nlc3NlZE1lc3NhZ2VcclxuICAgIGNoYXRNZXNzYWdlLl9zb3VyY2UuY29udGVudCA9IHByb2Nlc3NlZE1lc3NhZ2VcclxuICAgIG1lc3NhZ2VPcHRpb25zLmNoYXRCdWJibGUgPSBmYWxzZVxyXG4gIH0pXHJcbn1cclxuIl0sIm5hbWVzIjpbImNyZWF0ZSIsImh0bWwiLCJiZWZvcmUiLCJyZWZlcmVuY2VOb2RlIiwibmV3Tm9kZSIsImZpbmQiLCJzZWxlY3RvciIsInBhcmVudE5vZGUiLCJhcHBlbmQiLCJvbiIsImV2ZW50VHlwZSIsImV2ZW50RnVuY3Rpb24iLCJ0cmlnZ2VyIiwicmVtb3ZlQ2xhc3MiLCJjbGFzc1N0cmluZyIsImFkZENsYXNzIiwicmVtb3ZlIiwibm9kZSIsImF0dHIiLCJhdHRySWQiLCJhdHRyVmFsdWUiLCJyZW1vdmVBdHRyIiwiZm9jdXMiLCJPUklHSU5fRk9MREVSIiwidCIsInRleHQiLCJfYSIsInJhbmRvbVN0cmluZyIsInVzZXJDYW5VcGxvYWQiLCJzaWxlbnQiLCJ1c2VyUm9sZSIsImZpbGVVcGxvYWRQZXJtaXNzaW9ucyIsIl9iIiwiX2MiLCJ1cGxvYWRQZXJtaXNzaW9uIiwiX2QiLCJnZXRGb3VuZHJ5VmVyc2lvbiIsImlzVmVyaW9zbkFmdGVyMTMiLCJGaWxlUGlja2VySW1wbGVtZW50YXRpb24iLCJJbWFnZVBvcG91dEltcGxlbWVudGF0aW9uIiwiX21lcmdlTmFtZXNwYWNlcyIsImUiLCJyIiwiaSIsImNvcHlFeGlmV2l0aG91dE9yaWVudGF0aW9uIiwibyIsImdldEFwcDFTZWdtZW50IiwicyIsImEiLCJmIiwibCIsImMiLCJVWklQIiwidSIsImgiLCJkIiwiQSIsImciLCJwIiwibSIsIl8iLCJ3IiwiYiIsInkiLCJFIiwiRiIsIkIiLCJVIiwiQyIsIkkiLCJRIiwiTSIsIngiLCJTIiwiUiIsIlQiLCJPIiwiUCIsIkgiLCJMIiwicHVzaFYiLCJVUE5HIiwiZGVjb2RlSW1hZ2UiLCJfZ2V0QlBQIiwidiIsIl9kZWNvbXByZXNzIiwiX2luZmxhdGUiLCJfZmlsdGVyWmVybyIsIm4iLCJfcGFldGgiLCJfSUhEUiIsIl9jb3B5VGlsZSIsImFkZEVyciIsIk4iLCJEIiwiZGl0aGVyIiwiX21haW4iLCJjb21wcmVzc1BORyIsImNvbXByZXNzIiwiX3ByZXBhcmVEaWZmIiwiX3VwZGF0ZUZyYW1lIiwicXVhbnRpemUiLCJfZmlsdGVyTGluZSIsImdldEtEdHJlZSIsImdldE5lYXJlc3QiLCJwbGFuZURzdCIsInN0YXRzIiwiZXN0YXRzIiwic3BsaXRQaXhlbHMiLCJ2ZWNEb3QiLCJzZXQxNiIsInNldDMyIiwic2VlayIsImNvbnZlcnQiLCJDdXN0b21GaWxlIiwiQ3VzdG9tRmlsZVJlYWRlciIsImdldEZpbGVmcm9tRGF0YVVybCIsImdldERhdGFVcmxGcm9tRmlsZSIsImxvYWRJbWFnZSIsImdldEJyb3dzZXJOYW1lIiwiYXBwcm94aW1hdGVCZWxvd01heGltdW1DYW52YXNTaXplT2ZCcm93c2VyIiwiZ2V0TmV3Q2FudmFzQW5kQ3R4IiwiZHJhd0ltYWdlSW5DYW52YXMiLCJpc0lPUyIsImRyYXdGaWxlSW5DYW52YXMiLCIkVHJ5XzJfUG9zdCIsIiRUcnlfMl9DYXRjaCIsIiRUcnlfM19DYXRjaCIsImNhbnZhc1RvRmlsZSIsIiRJZl80IiwiJElmXzUiLCIkSWZfNiIsImNsZWFudXBDYW52YXNNZW1vcnkiLCJpc0F1dG9PcmllbnRhdGlvbkluQnJvd3NlciIsImdldEV4aWZPcmllbnRhdGlvbiIsImhhbmRsZU1heFdpZHRoT3JIZWlnaHQiLCJmb2xsb3dFeGlmT3JpZW50YXRpb24iLCJpbmNQcm9ncmVzcyIsInNldFByb2dyZXNzIiwiJElmXzIiLCIkTG9vcF8zIiwiJExvb3BfM19leGl0IiwiY29tcHJlc3NPbldlYldvcmtlciIsImltYWdlQ29tcHJlc3Npb24iLCIkVHJ5XzFfQ2F0Y2giLCJjcmVhdGVVcGxvYWRGb2xkZXIiLCJ1cGxvYWRMb2NhdGlvbiIsImxvY2F0aW9uIiwiZ2V0U2V0dGluZyIsInNldFNldHRpbmciLCJrZXkiLCJ2YWx1ZSIsImdldFNldHRpbmdzIiwibmV3VXBsb2FkTG9jYXRpb24iLCJkZWZhdWx0TG9jYXRpb24iLCJzaG91bGRDaGFuZ2VMb2NhdGlvbiIsInJlZ2lzdGVyU2V0dGluZyIsInNldHRpbmciLCJSRVNUUklDVEVEX0RPTUFJTlMiLCJkb21QYXJzZXIiLCJpbWFnZVF1ZXVlIiwiaXNGaWxlSW1hZ2UiLCJmaWxlIiwiaXNCbG9iVXJsIiwic3JjIiwic2FmZVJldm9rZU9iamVjdFVybCIsImNyZWF0ZUltYWdlUHJldmlldyIsImltYWdlU3JjIiwiaWQiLCJhZGRFdmVudFRvUmVtb3ZlQnV0dG9uIiwicmVtb3ZlQnV0dG9uIiwic2F2ZVZhbHVlIiwidXBsb2FkQXJlYSIsImltYWdlIiwiaW1nRGF0YSIsInVwbG9hZEltYWdlIiwiZ2VuZXJhdGVGaWxlTmFtZSIsInN2IiwidHlwZSIsIm5hbWUiLCJmaWxlRXh0ZW5zaW9uIiwibmV3TmFtZSIsImNvbXByZXNzZWRJbWFnZSIsIm5ld0ltYWdlIiwiaW1hZ2VMb2NhdGlvbiIsImFkZEltYWdlVG9RdWV1ZSIsInNpZGViYXIiLCJpbWFnZVByZXZpZXciLCJpbWFnZXNGaWxlUmVhZGVySGFuZGxlciIsIl9ldnQiLCJwcm9jZXNzSW1hZ2VGaWxlcyIsImZpbGVzIiwicHJvY2Vzc0Ryb3BBbmRQYXN0ZUltYWdlcyIsImV2ZW50RGF0YSIsImV4dHJhY3RVcmxGcm9tRXZlbnREYXRhIiwiZWQiLCJpbWFnZXMiLCJpbWFnZVVybHMiLCJpbWciLCJpdSIsInJkIiwidXJsc0Zyb21FdmVudERhdGFIYW5kbGVyIiwidXJscyIsIml0ZW1zIiwiaXRlbSIsImdldEltYWdlUXVldWUiLCJlbnN1cmVVcGxvYWRlZFF1ZXVlIiwib2xkU3JjIiwidXBsb2FkZWRQYXRoIiwicmVtb3ZlQWxsRnJvbVF1ZXVlIiwiaW1hZ2VEYXRhIiwiaW1hZ2VFbGVtZW50IiwiY3JlYXRlVXBsb2FkQXJlYSIsImluaXRVcGxvYWRBcmVhIiwiY2hhdE1lc3NhZ2UiLCJjaGF0Q29udHJvbHMiLCJjbGVhckJ0biIsImNyZWF0ZVVwbG9hZEJ1dHRvbiIsImNyZWF0ZUhpZGRlblVwbG9hZElucHV0Iiwic2V0dXBFdmVudHMiLCJ1cGxvYWRCdXR0b24iLCJoaWRkZW5VcGxvYWRJbnB1dCIsImhpZGRlblVwbG9hZElucHV0Q2hhbmdlRXZlbnRIYW5kbGVyIiwiZXZ0IiwiY3VycmVudFRhcmdldCIsInVwbG9hZEJ1dHRvbkNsaWNrRXZlbnRIYW5kbGVyIiwiaW5pdFVwbG9hZEJ1dHRvbiIsImNvbnRyb2xCdXR0b25zIiwibmV3Q29udHJvbEJ1dHRvbnMiLCJ0b2dnbGVDaGF0IiwiY2hhdCIsInRvZ2dsZSIsInRvZ2dsZVNwaW5uZXIiLCJjaGF0Rm9ybSIsInNwaW5uZXJJZCIsInNwaW5uZXIiLCJuZXdTcGlubmVyIiwiZ2V0VXBsb2FkaW5nU3RhdGVzIiwiY2hhdEZvcm1RdWVyeSIsImlzU2VuZGluZyIsImltYWdlVGVtcGxhdGUiLCJpbWFnZVByb3BzIiwibWVzc2FnZVRlbXBsYXRlIiwiZ2V0Q2hhdE1lc3NhZ2VUeXBlIiwiY2hhdE1lc3NhZ2VUeXBlIiwicGFzdGVBbmREcm9wRXZlbnRIYW5kbGVyIiwib3JpZ2luYWxFdmVudCIsInN1Ym1pdEhhbmRsZXIiLCJ1cGxvYWRTdGF0ZSIsImlucHV0IiwiY29udGVudCIsImlzVXBsb2FkQXJlYVJlbmRlcmVkIiwiaW5pdENoYXRTaWRlYmFyIiwiaW5pdENoYXRNZXNzYWdlIiwiaW1hZ2VQb3B1cCIsImltYWdlTWFya2Rvd25SZWciLCJpbWFnZVJlZyIsInByb2Nlc3NNZXNzYWdlIiwibWVzc2FnZSIsInJlZ2lzdGVyU2V0dGluZ3MiLCJyZWdpc3Rlckhvb2tzIiwiXzAiLCJjaGF0TWVzc2FnZUVsZW1lbnQiLCJpbml0RXZlbnRzIiwiY29sbGFwc2VkIiwic2lkZWJhckVsZW1lbnQiLCJzaWRlYmFySnEiLCJjaGF0TG9nIiwiY2hhdExvZ0VsZW1lbnQiLCJjaGF0TG9nSnEiLCJ1c2VyT3B0aW9ucyIsIm1lc3NhZ2VPcHRpb25zIiwicHJvY2Vzc2VkTWVzc2FnZSJdLCJtYXBwaW5ncyI6IkFBQ08sTUFBTUEsS0FBUyxDQUFDQyxNQUF1QyxFQUFFQSxDQUFJLEdBQ3ZEQyxLQUFTLENBQUNDLEdBQXVCQyxNQUE0QkQsRUFBYyxPQUFPQyxDQUFPLEdBRXpGQyxLQUFPLENBQUNDLEdBQWtCQyxNQUFnQ0EsSUFBYUEsRUFBVyxLQUFLRCxDQUFRLElBQUksRUFBRUEsQ0FBUSxHQUM3R0UsS0FBUyxDQUFDRCxHQUFvQkgsTUFBNEJHLEVBQVcsT0FBT0gsQ0FBTyxHQUVuRkssS0FBSyxDQUFDRixHQUFvQkcsR0FBbUJDLE1BQW9DSixFQUFXLEdBQUdHLEdBQVdDLENBQWEsR0FDdkhDLEtBQVUsQ0FBQ0wsR0FBb0JHLE1BQThCSCxFQUFXLFFBQVFHLENBQVMsR0FDekZHLEtBQWMsQ0FBQ04sR0FBb0JPLE1BQWdDUCxFQUFXLFlBQVlPLENBQVcsR0FDckdDLEtBQVcsQ0FBQ1IsR0FBb0JPLE1BQWdDUCxFQUFXLFNBQVNPLENBQVcsR0FDL0ZFLEtBQVMsQ0FBQ0MsTUFBeUJBLEVBQUssT0FBTyxHQUMvQ0MsS0FBTyxDQUFDRCxHQUFjRSxHQUFnQkMsTUFBaURBLElBQVlILEVBQUssS0FBS0UsR0FBUUMsQ0FBUyxJQUFJSCxFQUFLLEtBQUtFLENBQU0sR0FDbEpFLEtBQWEsQ0FBQ0osR0FBY0UsTUFBMkJGLEVBQUssV0FBV0UsQ0FBTSxHQUM3RUcsS0FBUSxDQUFDTCxNQUF5QkEsRUFBSyxNQUFNLEdDZDdDTSxLQUFnQixRQUNoQkMsS0FBSSxDQUFDQzs7QUFBMEIsV0FBQUMsSUFBQSw2QkFBZSxTQUFmLGdCQUFBQSxFQUFxQixTQUFTLE1BQU1ELFNBQVc7QUFBQSxHQUM5RUUsS0FBZSxNQUFjLEtBQUssU0FBUyxTQUFTLEVBQUUsRUFBRSxVQUFVLEdBQUcsRUFBRSxJQUFJLEtBQUssT0FBUyxFQUFBLFNBQVMsRUFBRSxFQUFFLFVBQVUsR0FBRyxFQUFFLEdBQ3JIQyxLQUFnQixDQUFDQyxJQUFTLE9BQW1COztBQUNsRCxRQUFBQyxLQUFZSixJQUFBLDZCQUFlLFNBQWYsZ0JBQUFBLEVBQXFCLE1BQ2pDSyxLQUF5QkMsSUFBQSw2QkFBZSxnQkFBZixnQkFBQUEsRUFBNEI7QUFFdkQsTUFBQSxDQUFDRixLQUFZLENBQUNDO0FBQ2hCLFdBQUtGLE1BQVFJLElBQUEsR0FBRyxrQkFBSCxRQUFBQSxFQUFrQixLQUFLVCxHQUFFLG1CQUFtQixJQUNsRDtBQUdILFFBQUFVLElBQW1CSCxFQUFzQixTQUFTRCxDQUFRO0FBQzVELFNBQUEsQ0FBQ0ksS0FBb0IsQ0FBQ0wsT0FBUU0sSUFBQSxHQUFHLGtCQUFILFFBQUFBLEVBQWtCLEtBQUtYLEdBQUUsbUJBQW1CLEtBRXZFVTtBQUNULEdBRWFFLEtBQW9CLE1BQU8sNkJBQWUsU0FFMUNDLEtBQW1CLE1BQU0sT0FBT0QsR0FBbUIsQ0FBQSxLQUFLLElBRXhERSxLQUEyQixNQUFNRCxHQUFpQixJQUMzRCxRQUFRLGFBQWEsS0FBSyxXQUFXLGlCQUNyQyxZQUVTRSxLQUE0QixNQUFNRixPQUMzQyxRQUFRLGFBQWEsS0FBSyxjQUMxQjtBQ3JCSixTQUFTRyxHQUFpQkMsR0FBRWpCLEdBQUU7QUFBQyxTQUFPQSxFQUFFLFFBQVMsU0FBU0EsR0FBRTtBQUFDLElBQUFBLEtBQWEsT0FBT0EsS0FBakIsWUFBb0IsQ0FBQyxNQUFNLFFBQVFBLENBQUMsS0FBRyxPQUFPLEtBQUtBLENBQUMsRUFBRSxRQUFTLFNBQVNrQixHQUFFO0FBQUMsVUFBZUEsTUFBWixhQUFlLEVBQUVBLEtBQUtELElBQUc7QUFBQyxZQUFJRSxJQUFFLE9BQU8seUJBQXlCbkIsR0FBRWtCLENBQUM7QUFBRSxlQUFPLGVBQWVELEdBQUVDLEdBQUVDLEVBQUUsTUFBSUEsSUFBRSxFQUFDLFlBQVcsSUFBRyxLQUFJLFdBQVU7QUFBQyxpQkFBT25CLEVBQUVrQjtBQUFBLFFBQUUsRUFBQyxDQUFDO0FBQUEsTUFBQztBQUFBLElBQUMsQ0FBRztBQUFBLEVBQUEsQ0FBRyxHQUFDLE9BQU8sT0FBT0QsQ0FBQztBQUFDO0FBQUMsU0FBU0csR0FBMkJILEdBQUVqQixHQUFFO0FBQUMsU0FBTyxJQUFJLFFBQVMsU0FBU2tCLEdBQUVDLEdBQUU7QUFBQyxRQUFJRTtBQUFFLFdBQU9DLEdBQWVMLENBQUMsRUFBRSxLQUFNLFNBQVNBLEdBQUU7QUFBQyxVQUFHO0FBQUMsZUFBT0ksSUFBRUosR0FBRUMsRUFBRSxJQUFJLEtBQUssQ0FBQ2xCLEVBQUUsTUFBTSxHQUFFLENBQUMsR0FBRXFCLEdBQUVyQixFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUUsRUFBQyxNQUFLLGFBQVksQ0FBQyxDQUFDO0FBQUEsTUFBQyxTQUFPaUIsR0FBTjtBQUFTLGVBQU9FLEVBQUVGLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQyxHQUFHRSxDQUFDO0FBQUEsRUFBQyxDQUFHO0FBQUE7QUFBQyxNQUFNRyxLQUFlLENBQUFMLE1BQUcsSUFBSSxRQUFTLENBQUNqQixHQUFFa0IsTUFBSTtBQUFDLFFBQU1DLElBQUUsSUFBSTtBQUFXLEVBQUFBLEVBQUUsaUJBQWlCLFFBQVEsQ0FBQyxFQUFDLFFBQU8sRUFBQyxRQUFPLEVBQUMsRUFBQyxNQUFJO0FBQUMsVUFBTUEsSUFBRSxJQUFJLFNBQVMsQ0FBQztBQUFFLFFBQUlFLElBQUU7QUFBRSxRQUFXRixFQUFFLFVBQVVFLENBQUMsTUFBckI7QUFBdUIsYUFBT0gsRUFBRSxrQkFBa0I7QUFBRSxTQUFJRyxLQUFHLE9BQUk7QUFBQyxZQUFNLElBQUVGLEVBQUUsVUFBVUUsQ0FBQztBQUFFLFVBQVcsTUFBUjtBQUFVO0FBQU0sWUFBTUUsSUFBRUosRUFBRSxVQUFVRSxJQUFFLENBQUM7QUFBRSxVQUFXLE1BQVIsU0FBd0JGLEVBQUUsVUFBVUUsSUFBRSxDQUFDLE1BQTVCLFlBQThCO0FBQUMsY0FBTUcsSUFBRUgsSUFBRTtBQUFHLFlBQUlJO0FBQUUsZ0JBQU9OLEVBQUUsVUFBVUssQ0FBQztVQUFHLEtBQUs7QUFBTSxZQUFBQyxJQUFFO0FBQUc7QUFBQSxVQUFNLEtBQUs7QUFBTSxZQUFBQSxJQUFFO0FBQUc7QUFBQSxVQUFNO0FBQVEsbUJBQU9QLEVBQUUscUNBQXFDO0FBQUEsUUFBQztBQUFDLFlBQVFDLEVBQUUsVUFBVUssSUFBRSxHQUFFQyxDQUFDLE1BQXRCO0FBQXdCLGlCQUFPUCxFQUFFLHNDQUFzQztBQUFFLGNBQU1RLElBQUVQLEVBQUUsVUFBVUssSUFBRSxHQUFFQyxDQUFDLEdBQUVFLElBQUVILElBQUVFLElBQUUsSUFBRSxLQUFHUCxFQUFFLFVBQVVLLElBQUVFLEdBQUVELENBQUM7QUFBRSxpQkFBUVIsSUFBRU8sSUFBRUUsSUFBRSxHQUFFVCxJQUFFVSxHQUFFVixLQUFHO0FBQUksY0FBUUUsRUFBRSxVQUFVRixHQUFFUSxDQUFDLEtBQXBCLEtBQXNCO0FBQUMsZ0JBQU9OLEVBQUUsVUFBVUYsSUFBRSxHQUFFUSxDQUFDLE1BQXJCO0FBQXVCLHFCQUFPUCxFQUFFLGtDQUFrQztBQUFFLGdCQUFPQyxFQUFFLFVBQVVGLElBQUUsR0FBRVEsQ0FBQyxNQUFyQjtBQUF1QixxQkFBT1AsRUFBRSxtQ0FBbUM7QUFBRSxZQUFBQyxFQUFFLFVBQVVGLElBQUUsR0FBRSxHQUFFUSxDQUFDO0FBQUU7QUFBQSxVQUFLO0FBQUUsZUFBT3pCLEVBQUUsRUFBRSxNQUFNcUIsR0FBRUEsSUFBRSxJQUFFRSxDQUFDLENBQUM7QUFBQSxNQUFDO0FBQUMsTUFBQUYsS0FBRyxJQUFFRTtBQUFBLElBQUM7QUFBQyxXQUFPdkIsRUFBRSxJQUFJLE1BQUk7QUFBQSxFQUFDLENBQUcsR0FBQ21CLEVBQUUsa0JBQWtCRixDQUFDO0FBQUMsQ0FBQztBQUFHLElBQUlBLEtBQUUsQ0FBRSxHQUFDakIsS0FBRSxFQUFDLElBQUksVUFBUztBQUFDLFNBQU9pQjtBQUFDLEdBQUUsSUFBSSxRQUFRakIsR0FBRTtBQUFDLEVBQUFpQixLQUFFakI7QUFBQyxFQUFDO0FBQUEsQ0FBRyxTQUFTaUIsR0FBRTtBQUFDLE1BQUlDLEdBQUVDLEdBQUVTLElBQUssQ0FBQTtBQUFHLEVBQUE1QixHQUFFLFVBQVE0QixHQUFLQSxFQUFLLFFBQU0sU0FBUyxHQUFFLEdBQUU7QUFBQyxhQUFRVixJQUFFVSxFQUFLLElBQUksWUFBV1QsSUFBRVMsRUFBSyxJQUFJLFVBQVNQLElBQUUsR0FBRUcsSUFBRSxDQUFFLEdBQUNELElBQUUsSUFBSSxXQUFXLENBQUMsR0FBRUUsSUFBRUYsRUFBRSxTQUFPLEdBQWFKLEVBQUVJLEdBQUVFLENBQUMsS0FBaEI7QUFBbUIsTUFBQUE7QUFBSSxJQUFBSixJQUFFSSxHQUFFSixLQUFHO0FBQUUsUUFBSUssSUFBRVIsRUFBRUssR0FBRUYsS0FBRyxDQUFDO0FBQUUsSUFBQUgsRUFBRUssR0FBRUYsS0FBRyxDQUFDO0FBQUUsUUFBSU0sSUFBRVIsRUFBRUksR0FBRUYsS0FBRyxDQUFDLEdBQUVRLElBQUVWLEVBQUVJLEdBQUVGLEtBQUcsQ0FBQztBQUFFLElBQUFBLEtBQUcsR0FBRUEsSUFBRVE7QUFBRSxhQUFRQyxJQUFFLEdBQUVBLElBQUVKLEdBQUVJLEtBQUk7QUFBQyxNQUFBWCxFQUFFSSxHQUFFRixDQUFDLEdBQUVBLEtBQUcsR0FBRUEsS0FBRyxHQUFFQSxLQUFHLEdBQUVGLEVBQUVJLEdBQUVGLEtBQUcsQ0FBQyxHQUFFTSxJQUFFUixFQUFFSSxHQUFFRixLQUFHLENBQUM7QUFBRSxVQUFJVSxJQUFFWixFQUFFSSxHQUFFRixLQUFHLENBQUMsR0FBRVcsSUFBRWQsRUFBRUssR0FBRUYsS0FBRyxDQUFDLEdBQUVZLElBQUVmLEVBQUVLLEdBQUVGLElBQUUsQ0FBQyxHQUFFYSxJQUFFaEIsRUFBRUssR0FBRUYsSUFBRSxDQUFDO0FBQUUsTUFBQUEsS0FBRztBQUFFLFVBQUljLElBQUVoQixFQUFFSSxHQUFFRixLQUFHLENBQUM7QUFBRSxNQUFBQSxLQUFHLEdBQUVBLEtBQUdXLElBQUVDLElBQUVDLEdBQUVOLEVBQUssV0FBV0wsR0FBRVksR0FBRVgsR0FBRUcsR0FBRUksR0FBRSxDQUFDO0FBQUEsSUFBQztBQUFDLFdBQU9QO0FBQUEsRUFBQyxHQUFFSSxFQUFLLGFBQVcsU0FBUyxHQUFFLEdBQUVWLEdBQUVDLEdBQUVFLEdBQUVHLEdBQUU7QUFBQyxRQUFJRCxJQUFFSyxFQUFLLElBQUksWUFBV0gsSUFBRUcsRUFBSyxJQUFJO0FBQVMsSUFBQUgsRUFBRSxHQUFFLENBQUMsR0FBRUYsRUFBRSxHQUFFLEtBQUcsQ0FBQyxHQUFFQSxFQUFFLEdBQUUsS0FBRyxDQUFDO0FBQUUsUUFBSUcsSUFBRUgsRUFBRSxHQUFFLEtBQUcsQ0FBQztBQUFFLElBQUFFLEVBQUUsR0FBRSxLQUFHLENBQUMsR0FBRUEsRUFBRSxHQUFFLEtBQUcsQ0FBQyxHQUFFLEtBQUc7QUFBRSxRQUFJRSxJQUFFSixFQUFFLEdBQUUsS0FBRyxDQUFDLEdBQUVNLElBQUVOLEVBQUUsR0FBRSxLQUFHLENBQUM7QUFBRSxTQUFHO0FBQUUsUUFBSU8sSUFBRUYsRUFBSyxJQUFJLFNBQVMsR0FBRSxHQUFFRCxDQUFDO0FBQUUsUUFBRyxLQUFHQSxHQUFFLEtBQUdFLEdBQUVMO0FBQUUsTUFBQU4sRUFBRVksS0FBRyxFQUFDLE1BQUtULEdBQUUsT0FBTUYsRUFBQztBQUFBLFNBQU07QUFBQyxVQUFJWSxJQUFFLElBQUksV0FBVyxFQUFFLFFBQU8sQ0FBQztBQUFFLFVBQU1MLEtBQUg7QUFBSyxRQUFBUixFQUFFWSxLQUFHLElBQUksV0FBV0MsRUFBRSxPQUFPLE1BQU0sR0FBRSxJQUFFWixDQUFDLENBQUM7QUFBQSxXQUFNO0FBQUMsWUFBTU8sS0FBSDtBQUFLLGdCQUFLLGlDQUErQkE7QUFBRSxZQUFJTSxJQUFFLElBQUksV0FBV1gsQ0FBQztBQUFFLFFBQUFPLEVBQUssV0FBV0csR0FBRUMsQ0FBQyxHQUFFZCxFQUFFWSxLQUFHRTtBQUFBLE1BQUM7QUFBQSxJQUFDO0FBQUEsRUFBQyxHQUFFSixFQUFLLGFBQVcsU0FBUyxHQUFFLEdBQUU7QUFBQyxXQUFPQSxFQUFLLEVBQUUsUUFBUSxHQUFFLENBQUM7QUFBQSxFQUFDLEdBQUVBLEVBQUssVUFBUSxTQUFTLEdBQUUsR0FBRTtBQUFDLFdBQU8sRUFBRSxJQUFHLEVBQUUsSUFBR0EsRUFBSyxXQUFXLElBQUksV0FBVyxFQUFFLFFBQU8sRUFBRSxhQUFXLEdBQUUsRUFBRSxTQUFPLENBQUMsR0FBRSxDQUFDO0FBQUEsRUFBQyxHQUFFQSxFQUFLLFVBQVEsU0FBUyxHQUFFLEdBQUU7QUFBQyxJQUFNLEtBQU4sU0FBVSxJQUFFLEVBQUMsT0FBTSxFQUFDO0FBQUcsUUFBSVYsSUFBRSxHQUFFQyxJQUFFLElBQUksV0FBVyxLQUFHLEtBQUssTUFBTSxNQUFJLEVBQUUsTUFBTSxDQUFDO0FBQUUsSUFBQUEsRUFBRUQsS0FBRyxLQUFJQyxFQUFFRCxJQUFFLEtBQUcsS0FBSUEsS0FBRyxHQUFFQSxJQUFFVSxFQUFLLEVBQUUsV0FBVyxHQUFFVCxHQUFFRCxHQUFFLEVBQUUsS0FBSztBQUFFLFFBQUlHLElBQUVPLEVBQUssTUFBTSxHQUFFLEdBQUUsRUFBRSxNQUFNO0FBQUUsV0FBT1QsRUFBRUQsSUFBRSxLQUFHRyxNQUFJLEtBQUcsS0FBSUYsRUFBRUQsSUFBRSxLQUFHRyxNQUFJLEtBQUcsS0FBSUYsRUFBRUQsSUFBRSxLQUFHRyxNQUFJLElBQUUsS0FBSUYsRUFBRUQsSUFBRSxLQUFHRyxNQUFJLElBQUUsS0FBSSxJQUFJLFdBQVdGLEVBQUUsUUFBTyxHQUFFRCxJQUFFLENBQUM7QUFBQSxFQUFDLEdBQUVVLEVBQUssYUFBVyxTQUFTLEdBQUUsR0FBRTtBQUFDLElBQU0sS0FBTixTQUFVLElBQUUsRUFBQyxPQUFNLEVBQUM7QUFBRyxRQUFJVixJQUFFLElBQUksV0FBVyxLQUFHLEtBQUssTUFBTSxNQUFJLEVBQUUsTUFBTSxDQUFDLEdBQUVDLElBQUVTLEVBQUssRUFBRSxXQUFXLEdBQUVWLEdBQUVDLEdBQUUsRUFBRSxLQUFLO0FBQUUsV0FBTyxJQUFJLFdBQVdELEVBQUUsUUFBTyxHQUFFQyxDQUFDO0FBQUEsRUFBQyxHQUFFUyxFQUFLLFNBQU8sU0FBUyxHQUFFLEdBQUU7QUFBQyxJQUFNLEtBQU4sU0FBVSxJQUFFO0FBQUksUUFBSVYsSUFBRSxHQUFFQyxJQUFFUyxFQUFLLElBQUksV0FBVVAsSUFBRU8sRUFBSyxJQUFJLGFBQVlKLElBQUUsQ0FBQTtBQUFHLGFBQVFELEtBQUssR0FBRTtBQUFDLFVBQUlFLElBQUUsQ0FBQ0csRUFBSyxRQUFRTCxDQUFDLEtBQUcsQ0FBQyxHQUFFRyxJQUFFLEVBQUVILElBQUdJLElBQUVDLEVBQUssSUFBSSxJQUFJRixHQUFFLEdBQUVBLEVBQUUsTUFBTTtBQUFFLE1BQUFGLEVBQUVELEtBQUcsRUFBQyxLQUFJRSxHQUFFLE9BQU1DLEVBQUUsUUFBTyxLQUFJQyxHQUFFLE1BQUtGLElBQUVHLEVBQUssV0FBV0YsQ0FBQyxJQUFFQSxFQUFDO0FBQUEsSUFBQztBQUFDLGFBQVFILEtBQUtDO0FBQUUsTUFBQU4sS0FBR00sRUFBRUQsR0FBRyxLQUFLLFNBQU8sS0FBRyxLQUFHLElBQUVLLEVBQUssSUFBSSxTQUFTTCxDQUFDO0FBQUUsSUFBQUwsS0FBRztBQUFHLFFBQUlXLElBQUUsSUFBSSxXQUFXWCxDQUFDLEdBQUVZLElBQUUsR0FBRUMsSUFBRSxDQUFBO0FBQUcsYUFBUVIsS0FBS0MsR0FBRTtBQUFDLFVBQUlRLElBQUVSLEVBQUVEO0FBQUcsTUFBQVEsRUFBRSxLQUFLRCxDQUFDLEdBQUVBLElBQUVGLEVBQUssYUFBYUMsR0FBRUMsR0FBRVAsR0FBRVMsR0FBRSxDQUFDO0FBQUEsSUFBQztBQUFDLFFBQUlDLElBQUUsR0FBRUMsSUFBRUo7QUFBRSxhQUFRUCxLQUFLQztBQUFHLE1BQUFRLElBQUVSLEVBQUVELElBQUdRLEVBQUUsS0FBS0QsQ0FBQyxHQUFFQSxJQUFFRixFQUFLLGFBQWFDLEdBQUVDLEdBQUVQLEdBQUVTLEdBQUUsR0FBRUQsRUFBRUUsSUFBSTtBQUFFLFFBQUlFLElBQUVMLElBQUVJO0FBQUUsV0FBT2YsRUFBRVUsR0FBRUMsR0FBRSxTQUFTLEdBQUVBLEtBQUcsR0FBRVQsRUFBRVEsR0FBRUMsS0FBRyxHQUFFRyxDQUFDLEdBQUVaLEVBQUVRLEdBQUVDLEtBQUcsR0FBRUcsQ0FBQyxHQUFFZCxFQUFFVSxHQUFFQyxLQUFHLEdBQUVLLENBQUMsR0FBRWhCLEVBQUVVLEdBQUVDLEtBQUcsR0FBRUksQ0FBQyxHQUFFSixLQUFHLEdBQUVBLEtBQUcsR0FBRUQsRUFBRTtBQUFBLEVBQU0sR0FBRUQsRUFBSyxVQUFRLFNBQVMsR0FBRTtBQUFDLFFBQUksSUFBRSxFQUFFLE1BQU0sR0FBRyxFQUFFLE1BQU0sWUFBYTtBQUFDLFdBQVUsbUJBQW1CLFFBQVEsQ0FBQyxLQUFoQztBQUFBLEVBQWlDLEdBQUVBLEVBQUssZUFBYSxTQUFTLEdBQUUsR0FBRVYsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRTtBQUFDLFFBQUlELElBQUVLLEVBQUssSUFBSSxXQUFVSCxJQUFFRyxFQUFLLElBQUksYUFBWUYsSUFBRVAsRUFBRTtBQUFLLFdBQU9JLEVBQUUsR0FBRSxHQUFLRixLQUFILElBQUssV0FBUyxRQUFRLEdBQUUsS0FBRyxHQUFLQSxLQUFILE1BQU8sS0FBRyxJQUFHSSxFQUFFLEdBQUUsR0FBRSxFQUFFLEdBQUVBLEVBQUUsR0FBRSxLQUFHLEdBQUUsQ0FBQyxHQUFFQSxFQUFFLEdBQUUsS0FBRyxHQUFFTixFQUFFLE1BQUksSUFBRSxDQUFDLEdBQUVJLEVBQUUsR0FBRSxLQUFHLEdBQUUsQ0FBQyxHQUFFQSxFQUFFLEdBQUUsS0FBRyxHQUFFSixFQUFFLEdBQUcsR0FBRUksRUFBRSxHQUFFLEtBQUcsR0FBRUcsRUFBRSxNQUFNLEdBQUVILEVBQUUsR0FBRSxLQUFHLEdBQUVKLEVBQUUsS0FBSyxHQUFFTSxFQUFFLEdBQUUsS0FBRyxHQUFFRyxFQUFLLElBQUksU0FBU1YsQ0FBQyxDQUFDLEdBQUVPLEVBQUUsR0FBRSxLQUFHLEdBQUUsQ0FBQyxHQUFFLEtBQUcsR0FBS0osS0FBSCxNQUFPLEtBQUcsR0FBRSxLQUFHLEdBQUVFLEVBQUUsR0FBRSxLQUFHLEdBQUVDLENBQUMsR0FBRSxLQUFHLElBQUcsS0FBR0ksRUFBSyxJQUFJLFVBQVUsR0FBRSxHQUFFVixDQUFDLEdBQUtHLEtBQUgsTUFBTyxFQUFFLElBQUlLLEdBQUUsQ0FBQyxHQUFFLEtBQUdBLEVBQUUsU0FBUTtBQUFBLEVBQUMsR0FBRUUsRUFBSyxNQUFJLEVBQUMsT0FBTSxXQUFVO0FBQUMsYUFBUSxJQUFFLElBQUksWUFBWSxHQUFHLEdBQUUsSUFBRSxHQUFFLElBQUUsS0FBSSxLQUFJO0FBQUMsZUFBUVYsSUFBRSxHQUFFQyxJQUFFLEdBQUVBLElBQUUsR0FBRUE7QUFBSSxZQUFFRCxJQUFFQSxJQUFFLGFBQVdBLE1BQUksSUFBRUEsT0FBSztBQUFFLFFBQUUsS0FBR0E7QUFBQSxJQUFDO0FBQUMsV0FBTztBQUFBLEVBQUMsRUFBRyxHQUFDLFFBQU8sU0FBUyxHQUFFLEdBQUVBLEdBQUVDLEdBQUU7QUFBQyxhQUFRRSxJQUFFLEdBQUVBLElBQUVGLEdBQUVFO0FBQUksVUFBRU8sRUFBSyxJQUFJLE1BQU0sT0FBSyxJQUFFLEVBQUVWLElBQUVHLE9BQUssTUFBSTtBQUFFLFdBQU87QUFBQSxFQUFDLEdBQUUsS0FBSSxTQUFTLEdBQUUsR0FBRUgsR0FBRTtBQUFDLFdBQU8sYUFBV1UsRUFBSyxJQUFJLE9BQU8sWUFBVyxHQUFFLEdBQUVWLENBQUM7QUFBQSxFQUFDLEVBQUMsR0FBRVUsRUFBSyxRQUFNLFNBQVMsR0FBRSxHQUFFVixHQUFFO0FBQUMsYUFBUUMsSUFBRSxHQUFFRSxJQUFFLEdBQUVHLElBQUUsR0FBRUQsSUFBRSxJQUFFTCxHQUFFTSxJQUFFRCxLQUFHO0FBQUMsZUFBUUUsSUFBRSxLQUFLLElBQUlELElBQUUsTUFBS0QsQ0FBQyxHQUFFQyxJQUFFQztBQUFHLFFBQUFKLEtBQUdGLEtBQUcsRUFBRUs7QUFBSyxNQUFBTCxLQUFHLE9BQU1FLEtBQUc7QUFBQSxJQUFLO0FBQUMsV0FBT0EsS0FBRyxLQUFHRjtBQUFBLEVBQUMsR0FBRVMsRUFBSyxNQUFJLEVBQUMsWUFBVyxTQUFTLEdBQUUsR0FBRTtBQUFDLFdBQU8sRUFBRSxLQUFHLEVBQUUsSUFBRSxNQUFJO0FBQUEsRUFBQyxHQUFFLGFBQVksU0FBUyxHQUFFLEdBQUVWLEdBQUU7QUFBQyxNQUFFLEtBQUcsTUFBSUEsR0FBRSxFQUFFLElBQUUsS0FBR0EsS0FBRyxJQUFFO0FBQUEsRUFBRyxHQUFFLFVBQVMsU0FBUyxHQUFFLEdBQUU7QUFBQyxXQUFPLFdBQVMsRUFBRSxJQUFFLE1BQUksRUFBRSxJQUFFLE1BQUksS0FBRyxFQUFFLElBQUUsTUFBSSxJQUFFLEVBQUU7QUFBQSxFQUFHLEdBQUUsV0FBVSxTQUFTLEdBQUUsR0FBRUEsR0FBRTtBQUFDLE1BQUUsS0FBRyxNQUFJQSxHQUFFLEVBQUUsSUFBRSxLQUFHQSxLQUFHLElBQUUsS0FBSSxFQUFFLElBQUUsS0FBR0EsS0FBRyxLQUFHLEtBQUksRUFBRSxJQUFFLEtBQUdBLEtBQUcsS0FBRztBQUFBLEVBQUcsR0FBRSxXQUFVLFNBQVMsR0FBRSxHQUFFQSxHQUFFO0FBQUMsYUFBUUMsSUFBRSxJQUFHRSxJQUFFLEdBQUVBLElBQUVILEdBQUVHO0FBQUksTUFBQUYsS0FBRyxPQUFPLGFBQWEsRUFBRSxJQUFFRSxFQUFFO0FBQUUsV0FBT0Y7QUFBQSxFQUFDLEdBQUUsWUFBVyxTQUFTLEdBQUUsR0FBRUQsR0FBRTtBQUFDLGFBQVFDLElBQUUsR0FBRUEsSUFBRUQsRUFBRSxRQUFPQztBQUFJLFFBQUUsSUFBRUEsS0FBR0QsRUFBRSxXQUFXQyxDQUFDO0FBQUEsRUFBQyxHQUFFLEtBQUksU0FBUyxHQUFFO0FBQUMsV0FBTyxFQUFFLFNBQU8sSUFBRSxNQUFJLElBQUU7QUFBQSxFQUFDLEdBQUUsVUFBUyxTQUFTLEdBQUUsR0FBRUQsR0FBRTtBQUFDLGFBQVFDLEdBQUVFLElBQUUsSUFBR0csSUFBRSxHQUFFQSxJQUFFTixHQUFFTTtBQUFJLE1BQUFILEtBQUcsTUFBSU8sRUFBSyxJQUFJLElBQUksRUFBRSxJQUFFSixHQUFHLFNBQVMsRUFBRSxDQUFDO0FBQUUsUUFBRztBQUFDLE1BQUFMLElBQUUsbUJBQW1CRSxDQUFDO0FBQUEsSUFBQyxRQUFDO0FBQVMsYUFBT08sRUFBSyxJQUFJLFVBQVUsR0FBRSxHQUFFVixDQUFDO0FBQUEsSUFBQztBQUFDLFdBQU9DO0FBQUEsRUFBQyxHQUFFLFdBQVUsU0FBUyxHQUFFLEdBQUVELEdBQUU7QUFBQyxhQUFRQyxJQUFFRCxFQUFFLFFBQU9HLElBQUUsR0FBRUcsSUFBRSxHQUFFQSxJQUFFTCxHQUFFSyxLQUFJO0FBQUMsVUFBSUQsSUFBRUwsRUFBRSxXQUFXTSxDQUFDO0FBQUUsV0FBTyxhQUFXRCxNQUFmO0FBQWtCLFVBQUUsSUFBRUYsS0FBR0UsR0FBRUY7QUFBQSxnQkFBZ0IsYUFBV0UsTUFBZjtBQUFrQixVQUFFLElBQUVGLEtBQUcsTUFBSUUsS0FBRyxHQUFFLEVBQUUsSUFBRUYsSUFBRSxLQUFHLE1BQUlFLEtBQUcsSUFBRSxJQUFHRixLQUFHO0FBQUEsZ0JBQWMsYUFBV0UsTUFBZjtBQUFrQixVQUFFLElBQUVGLEtBQUcsTUFBSUUsS0FBRyxJQUFHLEVBQUUsSUFBRUYsSUFBRSxLQUFHLE1BQUlFLEtBQUcsSUFBRSxJQUFHLEVBQUUsSUFBRUYsSUFBRSxLQUFHLE1BQUlFLEtBQUcsSUFBRSxJQUFHRixLQUFHO0FBQUEsV0FBTTtBQUFDLGFBQU8sYUFBV0UsTUFBZjtBQUFrQixnQkFBSztBQUFJLFVBQUUsSUFBRUYsS0FBRyxNQUFJRSxLQUFHLElBQUcsRUFBRSxJQUFFRixJQUFFLEtBQUcsTUFBSUUsS0FBRyxLQUFHLElBQUcsRUFBRSxJQUFFRixJQUFFLEtBQUcsTUFBSUUsS0FBRyxJQUFFLElBQUcsRUFBRSxJQUFFRixJQUFFLEtBQUcsTUFBSUUsS0FBRyxJQUFFLElBQUdGLEtBQUc7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFDLFdBQU9BO0FBQUEsRUFBQyxHQUFFLFVBQVMsU0FBUyxHQUFFO0FBQUMsYUFBUSxJQUFFLEVBQUUsUUFBT0gsSUFBRSxHQUFFQyxJQUFFLEdBQUVBLElBQUUsR0FBRUEsS0FBSTtBQUFDLFVBQUlFLElBQUUsRUFBRSxXQUFXRixDQUFDO0FBQUUsV0FBTyxhQUFXRSxNQUFmO0FBQWtCLFFBQUFIO0FBQUEsZ0JBQWdCLGFBQVdHLE1BQWY7QUFBa0IsUUFBQUgsS0FBRztBQUFBLGdCQUFjLGFBQVdHLE1BQWY7QUFBa0IsUUFBQUgsS0FBRztBQUFBLFdBQU07QUFBQyxhQUFPLGFBQVdHLE1BQWY7QUFBa0IsZ0JBQUs7QUFBSSxRQUFBSCxLQUFHO0FBQUEsTUFBQztBQUFBLElBQUM7QUFBQyxXQUFPQTtBQUFBLEVBQUMsRUFBQyxHQUFFVSxFQUFLLElBQUUsQ0FBRSxHQUFDQSxFQUFLLEVBQUUsYUFBVyxTQUFTLEdBQUUsR0FBRVYsR0FBRUMsR0FBRTtBQUFDLFFBQUlFLElBQUUsQ0FBQyxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLEdBQUUsSUFBRyxHQUFFLENBQUMsR0FBRSxDQUFDLEdBQUUsR0FBRSxJQUFHLElBQUcsQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLElBQUcsSUFBRyxDQUFDLEdBQUUsQ0FBQyxHQUFFLElBQUcsSUFBRyxJQUFHLENBQUMsR0FBRSxDQUFDLEdBQUUsSUFBRyxLQUFJLEtBQUksQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLEtBQUksS0FBSSxDQUFDLEdBQUUsQ0FBQyxJQUFHLEtBQUksS0FBSSxNQUFLLENBQUMsR0FBRSxDQUFDLElBQUcsS0FBSSxLQUFJLE1BQUssQ0FBQyxDQUFDLEVBQUVGLElBQUdLLElBQUVJLEVBQUssRUFBRSxHQUFFTCxJQUFFSyxFQUFLLEVBQUU7QUFBVyxJQUFBQSxFQUFLLEVBQUU7QUFBTSxRQUFJSCxJQUFFRyxFQUFLLEVBQUUsUUFBT0YsSUFBRSxHQUFFQyxJQUFFVCxLQUFHLEdBQUVXLElBQUUsR0FBRUMsSUFBRSxFQUFFO0FBQU8sUUFBTVgsS0FBSCxHQUFLO0FBQUMsYUFBS08sSUFBRUk7QUFBSSxRQUFBTCxFQUFFLEdBQUVFLEdBQUVELEtBQUdVLElBQUUsS0FBSyxJQUFJLE9BQU1OLElBQUVKLENBQUMsTUFBSUksSUFBRSxJQUFFLENBQUMsR0FBRUgsSUFBRUMsRUFBSyxFQUFFLFdBQVcsR0FBRUYsR0FBRVUsR0FBRSxHQUFFVCxJQUFFLENBQUMsR0FBRUQsS0FBR1U7QUFBRSxhQUFPVCxNQUFJO0FBQUEsSUFBQztBQUFDLFFBQUlJLElBQUVQLEVBQUUsTUFBS1EsSUFBRVIsRUFBRSxNQUFLUyxJQUFFVCxFQUFFLE1BQUtVLElBQUUsR0FBRUMsSUFBRSxHQUFFRSxJQUFFLEdBQUUsSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUU7QUFBRSxTQUFJVCxJQUFFLE1BQUlFLEVBQUVPLElBQUVYLEVBQUssRUFBRSxNQUFNLEdBQUUsQ0FBQyxLQUFHLElBQUdGLElBQUUsR0FBRUEsSUFBRUksR0FBRUosS0FBSTtBQUFDLFVBQUdZLElBQUVDLEdBQUViLElBQUUsSUFBRUksSUFBRSxHQUFFO0FBQUMsUUFBQVMsSUFBRVgsRUFBSyxFQUFFLE1BQU0sR0FBRUYsSUFBRSxDQUFDO0FBQUUsWUFBSWMsSUFBRWQsSUFBRSxJQUFFO0FBQU0sUUFBQU8sRUFBRU8sS0FBR1IsRUFBRU8sSUFBR1AsRUFBRU8sS0FBR0M7QUFBQSxNQUFDO0FBQUMsVUFBR1gsS0FBR0gsR0FBRTtBQUFDLFNBQUNRLElBQUUsUUFBTUMsSUFBRSxVQUFRTCxJQUFFSixJQUFFLFFBQU1HLElBQUVILE1BQUlLLEVBQUVHLEtBQUdSLElBQUVHLEdBQUVLLEtBQUcsR0FBRUwsSUFBRUgsSUFBR0MsSUFBRUMsRUFBSyxFQUFFLFlBQVlGLEtBQUdJLElBQUUsS0FBR0QsS0FBR0MsSUFBRSxJQUFFLEdBQUVDLEdBQUVHLEdBQUUsR0FBRSxHQUFFRyxHQUFFWCxJQUFFVyxHQUFFLEdBQUVWLENBQUMsR0FBRU8sSUFBRUMsSUFBRSxJQUFFLEdBQUVFLElBQUVYO0FBQUcsWUFBSWUsSUFBRTtBQUFFLFFBQUFmLElBQUVJLElBQUUsTUFBSVcsSUFBRWIsRUFBSyxFQUFFLFdBQVcsR0FBRUYsR0FBRU8sR0FBRUssR0FBRSxLQUFLLElBQUlqQixFQUFFLElBQUdTLElBQUVKLENBQUMsR0FBRUwsRUFBRSxFQUFFO0FBQUcsWUFBSWUsSUFBRUssTUFBSSxJQUFHQyxJQUFFLFFBQU1EO0FBQUUsWUFBTUEsS0FBSCxHQUFLO0FBQUMsVUFBQUMsSUFBRSxRQUFNRDtBQUFFLGNBQUlFLElBQUVwQixFQUFFYSxJQUFFSyxNQUFJLElBQUdqQixFQUFFLEdBQUc7QUFBRSxVQUFBQSxFQUFFLEtBQUssTUFBSW1CO0FBQUssY0FBSUMsSUFBRXJCLEVBQUVtQixHQUFFbEIsRUFBRSxHQUFHO0FBQUUsVUFBQUEsRUFBRSxLQUFLb0IsTUFBSyxLQUFHcEIsRUFBRSxJQUFJbUIsS0FBR25CLEVBQUUsSUFBSW9CLElBQUdiLEVBQUVHLEtBQUdFLEtBQUcsS0FBR1YsSUFBRUcsR0FBRUUsRUFBRUcsSUFBRSxLQUFHUSxLQUFHLEtBQUdDLEtBQUcsSUFBRUMsR0FBRVYsS0FBRyxHQUFFTCxJQUFFSCxJQUFFVTtBQUFBLFFBQUM7QUFBTSxVQUFBWixFQUFFLEtBQUssRUFBRUU7QUFBTSxRQUFBUztBQUFBLE1BQUc7QUFBQSxJQUFDO0FBQUMsU0FBSUUsS0FBR1gsS0FBTSxFQUFFLFVBQUwsTUFBY0csSUFBRUgsTUFBSUssRUFBRUcsS0FBR1IsSUFBRUcsR0FBRUssS0FBRyxHQUFFTCxJQUFFSCxJQUFHQyxJQUFFQyxFQUFLLEVBQUUsWUFBWSxHQUFFRyxHQUFFRyxHQUFFLEdBQUUsR0FBRUcsR0FBRVgsSUFBRVcsR0FBRSxHQUFFVixDQUFDLEdBQUVPLElBQUUsR0FBRUMsSUFBRSxHQUFFRCxJQUFFQyxJQUFFLElBQUUsR0FBRUUsSUFBRVgsS0FBTyxJQUFFQyxNQUFOO0FBQVUsTUFBQUE7QUFBSSxXQUFPQSxNQUFJO0FBQUEsRUFBQyxHQUFFQyxFQUFLLEVBQUUsYUFBVyxTQUFTLEdBQUUsR0FBRVYsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRTtBQUFDLFFBQUlELElBQUUsUUFBTSxHQUFFRSxJQUFFUCxFQUFFSyxJQUFHRyxJQUFFSCxJQUFFRSxJQUFFLFFBQU07QUFBTSxRQUFHQSxLQUFHRixLQUFHSixLQUFHUyxFQUFLLEVBQUUsTUFBTSxHQUFFLElBQUVGLENBQUM7QUFBRSxhQUFPO0FBQUUsYUFBUUMsSUFBRSxHQUFFRSxJQUFFLEdBQUVDLElBQUUsS0FBSyxJQUFJLE9BQU0sQ0FBQyxHQUFFSixLQUFHSSxLQUFNLEVBQUVOLEtBQUwsS0FBUUMsS0FBR0YsS0FBRztBQUFDLFVBQU1JLEtBQUgsS0FBTSxFQUFFLElBQUVBLE1BQUksRUFBRSxJQUFFQSxJQUFFRCxJQUFHO0FBQUMsWUFBSUssSUFBRUgsRUFBSyxFQUFFLFNBQVMsR0FBRSxHQUFFRixDQUFDO0FBQUUsWUFBR0ssSUFBRUosR0FBRTtBQUFDLGNBQUdFLElBQUVILElBQUdDLElBQUVJLE1BQUlWO0FBQUU7QUFBTSxVQUFBSyxJQUFFLElBQUVLLE1BQUlBLElBQUVMLElBQUU7QUFBRyxtQkFBUU0sSUFBRSxHQUFFQyxJQUFFLEdBQUVBLElBQUVGLElBQUUsR0FBRUUsS0FBSTtBQUFDLGdCQUFJQyxJQUFFLElBQUVSLElBQUVPLElBQUUsUUFBTSxPQUFNRSxJQUFFRCxJQUFFaEIsRUFBRWdCLEtBQUcsUUFBTTtBQUFNLFlBQUFDLElBQUVILE1BQUlBLElBQUVHLEdBQUVWLElBQUVTO0FBQUEsVUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDO0FBQUMsTUFBQVIsTUFBSUgsSUFBRUUsTUFBSUEsSUFBRVAsRUFBRUssTUFBSSxRQUFNO0FBQUEsSUFBSztBQUFDLFdBQU9JLEtBQUcsS0FBR0U7QUFBQSxFQUFDLEdBQUVELEVBQUssRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFVixHQUFFO0FBQUMsUUFBRyxFQUFFLE1BQUksRUFBRSxJQUFFQSxNQUFJLEVBQUUsSUFBRSxNQUFJLEVBQUUsSUFBRSxJQUFFQSxNQUFJLEVBQUUsSUFBRSxNQUFJLEVBQUUsSUFBRSxJQUFFQTtBQUFHLGFBQU87QUFBRSxRQUFJQyxJQUFFLEdBQUVFLElBQUUsS0FBSyxJQUFJLEVBQUUsUUFBTyxJQUFFLEdBQUc7QUFBRSxTQUFJLEtBQUcsR0FBRSxJQUFFQSxLQUFHLEVBQUUsTUFBSSxFQUFFLElBQUVIO0FBQUk7QUFBSSxXQUFPLElBQUVDO0FBQUEsRUFBQyxHQUFFUyxFQUFLLEVBQUUsUUFBTSxTQUFTLEdBQUUsR0FBRTtBQUFDLFlBQU8sRUFBRSxNQUFJLElBQUUsRUFBRSxJQUFFLE9BQUssRUFBRSxJQUFFLE1BQUksS0FBRztBQUFBLEVBQUssR0FBRUEsRUFBSyxRQUFNLEdBQUVBLEVBQUssRUFBRSxjQUFZLFNBQVMsR0FBRSxHQUFFVixHQUFFQyxHQUFFRSxHQUFFRyxHQUFFRCxHQUFFRSxHQUFFQyxHQUFFO0FBQUMsUUFBSUMsR0FBRUUsR0FBRUMsR0FBRUMsR0FBRUMsR0FBRUMsR0FBRUMsR0FBRUMsR0FBRUUsR0FBRSxJQUFFVCxFQUFLLEVBQUUsR0FBRVUsSUFBRVYsRUFBSyxFQUFFLFFBQU9XLElBQUVYLEVBQUssRUFBRTtBQUFPLE1BQUUsS0FBSyxRQUFPQyxLQUFHRixJQUFFQyxFQUFLLEVBQUUsU0FBVSxHQUFFLElBQUdFLElBQUVILEVBQUUsSUFBR0ksSUFBRUosRUFBRSxJQUFHSyxJQUFFTCxFQUFFLElBQUdNLElBQUVOLEVBQUUsSUFBR08sSUFBRVAsRUFBRSxJQUFHUSxJQUFFUixFQUFFLElBQUdVLElBQUVWLEVBQUU7QUFBRyxRQUFJYSxJQUFFLE9BQVFkLElBQUUsSUFBRSxNQUFSLElBQVcsSUFBRSxLQUFHQSxJQUFFLElBQUUsT0FBS0gsS0FBRyxJQUFHa0IsSUFBRXRCLElBQUVTLEVBQUssRUFBRSxTQUFTLEVBQUUsUUFBTyxFQUFFLElBQUksSUFBRUEsRUFBSyxFQUFFLFNBQVMsRUFBRSxRQUFPLEVBQUUsSUFBSSxHQUFFUSxJQUFFakIsSUFBRVMsRUFBSyxFQUFFLFNBQVMsRUFBRSxPQUFNLEVBQUUsSUFBSSxJQUFFQSxFQUFLLEVBQUUsU0FBUyxFQUFFLE9BQU0sRUFBRSxJQUFJO0FBQUUsSUFBQVEsS0FBRyxLQUFHLElBQUVGLElBQUVOLEVBQUssRUFBRSxTQUFTLEVBQUUsT0FBTSxFQUFFLElBQUksS0FBRyxJQUFFLEVBQUUsS0FBSyxNQUFJLElBQUUsRUFBRSxLQUFLLE1BQUksSUFBRSxFQUFFLEtBQUs7QUFBSyxhQUFRYyxJQUFFLEdBQUVBLElBQUUsS0FBSUE7QUFBSSxRQUFFLEtBQUtBLEtBQUc7QUFBRSxTQUFJQSxJQUFFLEdBQUVBLElBQUUsSUFBR0E7QUFBSSxRQUFFLEtBQUtBLEtBQUc7QUFBRSxTQUFJQSxJQUFFLEdBQUVBLElBQUUsSUFBR0E7QUFBSSxRQUFFLEtBQUtBLEtBQUc7QUFBRSxRQUFJQyxJQUFFSCxJQUFFQyxLQUFHRCxJQUFFSixJQUFFLElBQUVLLElBQUVMLElBQUUsSUFBRTtBQUFFLFFBQUdFLEVBQUViLEdBQUVDLEdBQUUsQ0FBQyxHQUFFWSxFQUFFYixHQUFFQyxJQUFFLEdBQUVpQixDQUFDLEdBQUVqQixLQUFHLEdBQUtpQixLQUFILEdBQUs7QUFBQyxjQUFTLElBQUVqQixNQUFOO0FBQVUsUUFBQUE7QUFBSSxNQUFBQSxJQUFFRSxFQUFLLEVBQUUsV0FBV1AsR0FBRUcsR0FBRUQsR0FBRUUsR0FBRUMsQ0FBQztBQUFBLElBQUMsT0FBSztBQUFDLFVBQUlrQixHQUFFQztBQUFFLFVBQU1GLEtBQUgsTUFBT0MsSUFBRSxFQUFFLFFBQU9DLElBQUUsRUFBRSxTQUFXRixLQUFILEdBQUs7QUFBQyxRQUFBZixFQUFLLEVBQUUsVUFBVSxFQUFFLE9BQU1DLENBQUMsR0FBRUQsRUFBSyxFQUFFLFNBQVMsRUFBRSxPQUFNQyxDQUFDLEdBQUVELEVBQUssRUFBRSxVQUFVLEVBQUUsT0FBTUUsQ0FBQyxHQUFFRixFQUFLLEVBQUUsU0FBUyxFQUFFLE9BQU1FLENBQUMsR0FBRUYsRUFBSyxFQUFFLFVBQVUsRUFBRSxPQUFNRyxDQUFDLEdBQUVILEVBQUssRUFBRSxTQUFTLEVBQUUsT0FBTUcsQ0FBQyxHQUFFYSxJQUFFLEVBQUUsT0FBTUMsSUFBRSxFQUFFLE9BQU1OLEVBQUVkLEdBQUVDLEdBQUVNLElBQUUsR0FBRyxHQUFFTyxFQUFFZCxHQUFFQyxLQUFHLEdBQUVPLElBQUUsQ0FBQyxHQUFFTSxFQUFFZCxHQUFFQyxLQUFHLEdBQUVRLElBQUUsQ0FBQyxHQUFFUixLQUFHO0FBQUUsaUJBQVFvQixJQUFFLEdBQUVBLElBQUVaLEdBQUVZO0FBQUksVUFBQVAsRUFBRWQsR0FBRUMsSUFBRSxJQUFFb0IsR0FBRSxFQUFFLE1BQU0sS0FBRyxFQUFFLEtBQUtBLE1BQUksR0FBRztBQUFFLFFBQUFwQixLQUFHLElBQUVRLEdBQUVSLElBQUVFLEVBQUssRUFBRSxVQUFVTyxHQUFFLEVBQUUsT0FBTVYsR0FBRUMsQ0FBQyxHQUFFQSxJQUFFRSxFQUFLLEVBQUUsVUFBVVMsR0FBRSxFQUFFLE9BQU1aLEdBQUVDLENBQUM7QUFBQSxNQUFDO0FBQUMsZUFBUXFCLElBQUV2QixHQUFFd0IsSUFBRSxHQUFFQSxJQUFFOUIsR0FBRThCLEtBQUcsR0FBRTtBQUFDLGlCQUFRQyxJQUFFLEVBQUVELElBQUdFLElBQUVELE1BQUksSUFBR0UsSUFBRUosS0FBRyxVQUFRRSxJQUFHRixJQUFFSTtBQUFHLFVBQUF6QixJQUFFRSxFQUFLLEVBQUUsVUFBVVAsRUFBRTBCLE1BQUtILEdBQUVuQixHQUFFQyxDQUFDO0FBQUUsWUFBTXdCLEtBQUgsR0FBSztBQUFDLGNBQUlFLElBQUUsRUFBRUosSUFBRSxJQUFHSyxJQUFFRCxLQUFHLElBQUdFLElBQUVGLEtBQUcsSUFBRSxLQUFJRyxJQUFFLE1BQUlIO0FBQUUsVUFBQWIsRUFBRWQsR0FBRUMsSUFBRUUsRUFBSyxFQUFFLFVBQVUsTUFBSTBCLEdBQUVWLEdBQUVuQixHQUFFQyxDQUFDLEdBQUV3QixJQUFFLEVBQUUsSUFBSUksRUFBRSxHQUFFNUIsS0FBRyxFQUFFLElBQUk0QixJQUFHaEIsRUFBRWIsR0FBRUMsSUFBRUUsRUFBSyxFQUFFLFVBQVUyQixHQUFFVixHQUFFcEIsR0FBRUMsQ0FBQyxHQUFFMkIsSUFBRSxFQUFFLElBQUlFLEVBQUUsR0FBRTdCLEtBQUcsRUFBRSxJQUFJNkIsSUFBR1IsS0FBR0c7QUFBQSxRQUFDO0FBQUEsTUFBQztBQUFDLE1BQUF4QixJQUFFRSxFQUFLLEVBQUUsVUFBVSxLQUFJZ0IsR0FBRW5CLEdBQUVDLENBQUM7QUFBQSxJQUFDO0FBQUMsV0FBT0E7QUFBQSxFQUFDLEdBQUVFLEVBQUssRUFBRSxhQUFXLFNBQVMsR0FBRSxHQUFFVixHQUFFQyxHQUFFRSxHQUFFO0FBQUMsUUFBSUcsSUFBRUgsTUFBSTtBQUFFLFdBQU9GLEVBQUVLLEtBQUdOLEdBQUVDLEVBQUVLLElBQUUsS0FBR04sTUFBSSxHQUFFQyxFQUFFSyxJQUFFLEtBQUcsTUFBSUwsRUFBRUssSUFBR0wsRUFBRUssSUFBRSxLQUFHLE1BQUlMLEVBQUVLLElBQUUsSUFBR0EsS0FBRyxHQUFFTCxFQUFFLElBQUksSUFBSSxXQUFXLEVBQUUsUUFBTyxHQUFFRCxDQUFDLEdBQUVNLENBQUMsR0FBRUgsS0FBR0gsSUFBRSxLQUFHO0FBQUEsRUFBRSxHQUFFVSxFQUFLLEVBQUUsV0FBUyxXQUFVO0FBQUMsYUFBUSxJQUFFQSxFQUFLLEVBQUUsR0FBRSxJQUFFQSxFQUFLLEVBQUUsU0FBUyxFQUFFLE1BQUssRUFBRSxPQUFNLEVBQUUsR0FBRVYsSUFBRVUsRUFBSyxFQUFFLFNBQVMsRUFBRSxNQUFLLEVBQUUsT0FBTSxFQUFFLEdBQUVULElBQUUsQ0FBRSxHQUFDRSxJQUFFTyxFQUFLLEVBQUUsVUFBVSxFQUFFLE9BQU1ULENBQUMsR0FBRUssSUFBRSxDQUFFLEdBQUNELElBQUVLLEVBQUssRUFBRSxVQUFVLEVBQUUsT0FBTUosQ0FBQyxHQUFFQyxJQUFFLEdBQUVBLElBQUVOLEVBQUUsUUFBT00sS0FBRztBQUFFLFFBQUUsS0FBS04sRUFBRU07QUFBTSxTQUFJQSxJQUFFLEdBQUVBLElBQUVELEVBQUUsUUFBT0MsS0FBRztBQUFFLFFBQUUsS0FBS0QsRUFBRUM7QUFBTSxhQUFRQyxJQUFFRSxFQUFLLEVBQUUsU0FBUyxFQUFFLE1BQUssRUFBRSxPQUFNLENBQUMsR0FBRUQsSUFBRSxJQUFHQSxJQUFFLEtBQU0sRUFBRSxNQUFNLEtBQUcsRUFBRSxLQUFLQSxJQUFFLE1BQUksT0FBM0I7QUFBZ0MsTUFBQUE7QUFBSSxXQUFNLENBQUMsR0FBRVQsR0FBRVEsR0FBRUwsR0FBRUUsR0FBRUksR0FBRVIsR0FBRUssQ0FBQztBQUFBLEVBQUMsR0FBRUksRUFBSyxFQUFFLFlBQVUsU0FBUyxHQUFFO0FBQUMsYUFBUSxJQUFFLENBQUUsR0FBQ1YsSUFBRSxHQUFFQSxJQUFFLEVBQUUsUUFBT0EsS0FBRztBQUFFLFFBQUUsS0FBSyxFQUFFQSxJQUFFLEVBQUU7QUFBRSxXQUFPO0FBQUEsRUFBQyxHQUFFVSxFQUFLLEVBQUUsVUFBUSxTQUFTLEdBQUU7QUFBQyxhQUFRLElBQUUsSUFBR1YsSUFBRSxHQUFFQSxJQUFFLEVBQUUsUUFBT0EsS0FBRztBQUFFLE1BQUcsRUFBRUEsSUFBRSxNQUFQLE1BQVksTUFBSUEsS0FBRyxLQUFHO0FBQUssV0FBTztBQUFBLEVBQUMsR0FBRVUsRUFBSyxFQUFFLFdBQVMsU0FBUyxHQUFFLEdBQUU7QUFBQyxhQUFRVixJQUFFLEdBQUVDLElBQUUsR0FBRUEsSUFBRSxFQUFFLFFBQU9BO0FBQUksTUFBQUQsS0FBRyxFQUFFQyxLQUFHLEVBQUUsS0FBR0EsS0FBRztBQUFJLFdBQU9EO0FBQUEsRUFBQyxHQUFFVSxFQUFLLEVBQUUsWUFBVSxTQUFTLEdBQUUsR0FBRVYsR0FBRUMsR0FBRTtBQUFDLGFBQVFFLElBQUUsR0FBRUEsSUFBRSxFQUFFLFFBQU9BLEtBQUcsR0FBRTtBQUFDLFVBQUlHLElBQUUsRUFBRUgsSUFBR0UsSUFBRSxFQUFFRixJQUFFO0FBQUcsTUFBQUYsSUFBRVMsRUFBSyxFQUFFLFVBQVVKLEdBQUUsR0FBRU4sR0FBRUMsQ0FBQztBQUFFLFVBQUlNLElBQU1ELEtBQUosS0FBTSxJQUFNQSxLQUFKLEtBQU0sSUFBRTtBQUFFLE1BQUFBLElBQUUsT0FBS0ksRUFBSyxFQUFFLE9BQU9WLEdBQUVDLEdBQUVJLEdBQUVFLENBQUMsR0FBRU4sS0FBR007QUFBQSxJQUFFO0FBQUMsV0FBT047QUFBQSxFQUFDLEdBQUVTLEVBQUssRUFBRSxZQUFVLFNBQVMsR0FBRSxHQUFFO0FBQUMsYUFBUVYsSUFBRSxFQUFFLFFBQVVBLEtBQUgsS0FBUyxFQUFFQSxJQUFFLE1BQVA7QUFBVyxNQUFBQSxLQUFHO0FBQUUsYUFBUUMsSUFBRSxHQUFFQSxJQUFFRCxHQUFFQyxLQUFHLEdBQUU7QUFBQyxVQUFJRSxJQUFFLEVBQUVGLElBQUUsSUFBR0ssSUFBRUwsSUFBRSxJQUFFRCxJQUFFLEVBQUVDLElBQUUsS0FBRyxJQUFHSSxJQUFFSixJQUFFLElBQUVELElBQUUsRUFBRUMsSUFBRSxLQUFHLElBQUdNLElBQUtOLEtBQUgsSUFBSyxLQUFHLEVBQUVBLElBQUU7QUFBRyxVQUFNRSxLQUFILEtBQU1HLEtBQUdILEtBQUdFLEtBQUdGLEdBQUU7QUFBQyxpQkFBUUssSUFBRVAsSUFBRSxHQUFFTyxJQUFFLElBQUVSLEtBQUcsRUFBRVEsSUFBRSxNQUFJTDtBQUFHLFVBQUFLLEtBQUc7QUFBRSxTQUFDQyxJQUFFLEtBQUssSUFBSUQsSUFBRSxJQUFFUCxNQUFJLEdBQUUsR0FBRyxLQUFHLEtBQUcsRUFBRSxLQUFLLElBQUdRLElBQUUsQ0FBQyxJQUFFLEVBQUUsS0FBSyxJQUFHQSxJQUFFLEVBQUUsR0FBRVIsS0FBRyxJQUFFUSxJQUFFO0FBQUEsTUFBQyxXQUFTTixLQUFHSSxLQUFHRCxLQUFHSCxLQUFHRSxLQUFHRixHQUFFO0FBQUMsYUFBSUssSUFBRVAsSUFBRSxHQUFFTyxJQUFFLElBQUVSLEtBQUcsRUFBRVEsSUFBRSxNQUFJTDtBQUFHLFVBQUFLLEtBQUc7QUFBRSxZQUFJQyxJQUFFLEtBQUssSUFBSUQsSUFBRSxJQUFFUCxNQUFJLEdBQUUsQ0FBQztBQUFFLFVBQUUsS0FBSyxJQUFHUSxJQUFFLENBQUMsR0FBRVIsS0FBRyxJQUFFUSxJQUFFO0FBQUEsTUFBQztBQUFNLFVBQUUsS0FBS04sR0FBRSxDQUFDO0FBQUEsSUFBQztBQUFDLFdBQU9ILE1BQUk7QUFBQSxFQUFDLEdBQUVVLEVBQUssRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFVixHQUFFO0FBQUMsUUFBSUMsSUFBRSxDQUFFLEdBQUNFLElBQUUsRUFBRSxRQUFPRyxJQUFFLEVBQUUsUUFBT0QsSUFBRTtBQUFFLFNBQUlBLElBQUUsR0FBRUEsSUFBRUMsR0FBRUQsS0FBRztBQUFFLFFBQUVBLEtBQUcsR0FBRSxFQUFFQSxJQUFFLEtBQUc7QUFBRSxTQUFJQSxJQUFFLEdBQUVBLElBQUVGLEdBQUVFO0FBQUksTUFBRyxFQUFFQSxNQUFMLEtBQVNKLEVBQUUsS0FBSyxFQUFDLEtBQUlJLEdBQUUsR0FBRSxFQUFFQSxHQUFFLENBQUM7QUFBRSxRQUFJRSxJQUFFTixFQUFFLFFBQU9PLElBQUVQLEVBQUUsTUFBTSxDQUFDO0FBQUUsUUFBTU0sS0FBSDtBQUFLLGFBQU87QUFBRSxRQUFNQSxLQUFILEdBQUs7QUFBQyxVQUFJRSxJQUFFUixFQUFFLEdBQUc7QUFBSSxhQUFBTyxJQUFLQyxLQUFILElBQUssSUFBRSxHQUFTLEVBQUUsS0FBR0EsS0FBRyxNQUFJLEdBQUUsRUFBRSxLQUFHRCxLQUFHLE1BQUksR0FBRTtBQUFBLElBQUM7QUFBQyxJQUFBUCxFQUFFLEtBQU0sU0FBU0YsR0FBRWpCLEdBQUU7QUFBQyxhQUFPaUIsRUFBRSxJQUFFakIsRUFBRTtBQUFBLElBQUMsQ0FBRztBQUFDLFFBQUk2QixJQUFFVixFQUFFLElBQUdXLElBQUVYLEVBQUUsSUFBR1ksSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUU7QUFBRSxTQUFJZCxFQUFFLEtBQUcsRUFBQyxLQUFJLElBQUcsR0FBRVUsRUFBRSxJQUFFQyxFQUFFLEdBQUUsR0FBRUQsR0FBRSxHQUFFQyxHQUFFLEdBQUUsRUFBQyxHQUFFRSxLQUFHUCxJQUFFO0FBQUcsTUFBQUksSUFBRUUsS0FBR0MsTUFBSUMsS0FBR1IsS0FBR04sRUFBRVksR0FBRyxJQUFFWixFQUFFYyxHQUFHLEtBQUdkLEVBQUVZLE9BQUtaLEVBQUVjLE1BQUtILElBQUVDLEtBQUdDLE1BQUlDLEtBQUdSLEtBQUdOLEVBQUVZLEdBQUcsSUFBRVosRUFBRWMsR0FBRyxLQUFHZCxFQUFFWSxPQUFLWixFQUFFYyxNQUFLZCxFQUFFYSxPQUFLLEVBQUMsS0FBSSxJQUFHLEdBQUVILEVBQUUsSUFBRUMsRUFBRSxHQUFFLEdBQUVELEdBQUUsR0FBRUMsRUFBQztBQUFFLFFBQUlJLElBQUVOLEVBQUssRUFBRSxTQUFTVCxFQUFFYSxJQUFFLElBQUcsQ0FBQztBQUFFLFNBQUlFLElBQUVoQixNQUFJVSxFQUFLLEVBQUUsY0FBY0YsR0FBRVIsR0FBRWdCLENBQUMsR0FBRUEsSUFBRWhCLElBQUdLLElBQUUsR0FBRUEsSUFBRUUsR0FBRUY7QUFBSSxRQUFFLEtBQUdHLEVBQUVILEdBQUcsT0FBSyxNQUFJRyxFQUFFSCxHQUFHO0FBQUUsV0FBT1c7QUFBQSxFQUFDLEdBQUVOLEVBQUssRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFO0FBQUMsV0FBVSxFQUFFLE9BQU4sTUFBVyxFQUFFLElBQUUsR0FBRSxLQUFHLEtBQUssSUFBSUEsRUFBSyxFQUFFLFNBQVMsRUFBRSxHQUFFLElBQUUsQ0FBQyxHQUFFQSxFQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUUsSUFBRSxDQUFDLENBQUM7QUFBQSxFQUFDLEdBQUVBLEVBQUssRUFBRSxnQkFBYyxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLFFBQUlDLElBQUUsR0FBRUUsSUFBRSxLQUFHSCxJQUFFLEdBQUVNLElBQUU7QUFBRSxTQUFJLEVBQUUsS0FBTSxTQUFTUCxHQUFFakIsR0FBRTtBQUFDLGFBQU9BLEVBQUUsS0FBR2lCLEVBQUUsSUFBRUEsRUFBRSxJQUFFakIsRUFBRSxJQUFFQSxFQUFFLElBQUVpQixFQUFFO0FBQUEsSUFBQyxDQUFDLEdBQUdFLElBQUUsR0FBRUEsSUFBRSxFQUFFLFVBQVEsRUFBRUEsR0FBRyxJQUFFLEdBQUVBLEtBQUk7QUFBQyxVQUFJSSxJQUFFLEVBQUVKLEdBQUc7QUFBRSxRQUFFQSxHQUFHLElBQUUsR0FBRUssS0FBR0gsS0FBRyxLQUFHSCxJQUFFSztBQUFBLElBQUU7QUFBQyxTQUFJQyxPQUFLTixJQUFFLEdBQUVNLElBQUU7QUFBSSxPQUFDRCxJQUFFLEVBQUVKLEdBQUcsS0FBRyxLQUFHLEVBQUVBLEdBQUcsS0FBSUssS0FBRyxLQUFHLElBQUVELElBQUUsS0FBR0o7QUFBSSxXQUFLQSxLQUFHLEdBQUVBO0FBQUksUUFBRUEsR0FBRyxLQUFHLEtBQUdLLElBQUUsTUFBSSxFQUFFTCxHQUFHLEtBQUlLO0FBQUssSUFBR0EsS0FBSCxLQUFNLFFBQVEsSUFBSSxXQUFXO0FBQUEsRUFBQyxHQUFFSSxFQUFLLEVBQUUsYUFBVyxTQUFTLEdBQUUsR0FBRTtBQUFDLFFBQUlWLElBQUU7QUFBRSxXQUFPLEVBQUUsS0FBR0EsTUFBSSxNQUFJQSxLQUFHLEtBQUksRUFBRSxJQUFFQSxNQUFJLE1BQUlBLEtBQUcsSUFBRyxFQUFFLElBQUVBLE1BQUksTUFBSUEsS0FBRyxJQUFHLEVBQUUsSUFBRUEsTUFBSSxNQUFJQSxLQUFHLElBQUcsRUFBRSxJQUFFQSxNQUFJLE1BQUlBLEtBQUcsSUFBR0E7QUFBQSxFQUFDLEdBQUVVLEVBQUssRUFBRSxZQUFVLFNBQVMsR0FBRSxHQUFFVixHQUFFQyxHQUFFO0FBQUMsV0FBT1MsRUFBSyxFQUFFLE9BQU9WLEdBQUVDLEdBQUUsRUFBRSxLQUFHLEVBQUUsR0FBRUEsSUFBRSxFQUFFLEtBQUcsS0FBRztBQUFBLEVBQUcsR0FBRVMsRUFBSyxFQUFFLFVBQVEsU0FBUyxHQUFFLEdBQUU7QUFBQyxRQUFJVixJQUFFO0FBQVcsUUFBTSxFQUFFLE1BQUwsS0FBWSxFQUFFLE1BQUw7QUFBUSxhQUFPLEtBQUcsSUFBSUEsRUFBRSxDQUFDO0FBQUUsUUFBSUMsSUFBRVMsRUFBSyxHQUFFUCxJQUFFRixFQUFFLFFBQU9LLElBQUVMLEVBQUUsUUFBT0ksSUFBRUosRUFBRSxhQUFZTSxJQUFFTixFQUFFLFdBQVVPLElBQUVQLEVBQUUsV0FBVVEsSUFBRVIsRUFBRSxRQUFPVSxJQUFFVixFQUFFLEdBQUVXLElBQVEsS0FBTjtBQUFRLElBQUFBLE1BQUksSUFBRSxJQUFJWixFQUFFLEVBQUUsV0FBUyxLQUFHLENBQUM7QUFBRyxhQUFRYSxHQUFFQyxHQUFFQyxJQUFFLEdBQUVDLElBQUUsR0FBRUMsSUFBRSxHQUFFRSxJQUFFLEdBQUUsSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUUsR0FBRUMsSUFBRSxHQUFFQyxJQUFFLEdBQUtSLEtBQUg7QUFBTSxVQUFHQSxJQUFFWixFQUFFLEdBQUVvQixHQUFFLENBQUMsR0FBRVAsSUFBRWIsRUFBRSxHQUFFb0IsSUFBRSxHQUFFLENBQUMsR0FBRUEsS0FBRyxHQUFLUCxLQUFILEdBQUs7QUFBQyxZQUFHSixNQUFJLElBQUVGLEVBQUssRUFBRSxPQUFPLEdBQUVZLEtBQUcsS0FBRyxHQUFHLElBQU1OLEtBQUgsTUFBT0gsSUFBRUYsRUFBRSxPQUFNRyxJQUFFSCxFQUFFLE9BQU1TLElBQUUsS0FBSUMsSUFBRSxLQUFPTCxLQUFILEdBQUs7QUFBQyxVQUFBQyxJQUFFWCxFQUFFLEdBQUVpQixHQUFFLENBQUMsSUFBRSxLQUFJSixJQUFFYixFQUFFLEdBQUVpQixJQUFFLEdBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRWpCLEVBQUUsR0FBRWlCLElBQUUsSUFBRyxDQUFDLElBQUUsR0FBRUEsS0FBRztBQUFHLG1CQUFRTCxJQUFFLEdBQUVBLElBQUUsSUFBR0EsS0FBRztBQUFFLFlBQUFQLEVBQUUsTUFBTU8sS0FBRyxHQUFFUCxFQUFFLE1BQU1PLElBQUUsS0FBRztBQUFFLGNBQUlNLElBQUU7QUFBRSxlQUFJTixJQUFFLEdBQUVBLElBQUUsR0FBRUEsS0FBSTtBQUFDLGdCQUFJTyxJQUFFbkIsRUFBRSxHQUFFaUIsSUFBRSxJQUFFTCxHQUFFLENBQUM7QUFBRSxZQUFBUCxFQUFFLE1BQU0sS0FBR0EsRUFBRSxLQUFLTyxNQUFJLE1BQUlPLEdBQUVBLElBQUVELE1BQUlBLElBQUVDO0FBQUEsVUFBRTtBQUFDLFVBQUFGLEtBQUcsSUFBRSxHQUFFaEIsRUFBRUksRUFBRSxPQUFNYSxDQUFDLEdBQUVoQixFQUFFRyxFQUFFLE9BQU1hLEdBQUViLEVBQUUsSUFBSSxHQUFFRSxJQUFFRixFQUFFLE1BQUtHLElBQUVILEVBQUUsTUFBS1ksSUFBRWxCLEVBQUVNLEVBQUUsT0FBTSxLQUFHYSxLQUFHLEdBQUVQLElBQUVFLEdBQUUsR0FBRUksR0FBRVosRUFBRSxLQUFLO0FBQUUsY0FBSWUsSUFBRXpCLEVBQUUsU0FBU1UsRUFBRSxPQUFNLEdBQUVNLEdBQUVOLEVBQUUsS0FBSztBQUFFLFVBQUFTLEtBQUcsS0FBR00sS0FBRztBQUFFLGNBQUlDLElBQUUxQixFQUFFLFNBQVNVLEVBQUUsT0FBTU0sR0FBRUUsR0FBRVIsRUFBRSxLQUFLO0FBQUUsVUFBQVUsS0FBRyxLQUFHTSxLQUFHLEdBQUVwQixFQUFFSSxFQUFFLE9BQU1lLENBQUMsR0FBRWxCLEVBQUVHLEVBQUUsT0FBTWUsR0FBRWIsQ0FBQyxHQUFFTixFQUFFSSxFQUFFLE9BQU1nQixDQUFDLEdBQUVuQixFQUFFRyxFQUFFLE9BQU1nQixHQUFFYixDQUFDO0FBQUEsUUFBQztBQUFDLG1CQUFPO0FBQUMsY0FBSWMsSUFBRWYsRUFBRUosRUFBRSxHQUFFYyxDQUFDLElBQUVIO0FBQUcsVUFBQUcsS0FBRyxLQUFHSztBQUFFLGNBQUlDLElBQUVELE1BQUk7QUFBRSxjQUFHQyxNQUFJLEtBQUc7QUFBRSxjQUFFUCxPQUFLTztBQUFBLGVBQU07QUFBQyxnQkFBUUEsS0FBTDtBQUFPO0FBQU0sZ0JBQUlDLElBQUVSLElBQUVPLElBQUU7QUFBSSxnQkFBR0EsSUFBRSxLQUFJO0FBQUMsa0JBQUlFLElBQUVwQixFQUFFLEtBQUtrQixJQUFFO0FBQUssY0FBQUMsSUFBRVIsS0FBR1MsTUFBSSxLQUFHekIsRUFBRSxHQUFFaUIsR0FBRSxJQUFFUSxDQUFDLEdBQUVSLEtBQUcsSUFBRVE7QUFBQSxZQUFDO0FBQUMsZ0JBQUlDLElBQUVsQixFQUFFTCxFQUFFLEdBQUVjLENBQUMsSUFBRUY7QUFBRyxZQUFBRSxLQUFHLEtBQUdTO0FBQUUsZ0JBQUlDLElBQUVELE1BQUksR0FBRUUsSUFBRXZCLEVBQUUsS0FBS3NCLElBQUdFLEtBQUdELE1BQUksS0FBRy9CLEVBQUUsR0FBRW9CLEdBQUUsS0FBR1csQ0FBQztBQUFFLGlCQUFJWCxLQUFHLEtBQUdXLEdBQUV0QixNQUFJLElBQUVGLEVBQUssRUFBRSxPQUFPLEdBQUVZLEtBQUcsS0FBRyxHQUFHLElBQUdBLElBQUVRO0FBQUcsZ0JBQUVSLEtBQUcsRUFBRUEsTUFBSWEsSUFBRyxFQUFFYixLQUFHLEVBQUVBLE1BQUlhLElBQUcsRUFBRWIsS0FBRyxFQUFFQSxNQUFJYSxJQUFHLEVBQUViLEtBQUcsRUFBRUEsTUFBSWE7QUFBRyxZQUFBYixJQUFFUTtBQUFBLFVBQUM7QUFBQSxRQUFDO0FBQUEsTUFBQyxPQUFLO0FBQUMsU0FBSSxJQUFFUCxNQUFOLE1BQVdBLEtBQUcsS0FBRyxJQUFFQTtBQUFJLFlBQUlhLElBQUUsS0FBR2IsTUFBSSxJQUFHYyxJQUFFLEVBQUVELElBQUUsS0FBRyxFQUFFQSxJQUFFLE1BQUk7QUFBRSxRQUFBeEIsTUFBSSxJQUFFRixFQUFLLEVBQUUsT0FBTyxHQUFFWSxJQUFFZSxDQUFDLElBQUcsRUFBRSxJQUFJLElBQUlyQyxFQUFFLEVBQUUsUUFBTyxFQUFFLGFBQVdvQyxHQUFFQyxDQUFDLEdBQUVmLENBQUMsR0FBRUMsSUFBRWEsSUFBRUMsS0FBRyxHQUFFZixLQUFHZTtBQUFBLE1BQUM7QUFBQyxXQUFPLEVBQUUsVUFBUWYsSUFBRSxJQUFFLEVBQUUsTUFBTSxHQUFFQSxDQUFDO0FBQUEsRUFBQyxHQUFFWixFQUFLLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRTtBQUFDLFFBQUlWLElBQUUsRUFBRTtBQUFPLFFBQUcsS0FBR0E7QUFBRSxhQUFPO0FBQUUsUUFBSUMsSUFBRSxJQUFJLFdBQVcsS0FBSyxJQUFJRCxLQUFHLEdBQUUsQ0FBQyxDQUFDO0FBQUUsV0FBT0MsRUFBRSxJQUFJLEdBQUUsQ0FBQyxHQUFFQTtBQUFBLEVBQUMsR0FBRVMsRUFBSyxFQUFFLGNBQVksU0FBUyxHQUFFLEdBQUVWLEdBQUVDLEdBQUVFLEdBQUVHLEdBQUU7QUFBQyxhQUFRRCxJQUFFSyxFQUFLLEVBQUUsUUFBT0gsSUFBRUcsRUFBSyxFQUFFLFFBQU9GLElBQUUsR0FBRUEsSUFBRVIsS0FBRztBQUFDLFVBQUlTLElBQUUsRUFBRUYsRUFBRU4sR0FBRUUsQ0FBQyxJQUFFO0FBQUcsTUFBQUEsS0FBRyxLQUFHTTtBQUFFLFVBQUlFLElBQUVGLE1BQUk7QUFBRSxVQUFHRSxLQUFHO0FBQUcsUUFBQUwsRUFBRUUsS0FBR0csR0FBRUg7QUFBQSxXQUFRO0FBQUMsWUFBSUksSUFBRSxHQUFFQyxJQUFFO0FBQUUsUUFBSUYsS0FBSixNQUFPRSxJQUFFLElBQUVSLEVBQUVKLEdBQUVFLEdBQUUsQ0FBQyxHQUFFQSxLQUFHLEdBQUVTLElBQUVOLEVBQUVFLElBQUUsTUFBUUcsS0FBSixNQUFPRSxJQUFFLElBQUVSLEVBQUVKLEdBQUVFLEdBQUUsQ0FBQyxHQUFFQSxLQUFHLEtBQU9RLEtBQUosT0FBUUUsSUFBRSxLQUFHUixFQUFFSixHQUFFRSxHQUFFLENBQUMsR0FBRUEsS0FBRztBQUFHLGlCQUFRVyxJQUFFTixJQUFFSyxHQUFFTCxJQUFFTTtBQUFHLFVBQUFSLEVBQUVFLEtBQUdJLEdBQUVKO0FBQUEsTUFBRztBQUFBLElBQUM7QUFBQyxXQUFPTDtBQUFBLEVBQUMsR0FBRU8sRUFBSyxFQUFFLFdBQVMsU0FBUyxHQUFFLEdBQUVWLEdBQUVDLEdBQUU7QUFBQyxhQUFRRSxJQUFFLEdBQUVHLElBQUUsR0FBRUQsSUFBRUosRUFBRSxXQUFTLEdBQUVLLElBQUVOLEtBQUc7QUFBQyxVQUFJTyxJQUFFLEVBQUVELElBQUU7QUFBRyxNQUFBTCxFQUFFSyxLQUFHLEtBQUcsR0FBRUwsRUFBRSxLQUFHSyxLQUFHLE1BQUlDLEdBQUVBLElBQUVKLE1BQUlBLElBQUVJLElBQUdEO0FBQUEsSUFBRztBQUFDLFdBQUtBLElBQUVEO0FBQUcsTUFBQUosRUFBRUssS0FBRyxLQUFHLEdBQUVMLEVBQUUsS0FBR0ssS0FBRyxNQUFJLEdBQUVBO0FBQUksV0FBT0g7QUFBQSxFQUFDLEdBQUVPLEVBQUssRUFBRSxZQUFVLFNBQVMsR0FBRSxHQUFFO0FBQUMsYUFBUVYsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRUQsSUFBRUssRUFBSyxFQUFFLEdBQUVILElBQUUsRUFBRSxRQUFPQyxJQUFFSCxFQUFFLFVBQVNJLElBQUUsR0FBRUEsS0FBRyxHQUFFQTtBQUFJLE1BQUFELEVBQUVDLEtBQUc7QUFBRSxTQUFJQSxJQUFFLEdBQUVBLElBQUVGLEdBQUVFLEtBQUc7QUFBRSxNQUFBRCxFQUFFLEVBQUVDO0FBQU0sUUFBSUUsSUFBRU4sRUFBRTtBQUFVLFNBQUlMLElBQUUsR0FBRVEsRUFBRSxLQUFHLEdBQUVQLElBQUUsR0FBRUEsS0FBRyxHQUFFQTtBQUFJLE1BQUFELElBQUVBLElBQUVRLEVBQUVQLElBQUUsTUFBSSxHQUFFVSxFQUFFVixLQUFHRDtBQUFFLFNBQUlHLElBQUUsR0FBRUEsSUFBRUksR0FBRUosS0FBRztBQUFFLE9BQUlHLElBQUUsRUFBRUgsSUFBRSxPQUFWLE1BQWdCLEVBQUVBLEtBQUdRLEVBQUVMLElBQUdLLEVBQUVMO0FBQUEsRUFBSyxHQUFFSSxFQUFLLEVBQUUsWUFBVSxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLGFBQVFDLElBQUUsRUFBRSxRQUFPRSxJQUFFTyxFQUFLLEVBQUUsRUFBRSxPQUFNSixJQUFFLEdBQUVBLElBQUVMLEdBQUVLLEtBQUc7QUFBRSxVQUFNLEVBQUVBLElBQUUsTUFBUDtBQUFVLGlCQUFRRCxJQUFFQyxLQUFHLEdBQUVDLElBQUUsRUFBRUQsSUFBRSxJQUFHRSxJQUFFSCxLQUFHLElBQUVFLEdBQUVFLElBQUUsSUFBRUYsR0FBRUksSUFBRSxFQUFFTCxNQUFJRyxHQUFFRyxJQUFFRCxLQUFHLEtBQUdGLElBQUdFLEtBQUdDO0FBQUksVUFBQVosRUFBRUcsRUFBRVEsT0FBSyxLQUFHLEtBQUdILEdBQUVHO0FBQUEsRUFBSSxHQUFFRCxFQUFLLEVBQUUsV0FBUyxTQUFTLEdBQUUsR0FBRTtBQUFDLGFBQVFWLElBQUVVLEVBQUssRUFBRSxFQUFFLE9BQU1ULElBQUUsS0FBRyxHQUFFRSxJQUFFLEdBQUVBLElBQUUsRUFBRSxRQUFPQSxLQUFHLEdBQUU7QUFBQyxVQUFJRyxJQUFFLEVBQUVILE1BQUksSUFBRSxFQUFFQSxJQUFFO0FBQUcsUUFBRUEsS0FBR0gsRUFBRU0sT0FBS0w7QUFBQSxJQUFDO0FBQUEsRUFBQyxHQUFFUyxFQUFLLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLElBQUFBLE1BQUksSUFBRTtBQUFFLFFBQUlDLElBQUUsTUFBSTtBQUFFLE1BQUVBLE1BQUlELEdBQUUsRUFBRUMsSUFBRSxNQUFJRCxNQUFJO0FBQUEsRUFBQyxHQUFFVSxFQUFLLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLElBQUFBLE1BQUksSUFBRTtBQUFFLFFBQUlDLElBQUUsTUFBSTtBQUFFLE1BQUVBLE1BQUlELEdBQUUsRUFBRUMsSUFBRSxNQUFJRCxNQUFJLEdBQUUsRUFBRUMsSUFBRSxNQUFJRCxNQUFJO0FBQUEsRUFBRSxHQUFFVSxFQUFLLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLFlBQU8sRUFBRSxNQUFJLEtBQUcsRUFBRSxLQUFHLE1BQUksT0FBSyxRQUFNLElBQUUsTUFBSSxLQUFHQSxLQUFHO0FBQUEsRUFBQyxHQUFFVSxFQUFLLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRVYsR0FBRTtBQUFDLFlBQU8sRUFBRSxNQUFJLEtBQUcsRUFBRSxLQUFHLE1BQUksT0FBSyxJQUFFLEVBQUUsS0FBRyxNQUFJLE9BQUssU0FBTyxJQUFFLE1BQUksS0FBR0EsS0FBRztBQUFBLEVBQUMsR0FBRVUsRUFBSyxFQUFFLFNBQU8sU0FBUyxHQUFFLEdBQUU7QUFBQyxZQUFPLEVBQUUsTUFBSSxLQUFHLEVBQUUsS0FBRyxNQUFJLE9BQUssSUFBRSxFQUFFLEtBQUcsTUFBSSxPQUFLLFNBQU8sSUFBRTtBQUFBLEVBQUUsR0FBRUEsRUFBSyxFQUFFLFNBQU8sU0FBUyxHQUFFLEdBQUU7QUFBQyxZQUFPLEVBQUUsTUFBSSxLQUFHLEVBQUUsS0FBRyxNQUFJLE9BQUssSUFBRSxFQUFFLEtBQUcsTUFBSSxPQUFLLEtBQUcsRUFBRSxLQUFHLE1BQUksT0FBSyxTQUFPLElBQUU7QUFBQSxFQUFFLEdBQUVBLEVBQUssRUFBRSxLQUFHVixJQUFFLGFBQVlDLElBQUUsYUFBWSxFQUFDLFdBQVUsSUFBSUQsRUFBRSxFQUFFLEdBQUUsVUFBUyxJQUFJQSxFQUFFLEVBQUUsR0FBRSxNQUFLLENBQUMsSUFBRyxJQUFHLElBQUcsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUcsR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLElBQUcsR0FBRSxJQUFHLEdBQUUsRUFBRSxHQUFFLEtBQUksQ0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsS0FBSSxLQUFJLEtBQUksS0FBSSxLQUFJLEtBQUksS0FBSSxLQUFJLEdBQUcsR0FBRSxLQUFJLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsTUFBSyxJQUFJQSxFQUFFLEVBQUUsR0FBRSxLQUFJLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLEtBQUksS0FBSSxLQUFJLEtBQUksS0FBSSxLQUFJLE1BQUssTUFBSyxNQUFLLE1BQUssTUFBSyxNQUFLLE1BQUssT0FBTSxPQUFNLE9BQU0sT0FBTSxLQUFLLEdBQUUsS0FBSSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLEdBQUUsQ0FBQyxHQUFFLE1BQUssSUFBSUMsRUFBRSxFQUFFLEdBQUUsT0FBTSxJQUFJRCxFQUFFLEdBQUcsR0FBRSxRQUFPLENBQUEsR0FBRyxPQUFNLElBQUlBLEVBQUUsRUFBRSxHQUFFLFFBQU8sQ0FBQSxHQUFHLE1BQUssSUFBSUEsRUFBRSxLQUFLLEdBQUUsT0FBTSxDQUFBLEdBQUcsT0FBTSxDQUFBLEdBQUcsTUFBSyxJQUFJQSxFQUFFLEtBQUssR0FBRSxPQUFNLENBQUUsR0FBQyxNQUFLLElBQUlBLEVBQUUsR0FBRyxHQUFFLE9BQU0sQ0FBRSxHQUFDLE9BQU0sSUFBSUEsRUFBRSxLQUFLLEdBQUUsTUFBSyxJQUFJQyxFQUFFLEdBQUcsR0FBRSxNQUFLLElBQUlBLEVBQUUsRUFBRSxHQUFFLE1BQUssSUFBSUEsRUFBRSxFQUFFLEdBQUUsTUFBSyxJQUFJQSxFQUFFLElBQUksR0FBRSxNQUFLLElBQUlELEVBQUUsS0FBSyxHQUFFLE1BQUssSUFBSUEsRUFBRSxLQUFLLEVBQUMsSUFBRyxXQUFVO0FBQUMsYUFBUSxJQUFFVSxFQUFLLEVBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRSxPQUFNLEtBQUk7QUFBQyxVQUFJVixJQUFFO0FBQUUsTUFBQUEsS0FBRyxjQUFZQSxLQUFHLGNBQVlBLEtBQUcsY0FBWUEsS0FBRyxhQUFXQSxPQUFLLEtBQUcsYUFBV0EsTUFBSSxRQUFNLEtBQUcsWUFBVUEsTUFBSSxRQUFNLEtBQUcsWUFBVUEsTUFBSSxRQUFNLEtBQUcsV0FBU0EsTUFBSSxHQUFFLEVBQUUsTUFBTSxNQUFJQSxNQUFJLEtBQUdBLEtBQUcsUUFBTTtBQUFBLElBQUU7QUFBQyxhQUFTc0MsRUFBTXZDLEdBQUVqQixHQUFFLEdBQUU7QUFBQyxhQUFRQSxPQUFIO0FBQVEsUUFBQWlCLEVBQUUsS0FBSyxHQUFFLENBQUM7QUFBQSxJQUFDO0FBQUMsU0FBSSxJQUFFLEdBQUUsSUFBRSxJQUFHO0FBQUksUUFBRSxLQUFLLEtBQUcsRUFBRSxJQUFJLE1BQUksSUFBRSxFQUFFLElBQUksSUFBRyxFQUFFLEtBQUssS0FBRyxFQUFFLElBQUksTUFBSSxJQUFFLEVBQUUsSUFBSTtBQUFHLElBQUF1QyxFQUFNLEVBQUUsUUFBTyxLQUFJLENBQUMsR0FBRUEsRUFBTSxFQUFFLFFBQU8sS0FBSSxDQUFDLEdBQUVBLEVBQU0sRUFBRSxRQUFPLElBQUcsQ0FBQyxHQUFFQSxFQUFNLEVBQUUsUUFBTyxHQUFFLENBQUMsR0FBRTVCLEVBQUssRUFBRSxVQUFVLEVBQUUsUUFBTyxDQUFDLEdBQUVBLEVBQUssRUFBRSxVQUFVLEVBQUUsUUFBTyxHQUFFLEVBQUUsS0FBSyxHQUFFQSxFQUFLLEVBQUUsU0FBUyxFQUFFLFFBQU8sQ0FBQyxHQUFFNEIsRUFBTSxFQUFFLFFBQU8sSUFBRyxDQUFDLEdBQUU1QixFQUFLLEVBQUUsVUFBVSxFQUFFLFFBQU8sQ0FBQyxHQUFFQSxFQUFLLEVBQUUsVUFBVSxFQUFFLFFBQU8sR0FBRSxFQUFFLEtBQUssR0FBRUEsRUFBSyxFQUFFLFNBQVMsRUFBRSxRQUFPLENBQUMsR0FBRTRCLEVBQU0sRUFBRSxPQUFNLElBQUcsQ0FBQyxHQUFFQSxFQUFNLEVBQUUsT0FBTSxLQUFJLENBQUMsR0FBRUEsRUFBTSxFQUFFLE9BQU0sSUFBRyxDQUFDLEdBQUVBLEVBQU0sRUFBRSxPQUFNLEtBQUksQ0FBQztBQUFBLEVBQUMsRUFBRztBQUFBLEdBQUc7QUFBQyxJQUFJNUIsS0FBS1osR0FBaUIsRUFBQyxXQUFVLE1BQUssU0FBUUMsR0FBQyxHQUFFLENBQUNBLEVBQUMsQ0FBQztBQUFFLE1BQU13QyxLQUFLLFdBQVU7QUFBQyxNQUFJeEMsSUFBRSxFQUFDLFNBQVNBLEdBQUVqQixHQUFFO0FBQUMsV0FBUWlCLEVBQUVqQixNQUFMO0FBQVMsTUFBQUE7QUFBSSxXQUFPQTtBQUFBLEVBQUMsR0FBRSxZQUFXLENBQUNpQixHQUFFakIsTUFBSWlCLEVBQUVqQixNQUFJLElBQUVpQixFQUFFakIsSUFBRSxJQUFHLFlBQVlpQixHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxJQUFBRCxFQUFFakIsS0FBR2tCLEtBQUcsSUFBRSxLQUFJRCxFQUFFakIsSUFBRSxLQUFHLE1BQUlrQjtBQUFBLEVBQUMsR0FBRSxVQUFTLENBQUNELEdBQUVqQixNQUFJLFdBQVNpQixFQUFFakIsTUFBSWlCLEVBQUVqQixJQUFFLE1BQUksS0FBR2lCLEVBQUVqQixJQUFFLE1BQUksSUFBRWlCLEVBQUVqQixJQUFFLEtBQUksVUFBVWlCLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLElBQUFELEVBQUVqQixLQUFHa0IsS0FBRyxLQUFHLEtBQUlELEVBQUVqQixJQUFFLEtBQUdrQixLQUFHLEtBQUcsS0FBSUQsRUFBRWpCLElBQUUsS0FBR2tCLEtBQUcsSUFBRSxLQUFJRCxFQUFFakIsSUFBRSxLQUFHLE1BQUlrQjtBQUFBLEVBQUMsR0FBRSxVQUFVRCxHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxRQUFJQyxJQUFFO0FBQUcsYUFBUUUsSUFBRSxHQUFFQSxJQUFFSCxHQUFFRztBQUFJLE1BQUFGLEtBQUcsT0FBTyxhQUFhRixFQUFFakIsSUFBRXFCLEVBQUU7QUFBRSxXQUFPRjtBQUFBLEVBQUMsR0FBRSxXQUFXRixHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxhQUFRQyxJQUFFLEdBQUVBLElBQUVELEVBQUUsUUFBT0M7QUFBSSxNQUFBRixFQUFFakIsSUFBRW1CLEtBQUdELEVBQUUsV0FBV0MsQ0FBQztBQUFBLEVBQUMsR0FBRSxVQUFVRixHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxVQUFNQyxJQUFFLENBQUE7QUFBRyxhQUFRRSxJQUFFLEdBQUVBLElBQUVILEdBQUVHO0FBQUksTUFBQUYsRUFBRSxLQUFLRixFQUFFakIsSUFBRXFCLEVBQUU7QUFBRSxXQUFPRjtBQUFBLEVBQUMsR0FBRSxLQUFJLENBQUFGLE1BQUdBLEVBQUUsU0FBTyxJQUFFLElBQUlBLE1BQUlBLEdBQUUsU0FBU2pCLEdBQUVrQixHQUFFQyxHQUFFO0FBQUMsUUFBSUUsR0FBRUcsSUFBRTtBQUFHLGFBQVFILElBQUUsR0FBRUEsSUFBRUYsR0FBRUU7QUFBSSxNQUFBRyxLQUFHLElBQUlQLEVBQUUsSUFBSWpCLEVBQUVrQixJQUFFRyxHQUFHLFNBQVMsRUFBRSxDQUFDO0FBQUksUUFBRztBQUFDLE1BQUFBLElBQUUsbUJBQW1CRyxDQUFDO0FBQUEsSUFBQyxRQUFDO0FBQVMsYUFBT1AsRUFBRSxVQUFVakIsR0FBRWtCLEdBQUVDLENBQUM7QUFBQSxJQUFDO0FBQUMsV0FBT0U7QUFBQSxFQUFDLEVBQUM7QUFBRSxXQUFTcUMsRUFBWTFELEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFO0FBQUMsVUFBTUcsSUFBRU4sSUFBRUMsR0FBRUksSUFBRW9DLEVBQVF0QyxDQUFDLEdBQUVJLElBQUUsS0FBSyxLQUFLUCxJQUFFSyxJQUFFLENBQUMsR0FBRUcsSUFBRSxJQUFJLFdBQVcsSUFBRUYsQ0FBQyxHQUFFRyxJQUFFLElBQUksWUFBWUQsRUFBRSxNQUFNLEdBQUUsRUFBQyxPQUFNRyxFQUFDLElBQUVSLEdBQUUsRUFBQyxPQUFNUyxFQUFDLElBQUVULEdBQUVVLElBQUVkLEVBQUU7QUFBVyxRQUFNWSxLQUFILEdBQUs7QUFBQyxZQUFNWixJQUFFTyxLQUFHO0FBQUUsVUFBTU0sS0FBSDtBQUFLLGlCQUFRRSxJQUFFLEdBQUVBLElBQUVmLEdBQUVlLEtBQUc7QUFBRSxVQUFBTixFQUFFTSxLQUFHaEMsRUFBRWdDLElBQUdOLEVBQUVNLElBQUUsS0FBR2hDLEVBQUVnQyxJQUFFLElBQUdOLEVBQUVNLElBQUUsS0FBR2hDLEVBQUVnQyxJQUFFLElBQUdOLEVBQUVNLElBQUUsS0FBR2hDLEVBQUVnQyxJQUFFO0FBQUcsVUFBT0YsS0FBSjtBQUFNLGFBQUlFLElBQUUsR0FBRUEsSUFBRWYsR0FBRWU7QUFBSSxVQUFBTixFQUFFTSxLQUFHaEMsRUFBRWdDLEtBQUc7QUFBQSxJQUFFLFdBQVlILEtBQUgsR0FBSztBQUFDLFlBQU1aLElBQUVJLEVBQUUsS0FBSztBQUFLLFVBQVNKLEtBQU4sTUFBUTtBQUFDLFlBQU1hLEtBQUg7QUFBSyxlQUFJRSxJQUFFLEdBQUVBLElBQUVSLEdBQUVRLEtBQUk7QUFBQyxnQkFBSUMsSUFBRSxJQUFFRDtBQUFFLFlBQUFMLEVBQUVLLEtBQUcsT0FBSyxLQUFHaEMsRUFBRWlDLElBQUUsTUFBSSxLQUFHakMsRUFBRWlDLElBQUUsTUFBSSxJQUFFakMsRUFBRWlDO0FBQUEsVUFBRTtBQUFDLFlBQU9ILEtBQUo7QUFBTSxlQUFJRSxJQUFFLEdBQUVBLElBQUVSLEdBQUVRO0FBQUssWUFBQUMsSUFBRSxJQUFFRCxHQUFFTCxFQUFFSyxLQUFHLE9BQUssS0FBR2hDLEVBQUVpQyxJQUFFLE1BQUksS0FBR2pDLEVBQUVpQyxJQUFFLE1BQUksSUFBRWpDLEVBQUVpQztBQUFBLE1BQUcsT0FBSztBQUFDLFlBQUlDLElBQUVqQixFQUFFO0FBQUcsY0FBTUMsSUFBRUQsRUFBRSxJQUFHRSxJQUFFRixFQUFFO0FBQUcsWUFBTWEsS0FBSDtBQUFLLGVBQUlFLElBQUUsR0FBRUEsSUFBRVIsR0FBRVEsS0FBSTtBQUFDLGdCQUFJRyxJQUFFSCxLQUFHO0FBQUUsWUFBQUMsSUFBRSxJQUFFRCxHQUFFTCxFQUFFSyxLQUFHLE9BQUssS0FBR2hDLEVBQUVpQyxJQUFFLE1BQUksS0FBR2pDLEVBQUVpQyxJQUFFLE1BQUksSUFBRWpDLEVBQUVpQyxJQUFHakMsRUFBRWlDLE1BQUlDLEtBQUdsQyxFQUFFaUMsSUFBRSxNQUFJZixLQUFHbEIsRUFBRWlDLElBQUUsTUFBSWQsTUFBSU8sRUFBRVMsSUFBRSxLQUFHO0FBQUEsVUFBRTtBQUFDLFlBQU9MLEtBQUo7QUFBTSxlQUFJRSxJQUFFLEdBQUVBLElBQUVSLEdBQUVRO0FBQUssWUFBQUcsSUFBRUgsS0FBRyxHQUFFQyxJQUFFLElBQUVELEdBQUVMLEVBQUVLLEtBQUcsT0FBSyxLQUFHaEMsRUFBRWlDLElBQUUsTUFBSSxLQUFHakMsRUFBRWlDLElBQUUsTUFBSSxJQUFFakMsRUFBRWlDLElBQUdGLEVBQUUvQixHQUFFaUMsQ0FBQyxLQUFHQyxLQUFHSCxFQUFFL0IsR0FBRWlDLElBQUUsQ0FBQyxLQUFHZixLQUFHYSxFQUFFL0IsR0FBRWlDLElBQUUsQ0FBQyxLQUFHZCxNQUFJTyxFQUFFUyxJQUFFLEtBQUc7QUFBQSxNQUFHO0FBQUEsSUFBQyxXQUFZTixLQUFILEdBQUs7QUFBQyxZQUFNWixJQUFFSSxFQUFFLEtBQUssTUFBS0UsSUFBRUYsRUFBRSxLQUFLLE1BQUtNLElBQUVKLElBQUVBLEVBQUUsU0FBTztBQUFFLFVBQU1PLEtBQUg7QUFBSyxpQkFBUSxJQUFFLEdBQUUsSUFBRVgsR0FBRSxLQUFJO0FBQUMsY0FBSXlDLElBQUUsSUFBRW5DLEdBQUVhLElBQUUsSUFBRXBCO0FBQUUsZUFBSWMsSUFBRSxHQUFFQSxJQUFFZCxHQUFFYyxLQUFJO0FBQUMsWUFBQUcsSUFBRUcsSUFBRU4sS0FBRztBQUFFLGdCQUFJTyxJQUFFLEtBQUdDLElBQUV4QyxFQUFFNEQsS0FBRzVCLEtBQUcsT0FBSyxNQUFJLElBQUVBLE1BQUksS0FBRztBQUFHLFlBQUFOLEVBQUVTLEtBQUdsQixFQUFFc0IsSUFBR2IsRUFBRVMsSUFBRSxLQUFHbEIsRUFBRXNCLElBQUUsSUFBR2IsRUFBRVMsSUFBRSxLQUFHbEIsRUFBRXNCLElBQUUsSUFBR2IsRUFBRVMsSUFBRSxLQUFHSyxJQUFFYixJQUFFSixFQUFFaUIsS0FBRztBQUFBLFVBQUc7QUFBQSxRQUFDO0FBQUMsVUFBTVYsS0FBSDtBQUFLLGFBQUksSUFBRSxHQUFFLElBQUVYLEdBQUU7QUFBSSxlQUFJeUMsSUFBRSxJQUFFbkMsR0FBRWEsSUFBRSxJQUFFcEIsR0FBRWMsSUFBRSxHQUFFQSxJQUFFZCxHQUFFYztBQUFLLFlBQUFHLElBQUVHLElBQUVOLEtBQUcsR0FBRU8sSUFBRSxLQUFHQyxJQUFFeEMsRUFBRTRELEtBQUc1QixLQUFHLE9BQUssTUFBSSxJQUFFQSxNQUFJLEtBQUcsSUFBR04sRUFBRVMsS0FBR2xCLEVBQUVzQixJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdLLElBQUViLElBQUVKLEVBQUVpQixLQUFHO0FBQUksVUFBTVYsS0FBSDtBQUFLLGFBQUksSUFBRSxHQUFFLElBQUVYLEdBQUU7QUFBSSxlQUFJeUMsSUFBRSxJQUFFbkMsR0FBRWEsSUFBRSxJQUFFcEIsR0FBRWMsSUFBRSxHQUFFQSxJQUFFZCxHQUFFYztBQUFLLFlBQUFHLElBQUVHLElBQUVOLEtBQUcsR0FBRU8sSUFBRSxLQUFHQyxJQUFFeEMsRUFBRTRELEtBQUc1QixLQUFHLE9BQUssTUFBSSxJQUFFQSxNQUFJLEtBQUcsS0FBSU4sRUFBRVMsS0FBR2xCLEVBQUVzQixJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdLLElBQUViLElBQUVKLEVBQUVpQixLQUFHO0FBQUksVUFBTVYsS0FBSDtBQUFLLGFBQUlFLElBQUUsR0FBRUEsSUFBRVIsR0FBRVEsS0FBSTtBQUFDLGNBQUlRO0FBQUUsVUFBQUwsSUFBRUgsS0FBRyxHQUFFTyxJQUFFLEtBQUdDLElBQUV4QyxFQUFFZ0MsS0FBSU4sRUFBRVMsS0FBR2xCLEVBQUVzQixJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdsQixFQUFFc0IsSUFBRSxJQUFHYixFQUFFUyxJQUFFLEtBQUdLLElBQUViLElBQUVKLEVBQUVpQixLQUFHO0FBQUEsUUFBRztBQUFBLElBQUMsV0FBWVgsS0FBSCxHQUFLO0FBQUMsVUFBTUMsS0FBSDtBQUFLLGFBQUlFLElBQUUsR0FBRUEsSUFBRVIsR0FBRVEsS0FBSTtBQUFDLFVBQUFHLElBQUVILEtBQUc7QUFBRSxjQUFJUyxJQUFFekMsRUFBRW9DLElBQUVKLEtBQUc7QUFBRyxVQUFBTixFQUFFUyxLQUFHTSxHQUFFZixFQUFFUyxJQUFFLEtBQUdNLEdBQUVmLEVBQUVTLElBQUUsS0FBR00sR0FBRWYsRUFBRVMsSUFBRSxLQUFHbkMsRUFBRW9DLElBQUU7QUFBQSxRQUFFO0FBQUMsVUFBT04sS0FBSjtBQUFNLGFBQUlFLElBQUUsR0FBRUEsSUFBRVIsR0FBRVEsS0FBSTtBQUFDLGNBQUlJO0FBQUUsVUFBQUQsSUFBRUgsS0FBRyxHQUFFUyxJQUFFekMsRUFBRW9DLElBQUVKLEtBQUcsSUFBR04sRUFBRVMsS0FBR00sR0FBRWYsRUFBRVMsSUFBRSxLQUFHTSxHQUFFZixFQUFFUyxJQUFFLEtBQUdNLEdBQUVmLEVBQUVTLElBQUUsS0FBR25DLEVBQUVvQyxJQUFFO0FBQUEsUUFBRTtBQUFBLElBQUMsV0FBWVAsS0FBSDtBQUFLLFdBQUlLLElBQUViLEVBQUUsS0FBSyxPQUFLQSxFQUFFLEtBQUssT0FBSyxJQUFHLElBQUUsR0FBRSxJQUFFRixHQUFFLEtBQUk7QUFBQyxjQUFNRixJQUFFLElBQUVRLEdBQUVOLElBQUUsSUFBRUQ7QUFBRSxZQUFNWSxLQUFIO0FBQUssbUJBQVFZLElBQUUsR0FBRUEsSUFBRXhCLEdBQUV3QixLQUFJO0FBQUMsZ0JBQUlDLEtBQUdGLElBQUUsT0FBS3pDLEVBQUVpQixLQUFHeUIsTUFBSSxRQUFNLEtBQUcsSUFBRUEsS0FBRyxPQUFLLE1BQUlSLElBQUUsSUFBRTtBQUFJLFlBQUFQLEVBQUVSLElBQUV1QixLQUFHQyxLQUFHLEtBQUdGLEtBQUcsS0FBR0EsS0FBRyxJQUFFQTtBQUFBLFVBQUM7QUFBQSxpQkFBWVgsS0FBSDtBQUFLLGVBQUlZLElBQUUsR0FBRUEsSUFBRXhCLEdBQUV3QjtBQUFLLFlBQUFDLEtBQUdGLElBQUUsTUFBSXpDLEVBQUVpQixLQUFHeUIsTUFBSSxRQUFNLE1BQUksSUFBRUEsTUFBSSxLQUFHLE9BQUssS0FBR1IsSUFBRSxJQUFFLEtBQUlQLEVBQUVSLElBQUV1QixLQUFHQyxLQUFHLEtBQUdGLEtBQUcsS0FBR0EsS0FBRyxJQUFFQTtBQUFBLGlCQUFhWCxLQUFIO0FBQUssZUFBSVksSUFBRSxHQUFFQSxJQUFFeEIsR0FBRXdCO0FBQUssWUFBQUMsS0FBR0YsSUFBRSxNQUFJekMsRUFBRWlCLEtBQUd5QixNQUFJLFFBQU0sTUFBSSxJQUFFQSxNQUFJLEtBQUcsUUFBTSxLQUFHUixJQUFFLElBQUUsS0FBSVAsRUFBRVIsSUFBRXVCLEtBQUdDLEtBQUcsS0FBR0YsS0FBRyxLQUFHQSxLQUFHLElBQUVBO0FBQUEsaUJBQWFYLEtBQUg7QUFBSyxlQUFJWSxJQUFFLEdBQUVBLElBQUV4QixHQUFFd0I7QUFBSyxZQUFBQyxLQUFHRixJQUFFekMsRUFBRWlCLElBQUV5QixPQUFLUixJQUFFLElBQUUsS0FBSVAsRUFBRVIsSUFBRXVCLEtBQUdDLEtBQUcsS0FBR0YsS0FBRyxLQUFHQSxLQUFHLElBQUVBO0FBQUEsaUJBQWNYLEtBQUo7QUFBTSxlQUFJWSxJQUFFLEdBQUVBLElBQUV4QixHQUFFd0I7QUFBSyxZQUFBRCxJQUFFekMsRUFBRWlCLEtBQUd5QixLQUFHLEtBQUlDLElBQUVaLEVBQUUvQixHQUFFaUIsS0FBR3lCLEtBQUcsRUFBRSxLQUFHUixJQUFFLElBQUUsS0FBSVAsRUFBRVIsSUFBRXVCLEtBQUdDLEtBQUcsS0FBR0YsS0FBRyxLQUFHQSxLQUFHLElBQUVBO0FBQUEsTUFBRTtBQUFDLFdBQU9mO0FBQUEsRUFBQztBQUFDLFdBQVNtQyxFQUFZNUMsR0FBRUMsR0FBRUMsR0FBRUUsR0FBRTtBQUFDLFVBQU1HLElBQUVtQyxFQUFRMUMsQ0FBQyxHQUFFTSxJQUFFLEtBQUssS0FBS0osSUFBRUssSUFBRSxDQUFDLEdBQUVDLElBQUUsSUFBSSxZQUFZRixJQUFFLElBQUVOLEVBQUUsYUFBV0ksQ0FBQztBQUFFLFdBQU9ILElBQUVELEVBQUUsS0FBSyxPQUFLakIsRUFBRWtCLEdBQUVPLENBQUMsSUFBRXFDLEVBQVM1QyxHQUFFTyxDQUFDLEdBQUtSLEVBQUUsYUFBTCxJQUFlQyxJQUFFNkMsRUFBWTdDLEdBQUVELEdBQUUsR0FBRUUsR0FBRUUsQ0FBQyxJQUFLSixFQUFFLGFBQUwsTUFBaUJDLElBQUUsU0FBd0JELEdBQUVqQixHQUFFO0FBQUMsWUFBTWtCLElBQUVsQixFQUFFLE9BQU1tQixJQUFFbkIsRUFBRSxRQUFPcUIsSUFBRXNDLEVBQVEzRCxDQUFDLEdBQUV3QixJQUFFSCxLQUFHLEdBQUVFLElBQUUsS0FBSyxLQUFLTCxJQUFFRyxJQUFFLENBQUMsR0FBRUksSUFBRSxJQUFJLFdBQVdOLElBQUVJLENBQUM7QUFBRSxVQUFJRyxJQUFFO0FBQUUsWUFBTUMsSUFBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsR0FBRUUsSUFBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsR0FBRUMsSUFBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsR0FBRUMsSUFBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUM7QUFBRSxVQUFJQyxJQUFFO0FBQUUsYUFBS0EsSUFBRSxLQUFHO0FBQUMsY0FBTUUsSUFBRUosRUFBRUUsSUFBR0csSUFBRUosRUFBRUM7QUFBRyxZQUFJSyxJQUFFLEdBQUV1QixJQUFFLEdBQUV0QixJQUFFWCxFQUFFSztBQUFHLGVBQUtNLElBQUVuQjtBQUFHLFVBQUFtQixLQUFHSixHQUFFMEI7QUFBSSxZQUFJckIsSUFBRVYsRUFBRUc7QUFBRyxlQUFLTyxJQUFFckI7QUFBRyxVQUFBcUIsS0FBR0osR0FBRUU7QUFBSSxjQUFNRyxJQUFFLEtBQUssS0FBS0gsSUFBRWhCLElBQUUsQ0FBQztBQUFFLFFBQUEwQyxFQUFZOUMsR0FBRWpCLEdBQUUwQixHQUFFVyxHQUFFdUIsQ0FBQztBQUFFLFlBQUluQixJQUFFLEdBQUVMLElBQUVULEVBQUVLO0FBQUcsZUFBS0ksSUFBRWpCLEtBQUc7QUFBQyxjQUFJbkIsSUFBRTZCLEVBQUVHLElBQUdiLElBQUVPLElBQUVlLElBQUVELEtBQUc7QUFBRSxpQkFBS3hDLElBQUVrQixLQUFHO0FBQUMsZ0JBQUllO0FBQW1NLGdCQUEzTFosS0FBSCxNQUFLWSxLQUFHQSxJQUFFaEIsRUFBRUUsS0FBRyxPQUFLLEtBQUcsSUFBRUEsS0FBRyxHQUFFTSxFQUFFVyxJQUFFYixLQUFHdkIsS0FBRyxPQUFLaUMsS0FBRyxNQUFJLElBQUVqQyxNQUFJLEtBQVNxQixLQUFILE1BQUtZLEtBQUdBLElBQUVoQixFQUFFRSxLQUFHLE9BQUssS0FBRyxJQUFFQSxLQUFHLEdBQUVNLEVBQUVXLElBQUViLEtBQUd2QixLQUFHLE9BQUtpQyxLQUFHLE1BQUksSUFBRWpDLE1BQUksS0FBU3FCLEtBQUgsTUFBS1ksS0FBR0EsSUFBRWhCLEVBQUVFLEtBQUcsT0FBSyxLQUFHLElBQUVBLEtBQUcsSUFBR00sRUFBRVcsSUFBRWIsS0FBR3ZCLEtBQUcsT0FBS2lDLEtBQUcsTUFBSSxJQUFFakMsTUFBSSxLQUFNcUIsS0FBRyxHQUFFO0FBQUMsb0JBQU1ILElBQUVrQixJQUFFYixJQUFFdkIsSUFBRXdCO0FBQUUsdUJBQVF4QixJQUFFLEdBQUVBLElBQUV3QixHQUFFeEI7QUFBSSxnQkFBQXlCLEVBQUVQLElBQUVsQixLQUFHaUIsR0FBR0UsS0FBRyxLQUFHbkI7QUFBQSxZQUFFO0FBQUMsWUFBQW1CLEtBQUdFLEdBQUVyQixLQUFHbUM7QUFBQSxVQUFDO0FBQUMsVUFBQU0sS0FBSUwsS0FBR0Y7QUFBQSxRQUFDO0FBQUMsUUFBQUcsSUFBRXVCLEtBQUcsTUFBSWxDLEtBQUdrQyxLQUFHLElBQUVwQixLQUFJUixLQUFHO0FBQUEsTUFBQztBQUFDLGFBQU9QO0FBQUEsSUFBQyxFQUFFUCxHQUFFRCxDQUFDLElBQUdDO0FBQUEsRUFBQztBQUFDLFdBQVM0QyxFQUFTN0MsR0FBRUMsR0FBRTtBQUFDLFdBQU9sQixFQUFFLElBQUksV0FBV2lCLEVBQUUsUUFBTyxHQUFFQSxFQUFFLFNBQU8sQ0FBQyxHQUFFQyxDQUFDO0FBQUEsRUFBQztBQUFDLE1BQUlsQixJQUFFLFdBQVU7QUFBQyxVQUFNaUIsSUFBRSxFQUFDLEdBQUUsQ0FBQSxFQUFFO0FBQUUsV0FBT0EsRUFBRSxFQUFFLElBQUUsU0FBU2pCLEdBQUVrQixHQUFFO0FBQUMsWUFBTUMsSUFBRTtBQUFXLFVBQUlFLEdBQUVHLEdBQUVELElBQUUsR0FBRUUsSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUUsR0FBRUUsSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUUsR0FBRUMsSUFBRSxHQUFFQyxJQUFFO0FBQUUsVUFBTWpDLEVBQUUsTUFBTCxLQUFZQSxFQUFFLE1BQUw7QUFBUSxlQUFPa0IsS0FBRyxJQUFJQyxFQUFFLENBQUM7QUFBRSxZQUFNZSxJQUFFakIsRUFBRSxHQUFFa0IsSUFBRUQsRUFBRSxHQUFFRyxJQUFFSCxFQUFFLEdBQUUwQixJQUFFMUIsRUFBRSxHQUFFSSxJQUFFSixFQUFFLEdBQUVLLElBQUVMLEVBQUUsR0FBRU0sSUFBRU4sRUFBRSxHQUFFTyxJQUFFUCxFQUFFLEdBQUVFLElBQVFsQixLQUFOO0FBQVEsV0FBSWtCLE1BQUlsQixJQUFFLElBQUlDLEVBQUVuQixFQUFFLFdBQVMsS0FBRyxDQUFDLElBQU11QixLQUFIO0FBQU0sWUFBR0EsSUFBRVksRUFBRW5DLEdBQUVpQyxHQUFFLENBQUMsR0FBRVIsSUFBRVUsRUFBRW5DLEdBQUVpQyxJQUFFLEdBQUUsQ0FBQyxHQUFFQSxLQUFHLEdBQUtSLEtBQUgsR0FBSztBQUFDLGNBQUdXLE1BQUlsQixJQUFFRCxFQUFFLEVBQUUsRUFBRUMsR0FBRWMsS0FBRyxLQUFHLEdBQUcsSUFBTVAsS0FBSCxNQUFPSixJQUFFb0IsRUFBRSxHQUFFakIsSUFBRWlCLEVBQUUsR0FBRVgsSUFBRSxLQUFJQyxJQUFFLEtBQU9OLEtBQUgsR0FBSztBQUFDLFlBQUFDLElBQUVXLEVBQUVyQyxHQUFFaUMsR0FBRSxDQUFDLElBQUUsS0FBSU4sSUFBRVUsRUFBRXJDLEdBQUVpQyxJQUFFLEdBQUUsQ0FBQyxJQUFFLEdBQUVKLElBQUVRLEVBQUVyQyxHQUFFaUMsSUFBRSxJQUFHLENBQUMsSUFBRSxHQUFFQSxLQUFHO0FBQUcsZ0JBQUloQixJQUFFO0FBQUUscUJBQVF5QixJQUFFLEdBQUVBLElBQUUsSUFBR0EsS0FBRztBQUFFLGNBQUFELEVBQUUsRUFBRUMsS0FBRyxHQUFFRCxFQUFFLEVBQUVDLElBQUUsS0FBRztBQUFFLGlCQUFJQSxJQUFFLEdBQUVBLElBQUViLEdBQUVhLEtBQUk7QUFBQyxvQkFBTXhCLElBQUVtQixFQUFFckMsR0FBRWlDLElBQUUsSUFBRVMsR0FBRSxDQUFDO0FBQUUsY0FBQUQsRUFBRSxFQUFFLEtBQUdBLEVBQUUsRUFBRUMsTUFBSSxNQUFJeEIsR0FBRUEsSUFBRUQsTUFBSUEsSUFBRUM7QUFBQSxZQUFFO0FBQUMsWUFBQWUsS0FBRyxJQUFFSixHQUFFUyxFQUFFRyxFQUFFLEdBQUV4QixDQUFDLEdBQUVzQixFQUFFRSxFQUFFLEdBQUV4QixHQUFFd0IsRUFBRSxDQUFDLEdBQUVwQixJQUFFb0IsRUFBRSxHQUFFakIsSUFBRWlCLEVBQUUsR0FBRVIsSUFBRTJCLEVBQUVuQixFQUFFLElBQUcsS0FBR3hCLEtBQUcsR0FBRVMsSUFBRUMsR0FBRTNCLEdBQUVpQyxHQUFFUSxFQUFFLENBQUM7QUFBRSxrQkFBTXZCLElBQUVnQixFQUFFLEVBQUVPLEVBQUUsR0FBRSxHQUFFZixHQUFFZSxFQUFFLENBQUM7QUFBRSxZQUFBWCxLQUFHLEtBQUdaLEtBQUc7QUFBRSxrQkFBTUMsSUFBRWUsRUFBRSxFQUFFTyxFQUFFLEdBQUVmLEdBQUVDLEdBQUVjLEVBQUUsQ0FBQztBQUFFLFlBQUFWLEtBQUcsS0FBR1osS0FBRyxHQUFFbUIsRUFBRUcsRUFBRSxHQUFFdkIsQ0FBQyxHQUFFcUIsRUFBRUUsRUFBRSxHQUFFdkIsR0FBRUcsQ0FBQyxHQUFFaUIsRUFBRUcsRUFBRSxHQUFFdEIsQ0FBQyxHQUFFb0IsRUFBRUUsRUFBRSxHQUFFdEIsR0FBRUssQ0FBQztBQUFBLFVBQUM7QUFBQyxxQkFBTztBQUFDLGtCQUFNUCxJQUFFSSxFQUFFbUIsRUFBRXhDLEdBQUVpQyxDQUFDLElBQUVIO0FBQUcsWUFBQUcsS0FBRyxLQUFHaEI7QUFBRSxrQkFBTUUsSUFBRUYsTUFBSTtBQUFFLGdCQUFHRSxNQUFJLEtBQUc7QUFBRSxjQUFBRCxFQUFFYyxPQUFLYjtBQUFBLGlCQUFNO0FBQUMsa0JBQVFBLEtBQUw7QUFBTztBQUFNO0FBQUMsb0JBQUlGLElBQUVlLElBQUViLElBQUU7QUFBSSxvQkFBR0EsSUFBRSxLQUFJO0FBQUMsd0JBQU1ELElBQUV1QixFQUFFLEVBQUV0QixJQUFFO0FBQUssa0JBQUFGLElBQUVlLEtBQUdkLE1BQUksS0FBR21CLEVBQUVyQyxHQUFFaUMsR0FBRSxJQUFFZixDQUFDLEdBQUVlLEtBQUcsSUFBRWY7QUFBQSxnQkFBQztBQUFDLHNCQUFNRyxJQUFFRyxFQUFFZ0IsRUFBRXhDLEdBQUVpQyxDQUFDLElBQUVGO0FBQUcsZ0JBQUFFLEtBQUcsS0FBR1o7QUFBRSxzQkFBTUUsSUFBRUYsTUFBSSxHQUFFSSxJQUFFZ0IsRUFBRSxFQUFFbEIsSUFBR0csS0FBR0QsTUFBSSxLQUFHVSxFQUFFbkMsR0FBRWlDLEdBQUUsS0FBR1IsQ0FBQztBQUFFLHFCQUFJUSxLQUFHLEtBQUdSLEdBQUVPLElBQUVmO0FBQUcsa0JBQUFDLEVBQUVjLEtBQUdkLEVBQUVjLE1BQUlOLElBQUdSLEVBQUVjLEtBQUdkLEVBQUVjLE1BQUlOLElBQUdSLEVBQUVjLEtBQUdkLEVBQUVjLE1BQUlOLElBQUdSLEVBQUVjLEtBQUdkLEVBQUVjLE1BQUlOO0FBQUcsZ0JBQUFNLElBQUVmO0FBQUEsY0FBQztBQUFBLFlBQUM7QUFBQSxVQUFDO0FBQUEsUUFBQyxPQUFLO0FBQUMsV0FBSSxJQUFFZ0IsTUFBTixNQUFXQSxLQUFHLEtBQUcsSUFBRUE7QUFBSSxnQkFBTVosSUFBRSxLQUFHWSxNQUFJLElBQUdULElBQUV4QixFQUFFcUIsSUFBRSxLQUFHckIsRUFBRXFCLElBQUUsTUFBSTtBQUFFLFVBQUFlLE1BQUlsQixJQUFFRCxFQUFFLEVBQUUsRUFBRUMsR0FBRWMsSUFBRVIsQ0FBQyxJQUFHTixFQUFFLElBQUksSUFBSUMsRUFBRW5CLEVBQUUsUUFBT0EsRUFBRSxhQUFXcUIsR0FBRUcsQ0FBQyxHQUFFUSxDQUFDLEdBQUVDLElBQUVaLElBQUVHLEtBQUcsR0FBRVEsS0FBR1I7QUFBQSxRQUFDO0FBQUMsYUFBT04sRUFBRSxVQUFRYyxJQUFFZCxJQUFFQSxFQUFFLE1BQU0sR0FBRWMsQ0FBQztBQUFBLElBQUMsR0FBRWYsRUFBRSxFQUFFLElBQUUsU0FBU0EsR0FBRWpCLEdBQUU7QUFBQyxZQUFNa0IsSUFBRUQsRUFBRTtBQUFPLFVBQUdqQixLQUFHa0I7QUFBRSxlQUFPRDtBQUFFLFlBQU1FLElBQUUsSUFBSSxXQUFXRCxLQUFHLENBQUM7QUFBRSxhQUFPQyxFQUFFLElBQUlGLEdBQUUsQ0FBQyxHQUFFRTtBQUFBLElBQUMsR0FBRUYsRUFBRSxFQUFFLElBQUUsU0FBU2pCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFRyxHQUFFRCxHQUFFO0FBQUMsWUFBTUUsSUFBRVIsRUFBRSxFQUFFLEdBQUVTLElBQUVULEVBQUUsRUFBRTtBQUFFLFVBQUlVLElBQUU7QUFBRSxhQUFLQSxJQUFFUixLQUFHO0FBQUMsY0FBTUYsSUFBRWpCLEVBQUUwQixFQUFFTCxHQUFFRyxDQUFDLElBQUVOO0FBQUcsUUFBQU0sS0FBRyxLQUFHUDtBQUFFLGNBQU1FLElBQUVGLE1BQUk7QUFBRSxZQUFHRSxLQUFHO0FBQUcsVUFBQUksRUFBRUksS0FBR1IsR0FBRVE7QUFBQSxhQUFRO0FBQUMsY0FBSVYsSUFBRSxHQUFFakIsSUFBRTtBQUFFLFVBQUltQixLQUFKLE1BQU9uQixJQUFFLElBQUV5QixFQUFFSixHQUFFRyxHQUFFLENBQUMsR0FBRUEsS0FBRyxHQUFFUCxJQUFFTSxFQUFFSSxJQUFFLE1BQVFSLEtBQUosTUFBT25CLElBQUUsSUFBRXlCLEVBQUVKLEdBQUVHLEdBQUUsQ0FBQyxHQUFFQSxLQUFHLEtBQU9MLEtBQUosT0FBUW5CLElBQUUsS0FBR3lCLEVBQUVKLEdBQUVHLEdBQUUsQ0FBQyxHQUFFQSxLQUFHO0FBQUcsZ0JBQU1OLElBQUVTLElBQUUzQjtBQUFFLGlCQUFLMkIsSUFBRVQ7QUFBRyxZQUFBSyxFQUFFSSxLQUFHVixHQUFFVTtBQUFBLFFBQUc7QUFBQSxNQUFDO0FBQUMsYUFBT0g7QUFBQSxJQUFDLEdBQUVQLEVBQUUsRUFBRSxJQUFFLFNBQVNBLEdBQUVqQixHQUFFa0IsR0FBRUMsR0FBRTtBQUFDLFVBQUlFLElBQUUsR0FBRUcsSUFBRTtBQUFFLFlBQU1ELElBQUVKLEVBQUUsV0FBUztBQUFFLGFBQUtLLElBQUVOLEtBQUc7QUFBQyxjQUFNQSxJQUFFRCxFQUFFTyxJQUFFeEI7QUFBRyxRQUFBbUIsRUFBRUssS0FBRyxLQUFHLEdBQUVMLEVBQUUsS0FBR0ssS0FBRyxNQUFJTixHQUFFQSxJQUFFRyxNQUFJQSxJQUFFSCxJQUFHTTtBQUFBLE1BQUc7QUFBQyxhQUFLQSxJQUFFRDtBQUFHLFFBQUFKLEVBQUVLLEtBQUcsS0FBRyxHQUFFTCxFQUFFLEtBQUdLLEtBQUcsTUFBSSxHQUFFQTtBQUFJLGFBQU9IO0FBQUEsSUFBQyxHQUFFSixFQUFFLEVBQUUsSUFBRSxTQUFTakIsR0FBRWtCLEdBQUU7QUFBQyxZQUFNQyxJQUFFRixFQUFFLEVBQUUsR0FBRUksSUFBRXJCLEVBQUU7QUFBTyxVQUFJd0IsR0FBRUQsR0FBRUUsR0FBTUM7QUFBRSxZQUFNQyxJQUFFUixFQUFFO0FBQUUsZUFBUVUsSUFBRSxHQUFFQSxLQUFHWCxHQUFFVztBQUFJLFFBQUFGLEVBQUVFLEtBQUc7QUFBRSxXQUFJQSxJQUFFLEdBQUVBLElBQUVSLEdBQUVRLEtBQUc7QUFBRSxRQUFBRixFQUFFM0IsRUFBRTZCO0FBQU0sWUFBTUMsSUFBRVgsRUFBRTtBQUFFLFdBQUlLLElBQUUsR0FBRUcsRUFBRSxLQUFHLEdBQUVKLElBQUUsR0FBRUEsS0FBR0wsR0FBRUs7QUFBSSxRQUFBQyxJQUFFQSxJQUFFRyxFQUFFSixJQUFFLE1BQUksR0FBRU8sRUFBRVAsS0FBR0M7QUFBRSxXQUFJQyxJQUFFLEdBQUVBLElBQUVKLEdBQUVJLEtBQUc7QUFBRSxRQUFBQyxJQUFFMUIsRUFBRXlCLElBQUUsSUFBTUMsS0FBSCxNQUFPMUIsRUFBRXlCLEtBQUdLLEVBQUVKLElBQUdJLEVBQUVKO0FBQUEsSUFBSyxHQUFFVCxFQUFFLEVBQUUsSUFBRSxTQUFTakIsR0FBRWtCLEdBQUVDLEdBQUU7QUFBQyxZQUFNRSxJQUFFckIsRUFBRSxRQUFPd0IsSUFBRVAsRUFBRSxFQUFFLEVBQUU7QUFBRSxlQUFRQSxJQUFFLEdBQUVBLElBQUVJLEdBQUVKLEtBQUc7QUFBRSxZQUFNakIsRUFBRWlCLElBQUUsTUFBUCxHQUFVO0FBQUMsZ0JBQU1JLElBQUVKLEtBQUcsR0FBRU0sSUFBRXZCLEVBQUVpQixJQUFFLElBQUdRLElBQUVKLEtBQUcsSUFBRUUsR0FBRUcsSUFBRVIsSUFBRUs7QUFBRSxjQUFJSSxJQUFFM0IsRUFBRWlCLE1BQUlTO0FBQUUsZ0JBQU1HLElBQUVGLEtBQUcsS0FBR0Q7QUFBRyxpQkFBS0MsS0FBR0U7QUFBSSxZQUFBVixFQUFFSyxFQUFFRyxPQUFLLEtBQUdULEtBQUdPLEdBQUVFO0FBQUEsUUFBSTtBQUFBLElBQUMsR0FBRVYsRUFBRSxFQUFFLElBQUUsU0FBU2pCLEdBQUVrQixHQUFFO0FBQUMsWUFBTUMsSUFBRUYsRUFBRSxFQUFFLEVBQUUsR0FBRUksSUFBRSxLQUFHSDtBQUFFLGVBQVFELElBQUUsR0FBRUEsSUFBRWpCLEVBQUUsUUFBT2lCLEtBQUcsR0FBRTtBQUFDLGNBQU1PLElBQUV4QixFQUFFaUIsTUFBSUMsSUFBRWxCLEVBQUVpQixJQUFFO0FBQUcsUUFBQWpCLEVBQUVpQixLQUFHRSxFQUFFSyxPQUFLSDtBQUFBLE1BQUM7QUFBQSxJQUFDLEdBQUVKLEVBQUUsRUFBRSxJQUFFLFNBQVNBLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLE1BQUFBLE1BQUksSUFBRWxCO0FBQUUsWUFBTW1CLElBQUVuQixNQUFJO0FBQUUsTUFBQWlCLEVBQUVFLE1BQUlELEdBQUVELEVBQUVFLElBQUUsTUFBSUQsTUFBSTtBQUFBLElBQUMsR0FBRUQsRUFBRSxFQUFFLElBQUUsU0FBU0EsR0FBRWpCLEdBQUVrQixHQUFFO0FBQUMsTUFBQUEsTUFBSSxJQUFFbEI7QUFBRSxZQUFNbUIsSUFBRW5CLE1BQUk7QUFBRSxNQUFBaUIsRUFBRUUsTUFBSUQsR0FBRUQsRUFBRUUsSUFBRSxNQUFJRCxNQUFJLEdBQUVELEVBQUVFLElBQUUsTUFBSUQsTUFBSTtBQUFBLElBQUUsR0FBRUQsRUFBRSxFQUFFLElBQUUsU0FBU0EsR0FBRWpCLEdBQUVrQixHQUFFO0FBQUMsY0FBT0QsRUFBRWpCLE1BQUksS0FBR2lCLEVBQUUsS0FBR2pCLE1BQUksT0FBSyxRQUFNLElBQUVBLE1BQUksS0FBR2tCLEtBQUc7QUFBQSxJQUFDLEdBQUVELEVBQUUsRUFBRSxJQUFFLFNBQVNBLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLGNBQU9ELEVBQUVqQixNQUFJLEtBQUdpQixFQUFFLEtBQUdqQixNQUFJLE9BQUssSUFBRWlCLEVBQUUsS0FBR2pCLE1BQUksT0FBSyxTQUFPLElBQUVBLE1BQUksS0FBR2tCLEtBQUc7QUFBQSxJQUFDLEdBQUVELEVBQUUsRUFBRSxJQUFFLFNBQVNBLEdBQUVqQixHQUFFO0FBQUMsY0FBT2lCLEVBQUVqQixNQUFJLEtBQUdpQixFQUFFLEtBQUdqQixNQUFJLE9BQUssSUFBRWlCLEVBQUUsS0FBR2pCLE1BQUksT0FBSyxTQUFPLElBQUVBO0FBQUEsSUFBRSxHQUFFaUIsRUFBRSxFQUFFLElBQUUsU0FBU0EsR0FBRWpCLEdBQUU7QUFBQyxjQUFPaUIsRUFBRWpCLE1BQUksS0FBR2lCLEVBQUUsS0FBR2pCLE1BQUksT0FBSyxJQUFFaUIsRUFBRSxLQUFHakIsTUFBSSxPQUFLLEtBQUdpQixFQUFFLEtBQUdqQixNQUFJLE9BQUssU0FBTyxJQUFFQTtBQUFBLElBQUUsR0FBRWlCLEVBQUUsRUFBRSxJQUFFLFdBQVU7QUFBQyxZQUFNQSxJQUFFLGFBQVlqQixJQUFFO0FBQVksYUFBTSxFQUFDLEdBQUUsSUFBSWlCLEVBQUUsRUFBRSxHQUFFLEdBQUUsSUFBSUEsRUFBRSxFQUFFLEdBQUUsR0FBRSxDQUFDLElBQUcsSUFBRyxJQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLElBQUcsR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLEVBQUUsR0FBRSxHQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLEtBQUksS0FBSSxLQUFJLEtBQUksS0FBSSxLQUFJLEtBQUksS0FBSSxHQUFHLEdBQUUsR0FBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLEdBQUUsSUFBSUEsRUFBRSxFQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxLQUFJLEtBQUksS0FBSSxLQUFJLEtBQUksS0FBSSxNQUFLLE1BQUssTUFBSyxNQUFLLE1BQUssTUFBSyxNQUFLLE9BQU0sT0FBTSxPQUFNLE9BQU0sS0FBSyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxHQUFFLENBQUMsR0FBRSxHQUFFLElBQUlqQixFQUFFLEVBQUUsR0FBRSxHQUFFLElBQUlpQixFQUFFLEdBQUcsR0FBRSxHQUFFLENBQUEsR0FBRyxHQUFFLElBQUlBLEVBQUUsRUFBRSxHQUFFLEdBQUUsQ0FBQSxHQUFHLEdBQUUsSUFBSUEsRUFBRSxLQUFLLEdBQUUsR0FBRSxDQUFFLEdBQUMsR0FBRSxDQUFFLEdBQUMsR0FBRSxJQUFJQSxFQUFFLEtBQUssR0FBRSxHQUFFLENBQUUsR0FBQyxHQUFFLElBQUlBLEVBQUUsR0FBRyxHQUFFLEdBQUUsQ0FBQSxHQUFHLEdBQUUsSUFBSUEsRUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFJakIsRUFBRSxHQUFHLEdBQUUsR0FBRSxJQUFJQSxFQUFFLEVBQUUsR0FBRSxHQUFFLElBQUlBLEVBQUUsRUFBRSxHQUFFLEdBQUUsSUFBSUEsRUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFJaUIsRUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFJQSxFQUFFLEtBQUssRUFBQztBQUFBLElBQUMsRUFBRyxHQUFDLFdBQVU7QUFBQyxZQUFNakIsSUFBRWlCLEVBQUUsRUFBRTtBQUFFLGVBQVFDLElBQUUsR0FBRUEsSUFBRSxPQUFNQSxLQUFJO0FBQUMsWUFBSUQsSUFBRUM7QUFBRSxRQUFBRCxLQUFHLGFBQVdBLE9BQUssS0FBRyxhQUFXQSxNQUFJLEdBQUVBLEtBQUcsYUFBV0EsT0FBSyxLQUFHLFlBQVVBLE1BQUksR0FBRUEsS0FBRyxhQUFXQSxPQUFLLEtBQUcsWUFBVUEsTUFBSSxHQUFFQSxLQUFHLGFBQVdBLE9BQUssS0FBRyxXQUFTQSxNQUFJLEdBQUVqQixFQUFFLEVBQUVrQixNQUFJRCxNQUFJLEtBQUdBLEtBQUcsUUFBTTtBQUFBLE1BQUU7QUFBQyxlQUFTK0MsRUFBRS9DLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLGVBQVFsQixPQUFIO0FBQVEsVUFBQWlCLEVBQUUsS0FBSyxHQUFFQyxDQUFDO0FBQUEsTUFBQztBQUFDLFdBQUlBLElBQUUsR0FBRUEsSUFBRSxJQUFHQTtBQUFJLFFBQUFsQixFQUFFLEVBQUVrQixLQUFHbEIsRUFBRSxFQUFFa0IsTUFBSSxJQUFFbEIsRUFBRSxFQUFFa0IsSUFBR2xCLEVBQUUsRUFBRWtCLEtBQUdsQixFQUFFLEVBQUVrQixNQUFJLElBQUVsQixFQUFFLEVBQUVrQjtBQUFHLE1BQUE4QyxFQUFFaEUsRUFBRSxHQUFFLEtBQUksQ0FBQyxHQUFFZ0UsRUFBRWhFLEVBQUUsR0FBRSxLQUFJLENBQUMsR0FBRWdFLEVBQUVoRSxFQUFFLEdBQUUsSUFBRyxDQUFDLEdBQUVnRSxFQUFFaEUsRUFBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFaUIsRUFBRSxFQUFFLEVBQUVqQixFQUFFLEdBQUUsQ0FBQyxHQUFFaUIsRUFBRSxFQUFFLEVBQUVqQixFQUFFLEdBQUUsR0FBRUEsRUFBRSxDQUFDLEdBQUVpQixFQUFFLEVBQUUsRUFBRWpCLEVBQUUsR0FBRSxDQUFDLEdBQUVnRSxFQUFFaEUsRUFBRSxHQUFFLElBQUcsQ0FBQyxHQUFFaUIsRUFBRSxFQUFFLEVBQUVqQixFQUFFLEdBQUUsQ0FBQyxHQUFFaUIsRUFBRSxFQUFFLEVBQUVqQixFQUFFLEdBQUUsR0FBRUEsRUFBRSxDQUFDLEdBQUVpQixFQUFFLEVBQUUsRUFBRWpCLEVBQUUsR0FBRSxDQUFDLEdBQUVnRSxFQUFFaEUsRUFBRSxHQUFFLElBQUcsQ0FBQyxHQUFFZ0UsRUFBRWhFLEVBQUUsR0FBRSxLQUFJLENBQUMsR0FBRWdFLEVBQUVoRSxFQUFFLEdBQUUsSUFBRyxDQUFDLEdBQUVnRSxFQUFFaEUsRUFBRSxHQUFFLEtBQUksQ0FBQztBQUFBLElBQUMsRUFBQyxHQUFHaUIsRUFBRSxFQUFFO0FBQUEsRUFBQyxFQUFDO0FBQUcsV0FBUzBDLEVBQVExQyxHQUFFO0FBQUMsV0FBTSxDQUFDLEdBQUUsTUFBSyxHQUFFLEdBQUUsR0FBRSxNQUFLLENBQUMsRUFBRUEsRUFBRSxTQUFPQSxFQUFFO0FBQUEsRUFBSztBQUFDLFdBQVM4QyxFQUFZOUMsR0FBRWpCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFO0FBQUMsUUFBSUcsSUFBRW1DLEVBQVEzRCxDQUFDO0FBQUUsVUFBTXVCLElBQUUsS0FBSyxLQUFLSixJQUFFSyxJQUFFLENBQUM7QUFBRSxRQUFJQyxHQUFFQztBQUFFLElBQUFGLElBQUUsS0FBSyxLQUFLQSxJQUFFLENBQUM7QUFBRSxRQUFJRyxJQUFFVixFQUFFQyxJQUFHVyxJQUFFO0FBQUUsUUFBR0YsSUFBRSxNQUFJVixFQUFFQyxLQUFHLENBQUMsR0FBRSxHQUFFLENBQUMsRUFBRVMsSUFBRSxLQUFPQSxLQUFIO0FBQUssV0FBSUUsSUFBRUwsR0FBRUssSUFBRU4sR0FBRU07QUFBSSxRQUFBWixFQUFFWSxJQUFFLEtBQUdaLEVBQUVZLElBQUUsTUFBSVosRUFBRVksSUFBRSxJQUFFTCxPQUFLLEtBQUc7QUFBSSxhQUFReEIsSUFBRSxHQUFFQSxJQUFFcUIsR0FBRXJCO0FBQUksVUFBR3lCLElBQUVQLElBQUVsQixJQUFFdUIsR0FBRUcsSUFBRUQsSUFBRXpCLElBQUUsR0FBRTJCLElBQUVWLEVBQUVTLElBQUUsSUFBR0csSUFBRSxHQUFLRixLQUFIO0FBQUssZUFBS0UsSUFBRU4sR0FBRU07QUFBSSxVQUFBWixFQUFFUSxJQUFFSSxLQUFHWixFQUFFUyxJQUFFRztBQUFBLGVBQWNGLEtBQUgsR0FBSztBQUFDLGVBQUtFLElBQUVMLEdBQUVLO0FBQUksVUFBQVosRUFBRVEsSUFBRUksS0FBR1osRUFBRVMsSUFBRUc7QUFBRyxlQUFLQSxJQUFFTixHQUFFTTtBQUFJLFVBQUFaLEVBQUVRLElBQUVJLEtBQUdaLEVBQUVTLElBQUVHLEtBQUdaLEVBQUVRLElBQUVJLElBQUVMO0FBQUEsTUFBRSxXQUFZRyxLQUFIO0FBQUssZUFBS0UsSUFBRU4sR0FBRU07QUFBSSxVQUFBWixFQUFFUSxJQUFFSSxLQUFHWixFQUFFUyxJQUFFRyxLQUFHWixFQUFFUSxJQUFFSSxJQUFFTjtBQUFBLGVBQWNJLEtBQUgsR0FBSztBQUFDLGVBQUtFLElBQUVMLEdBQUVLO0FBQUksVUFBQVosRUFBRVEsSUFBRUksS0FBR1osRUFBRVMsSUFBRUcsTUFBSVosRUFBRVEsSUFBRUksSUFBRU4sT0FBSztBQUFHLGVBQUtNLElBQUVOLEdBQUVNO0FBQUksVUFBQVosRUFBRVEsSUFBRUksS0FBR1osRUFBRVMsSUFBRUcsTUFBSVosRUFBRVEsSUFBRUksSUFBRU4sS0FBR04sRUFBRVEsSUFBRUksSUFBRUwsT0FBSztBQUFBLE1BQUUsT0FBSztBQUFDLGVBQUtLLElBQUVMLEdBQUVLO0FBQUksVUFBQVosRUFBRVEsSUFBRUksS0FBR1osRUFBRVMsSUFBRUcsS0FBR29DLEVBQU8sR0FBRWhELEVBQUVRLElBQUVJLElBQUVOLElBQUcsQ0FBQztBQUFFLGVBQUtNLElBQUVOLEdBQUVNO0FBQUksVUFBQVosRUFBRVEsSUFBRUksS0FBR1osRUFBRVMsSUFBRUcsS0FBR29DLEVBQU9oRCxFQUFFUSxJQUFFSSxJQUFFTCxJQUFHUCxFQUFFUSxJQUFFSSxJQUFFTixJQUFHTixFQUFFUSxJQUFFSSxJQUFFTCxJQUFFRCxFQUFFO0FBQUEsTUFBQztBQUFDLFdBQU9OO0FBQUEsRUFBQztBQUFDLFdBQVNnRCxFQUFPaEQsR0FBRWpCLEdBQUVrQixHQUFFO0FBQUMsVUFBTUMsSUFBRUYsSUFBRWpCLElBQUVrQixHQUFFRyxJQUFFRixJQUFFRixHQUFFTyxJQUFFTCxJQUFFbkIsR0FBRXVCLElBQUVKLElBQUVEO0FBQUUsV0FBT0csSUFBRUEsS0FBR0csSUFBRUEsS0FBR0gsSUFBRUEsS0FBR0UsSUFBRUEsSUFBRU4sSUFBRU8sSUFBRUEsS0FBR0QsSUFBRUEsSUFBRXZCLElBQUVrQjtBQUFBLEVBQUM7QUFBQyxXQUFTZ0QsRUFBTWxFLEdBQUVrQixHQUFFQyxHQUFFO0FBQUMsSUFBQUEsRUFBRSxRQUFNRixFQUFFLFNBQVNqQixHQUFFa0IsQ0FBQyxHQUFFQSxLQUFHLEdBQUVDLEVBQUUsU0FBT0YsRUFBRSxTQUFTakIsR0FBRWtCLENBQUMsR0FBRUEsS0FBRyxHQUFFQyxFQUFFLFFBQU1uQixFQUFFa0IsSUFBR0EsS0FBSUMsRUFBRSxRQUFNbkIsRUFBRWtCLElBQUdBLEtBQUlDLEVBQUUsV0FBU25CLEVBQUVrQixJQUFHQSxLQUFJQyxFQUFFLFNBQU9uQixFQUFFa0IsSUFBR0EsS0FBSUMsRUFBRSxZQUFVbkIsRUFBRWtCLElBQUdBO0FBQUEsRUFBRztBQUFDLFdBQVNpRCxFQUFVbEQsR0FBRWpCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFRyxHQUFFRCxHQUFFRSxHQUFFQyxHQUFFO0FBQUMsVUFBTUMsSUFBRSxLQUFLLElBQUkzQixHQUFFcUIsQ0FBQyxHQUFFUSxJQUFFLEtBQUssSUFBSVgsR0FBRU0sQ0FBQztBQUFFLFFBQUlNLElBQUUsR0FBRUMsSUFBRTtBQUFFLGFBQVFiLElBQUUsR0FBRUEsSUFBRVcsR0FBRVg7QUFBSSxlQUFRTSxJQUFFLEdBQUVBLElBQUVHLEdBQUVIO0FBQUksWUFBR0QsS0FBRyxLQUFHRSxLQUFHLEtBQUdLLElBQUVaLElBQUVsQixJQUFFd0IsS0FBRyxHQUFFTyxLQUFHTixJQUFFUCxLQUFHRyxJQUFFRSxJQUFFQyxLQUFHLE1BQUlNLEtBQUcsQ0FBQ0wsSUFBRVAsS0FBR2xCLElBQUV1QixJQUFFQyxLQUFHLEdBQUVPLElBQUViLElBQUVHLElBQUVHLEtBQUcsSUFBTUUsS0FBSDtBQUFLLFVBQUFQLEVBQUVZLEtBQUdkLEVBQUVhLElBQUdYLEVBQUVZLElBQUUsS0FBR2QsRUFBRWEsSUFBRSxJQUFHWCxFQUFFWSxJQUFFLEtBQUdkLEVBQUVhLElBQUUsSUFBR1gsRUFBRVksSUFBRSxLQUFHZCxFQUFFYSxJQUFFO0FBQUEsaUJBQWNKLEtBQUgsR0FBSztBQUFDLGNBQUlNLElBQUVmLEVBQUVhLElBQUUsS0FBSSxxQkFBT0csSUFBRWhCLEVBQUVhLEtBQUdFLEdBQUVFLElBQUVqQixFQUFFYSxJQUFFLEtBQUdFLEdBQUVHLElBQUVsQixFQUFFYSxJQUFFLEtBQUdFLEdBQUVLLElBQUVsQixFQUFFWSxJQUFFLE1BQUksSUFBRSxNQUFLNkIsSUFBRXpDLEVBQUVZLEtBQUdNLEdBQUVDLElBQUVuQixFQUFFWSxJQUFFLEtBQUdNLEdBQUVFLElBQUVwQixFQUFFWSxJQUFFLEtBQUdNO0FBQUUsZ0JBQU1yQyxJQUFFLElBQUVnQyxHQUFFZCxJQUFFYyxJQUFFSyxJQUFFckMsR0FBRXFCLElBQUtILEtBQUgsSUFBSyxJQUFFLElBQUVBO0FBQUUsVUFBQUMsRUFBRVksSUFBRSxLQUFHLE1BQUliLEdBQUVDLEVBQUVZLElBQUUsTUFBSUUsSUFBRTJCLElBQUU1RCxLQUFHcUIsR0FBRUYsRUFBRVksSUFBRSxNQUFJRyxJQUFFSSxJQUFFdEMsS0FBR3FCLEdBQUVGLEVBQUVZLElBQUUsTUFBSUksSUFBRUksSUFBRXZDLEtBQUdxQjtBQUFBLFFBQUMsV0FBWUssS0FBSDtBQUFNLFVBQUFNLElBQUVmLEVBQUVhLElBQUUsSUFBR0csSUFBRWhCLEVBQUVhLElBQUdJLElBQUVqQixFQUFFYSxJQUFFLElBQUdLLElBQUVsQixFQUFFYSxJQUFFLElBQUdPLElBQUVsQixFQUFFWSxJQUFFLElBQUc2QixJQUFFekMsRUFBRVksSUFBR08sSUFBRW5CLEVBQUVZLElBQUUsSUFBR1EsSUFBRXBCLEVBQUVZLElBQUUsSUFBR0MsS0FBR0ssS0FBR0osS0FBRzJCLEtBQUcxQixLQUFHSSxLQUFHSCxLQUFHSSxLQUFHcEIsRUFBRVksS0FBRyxHQUFFWixFQUFFWSxJQUFFLEtBQUcsR0FBRVosRUFBRVksSUFBRSxLQUFHLEdBQUVaLEVBQUVZLElBQUUsS0FBRyxNQUFJWixFQUFFWSxLQUFHRSxHQUFFZCxFQUFFWSxJQUFFLEtBQUdHLEdBQUVmLEVBQUVZLElBQUUsS0FBR0ksR0FBRWhCLEVBQUVZLElBQUUsS0FBR0M7QUFBQSxpQkFBY04sS0FBSCxHQUFLO0FBQXFFLGNBQXBFTSxJQUFFZixFQUFFYSxJQUFFLElBQUdHLElBQUVoQixFQUFFYSxJQUFHSSxJQUFFakIsRUFBRWEsSUFBRSxJQUFHSyxJQUFFbEIsRUFBRWEsSUFBRSxJQUFHTyxJQUFFbEIsRUFBRVksSUFBRSxJQUFHNkIsSUFBRXpDLEVBQUVZLElBQUdPLElBQUVuQixFQUFFWSxJQUFFLElBQUdRLElBQUVwQixFQUFFWSxJQUFFLElBQU1DLEtBQUdLLEtBQUdKLEtBQUcyQixLQUFHMUIsS0FBR0ksS0FBR0gsS0FBR0k7QUFBRTtBQUFTLGNBQUdQLElBQUUsT0FBS0ssSUFBRTtBQUFHLG1CQUFNO0FBQUEsUUFBRTtBQUFDLFdBQU07QUFBQSxFQUFFO0FBQUMsU0FBTSxFQUFDLFFBQU8sU0FBZ0JuQixHQUFFO0FBQUMsVUFBTUMsSUFBRSxJQUFJLFdBQVdELENBQUM7QUFBRSxRQUFJRyxJQUFFO0FBQUUsVUFBTUcsSUFBRVAsR0FBRU0sSUFBRUMsRUFBRSxZQUFXQyxJQUFFRCxFQUFFLFVBQVNFLElBQUUsRUFBQyxNQUFLLENBQUEsR0FBRyxRQUFPLENBQUEsRUFBRSxHQUFFQyxJQUFFLElBQUksV0FBV1IsRUFBRSxNQUFNO0FBQUUsUUFBSVUsR0FBRUMsSUFBRSxHQUFFQyxJQUFFO0FBQUUsVUFBTUMsSUFBRSxDQUFDLEtBQUksSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsRUFBRTtBQUFFLGFBQVFDLElBQUUsR0FBRUEsSUFBRSxHQUFFQTtBQUFJLFVBQUdkLEVBQUVjLE1BQUlELEVBQUVDO0FBQUcsY0FBSztBQUErQixXQUFLWixJQUFFRixFQUFFLFVBQVE7QUFBQyxZQUFNRixJQUFFTyxFQUFFLFNBQVNMLEdBQUVFLENBQUM7QUFBRSxNQUFBQSxLQUFHO0FBQUUsWUFBTUgsSUFBRU0sRUFBRSxVQUFVTCxHQUFFRSxHQUFFLENBQUM7QUFBRSxVQUFHQSxLQUFHLEdBQVVILEtBQVI7QUFBVSxRQUFBZ0QsRUFBTS9DLEdBQUVFLEdBQUVLLENBQUM7QUFBQSxlQUFrQlIsS0FBUixRQUFVO0FBQUMsaUJBQVFnQixJQUFFYixHQUFLRixFQUFFZSxNQUFMO0FBQVMsVUFBQUE7QUFBSSxRQUFBVixFQUFFLFVBQVVMLEdBQUVFLEdBQUVhLElBQUViLENBQUMsR0FBRUYsRUFBRWUsSUFBRTtBQUFHLGNBQU1YLElBQUVKLEVBQUUsTUFBTWUsSUFBRSxHQUFFYixJQUFFSixDQUFDO0FBQUUsWUFBSVEsSUFBRTtBQUFLLFlBQUc7QUFBQyxVQUFBQSxJQUFFcUMsRUFBU3ZDLENBQUM7QUFBQSxRQUFDLFFBQUM7QUFBUyxVQUFBRSxJQUFFekIsRUFBRXVCLENBQUM7QUFBQSxRQUFDO0FBQUMsUUFBQUcsRUFBRSxLQUFLUixLQUFHTztBQUFBLE1BQUMsV0FBaUJQLEtBQVI7QUFBVSxRQUFBUSxFQUFFLEtBQUtSLEtBQUdDLEVBQUUsTUFBTUUsR0FBRUEsSUFBRSxDQUFDO0FBQUEsZUFBa0JILEtBQVIsUUFBVTtBQUFDLGFBQUllLElBQUUsR0FBRUEsSUFBRWhCLEdBQUVnQjtBQUFJLFVBQUFOLEVBQUVHLElBQUVHLEtBQUdkLEVBQUVFLElBQUVZO0FBQUcsUUFBQUgsS0FBR2I7QUFBQSxNQUFDLFdBQWlCQyxLQUFSO0FBQVUsUUFBQVEsRUFBRSxLQUFLUixLQUFHLEVBQUMsWUFBV08sRUFBRU4sR0FBRUUsQ0FBQyxHQUFFLFdBQVVJLEVBQUVOLEdBQUVFLElBQUUsQ0FBQyxFQUFDLEdBQUVRLElBQUUsSUFBSSxXQUFXVixFQUFFLE1BQU07QUFBQSxlQUFrQkQsS0FBUixRQUFVO0FBQUMsUUFBTWEsS0FBSCxPQUFNUyxJQUFFZCxFQUFFLE9BQU9BLEVBQUUsT0FBTyxTQUFPLElBQUksT0FBS21DLEVBQVluQyxHQUFFRyxFQUFFLE1BQU0sR0FBRUUsQ0FBQyxHQUFFUyxFQUFFLEtBQUssT0FBTUEsRUFBRSxLQUFLLE1BQU0sR0FBRVQsSUFBRTtBQUFFLGNBQU1kLElBQUUsRUFBQyxHQUFFUSxFQUFFTixHQUFFRSxJQUFFLEVBQUUsR0FBRSxHQUFFSSxFQUFFTixHQUFFRSxJQUFFLEVBQUUsR0FBRSxPQUFNSSxFQUFFTixHQUFFRSxJQUFFLENBQUMsR0FBRSxRQUFPSSxFQUFFTixHQUFFRSxJQUFFLENBQUMsRUFBQztBQUFFLFlBQUlyQixJQUFFdUIsRUFBRUosR0FBRUUsSUFBRSxFQUFFO0FBQUUsUUFBQXJCLElBQUV1QixFQUFFSixHQUFFRSxJQUFFLEVBQUUsS0FBTXJCLEtBQUgsSUFBSyxNQUFJQTtBQUFHLGNBQU1rQixJQUFFLEVBQUMsTUFBS0QsR0FBRSxPQUFNLEtBQUssTUFBTSxNQUFJakIsQ0FBQyxHQUFFLFNBQVFtQixFQUFFRSxJQUFFLEtBQUksT0FBTUYsRUFBRUUsSUFBRSxJQUFHO0FBQUUsUUFBQUssRUFBRSxPQUFPLEtBQUtSLENBQUM7QUFBQSxNQUFDLFdBQWlCQSxLQUFSLFFBQVU7QUFBQyxhQUFJZSxJQUFFLEdBQUVBLElBQUVoQixJQUFFLEdBQUVnQjtBQUFJLFVBQUFKLEVBQUVFLElBQUVFLEtBQUdkLEVBQUVFLElBQUVZLElBQUU7QUFBRyxRQUFBRixLQUFHZCxJQUFFO0FBQUEsTUFBQyxXQUFpQkMsS0FBUjtBQUFVLFFBQUFRLEVBQUUsS0FBS1IsS0FBRyxDQUFDTSxFQUFFLFNBQVNMLEdBQUVFLENBQUMsR0FBRUcsRUFBRSxTQUFTTCxHQUFFRSxJQUFFLENBQUMsR0FBRUYsRUFBRUUsSUFBRSxFQUFFO0FBQUEsZUFBa0JILEtBQVI7QUFBd0IsYUFBYlEsRUFBRSxLQUFLUixLQUFHLENBQUUsR0FBS2UsSUFBRSxHQUFFQSxJQUFFLEdBQUVBO0FBQUksVUFBQVAsRUFBRSxLQUFLUixHQUFHLEtBQUtNLEVBQUUsU0FBU0wsR0FBRUUsSUFBRSxJQUFFWSxDQUFDLENBQUM7QUFBQSxlQUFrQmYsS0FBUixVQUFtQkEsS0FBUixRQUFVO0FBQUMsUUFBTVEsRUFBRSxLQUFLUixNQUFiLFNBQWtCUSxFQUFFLEtBQUtSLEtBQUcsQ0FBRTtBQUFFLFlBQUlpQixJQUFFWCxFQUFFLFNBQVNMLEdBQUVFLENBQUMsR0FBRSxJQUFFRyxFQUFFLFVBQVVMLEdBQUVFLEdBQUVjLElBQUVkLENBQUMsR0FBRXVDLElBQUV2QyxJQUFFSixJQUFFa0IsSUFBRTtBQUFFLFlBQVdqQixLQUFSO0FBQVUsVUFBQXFCLElBQUVmLEVBQUUsVUFBVUwsR0FBRWdCLElBQUUsR0FBRXlCLENBQUM7QUFBQSxhQUFNO0FBQUMsY0FBSXRCLElBQUV3QixFQUFTM0MsRUFBRSxNQUFNZ0IsSUFBRSxHQUFFQSxJQUFFLElBQUV5QixDQUFDLENBQUM7QUFBRSxVQUFBckIsSUFBRWYsRUFBRSxTQUFTYyxHQUFFLEdBQUVBLEVBQUUsTUFBTTtBQUFBLFFBQUM7QUFBQyxRQUFBWixFQUFFLEtBQUtSLEdBQUcsS0FBR3FCO0FBQUEsTUFBQyxXQUFpQnJCLEtBQVIsUUFBVTtBQUFDLFFBQU1RLEVBQUUsS0FBS1IsTUFBYixTQUFrQlEsRUFBRSxLQUFLUixLQUFHLENBQUEsSUFBSWlCLElBQUUsR0FBRUQsSUFBRWIsR0FBRWMsSUFBRVgsRUFBRSxTQUFTTCxHQUFFZSxDQUFDLEdBQUUsSUFBRVYsRUFBRSxVQUFVTCxHQUFFZSxHQUFFQyxJQUFFRCxDQUFDO0FBQUUsY0FBTWxDLElBQUVtQixFQUFFZSxJQUFFQyxJQUFFO0FBQUcsWUFBSUk7QUFBRSxRQUFBcEIsRUFBRWUsSUFBRSxJQUFHQSxLQUFHLEdBQUVDLElBQUVYLEVBQUUsU0FBU0wsR0FBRWUsQ0FBQyxHQUFFVixFQUFFLFVBQVVMLEdBQUVlLEdBQUVDLElBQUVELENBQUMsR0FBRUEsSUFBRUMsSUFBRSxHQUFFQSxJQUFFWCxFQUFFLFNBQVNMLEdBQUVlLENBQUMsR0FBRVYsRUFBRSxTQUFTTCxHQUFFZSxHQUFFQyxJQUFFRCxDQUFDLEdBQUUwQixJQUFFM0MsTUFBSWlCLElBQUVDLElBQUUsS0FBR2QsSUFBU3JCLEtBQUgsSUFBS3VDLElBQUVmLEVBQUUsU0FBU0wsR0FBRWUsR0FBRTBCLENBQUMsS0FBT3RCLElBQUV3QixFQUFTM0MsRUFBRSxNQUFNZSxHQUFFQSxJQUFFMEIsQ0FBQyxDQUFDLEdBQUVyQixJQUFFZixFQUFFLFNBQVNjLEdBQUUsR0FBRUEsRUFBRSxNQUFNLElBQUVaLEVBQUUsS0FBS1IsR0FBRyxLQUFHcUI7QUFBQSxNQUFDLFdBQWlCckIsS0FBUjtBQUFVLFFBQUFRLEVBQUUsS0FBS1IsS0FBR00sRUFBRSxVQUFVTCxHQUFFRSxHQUFFSixDQUFDO0FBQUEsZUFBa0JDLEtBQVIsUUFBVTtBQUFDLGNBQU1ELElBQUVTLEVBQUUsS0FBSyxLQUFLLFNBQU87QUFBZSxhQUFiQSxFQUFFLEtBQUtSLEtBQUcsQ0FBRSxHQUFLZSxJQUFFLEdBQUVBLElBQUVoQixHQUFFZ0I7QUFBSSxVQUFBUCxFQUFFLEtBQUtSLEdBQUcsS0FBS0ssRUFBRUosR0FBRUUsSUFBRSxJQUFFWSxDQUFDLENBQUM7QUFBQSxNQUFDLFdBQWlCZixLQUFSO0FBQVUsUUFBR1EsRUFBRSxTQUFMLElBQVdBLEVBQUUsS0FBS1IsS0FBR00sRUFBRSxVQUFVTCxHQUFFRSxHQUFFSixDQUFDLElBQUtTLEVBQUUsU0FBTCxJQUFXQSxFQUFFLEtBQUtSLEtBQUdLLEVBQUVKLEdBQUVFLENBQUMsSUFBS0ssRUFBRSxTQUFMLE1BQWFBLEVBQUUsS0FBS1IsS0FBRyxDQUFDSyxFQUFFSixHQUFFRSxDQUFDLEdBQUVFLEVBQUVKLEdBQUVFLElBQUUsQ0FBQyxHQUFFRSxFQUFFSixHQUFFRSxJQUFFLENBQUMsQ0FBQztBQUFBLGVBQW1CSCxLQUFSO0FBQVUsUUFBQVEsRUFBRSxLQUFLUixLQUFHTSxFQUFFLFNBQVNMLEdBQUVFLENBQUMsSUFBRTtBQUFBLGVBQW9CSCxLQUFSO0FBQVUsUUFBQVEsRUFBRSxLQUFLUixLQUFHQyxFQUFFRTtBQUFBLGVBQW1CSCxLQUFSO0FBQVUsUUFBR1EsRUFBRSxTQUFMLEtBQWVBLEVBQUUsU0FBTCxJQUFXQSxFQUFFLEtBQUtSLEtBQUcsQ0FBQ0ssRUFBRUosR0FBRUUsQ0FBQyxDQUFDLElBQUtLLEVBQUUsU0FBTCxLQUFlQSxFQUFFLFNBQUwsSUFBV0EsRUFBRSxLQUFLUixLQUFHLENBQUNLLEVBQUVKLEdBQUVFLENBQUMsR0FBRUUsRUFBRUosR0FBRUUsSUFBRSxDQUFDLEdBQUVFLEVBQUVKLEdBQUVFLElBQUUsQ0FBQyxDQUFDLElBQUtLLEVBQUUsU0FBTCxNQUFhQSxFQUFFLEtBQUtSLEtBQUdDLEVBQUVFO0FBQUEsZUFBb0JILEtBQVI7QUFBVTtBQUFNLE1BQUFHLEtBQUdKLEdBQUVPLEVBQUUsU0FBU0wsR0FBRUUsQ0FBQyxHQUFFQSxLQUFHO0FBQUEsSUFBQztBQUFDLFFBQUltQjtBQUFFLFdBQVVULEtBQUgsT0FBUVMsSUFBRWQsRUFBRSxPQUFPQSxFQUFFLE9BQU8sU0FBTyxJQUFJLE9BQUttQyxFQUFZbkMsR0FBRUcsRUFBRSxNQUFNLEdBQUVFLENBQUMsR0FBRVMsRUFBRSxLQUFLLE9BQU1BLEVBQUUsS0FBSyxNQUFNLElBQUdkLEVBQUUsT0FBS21DLEVBQVluQyxHQUFFQyxHQUFFRCxFQUFFLE9BQU1BLEVBQUUsTUFBTSxHQUFFLE9BQU9BLEVBQUUsVUFBUyxPQUFPQSxFQUFFLFdBQVUsT0FBT0EsRUFBRSxRQUFPQTtBQUFBLEVBQUMsR0FBRSxTQUFRLFNBQWlCVCxHQUFFO0FBQUMsVUFBTWpCLElBQUVpQixFQUFFLE9BQU1DLElBQUVELEVBQUU7QUFBTyxRQUFTQSxFQUFFLEtBQUssUUFBYjtBQUFrQixhQUFNLENBQUN5QyxFQUFZekMsRUFBRSxNQUFLakIsR0FBRWtCLEdBQUVELENBQUMsRUFBRSxNQUFNO0FBQUUsVUFBTUUsSUFBRSxDQUFBO0FBQUcsSUFBTUYsRUFBRSxPQUFPLEdBQUcsUUFBbEIsU0FBeUJBLEVBQUUsT0FBTyxHQUFHLE9BQUtBLEVBQUU7QUFBTSxVQUFNSSxJQUFFckIsSUFBRWtCLElBQUUsR0FBRU0sSUFBRSxJQUFJLFdBQVdILENBQUMsR0FBRUUsSUFBRSxJQUFJLFdBQVdGLENBQUMsR0FBRUksSUFBRSxJQUFJLFdBQVdKLENBQUM7QUFBRSxhQUFRTSxJQUFFLEdBQUVBLElBQUVWLEVBQUUsT0FBTyxRQUFPVSxLQUFJO0FBQUMsWUFBTUUsSUFBRVosRUFBRSxPQUFPVSxJQUFHRyxJQUFFRCxFQUFFLEtBQUssR0FBRUUsSUFBRUYsRUFBRSxLQUFLLEdBQUVHLElBQUVILEVBQUUsS0FBSyxPQUFNSSxJQUFFSixFQUFFLEtBQUssUUFBT0ssSUFBRXdCLEVBQVk3QixFQUFFLE1BQUtHLEdBQUVDLEdBQUVoQixDQUFDO0FBQUUsVUFBTVUsS0FBSDtBQUFLLGlCQUFRRCxJQUFFLEdBQUVBLElBQUVMLEdBQUVLO0FBQUksVUFBQUQsRUFBRUMsS0FBR0YsRUFBRUU7QUFBRyxVQUFNRyxFQUFFLFNBQUwsSUFBV3NDLEVBQVVqQyxHQUFFRixHQUFFQyxHQUFFVCxHQUFFeEIsR0FBRWtCLEdBQUVZLEdBQUVDLEdBQUUsQ0FBQyxJQUFLRixFQUFFLFNBQUwsS0FBWXNDLEVBQVVqQyxHQUFFRixHQUFFQyxHQUFFVCxHQUFFeEIsR0FBRWtCLEdBQUVZLEdBQUVDLEdBQUUsQ0FBQyxHQUFFWixFQUFFLEtBQUtLLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQyxHQUFLSyxFQUFFLFdBQUw7QUFBbUIsWUFBTUEsRUFBRSxXQUFMO0FBQWEsVUFBQXNDLEVBQVU1QyxHQUFFUyxHQUFFQyxHQUFFVCxHQUFFeEIsR0FBRWtCLEdBQUVZLEdBQUVDLEdBQUUsQ0FBQztBQUFBLGlCQUFhRixFQUFFLFdBQUw7QUFBYSxlQUFJSCxJQUFFLEdBQUVBLElBQUVMLEdBQUVLO0FBQUksWUFBQUYsRUFBRUUsS0FBR0QsRUFBRUM7QUFBQTtBQUFBLElBQUU7QUFBQyxXQUFPUDtBQUFBLEVBQUMsR0FBRSxRQUFPOEMsR0FBTyxXQUFVRSxHQUFVLE1BQUtsRCxFQUFDO0FBQUMsRUFBRztBQUFBLENBQUUsV0FBVTtBQUFDLFFBQUssRUFBQyxXQUFVQSxFQUFDLElBQUV3QyxJQUFLLEVBQUMsTUFBS3pELEVBQUMsSUFBRXlELElBQUt2QyxJQUFFdUMsR0FBSztBQUFPLE1BQUl0QyxJQUFFLEVBQUMsT0FBTSxXQUFVO0FBQUMsVUFBTUYsSUFBRSxJQUFJLFlBQVksR0FBRztBQUFFLGFBQVFqQixJQUFFLEdBQUVBLElBQUUsS0FBSUEsS0FBSTtBQUFDLFVBQUlrQixJQUFFbEI7QUFBRSxlQUFRaUIsSUFBRSxHQUFFQSxJQUFFLEdBQUVBO0FBQUksWUFBRUMsSUFBRUEsSUFBRSxhQUFXQSxNQUFJLElBQUVBLE9BQUs7QUFBRSxNQUFBRCxFQUFFakIsS0FBR2tCO0FBQUEsSUFBQztBQUFDLFdBQU9EO0FBQUEsRUFBQyxFQUFHLEdBQUMsT0FBT0EsR0FBRWpCLEdBQUVrQixHQUFFRyxHQUFFO0FBQUMsYUFBUUcsSUFBRSxHQUFFQSxJQUFFSCxHQUFFRztBQUFJLE1BQUFQLElBQUVFLEVBQUUsTUFBTSxPQUFLRixJQUFFakIsRUFBRWtCLElBQUVNLE9BQUtQLE1BQUk7QUFBRSxXQUFPQTtBQUFBLEVBQUMsR0FBRSxLQUFJLENBQUNBLEdBQUVqQixHQUFFa0IsTUFBSSxhQUFXQyxFQUFFLE9BQU8sWUFBV0YsR0FBRWpCLEdBQUVrQixDQUFDLEVBQUM7QUFBRSxXQUFTa0QsRUFBT25ELEdBQUVqQixHQUFFa0IsR0FBRUMsR0FBRTtBQUFDLElBQUFuQixFQUFFa0IsTUFBSUQsRUFBRSxLQUFHRSxLQUFHLEdBQUVuQixFQUFFa0IsSUFBRSxNQUFJRCxFQUFFLEtBQUdFLEtBQUcsR0FBRW5CLEVBQUVrQixJQUFFLE1BQUlELEVBQUUsS0FBR0UsS0FBRyxHQUFFbkIsRUFBRWtCLElBQUUsTUFBSUQsRUFBRSxLQUFHRSxLQUFHO0FBQUEsRUFBQztBQUFDLFdBQVNrRCxFQUFFcEQsR0FBRTtBQUFDLFdBQU8sS0FBSyxJQUFJLEdBQUUsS0FBSyxJQUFJLEtBQUlBLENBQUMsQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTcUQsRUFBRXJELEdBQUVqQixHQUFFO0FBQUMsVUFBTWtCLElBQUVELEVBQUUsS0FBR2pCLEVBQUUsSUFBR21CLElBQUVGLEVBQUUsS0FBR2pCLEVBQUUsSUFBR3FCLElBQUVKLEVBQUUsS0FBR2pCLEVBQUUsSUFBR3dCLElBQUVQLEVBQUUsS0FBR2pCLEVBQUU7QUFBRyxXQUFPa0IsSUFBRUEsSUFBRUMsSUFBRUEsSUFBRUUsSUFBRUEsSUFBRUcsSUFBRUE7QUFBQSxFQUFDO0FBQUMsV0FBUytDLEVBQU90RCxHQUFFakIsR0FBRWtCLEdBQUVDLEdBQUVFLEdBQUVHLEdBQUVELEdBQUU7QUFBQyxJQUFNQSxLQUFOLFNBQVVBLElBQUU7QUFBRyxVQUFNRSxJQUFFTixFQUFFLFFBQU9PLElBQUUsQ0FBQTtBQUFHLGFBQVFDLElBQUUsR0FBRUEsSUFBRUYsR0FBRUUsS0FBSTtBQUFDLFlBQU1WLElBQUVFLEVBQUVRO0FBQUcsTUFBQUQsRUFBRSxLQUFLLENBQUNULE1BQUksSUFBRSxLQUFJQSxNQUFJLElBQUUsS0FBSUEsTUFBSSxLQUFHLEtBQUlBLE1BQUksS0FBRyxHQUFHLENBQUM7QUFBQSxJQUFDO0FBQUMsU0FBSVUsSUFBRSxHQUFFQSxJQUFFRixHQUFFRSxLQUFJO0FBQUMsVUFBSVYsSUFBRTtBQUFXLGVBQVFZLElBQUUsR0FBRUMsSUFBRSxHQUFFQSxJQUFFTCxHQUFFSyxLQUFJO0FBQUMsWUFBSUMsSUFBRXVDLEVBQUU1QyxFQUFFQyxJQUFHRCxFQUFFSSxFQUFFO0FBQUUsUUFBQUEsS0FBR0gsS0FBR0ksSUFBRWQsTUFBSUEsSUFBRWMsR0FBRUYsSUFBRUM7QUFBQSxNQUFFO0FBQUEsSUFBQztBQUFDLFVBQU1FLElBQUUsSUFBSSxZQUFZWCxFQUFFLE1BQU0sR0FBRVksSUFBRSxJQUFJLFdBQVdqQyxJQUFFa0IsSUFBRSxDQUFDLEdBQUVnQixJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsSUFBRyxHQUFFLEdBQUUsSUFBRyxHQUFFLEdBQUUsSUFBRyxHQUFFLElBQUcsQ0FBQztBQUFFLFNBQUlQLElBQUUsR0FBRUEsSUFBRU8sRUFBRSxRQUFPUDtBQUFJLE1BQUFPLEVBQUVQLEtBQUcsUUFBTU8sRUFBRVAsS0FBRyxPQUFJLEtBQUc7QUFBSSxhQUFRTixJQUFFLEdBQUVBLElBQUVILEdBQUVHO0FBQUksZUFBUWdCLElBQUUsR0FBRUEsSUFBRXJDLEdBQUVxQyxLQUFJO0FBQUMsWUFBSUY7QUFBRSxRQUFBUixJQUFFLEtBQUdOLElBQUVyQixJQUFFcUMsSUFBU2QsS0FBSCxJQUFLWSxJQUFFLENBQUNrQyxFQUFFcEQsRUFBRVUsS0FBR00sRUFBRU4sRUFBRSxHQUFFMEMsRUFBRXBELEVBQUVVLElBQUUsS0FBR00sRUFBRU4sSUFBRSxFQUFFLEdBQUUwQyxFQUFFcEQsRUFBRVUsSUFBRSxLQUFHTSxFQUFFTixJQUFFLEVBQUUsR0FBRTBDLEVBQUVwRCxFQUFFVSxJQUFFLEtBQUdNLEVBQUVOLElBQUUsRUFBRSxDQUFDLEtBQU9JLElBQUVHLEVBQUUsS0FBRyxJQUFFYixNQUFJLElBQUVnQixLQUFJRixJQUFFLENBQUNrQyxFQUFFcEQsRUFBRVUsS0FBR0ksQ0FBQyxHQUFFc0MsRUFBRXBELEVBQUVVLElBQUUsS0FBR0ksQ0FBQyxHQUFFc0MsRUFBRXBELEVBQUVVLElBQUUsS0FBR0ksQ0FBQyxHQUFFc0MsRUFBRXBELEVBQUVVLElBQUUsS0FBR0ksQ0FBQyxDQUFDLElBQUVGLElBQUU7QUFBRSxZQUFJK0IsSUFBRTtBQUFTLGFBQUk5QixJQUFFLEdBQUVBLElBQUVMLEdBQUVLLEtBQUk7QUFBQyxnQkFBTWIsSUFBRXFELEVBQUVuQyxHQUFFVCxFQUFFSSxFQUFFO0FBQUUsVUFBQWIsSUFBRTJDLE1BQUlBLElBQUUzQyxHQUFFWSxJQUFFQztBQUFBLFFBQUU7QUFBQyxjQUFNUSxJQUFFWixFQUFFRyxJQUFHVSxJQUFFLENBQUNKLEVBQUUsS0FBR0csRUFBRSxJQUFHSCxFQUFFLEtBQUdHLEVBQUUsSUFBR0gsRUFBRSxLQUFHRyxFQUFFLElBQUdILEVBQUUsS0FBR0csRUFBRSxFQUFFO0FBQUUsUUFBR2YsS0FBSCxNQUFPYyxLQUFHckMsSUFBRSxLQUFHb0UsRUFBTzdCLEdBQUVOLEdBQUVOLElBQUUsR0FBRSxDQUFDLEdBQUVOLEtBQUdILElBQUUsTUFBT21CLEtBQUgsS0FBTStCLEVBQU83QixHQUFFTixHQUFFTixJQUFFLElBQUUzQixJQUFFLEdBQUUsQ0FBQyxHQUFFb0UsRUFBTzdCLEdBQUVOLEdBQUVOLElBQUUsSUFBRTNCLEdBQUUsQ0FBQyxHQUFFcUMsS0FBR3JDLElBQUUsS0FBR29FLEVBQU83QixHQUFFTixHQUFFTixJQUFFLElBQUUzQixJQUFFLEdBQUUsQ0FBQyxLQUFJd0IsRUFBRUcsS0FBRyxLQUFHRSxHQUFFRyxFQUFFTCxLQUFHLEtBQUdSLEVBQUVVO0FBQUEsTUFBRTtBQUFBLEVBQUM7QUFBQyxXQUFTMkMsRUFBTXZELEdBQUVDLEdBQUVHLEdBQUVHLEdBQUVELEdBQUU7QUFBQyxJQUFNQSxLQUFOLFNBQVVBLElBQUUsQ0FBQTtBQUFJLFVBQUssRUFBQyxLQUFJRSxFQUFDLElBQUVOLEdBQUVPLElBQUUxQixFQUFFLFdBQVUyQixJQUFFM0IsRUFBRSxhQUFZNkIsSUFBRTdCLEVBQUU7QUFBVyxRQUFJOEIsSUFBRTtBQUFFLFVBQU1DLElBQUVkLEVBQUUsT0FBTyxTQUFPO0FBQUUsUUFBSWUsR0FBRUMsSUFBRSxJQUFHQyxJQUFFLE1BQUlILElBQUUsS0FBRztBQUFHLFFBQVNSLEVBQUUsUUFBUixTQUFlVyxLQUFHLEtBQVVYLEVBQUUsUUFBUixTQUFlVyxLQUFHLEtBQVVYLEVBQUUsUUFBUixTQUFlUyxJQUFFLEtBQUssUUFBUVQsRUFBRSxJQUFJLEdBQUVXLEtBQUcsS0FBR0YsRUFBRSxTQUFPLElBQU1mLEVBQUUsU0FBTCxHQUFXO0FBQUMsZUFBUWtCLElBQUVsQixFQUFFLEtBQUssUUFBT29CLElBQUUsR0FBRUEsSUFBRUYsR0FBRUU7QUFBSSxRQUFBcEIsRUFBRSxLQUFLb0IsT0FBSyxNQUFJLFFBQU1KLElBQUU7QUFBSSxNQUFBQyxLQUFHLElBQUUsSUFBRUMsSUFBRSxLQUFHRixJQUFFLElBQUUsSUFBRUUsSUFBRSxJQUFFO0FBQUEsSUFBRTtBQUFDLGFBQVF5QixJQUFFLEdBQUVBLElBQUUzQyxFQUFFLE9BQU8sUUFBTzJDO0FBQUssTUFBQTdCLE1BQUlHLEtBQUcsS0FBSUEsTUFBSU8sSUFBRXhCLEVBQUUsT0FBTzJDLElBQUksS0FBSyxTQUFPLElBQU1BLEtBQUgsTUFBTzFCLEtBQUc7QUFBRyxJQUFBQSxLQUFHO0FBQUcsVUFBTUksSUFBRSxJQUFJLFdBQVdKLENBQUMsR0FBRUssSUFBRSxDQUFDLEtBQUksSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsRUFBRTtBQUFFLFNBQUlGLElBQUUsR0FBRUEsSUFBRSxHQUFFQTtBQUFJLE1BQUFDLEVBQUVELEtBQUdFLEVBQUVGO0FBQUcsUUFBR1gsRUFBRVksR0FBRVIsR0FBRSxFQUFFLEdBQUVBLEtBQUcsR0FBRUQsRUFBRVMsR0FBRVIsR0FBRSxNQUFNLEdBQUVBLEtBQUcsR0FBRUosRUFBRVksR0FBRVIsR0FBRVosQ0FBQyxHQUFFWSxLQUFHLEdBQUVKLEVBQUVZLEdBQUVSLEdBQUVULENBQUMsR0FBRVMsS0FBRyxHQUFFUSxFQUFFUixLQUFHYixFQUFFLE9BQU1hLEtBQUlRLEVBQUVSLEtBQUdiLEVBQUUsT0FBTWEsS0FBSVEsRUFBRVIsS0FBRyxHQUFFQSxLQUFJUSxFQUFFUixLQUFHLEdBQUVBLEtBQUlRLEVBQUVSLEtBQUcsR0FBRUEsS0FBSUosRUFBRVksR0FBRVIsR0FBRUwsRUFBRWEsR0FBRVIsSUFBRSxJQUFHLEVBQUUsQ0FBQyxHQUFFQSxLQUFHLEdBQVFQLEVBQUUsUUFBUixTQUFlRyxFQUFFWSxHQUFFUixHQUFFLENBQUMsR0FBRUEsS0FBRyxHQUFFRCxFQUFFUyxHQUFFUixHQUFFLE1BQU0sR0FBRUEsS0FBRyxHQUFFUSxFQUFFUixLQUFHUCxFQUFFLE1BQUtPLEtBQUlKLEVBQUVZLEdBQUVSLEdBQUVMLEVBQUVhLEdBQUVSLElBQUUsR0FBRSxDQUFDLENBQUMsR0FBRUEsS0FBRyxJQUFTUCxFQUFFLFFBQVIsTUFBYTtBQUFDLFlBQU1OLElBQUUsS0FBR2UsRUFBRTtBQUFPLE1BQUFOLEVBQUVZLEdBQUVSLEdBQUViLENBQUMsR0FBRWEsS0FBRyxHQUFFRCxFQUFFUyxHQUFFUixHQUFFLE1BQU0sR0FBRUEsS0FBRyxHQUFFRCxFQUFFUyxHQUFFUixHQUFFLGFBQWEsR0FBRUEsS0FBRyxJQUFHQSxLQUFHLEdBQUVRLEVBQUUsSUFBSU4sR0FBRUYsQ0FBQyxHQUFFQSxLQUFHRSxFQUFFLFFBQU9OLEVBQUVZLEdBQUVSLEdBQUVMLEVBQUVhLEdBQUVSLEtBQUdiLElBQUUsSUFBR0EsSUFBRSxDQUFDLENBQUMsR0FBRWEsS0FBRztBQUFBLElBQUM7QUFBQyxRQUFTUCxFQUFFLFFBQVIsU0FBZUcsRUFBRVksR0FBRVIsR0FBRSxDQUFDLEdBQUVBLEtBQUcsR0FBRUQsRUFBRVMsR0FBRVIsR0FBRSxNQUFNLEdBQUVBLEtBQUcsR0FBRUosRUFBRVksR0FBRVIsR0FBRVAsRUFBRSxLQUFLLEVBQUUsR0FBRU8sS0FBRyxHQUFFSixFQUFFWSxHQUFFUixHQUFFUCxFQUFFLEtBQUssRUFBRSxHQUFFTyxLQUFHLEdBQUVRLEVBQUVSLEtBQUdQLEVBQUUsS0FBSyxJQUFHTyxLQUFJSixFQUFFWSxHQUFFUixHQUFFTCxFQUFFYSxHQUFFUixJQUFFLElBQUcsRUFBRSxDQUFDLEdBQUVBLEtBQUcsSUFBR0MsTUFBSUwsRUFBRVksR0FBRVIsR0FBRSxDQUFDLEdBQUVBLEtBQUcsR0FBRUQsRUFBRVMsR0FBRVIsR0FBRSxNQUFNLEdBQUVBLEtBQUcsR0FBRUosRUFBRVksR0FBRVIsR0FBRWIsRUFBRSxPQUFPLE1BQU0sR0FBRWEsS0FBRyxHQUFFSixFQUFFWSxHQUFFUixHQUFRUCxFQUFFLFFBQVIsT0FBYUEsRUFBRSxPQUFLLENBQUMsR0FBRU8sS0FBRyxHQUFFSixFQUFFWSxHQUFFUixHQUFFTCxFQUFFYSxHQUFFUixJQUFFLElBQUcsRUFBRSxDQUFDLEdBQUVBLEtBQUcsSUFBTWIsRUFBRSxTQUFMLEdBQVc7QUFBb0QsV0FBbkRTLEVBQUVZLEdBQUVSLEdBQUUsS0FBR0ssSUFBRWxCLEVBQUUsS0FBSyxPQUFPLEdBQUVhLEtBQUcsR0FBRUQsRUFBRVMsR0FBRVIsR0FBRSxNQUFNLEdBQUVBLEtBQUcsR0FBTU8sSUFBRSxHQUFFQSxJQUFFRixHQUFFRSxLQUFJO0FBQUMsY0FBTXJDLElBQUUsSUFBRXFDLEdBQUVuQixJQUFFRCxFQUFFLEtBQUtvQixJQUFHbEIsSUFBRSxNQUFJRCxHQUFFRyxLQUFFSCxNQUFJLElBQUUsS0FBSU0sS0FBRU4sTUFBSSxLQUFHO0FBQUksUUFBQW9CLEVBQUVSLElBQUU5QixJQUFFLEtBQUdtQixHQUFFbUIsRUFBRVIsSUFBRTlCLElBQUUsS0FBR3FCLElBQUVpQixFQUFFUixJQUFFOUIsSUFBRSxLQUFHd0I7QUFBQSxNQUFDO0FBQUMsVUFBR00sS0FBRyxJQUFFSyxHQUFFVCxFQUFFWSxHQUFFUixHQUFFTCxFQUFFYSxHQUFFUixJQUFFLElBQUVLLElBQUUsR0FBRSxJQUFFQSxJQUFFLENBQUMsQ0FBQyxHQUFFTCxLQUFHLEdBQUVHLEdBQUU7QUFBa0MsYUFBakNQLEVBQUVZLEdBQUVSLEdBQUVLLENBQUMsR0FBRUwsS0FBRyxHQUFFRCxFQUFFUyxHQUFFUixHQUFFLE1BQU0sR0FBRUEsS0FBRyxHQUFNTyxJQUFFLEdBQUVBLElBQUVGLEdBQUVFO0FBQUksVUFBQUMsRUFBRVIsSUFBRU8sS0FBR3BCLEVBQUUsS0FBS29CLE9BQUssS0FBRztBQUFJLFFBQUFQLEtBQUdLLEdBQUVULEVBQUVZLEdBQUVSLEdBQUVMLEVBQUVhLEdBQUVSLElBQUVLLElBQUUsR0FBRUEsSUFBRSxDQUFDLENBQUMsR0FBRUwsS0FBRztBQUFBLE1BQUM7QUFBQSxJQUFDO0FBQUMsUUFBSVUsSUFBRTtBQUFFLFNBQUlvQixJQUFFLEdBQUVBLElBQUUzQyxFQUFFLE9BQU8sUUFBTzJDLEtBQUk7QUFBQyxVQUFJbkIsSUFBRXhCLEVBQUUsT0FBTzJDO0FBQUcsTUFBQTdCLE1BQUlMLEVBQUVZLEdBQUVSLEdBQUUsRUFBRSxHQUFFQSxLQUFHLEdBQUVELEVBQUVTLEdBQUVSLEdBQUUsTUFBTSxHQUFFQSxLQUFHLEdBQUVKLEVBQUVZLEdBQUVSLEdBQUVVLEdBQUcsR0FBRVYsS0FBRyxHQUFFSixFQUFFWSxHQUFFUixHQUFFVyxFQUFFLEtBQUssS0FBSyxHQUFFWCxLQUFHLEdBQUVKLEVBQUVZLEdBQUVSLEdBQUVXLEVBQUUsS0FBSyxNQUFNLEdBQUVYLEtBQUcsR0FBRUosRUFBRVksR0FBRVIsR0FBRVcsRUFBRSxLQUFLLENBQUMsR0FBRVgsS0FBRyxHQUFFSixFQUFFWSxHQUFFUixHQUFFVyxFQUFFLEtBQUssQ0FBQyxHQUFFWCxLQUFHLEdBQUVILEVBQUVXLEdBQUVSLEdBQUVOLEVBQUVvQyxFQUFFLEdBQUU5QixLQUFHLEdBQUVILEVBQUVXLEdBQUVSLEdBQUUsR0FBRyxHQUFFQSxLQUFHLEdBQUVRLEVBQUVSLEtBQUdXLEVBQUUsU0FBUVgsS0FBSVEsRUFBRVIsS0FBR1csRUFBRSxPQUFNWCxLQUFJSixFQUFFWSxHQUFFUixHQUFFTCxFQUFFYSxHQUFFUixJQUFFLElBQUcsRUFBRSxDQUFDLEdBQUVBLEtBQUc7QUFBRyxZQUFNOUIsSUFBRXlDLEVBQUU7QUFBSyxNQUFBZixFQUFFWSxHQUFFUixJQUFHSyxJQUFFbkMsRUFBRSxXQUFZNEQsS0FBSCxJQUFLLElBQUUsRUFBRSxHQUFFOUIsS0FBRztBQUFFLFlBQU1aLElBQUVZO0FBQUUsTUFBQUQsRUFBRVMsR0FBRVIsR0FBSzhCLEtBQUgsSUFBSyxTQUFPLE1BQU0sR0FBRTlCLEtBQUcsR0FBSzhCLEtBQUgsTUFBT2xDLEVBQUVZLEdBQUVSLEdBQUVVLEdBQUcsR0FBRVYsS0FBRyxJQUFHUSxFQUFFLElBQUl0QyxHQUFFOEIsQ0FBQyxHQUFFQSxLQUFHSyxHQUFFVCxFQUFFWSxHQUFFUixHQUFFTCxFQUFFYSxHQUFFcEIsR0FBRVksSUFBRVosQ0FBQyxDQUFDLEdBQUVZLEtBQUc7QUFBQSxJQUFDO0FBQUMsV0FBT0osRUFBRVksR0FBRVIsR0FBRSxDQUFDLEdBQUVBLEtBQUcsR0FBRUQsRUFBRVMsR0FBRVIsR0FBRSxNQUFNLEdBQUVBLEtBQUcsR0FBRUosRUFBRVksR0FBRVIsR0FBRUwsRUFBRWEsR0FBRVIsSUFBRSxHQUFFLENBQUMsQ0FBQyxHQUFFQSxLQUFHLEdBQUVRLEVBQUU7QUFBQSxFQUFNO0FBQUMsV0FBU21DLEVBQVl4RCxHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxhQUFRQyxJQUFFLEdBQUVBLElBQUVGLEVBQUUsT0FBTyxRQUFPRSxLQUFJO0FBQUMsWUFBTUUsSUFBRUosRUFBRSxPQUFPRTtBQUFHLE1BQUFFLEVBQUUsS0FBSztBQUFNLFlBQU1HLElBQUVILEVBQUUsS0FBSyxRQUFPRSxJQUFFLElBQUksV0FBV0MsSUFBRUgsRUFBRSxNQUFJRyxDQUFDO0FBQUUsTUFBQUgsRUFBRSxPQUFLMEMsRUFBWTFDLEVBQUUsS0FBSUcsR0FBRUgsRUFBRSxLQUFJQSxFQUFFLEtBQUlFLEdBQUV2QixHQUFFa0IsQ0FBQztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU3dELEVBQVMxRSxHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRTtBQUFDLFVBQU1ELElBQUVDLEVBQUUsSUFBR0MsSUFBRUQsRUFBRSxJQUFHRSxJQUFFRixFQUFFLElBQUdHLElBQUVILEVBQUUsSUFBR0ssSUFBRUwsRUFBRSxJQUFHTSxJQUFFTixFQUFFO0FBQUcsUUFBSU8sSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUU7QUFBSSxhQUFRQyxJQUFFLEdBQUVBLElBQUVsQyxFQUFFLFFBQU9rQyxLQUFJO0FBQUMsWUFBTWpCLEtBQUUsSUFBSSxXQUFXakIsRUFBRWtDLEVBQUU7QUFBRSxlQUFRQyxJQUFFbEIsR0FBRSxRQUFPb0IsSUFBRSxHQUFFQSxJQUFFRixHQUFFRSxLQUFHO0FBQUUsUUFBQUosS0FBR2hCLEdBQUVvQixJQUFFO0FBQUEsSUFBRTtBQUFDLFVBQU11QixJQUFPM0IsS0FBTCxLQUFPSyxJQUFFLFNBQWlCdEMsR0FBRWtCLEdBQUVDLElBQUVFLElBQUVHLEdBQUVELElBQUU7QUFBQyxZQUFNRSxLQUFFLENBQUE7QUFBRyxlQUFRQyxJQUFFLEdBQUVBLElBQUUxQixFQUFFLFFBQU8wQixLQUFJO0FBQUMsY0FBTUksS0FBRSxJQUFJLFdBQVc5QixFQUFFMEIsRUFBRSxHQUFFTSxLQUFFLElBQUksWUFBWUYsR0FBRSxNQUFNO0FBQUUsWUFBSUg7QUFBRSxZQUFJTSxLQUFFLEdBQUVDLEtBQUUsR0FBRUMsS0FBRWpCLEdBQUVtQixLQUFFbEIsSUFBRXlDLEtBQUV2QyxLQUFFLElBQUU7QUFBRSxZQUFNSyxLQUFILEdBQUs7QUFBQyxnQkFBTVksS0FBRWYsTUFBR0YsTUFBTUssS0FBSCxLQUFTRCxHQUFFQyxJQUFFLEdBQUcsV0FBVixJQUFrQixJQUFFO0FBQUUsY0FBSWEsS0FBRSxHQUFFQyxLQUFFO0FBQUksbUJBQVF2QixLQUFFLEdBQUVBLEtBQUVxQixJQUFFckIsTUFBSTtBQUFDLGdCQUFJWSxLQUFFLElBQUksV0FBVzdCLEVBQUUwQixJQUFFLElBQUVULEdBQUU7QUFBRSxrQkFBTUksS0FBRSxJQUFJLFlBQVlyQixFQUFFMEIsSUFBRSxJQUFFVCxHQUFFO0FBQUUsZ0JBQUlNLEtBQUVMLEdBQUVPLEtBQUVOLElBQUVRLEtBQUUsSUFBR0csS0FBRTtBQUFHLHFCQUFRYixLQUFFLEdBQUVBLEtBQUVFLElBQUVGO0FBQUksdUJBQVFqQixLQUFFLEdBQUVBLEtBQUVrQixHQUFFbEI7QUFBSyxnQkFBQWdDLEdBQUVELEtBQUVkLEtBQUVDLElBQUVsQixPQUFJcUIsR0FBRVUsUUFBSy9CLEtBQUV1QixPQUFJQSxLQUFFdkIsS0FBR0EsS0FBRTJCLE9BQUlBLEtBQUUzQixLQUFHaUIsS0FBRVEsT0FBSUEsS0FBRVIsS0FBR0EsS0FBRWEsT0FBSUEsS0FBRWI7QUFBSSxZQUFJVSxNQUFKLE9BQVFKLEtBQUVFLEtBQUVFLEtBQUVHLEtBQUUsSUFBR04sT0FBUSxJQUFFRCxPQUFOLEtBQVVBLE9BQVEsSUFBRUUsT0FBTixLQUFVQTtBQUFLLGtCQUFNbUMsTUFBR2pDLEtBQUVKLEtBQUUsTUFBSU8sS0FBRUwsS0FBRTtBQUFHLFlBQUFtQyxLQUFFcEIsT0FBSUEsS0FBRW9CLElBQUVyQixLQUFFdEIsSUFBRWdCLEtBQUVWLElBQUVXLEtBQUVULElBQUVVLEtBQUVSLEtBQUVKLEtBQUUsR0FBRWMsS0FBRVAsS0FBRUwsS0FBRTtBQUFBLFVBQUU7QUFBQyxVQUFBSSxLQUFFLElBQUksV0FBVzdCLEVBQUUwQixJQUFFLElBQUVhLEdBQUUsR0FBS0EsTUFBSCxNQUFPZCxHQUFFQyxJQUFFLEdBQUcsVUFBUSxJQUFHQyxLQUFFLElBQUksV0FBV1EsS0FBRUUsS0FBRSxDQUFDLEdBQUVwQixFQUFFWSxJQUFFWCxHQUFFQyxJQUFFUSxJQUFFUSxJQUFFRSxJQUFFLENBQUNKLElBQUUsQ0FBQ0MsSUFBRSxDQUFDLEdBQUUwQixLQUFFM0MsRUFBRWEsSUFBRVosR0FBRUMsSUFBRVEsSUFBRVEsSUFBRUUsSUFBRSxDQUFDSixJQUFFLENBQUNDLElBQUUsQ0FBQyxJQUFFLElBQUUsR0FBSzBCLE1BQUgsSUFBS2UsRUFBYTdDLElBQUVaLEdBQUVDLElBQUVRLElBQUUsRUFBQyxHQUFFTSxJQUFFLEdBQUVDLElBQUUsT0FBTUMsSUFBRSxRQUFPRSxHQUFDLENBQUMsSUFBRXBCLEVBQUVhLElBQUVaLEdBQUVDLElBQUVRLElBQUVRLElBQUVFLElBQUUsQ0FBQ0osSUFBRSxDQUFDQyxJQUFFLENBQUM7QUFBQSxRQUFDO0FBQU0sVUFBQVAsS0FBRUcsR0FBRSxNQUFNLENBQUM7QUFBRSxRQUFBTCxHQUFFLEtBQUssRUFBQyxNQUFLLEVBQUMsR0FBRVEsSUFBRSxHQUFFQyxJQUFFLE9BQU1DLElBQUUsUUFBT0UsR0FBQyxHQUFFLEtBQUlWLElBQUUsT0FBTWlDLElBQUUsU0FBUSxFQUFDLENBQUM7QUFBQSxNQUFDO0FBQUMsVUFBR3ZDO0FBQUUsYUFBSUssSUFBRSxHQUFFQSxJQUFFRCxHQUFFLFFBQU9DLEtBQUk7QUFBQyxlQUFPTSxLQUFFUCxHQUFFQyxJQUFJLFNBQVo7QUFBa0I7QUFBUyxnQkFBTVQsS0FBRWUsR0FBRSxNQUFLWCxLQUFFSSxHQUFFQyxJQUFFLEdBQUcsTUFBS0gsS0FBRSxLQUFLLElBQUlOLEdBQUUsR0FBRUksR0FBRSxDQUFDLEdBQUVNLEtBQUUsS0FBSyxJQUFJVixHQUFFLEdBQUVJLEdBQUUsQ0FBQyxHQUFFUSxLQUFFLEVBQUMsR0FBRU4sSUFBRSxHQUFFSSxJQUFFLE9BQU0sS0FBSyxJQUFJVixHQUFFLElBQUVBLEdBQUUsT0FBTUksR0FBRSxJQUFFQSxHQUFFLEtBQUssSUFBRUUsSUFBRSxRQUFPLEtBQUssSUFBSU4sR0FBRSxJQUFFQSxHQUFFLFFBQU9JLEdBQUUsSUFBRUEsR0FBRSxNQUFNLElBQUVNLEdBQUM7QUFBRSxVQUFBRixHQUFFQyxJQUFFLEdBQUcsVUFBUSxHQUFFQSxJQUFFLEtBQUcsS0FBR2tELEVBQWE1RSxHQUFFa0IsR0FBRUMsSUFBRU0sSUFBRUMsSUFBRSxHQUFFRyxJQUFFTCxDQUFDLEdBQUVvRCxFQUFhNUUsR0FBRWtCLEdBQUVDLElBQUVNLElBQUVDLEdBQUVHLElBQUVMLENBQUM7QUFBQSxRQUFDO0FBQUMsVUFBSU0sS0FBRTtBQUFFLFVBQU05QixFQUFFLFVBQUw7QUFBWSxpQkFBUStCLEtBQUUsR0FBRUEsS0FBRU4sR0FBRSxRQUFPTSxNQUFJO0FBQUMsY0FBSUM7QUFBRSxVQUFBRixPQUFJRSxLQUFFUCxHQUFFTSxLQUFJLEtBQUssUUFBTUMsR0FBRSxLQUFLO0FBQUEsUUFBTTtBQUFDLGFBQU9QO0FBQUEsSUFBQyxFQUFFekIsR0FBRWtCLEdBQUVDLEdBQUVJLEdBQUVFLEdBQUVDLENBQUMsR0FBRWEsSUFBRSxDQUFFLEdBQUNDLElBQUUsQ0FBRSxHQUFDQyxJQUFFLENBQUU7QUFBQyxRQUFNcEIsS0FBSCxHQUFLO0FBQUMsWUFBTUosS0FBRSxDQUFBO0FBQUcsV0FBSW9CLElBQUUsR0FBRUEsSUFBRUMsRUFBRSxRQUFPRDtBQUFJLFFBQUFwQixHQUFFLEtBQUtxQixFQUFFRCxHQUFHLElBQUksTUFBTTtBQUFFLFlBQU1yQyxJQUFFLFNBQW9CaUIsR0FBRTtBQUFDLFlBQUlqQixLQUFFO0FBQUUsaUJBQVFrQixLQUFFLEdBQUVBLEtBQUVELEVBQUUsUUFBT0M7QUFBSSxVQUFBbEIsTUFBR2lCLEVBQUVDLElBQUc7QUFBVyxjQUFNQyxJQUFFLElBQUksV0FBV25CLEVBQUM7QUFBRSxZQUFJcUIsS0FBRTtBQUFFLGFBQUlILEtBQUUsR0FBRUEsS0FBRUQsRUFBRSxRQUFPQyxNQUFJO0FBQUMsZ0JBQU1sQixLQUFFLElBQUksV0FBV2lCLEVBQUVDLEdBQUUsR0FBRU0sS0FBRXhCLEdBQUU7QUFBTyxtQkFBUWlCLEtBQUUsR0FBRUEsS0FBRU8sSUFBRVAsTUFBRyxHQUFFO0FBQUMsZ0JBQUlDLEtBQUVsQixHQUFFaUIsS0FBR08sS0FBRXhCLEdBQUVpQixLQUFFLElBQUdNLEtBQUV2QixHQUFFaUIsS0FBRTtBQUFHLGtCQUFNUSxLQUFFekIsR0FBRWlCLEtBQUU7QUFBRyxZQUFHUSxNQUFILE1BQU9QLEtBQUVNLEtBQUVELEtBQUUsSUFBR0osRUFBRUUsS0FBRUosTUFBR0MsSUFBRUMsRUFBRUUsS0FBRUosS0FBRSxLQUFHTyxJQUFFTCxFQUFFRSxLQUFFSixLQUFFLEtBQUdNLElBQUVKLEVBQUVFLEtBQUVKLEtBQUUsS0FBR1E7QUFBQSxVQUFDO0FBQUMsVUFBQUosTUFBR0c7QUFBQSxRQUFDO0FBQUMsZUFBT0wsRUFBRTtBQUFBLE1BQU0sRUFBRUYsRUFBQyxHQUFFQyxJQUFFMkQsRUFBUzdFLEdBQUVxQixDQUFDO0FBQUUsV0FBSWdCLElBQUUsR0FBRUEsSUFBRW5CLEVBQUUsS0FBSyxRQUFPbUI7QUFBSSxRQUFBRyxFQUFFLEtBQUt0QixFQUFFLEtBQUttQixHQUFHLElBQUksSUFBSTtBQUFFLFVBQUlsQixLQUFFO0FBQUUsV0FBSWtCLElBQUUsR0FBRUEsSUFBRUMsRUFBRSxRQUFPRCxLQUFJO0FBQUMsY0FBTXBCLE1BQUd5QixJQUFFSixFQUFFRCxJQUFJLElBQUk7QUFBTyxZQUFJRCxJQUFFLElBQUksV0FBV2xCLEVBQUUsS0FBSyxRQUFPQyxNQUFHLEdBQUVGLE1BQUcsQ0FBQztBQUFFLFFBQUF3QixFQUFFLEtBQUtMLENBQUM7QUFBRSxjQUFNcEMsSUFBRSxJQUFJLFdBQVdrQixFQUFFLE1BQUtDLElBQUVGLEVBQUM7QUFBRSxRQUFBYSxLQUFHeUMsRUFBTzdCLEVBQUUsS0FBSUEsRUFBRSxLQUFLLE9BQU1BLEVBQUUsS0FBSyxRQUFPRixHQUFFeEMsR0FBRW9DLENBQUMsR0FBRU0sRUFBRSxJQUFJLElBQUkxQyxDQUFDLEdBQUVtQixNQUFHRjtBQUFBLE1BQUM7QUFBQSxJQUFDO0FBQU0sV0FBSWlCLElBQUUsR0FBRUEsSUFBRUksRUFBRSxRQUFPSixLQUFJO0FBQUMsWUFBSVEsSUFBRUosRUFBRUo7QUFBRyxjQUFNakIsS0FBRSxJQUFJLFlBQVl5QixFQUFFLElBQUksTUFBTTtBQUFFLFlBQUlDLEtBQUVELEVBQUUsS0FBSztBQUErQyxhQUF6Q1AsSUFBRWxCLEdBQUUsUUFBT21CLElBQUUsSUFBSSxXQUFXRCxDQUFDLEdBQUVNLEVBQUUsS0FBS0wsQ0FBQyxHQUFNQyxJQUFFLEdBQUVBLElBQUVGLEdBQUVFLEtBQUk7QUFBQyxnQkFBTXJDLElBQUVpQixHQUFFb0I7QUFBRyxjQUFNQSxLQUFILEtBQU1yQyxLQUFHaUIsR0FBRW9CLElBQUU7QUFBRyxZQUFBRCxFQUFFQyxLQUFHRCxFQUFFQyxJQUFFO0FBQUEsbUJBQVdBLElBQUVNLE1BQUczQyxLQUFHaUIsR0FBRW9CLElBQUVNO0FBQUcsWUFBQVAsRUFBRUMsS0FBR0QsRUFBRUMsSUFBRU07QUFBQSxlQUFPO0FBQUMsZ0JBQUkxQixJQUFFc0IsRUFBRXZDO0FBQUcsZ0JBQVNpQixLQUFOLFNBQVVzQixFQUFFdkMsS0FBR2lCLElBQUV1QixFQUFFLFFBQU9BLEVBQUUsS0FBS3hDLENBQUMsR0FBRXdDLEVBQUUsVUFBUTtBQUFLO0FBQU0sWUFBQUosRUFBRUMsS0FBR3BCO0FBQUEsVUFBQztBQUFBLFFBQUM7QUFBQSxNQUFDO0FBQUMsVUFBTTJCLEtBQUVKLEVBQUU7QUFBaUUsU0FBMURJLE1BQUcsT0FBUWYsS0FBSCxNQUFPRyxJQUFFWSxNQUFHLElBQUUsSUFBRUEsTUFBRyxJQUFFLElBQUVBLE1BQUcsS0FBRyxJQUFFLEdBQUVaLElBQUUsS0FBSyxJQUFJQSxHQUFFTCxDQUFDLElBQU9PLElBQUUsR0FBRUEsSUFBRUksRUFBRSxRQUFPSixLQUFJO0FBQUMsT0FBQ1EsSUFBRUosRUFBRUosSUFBSSxLQUFLLEdBQUVRLEVBQUUsS0FBSyxHQUFFQyxLQUFFRCxFQUFFLEtBQUs7QUFBTSxZQUFNekIsS0FBRXlCLEVBQUUsS0FBSztBQUFPLFVBQUkxQyxJQUFFMEMsRUFBRTtBQUFJLFVBQUksWUFBWTFDLEVBQUUsTUFBTTtBQUFFLFVBQUlrQixJQUFFLElBQUV5QixJQUFFeEIsS0FBRTtBQUFFLFVBQUd5QixNQUFHLE9BQVFmLEtBQUgsR0FBSztBQUFDLFFBQUFYLElBQUUsS0FBSyxLQUFLYyxJQUFFVyxLQUFFLENBQUM7QUFBRSxZQUFJRSxLQUFFLElBQUksV0FBVzNCLElBQUVELEVBQUM7QUFBRSxjQUFNSSxLQUFFb0IsRUFBRVA7QUFBRyxpQkFBUWxDLElBQUUsR0FBRUEsSUFBRWlCLElBQUVqQixLQUFJO0FBQUMsVUFBQXFDLElBQUVyQyxJQUFFa0I7QUFBRSxnQkFBTUQsS0FBRWpCLElBQUUyQztBQUFFLGNBQU1YLEtBQUg7QUFBSyxxQkFBUWMsSUFBRSxHQUFFQSxJQUFFSCxJQUFFRztBQUFJLGNBQUFELEdBQUVSLElBQUVTLEtBQUd6QixHQUFFSixLQUFFNkI7QUFBQSxtQkFBY2QsS0FBSDtBQUFLLGlCQUFJYyxJQUFFLEdBQUVBLElBQUVILElBQUVHO0FBQUksY0FBQUQsR0FBRVIsS0FBR1MsS0FBRyxPQUFLekIsR0FBRUosS0FBRTZCLE1BQUksSUFBRSxLQUFHLElBQUVBO0FBQUEsbUJBQWNkLEtBQUg7QUFBSyxpQkFBSWMsSUFBRSxHQUFFQSxJQUFFSCxJQUFFRztBQUFJLGNBQUFELEdBQUVSLEtBQUdTLEtBQUcsT0FBS3pCLEdBQUVKLEtBQUU2QixNQUFJLElBQUUsS0FBRyxJQUFFQTtBQUFBLG1CQUFjZCxLQUFIO0FBQUssaUJBQUljLElBQUUsR0FBRUEsSUFBRUgsSUFBRUc7QUFBSSxjQUFBRCxHQUFFUixLQUFHUyxLQUFHLE9BQUt6QixHQUFFSixLQUFFNkIsTUFBSSxJQUFFLEtBQUcsSUFBRUE7QUFBQSxRQUFFO0FBQUMsUUFBQTlDLElBQUU2QyxJQUFFZCxJQUFFLEdBQUVaLEtBQUU7QUFBQSxNQUFDLFdBQVl5QyxLQUFILEtBQVN0QixFQUFFLFVBQUwsR0FBWTtBQUFDLFFBQUFPLEtBQUUsSUFBSSxXQUFXRixLQUFFMUIsS0FBRSxDQUFDO0FBQUUsY0FBTUksS0FBRXNCLEtBQUUxQjtBQUFFLGFBQUlvQixJQUFFLEdBQUVBLElBQUVoQixJQUFFZ0IsS0FBSTtBQUFDLGdCQUFNcEIsSUFBRSxJQUFFb0IsR0FBRW5CLEtBQUUsSUFBRW1CO0FBQUUsVUFBQVEsR0FBRTVCLEtBQUdqQixFQUFFa0IsS0FBRzJCLEdBQUU1QixJQUFFLEtBQUdqQixFQUFFa0IsS0FBRSxJQUFHMkIsR0FBRTVCLElBQUUsS0FBR2pCLEVBQUVrQixLQUFFO0FBQUEsUUFBRTtBQUFDLFFBQUFsQixJQUFFNkMsSUFBRWQsSUFBRSxHQUFFWixLQUFFLEdBQUVELElBQUUsSUFBRXlCO0FBQUEsTUFBQztBQUFDLE1BQUFELEVBQUUsTUFBSTFDLEdBQUUwQyxFQUFFLE1BQUl4QixHQUFFd0IsRUFBRSxNQUFJdkI7QUFBQSxJQUFDO0FBQUMsV0FBTSxFQUFDLE9BQU1ZLEdBQUUsT0FBTUMsR0FBRSxNQUFLUSxHQUFFLFFBQU9GLEVBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU3NDLEVBQWE1RSxHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRUQsR0FBRUUsR0FBRTtBQUFDLFVBQU1DLElBQUUsWUFBV0MsSUFBRSxhQUFZRSxJQUFFLElBQUlILEVBQUUxQixFQUFFd0IsSUFBRSxFQUFFLEdBQUVNLElBQUUsSUFBSUgsRUFBRTNCLEVBQUV3QixJQUFFLEVBQUUsR0FBRU8sSUFBRVAsSUFBRSxJQUFFeEIsRUFBRSxTQUFPLElBQUkwQixFQUFFMUIsRUFBRXdCLElBQUUsRUFBRSxJQUFFLE1BQUtRLElBQUUsSUFBSU4sRUFBRTFCLEVBQUV3QixFQUFFLEdBQUVTLElBQUUsSUFBSU4sRUFBRUssRUFBRSxNQUFNO0FBQUUsUUFBSUUsSUFBRWhCLEdBQUVpQixJQUFFaEIsR0FBRWtCLElBQUUsSUFBR3VCLElBQUU7QUFBRyxhQUFRM0MsSUFBRSxHQUFFQSxJQUFFTSxFQUFFLFFBQU9OO0FBQUksZUFBUWpCLElBQUUsR0FBRUEsSUFBRXVCLEVBQUUsT0FBTXZCLEtBQUk7QUFBQyxjQUFNbUIsSUFBRUksRUFBRSxJQUFFdkIsR0FBRXlCLElBQUVGLEVBQUUsSUFBRU4sR0FBRVMsSUFBRUQsSUFBRVAsSUFBRUMsR0FBRVEsS0FBRU0sRUFBRVA7QUFBRyxRQUFHQyxNQUFILEtBQVNOLEVBQUVHLElBQUUsR0FBRyxXQUFWLEtBQW1CTSxFQUFFSixNQUFJQyxPQUFVSSxLQUFOLFFBQVlBLEVBQUUsSUFBRUwsSUFBRSxNQUFULE9BQWVQLElBQUVlLE1BQUlBLElBQUVmLElBQUdBLElBQUVrQixNQUFJQSxJQUFFbEIsSUFBR00sSUFBRVUsTUFBSUEsSUFBRVYsSUFBR0EsSUFBRW1DLE1BQUlBLElBQUVuQztBQUFBLE1BQUc7QUFBQyxJQUFJWSxLQUFKLE9BQVFILElBQUVDLElBQUVFLElBQUV1QixJQUFFLElBQUduQyxPQUFRLElBQUVTLE1BQU4sS0FBVUEsTUFBUSxJQUFFQyxNQUFOLEtBQVVBLE1BQUtaLElBQUUsRUFBQyxHQUFFVyxHQUFFLEdBQUVDLEdBQUUsT0FBTUUsSUFBRUgsSUFBRSxHQUFFLFFBQU8wQixJQUFFekIsSUFBRSxFQUFDO0FBQUUsVUFBTUcsSUFBRWpCLEVBQUVHO0FBQUcsSUFBQWMsRUFBRSxPQUFLZixHQUFFZSxFQUFFLFFBQU0sR0FBRUEsRUFBRSxNQUFJLElBQUksV0FBV2YsRUFBRSxRQUFNQSxFQUFFLFNBQU8sQ0FBQyxHQUFLRixFQUFFRyxJQUFFLEdBQUcsV0FBVixLQUFtQlAsRUFBRVksR0FBRVgsR0FBRUMsR0FBRW1CLEVBQUUsS0FBSWYsRUFBRSxPQUFNQSxFQUFFLFFBQU8sQ0FBQ0EsRUFBRSxHQUFFLENBQUNBLEVBQUUsR0FBRSxDQUFDLEdBQUVvRCxFQUFhM0MsR0FBRWQsR0FBRUMsR0FBRW1CLEVBQUUsS0FBSWYsQ0FBQyxLQUFHTixFQUFFZSxHQUFFZCxHQUFFQyxHQUFFbUIsRUFBRSxLQUFJZixFQUFFLE9BQU1BLEVBQUUsUUFBTyxDQUFDQSxFQUFFLEdBQUUsQ0FBQ0EsRUFBRSxHQUFFLENBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU29ELEVBQWEzRSxHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRTtBQUFDLElBQUFQLEVBQUVqQixHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsRUFBRSxPQUFNQSxFQUFFLFFBQU8sQ0FBQ0EsRUFBRSxHQUFFLENBQUNBLEVBQUUsR0FBRSxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVN1QyxFQUFZOUMsR0FBRWpCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFRyxHQUFFRCxHQUFFO0FBQUMsVUFBTUUsSUFBRSxDQUFBO0FBQUcsUUFBSUMsR0FBRUMsSUFBRSxDQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQztBQUFFLElBQUlILEtBQUosS0FBTUcsSUFBRSxDQUFDSCxDQUFDLEtBQUd4QixJQUFFbUIsSUFBRSxPQUFRRCxLQUFILE9BQVFTLElBQUUsQ0FBQyxDQUFDLElBQUdKLE1BQUlHLElBQUUsRUFBQyxPQUFNLEVBQUM7QUFBRyxVQUFNRyxJQUFFRDtBQUFLLGFBQVFFLElBQUUsR0FBRUEsSUFBRUgsRUFBRSxRQUFPRyxLQUFJO0FBQUMsZUFBUU4sSUFBRSxHQUFFQSxJQUFFeEIsR0FBRXdCO0FBQUksUUFBQXNELEVBQVl6RCxHQUFFSixHQUFFTyxHQUFFTCxHQUFFRCxHQUFFUyxFQUFFRyxFQUFFO0FBQUUsTUFBQUwsRUFBRSxLQUFLSSxFQUFFLFFBQVFSLEdBQUVLLENBQUMsQ0FBQztBQUFBLElBQUM7QUFBQyxRQUFJSyxHQUFFQyxJQUFFO0FBQUksU0FBSUYsSUFBRSxHQUFFQSxJQUFFTCxFQUFFLFFBQU9LO0FBQUksTUFBQUwsRUFBRUssR0FBRyxTQUFPRSxNQUFJRCxJQUFFRCxHQUFFRSxJQUFFUCxFQUFFSyxHQUFHO0FBQVEsV0FBT0wsRUFBRU07QUFBQSxFQUFFO0FBQUMsV0FBUytDLEVBQVk3RCxHQUFFakIsR0FBRW1CLEdBQUVFLEdBQUVHLEdBQUVELEdBQUU7QUFBQyxVQUFNRSxJQUFFTixJQUFFRTtBQUFFLFFBQUlLLElBQUVELElBQUVOO0FBQUUsUUFBR0YsRUFBRVMsS0FBR0gsR0FBRUcsS0FBT0gsS0FBSDtBQUFLLFVBQUdGLElBQUU7QUFBSSxpQkFBUU0sSUFBRSxHQUFFQSxJQUFFTixHQUFFTTtBQUFJLFVBQUFWLEVBQUVTLElBQUVDLEtBQUczQixFQUFFeUIsSUFBRUU7QUFBQTtBQUFRLFFBQUFWLEVBQUUsSUFBSSxJQUFJLFdBQVdqQixFQUFFLFFBQU95QixHQUFFSixDQUFDLEdBQUVLLENBQUM7QUFBQSxhQUFhSCxLQUFILEdBQUs7QUFBQyxXQUFJSSxJQUFFLEdBQUVBLElBQUVILEdBQUVHO0FBQUksUUFBQVYsRUFBRVMsSUFBRUMsS0FBRzNCLEVBQUV5QixJQUFFRTtBQUFHLFdBQUlBLElBQUVILEdBQUVHLElBQUVOLEdBQUVNO0FBQUksUUFBQVYsRUFBRVMsSUFBRUMsS0FBRzNCLEVBQUV5QixJQUFFRSxLQUFHM0IsRUFBRXlCLElBQUVFLElBQUVILEtBQUcsTUFBSTtBQUFBLElBQUcsV0FBWUwsS0FBSCxHQUFLO0FBQUMsV0FBSVEsSUFBRSxHQUFFQSxJQUFFSCxHQUFFRztBQUFJLFFBQUFWLEVBQUVTLElBQUVDLEtBQUczQixFQUFFeUIsSUFBRUU7QUFBRyxVQUFNSixLQUFIO0FBQUssYUFBSUksSUFBRUgsR0FBRUcsSUFBRU4sR0FBRU07QUFBSSxVQUFBVixFQUFFUyxJQUFFQyxLQUFHM0IsRUFBRXlCLElBQUVFO0FBQUcsVUFBTUosS0FBSDtBQUFLLGFBQUlJLElBQUVILEdBQUVHLElBQUVOLEdBQUVNO0FBQUksVUFBQVYsRUFBRVMsSUFBRUMsS0FBRzNCLEVBQUV5QixJQUFFRSxNQUFJM0IsRUFBRXlCLElBQUVFLElBQUVILE1BQUksS0FBRyxNQUFJO0FBQUksVUFBTUQsS0FBSDtBQUFLLGFBQUlJLElBQUVILEdBQUVHLElBQUVOLEdBQUVNO0FBQUksVUFBQVYsRUFBRVMsSUFBRUMsS0FBRzNCLEVBQUV5QixJQUFFRSxLQUFHVCxFQUFFbEIsRUFBRXlCLElBQUVFLElBQUVILElBQUcsR0FBRSxDQUFDLElBQUUsTUFBSTtBQUFBLElBQUcsT0FBSztBQUFDLFVBQU1ELEtBQUg7QUFBSyxhQUFJSSxJQUFFLEdBQUVBLElBQUVOLEdBQUVNO0FBQUksVUFBQVYsRUFBRVMsSUFBRUMsS0FBRzNCLEVBQUV5QixJQUFFRSxLQUFHLE1BQUkzQixFQUFFeUIsSUFBRUUsSUFBRU4sS0FBRztBQUFJLFVBQU1FLEtBQUgsR0FBSztBQUFDLGFBQUlJLElBQUUsR0FBRUEsSUFBRUgsR0FBRUc7QUFBSSxVQUFBVixFQUFFUyxJQUFFQyxLQUFHM0IsRUFBRXlCLElBQUVFLEtBQUcsT0FBSzNCLEVBQUV5QixJQUFFRSxJQUFFTixNQUFJLEtBQUc7QUFBSSxhQUFJTSxJQUFFSCxHQUFFRyxJQUFFTixHQUFFTTtBQUFJLFVBQUFWLEVBQUVTLElBQUVDLEtBQUczQixFQUFFeUIsSUFBRUUsS0FBRyxPQUFLM0IsRUFBRXlCLElBQUVFLElBQUVOLEtBQUdyQixFQUFFeUIsSUFBRUUsSUFBRUgsTUFBSSxLQUFHO0FBQUEsTUFBRztBQUFDLFVBQU1ELEtBQUgsR0FBSztBQUFDLGFBQUlJLElBQUUsR0FBRUEsSUFBRUgsR0FBRUc7QUFBSSxVQUFBVixFQUFFUyxJQUFFQyxLQUFHM0IsRUFBRXlCLElBQUVFLEtBQUcsTUFBSVQsRUFBRSxHQUFFbEIsRUFBRXlCLElBQUVFLElBQUVOLElBQUcsQ0FBQyxJQUFFO0FBQUksYUFBSU0sSUFBRUgsR0FBRUcsSUFBRU4sR0FBRU07QUFBSSxVQUFBVixFQUFFUyxJQUFFQyxLQUFHM0IsRUFBRXlCLElBQUVFLEtBQUcsTUFBSVQsRUFBRWxCLEVBQUV5QixJQUFFRSxJQUFFSCxJQUFHeEIsRUFBRXlCLElBQUVFLElBQUVOLElBQUdyQixFQUFFeUIsSUFBRUUsSUFBRUgsSUFBRUgsRUFBRSxJQUFFO0FBQUEsTUFBRztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU3dELEVBQVM1RCxHQUFFakIsR0FBRTtBQUFDLFVBQU1rQixJQUFFLElBQUksV0FBV0QsQ0FBQyxHQUFFRSxJQUFFRCxFQUFFLE1BQU0sQ0FBQyxHQUFFRyxJQUFFLElBQUksWUFBWUYsRUFBRSxNQUFNLEdBQUVLLElBQUV1RCxFQUFVNUQsR0FBRW5CLENBQUMsR0FBRXVCLElBQUVDLEVBQUUsSUFBR0MsSUFBRUQsRUFBRSxJQUFHRSxJQUFFUixFQUFFLFFBQU9TLElBQUUsSUFBSSxXQUFXRCxLQUFHLENBQUM7QUFBRSxRQUFJRztBQUFFLFFBQUdYLEVBQUUsU0FBTztBQUFJLGVBQVFZLElBQUUsR0FBRUEsSUFBRUosR0FBRUksS0FBRztBQUFHLFFBQUFELElBQUVtRCxFQUFXekQsR0FBRVEsSUFBRWIsRUFBRVksTUFBSSxJQUFFLE1BQUtFLElBQUVkLEVBQUVZLElBQUUsTUFBSSxJQUFFLE1BQUtHLElBQUVmLEVBQUVZLElBQUUsTUFBSSxJQUFFLE1BQUtJLElBQUVoQixFQUFFWSxJQUFFLE1BQUksSUFBRSxJQUFJLEdBQUVILEVBQUVHLEtBQUcsS0FBR0QsRUFBRSxLQUFJUixFQUFFUyxLQUFHLEtBQUdELEVBQUUsSUFBSTtBQUFBO0FBQVUsV0FBSUMsSUFBRSxHQUFFQSxJQUFFSixHQUFFSSxLQUFHLEdBQUU7QUFBQyxZQUFJQyxJQUFFYixFQUFFWSxLQUFJLHFCQUFPRSxJQUFFZCxFQUFFWSxJQUFFLE1BQUksSUFBRSxNQUFLRyxJQUFFZixFQUFFWSxJQUFFLE1BQUksSUFBRSxNQUFLSSxJQUFFaEIsRUFBRVksSUFBRSxNQUFJLElBQUU7QUFBSyxhQUFJRCxJQUFFTixHQUFFTSxFQUFFO0FBQU0sVUFBQUEsSUFBRW9ELEVBQVNwRCxFQUFFLEtBQUlFLEdBQUVDLEdBQUVDLEdBQUVDLENBQUMsS0FBRyxJQUFFTCxFQUFFLE9BQUtBLEVBQUU7QUFBTSxRQUFBRixFQUFFRyxLQUFHLEtBQUdELEVBQUUsS0FBSVIsRUFBRVMsS0FBRyxLQUFHRCxFQUFFLElBQUk7QUFBQSxNQUFJO0FBQUMsV0FBTSxFQUFDLE1BQUtWLEVBQUUsUUFBTyxNQUFLUSxHQUFFLE1BQUtGLEVBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU3NELEVBQVU5RCxHQUFFakIsR0FBRWtCLEdBQUU7QUFBQyxJQUFNQSxLQUFOLFNBQVVBLElBQUU7QUFBTSxVQUFNQyxJQUFFLElBQUksWUFBWUYsRUFBRSxNQUFNLEdBQUVJLElBQUUsRUFBQyxJQUFHLEdBQUUsSUFBR0osRUFBRSxRQUFPLEtBQUksTUFBSyxLQUFJLE1BQUssTUFBSyxHQUFFLE1BQUssTUFBSyxPQUFNLEtBQUk7QUFBRSxJQUFBSSxFQUFFLE1BQUk2RCxFQUFNakUsR0FBRUksRUFBRSxJQUFHQSxFQUFFLEVBQUUsR0FBRUEsRUFBRSxNQUFJOEQsRUFBTzlELEVBQUUsR0FBRztBQUFFLFVBQU1HLElBQUUsQ0FBQ0gsQ0FBQztBQUFFLFdBQUtHLEVBQUUsU0FBT3hCLEtBQUc7QUFBQyxVQUFJQSxJQUFFLEdBQUVxQixJQUFFO0FBQUUsZUFBUUUsSUFBRSxHQUFFQSxJQUFFQyxFQUFFLFFBQU9EO0FBQUksUUFBQUMsRUFBRUQsR0FBRyxJQUFJLElBQUV2QixNQUFJQSxJQUFFd0IsRUFBRUQsR0FBRyxJQUFJLEdBQUVGLElBQUVFO0FBQUcsVUFBR3ZCLElBQUVrQjtBQUFFO0FBQU0sWUFBTSxJQUFFTSxFQUFFSCxJQUFHSyxJQUFFMEQsRUFBWW5FLEdBQUVFLEdBQUUsRUFBRSxJQUFHLEVBQUUsSUFBRyxFQUFFLElBQUksR0FBRSxFQUFFLElBQUksTUFBTTtBQUFFLFVBQUcsRUFBRSxNQUFJTyxLQUFHLEVBQUUsTUFBSUEsR0FBRTtBQUFDLFVBQUUsSUFBSSxJQUFFO0FBQUU7QUFBQSxNQUFRO0FBQUMsWUFBTUMsSUFBRSxFQUFDLElBQUcsRUFBRSxJQUFHLElBQUdELEdBQUUsS0FBSSxNQUFLLEtBQUksTUFBSyxNQUFLLEdBQUUsTUFBSyxNQUFLLE9BQU0sS0FBSTtBQUFFLE1BQUFDLEVBQUUsTUFBSXVELEVBQU1qRSxHQUFFVSxFQUFFLElBQUdBLEVBQUUsRUFBRSxHQUFFQSxFQUFFLE1BQUl3RCxFQUFPeEQsRUFBRSxHQUFHO0FBQUUsWUFBTUUsSUFBRSxFQUFDLElBQUdILEdBQUUsSUFBRyxFQUFFLElBQUcsS0FBSSxNQUFLLEtBQUksTUFBSyxNQUFLLEdBQUUsTUFBSyxNQUFLLE9BQU0sS0FBSTtBQUFzQyxXQUFwQ0csRUFBRSxNQUFJLEVBQUMsR0FBRSxDQUFFLEdBQUMsR0FBRSxDQUFFLEdBQUMsR0FBRSxFQUFFLElBQUksSUFBRUYsRUFBRSxJQUFJLEVBQUMsR0FBTUosSUFBRSxHQUFFQSxJQUFFLElBQUdBO0FBQUksUUFBQU0sRUFBRSxJQUFJLEVBQUVOLEtBQUcsRUFBRSxJQUFJLEVBQUVBLEtBQUdJLEVBQUUsSUFBSSxFQUFFSjtBQUFHLFdBQUlBLElBQUUsR0FBRUEsSUFBRSxHQUFFQTtBQUFJLFFBQUFNLEVBQUUsSUFBSSxFQUFFTixLQUFHLEVBQUUsSUFBSSxFQUFFQSxLQUFHSSxFQUFFLElBQUksRUFBRUo7QUFBRyxNQUFBTSxFQUFFLE1BQUlzRCxFQUFPdEQsRUFBRSxHQUFHLEdBQUUsRUFBRSxPQUFLRixHQUFFLEVBQUUsUUFBTUUsR0FBRUwsRUFBRUgsS0FBR00sR0FBRUgsRUFBRSxLQUFLSyxDQUFDO0FBQUEsSUFBQztBQUFrQyxTQUFqQ0wsRUFBRSxLQUFNLENBQUNQLEdBQUVqQixNQUFJQSxFQUFFLElBQUksSUFBRWlCLEVBQUUsSUFBSSxDQUFDLEdBQU9NLElBQUUsR0FBRUEsSUFBRUMsRUFBRSxRQUFPRDtBQUFJLE1BQUFDLEVBQUVELEdBQUcsTUFBSUE7QUFBRSxXQUFNLENBQUNGLEdBQUVHLENBQUM7QUFBQSxFQUFDO0FBQUMsV0FBU3dELEVBQVcvRCxHQUFFakIsR0FBRWtCLEdBQUVDLEdBQUVFLEdBQUU7QUFBQyxRQUFTSixFQUFFLFFBQVI7QUFBYSxhQUFPQSxFQUFFLE9BQUssU0FBY0EsR0FBRWpCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFO0FBQUMsY0FBTUcsSUFBRXhCLElBQUVpQixFQUFFLElBQUdNLElBQUVMLElBQUVELEVBQUUsSUFBR1EsSUFBRU4sSUFBRUYsRUFBRSxJQUFHUyxJQUFFTCxJQUFFSixFQUFFO0FBQUcsZUFBT08sSUFBRUEsSUFBRUQsSUFBRUEsSUFBRUUsSUFBRUEsSUFBRUMsSUFBRUE7QUFBQSxNQUFDLEVBQUVULEVBQUUsSUFBSSxHQUFFakIsR0FBRWtCLEdBQUVDLEdBQUVFLENBQUMsR0FBRUo7QUFBRSxVQUFNTyxJQUFFeUQsRUFBU2hFLEVBQUUsS0FBSWpCLEdBQUVrQixHQUFFQyxHQUFFRSxDQUFDO0FBQUUsUUFBSUUsSUFBRU4sRUFBRSxNQUFLUSxJQUFFUixFQUFFO0FBQU0sSUFBQU8sSUFBRSxNQUFJRCxJQUFFTixFQUFFLE9BQU1RLElBQUVSLEVBQUU7QUFBTSxVQUFNUyxJQUFFc0QsRUFBV3pELEdBQUV2QixHQUFFa0IsR0FBRUMsR0FBRUUsQ0FBQztBQUFFLFFBQUdLLEVBQUUsUUFBTUYsSUFBRUE7QUFBRSxhQUFPRTtBQUFFLFVBQU1DLElBQUVxRCxFQUFXdkQsR0FBRXpCLEdBQUVrQixHQUFFQyxHQUFFRSxDQUFDO0FBQUUsV0FBT00sRUFBRSxPQUFLRCxFQUFFLE9BQUtDLElBQUVEO0FBQUEsRUFBQztBQUFDLFdBQVN1RCxFQUFTaEUsR0FBRWpCLEdBQUVrQixHQUFFQyxHQUFFRSxHQUFFO0FBQUMsVUFBSyxFQUFDLEdBQUVHLEVBQUMsSUFBRVA7QUFBRSxXQUFPTyxFQUFFLEtBQUd4QixJQUFFd0IsRUFBRSxLQUFHTixJQUFFTSxFQUFFLEtBQUdMLElBQUVLLEVBQUUsS0FBR0gsSUFBRUosRUFBRTtBQUFBLEVBQUc7QUFBQyxXQUFTbUUsRUFBWW5FLEdBQUVqQixHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRTtBQUFDLFNBQUlMLEtBQUcsR0FBRUQsSUFBRUMsS0FBRztBQUFDLGFBQUtrRSxFQUFPcEUsR0FBRUMsR0FBRUcsQ0FBQyxLQUFHRztBQUFHLFFBQUFOLEtBQUc7QUFBRSxhQUFLbUUsRUFBT3BFLEdBQUVFLEdBQUVFLENBQUMsSUFBRUc7QUFBRyxRQUFBTCxLQUFHO0FBQUUsVUFBR0QsS0FBR0M7QUFBRTtBQUFNLFlBQU1JLElBQUV2QixFQUFFa0IsS0FBRztBQUFHLE1BQUFsQixFQUFFa0IsS0FBRyxLQUFHbEIsRUFBRW1CLEtBQUcsSUFBR25CLEVBQUVtQixLQUFHLEtBQUdJLEdBQUVMLEtBQUcsR0FBRUMsS0FBRztBQUFBLElBQUM7QUFBQyxXQUFLa0UsRUFBT3BFLEdBQUVDLEdBQUVHLENBQUMsSUFBRUc7QUFBRyxNQUFBTixLQUFHO0FBQUUsV0FBT0EsSUFBRTtBQUFBLEVBQUM7QUFBQyxXQUFTbUUsRUFBT3BFLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLFdBQU9ELEVBQUVqQixLQUFHa0IsRUFBRSxLQUFHRCxFQUFFakIsSUFBRSxLQUFHa0IsRUFBRSxLQUFHRCxFQUFFakIsSUFBRSxLQUFHa0IsRUFBRSxLQUFHRCxFQUFFakIsSUFBRSxLQUFHa0IsRUFBRTtBQUFBLEVBQUU7QUFBQyxXQUFTZ0UsRUFBTWpFLEdBQUVqQixHQUFFa0IsR0FBRTtBQUFDLFVBQU1DLElBQUUsQ0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUVFLElBQUUsQ0FBQyxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUVHLElBQUVOLElBQUVsQixLQUFHO0FBQUUsYUFBUXdCLElBQUV4QixHQUFFd0IsSUFBRU4sR0FBRU0sS0FBRyxHQUFFO0FBQUMsWUFBTXhCLElBQUVpQixFQUFFTyxLQUFJLHFCQUFPTixJQUFFRCxFQUFFTyxJQUFFLE1BQUksSUFBRSxNQUFLRCxJQUFFTixFQUFFTyxJQUFFLE1BQUksSUFBRSxNQUFLQyxJQUFFUixFQUFFTyxJQUFFLE1BQUksSUFBRTtBQUFLLE1BQUFILEVBQUUsTUFBSXJCLEdBQUVxQixFQUFFLE1BQUlILEdBQUVHLEVBQUUsTUFBSUUsR0FBRUYsRUFBRSxNQUFJSSxHQUFFTixFQUFFLE1BQUluQixJQUFFQSxHQUFFbUIsRUFBRSxNQUFJbkIsSUFBRWtCLEdBQUVDLEVBQUUsTUFBSW5CLElBQUV1QixHQUFFSixFQUFFLE1BQUluQixJQUFFeUIsR0FBRU4sRUFBRSxNQUFJRCxJQUFFQSxHQUFFQyxFQUFFLE1BQUlELElBQUVLLEdBQUVKLEVBQUUsTUFBSUQsSUFBRU8sR0FBRU4sRUFBRSxPQUFLSSxJQUFFQSxHQUFFSixFQUFFLE9BQUtJLElBQUVFLEdBQUVOLEVBQUUsT0FBS00sSUFBRUE7QUFBQSxJQUFDO0FBQUMsV0FBT04sRUFBRSxLQUFHQSxFQUFFLElBQUdBLEVBQUUsS0FBR0EsRUFBRSxJQUFHQSxFQUFFLEtBQUdBLEVBQUUsSUFBR0EsRUFBRSxNQUFJQSxFQUFFLElBQUdBLEVBQUUsTUFBSUEsRUFBRSxJQUFHQSxFQUFFLE1BQUlBLEVBQUUsS0FBSSxFQUFDLEdBQUVBLEdBQUUsR0FBRUUsR0FBRSxHQUFFRyxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMyRCxFQUFPbEUsR0FBRTtBQUFDLFVBQUssRUFBQyxHQUFFakIsRUFBQyxJQUFFaUIsR0FBRSxFQUFDLEdBQUVDLEVBQUMsSUFBRUQsR0FBRSxFQUFDLEdBQUVFLEVBQUMsSUFBRUYsR0FBRU8sSUFBRU4sRUFBRSxJQUFHSyxJQUFFTCxFQUFFLElBQUdPLElBQUVQLEVBQUUsSUFBR1EsSUFBRVIsRUFBRSxJQUFHUyxJQUFLUixLQUFILElBQUssSUFBRSxJQUFFQSxHQUFFVSxJQUFFLENBQUM3QixFQUFFLEtBQUd3QixJQUFFQSxJQUFFRyxHQUFFM0IsRUFBRSxLQUFHd0IsSUFBRUQsSUFBRUksR0FBRTNCLEVBQUUsS0FBR3dCLElBQUVDLElBQUVFLEdBQUUzQixFQUFFLEtBQUd3QixJQUFFRSxJQUFFQyxHQUFFM0IsRUFBRSxLQUFHdUIsSUFBRUMsSUFBRUcsR0FBRTNCLEVBQUUsS0FBR3VCLElBQUVBLElBQUVJLEdBQUUzQixFQUFFLEtBQUd1QixJQUFFRSxJQUFFRSxHQUFFM0IsRUFBRSxLQUFHdUIsSUFBRUcsSUFBRUMsR0FBRTNCLEVBQUUsS0FBR3lCLElBQUVELElBQUVHLEdBQUUzQixFQUFFLEtBQUd5QixJQUFFRixJQUFFSSxHQUFFM0IsRUFBRSxNQUFJeUIsSUFBRUEsSUFBRUUsR0FBRTNCLEVBQUUsTUFBSXlCLElBQUVDLElBQUVDLEdBQUUzQixFQUFFLE1BQUkwQixJQUFFRixJQUFFRyxHQUFFM0IsRUFBRSxNQUFJMEIsSUFBRUgsSUFBRUksR0FBRTNCLEVBQUUsTUFBSTBCLElBQUVELElBQUVFLEdBQUUzQixFQUFFLE1BQUkwQixJQUFFQSxJQUFFQyxDQUFDLEdBQUVHLElBQUVELEdBQUVFLElBQUVWO0FBQUUsUUFBSVcsSUFBRSxDQUFDLEtBQUssT0FBTSxHQUFHLEtBQUssT0FBUSxHQUFDLEtBQUssT0FBTSxHQUFHLEtBQUssT0FBUSxDQUFBLEdBQUVDLElBQUUsR0FBRUMsSUFBRTtBQUFFLFFBQU1mLEtBQUg7QUFBSyxlQUFRRixJQUFFLEdBQUVBLElBQUUsT0FBS2UsSUFBRUQsRUFBRSxRQUFRRCxHQUFFRSxDQUFDLEdBQUVFLElBQUUsS0FBSyxLQUFLSCxFQUFFLElBQUlDLEdBQUVBLENBQUMsQ0FBQyxHQUFFQSxJQUFFRCxFQUFFLElBQUksSUFBRUcsR0FBRUYsQ0FBQyxHQUFFLEVBQUtmLEtBQUgsS0FBTSxLQUFLLElBQUlpQixJQUFFRCxDQUFDLElBQUUsUUFBT2hCO0FBQUksUUFBQWdCLElBQUVDO0FBQUUsVUFBTUMsSUFBRSxDQUFDWCxJQUFFRyxHQUFFSixJQUFFSSxHQUFFRixJQUFFRSxHQUFFRCxJQUFFQyxDQUFDO0FBQUUsV0FBTSxFQUFDLEtBQUlFLEdBQUUsR0FBRU0sR0FBRSxHQUFFSCxHQUFFLEdBQUVDLEdBQUUsUUFBT0YsRUFBRSxJQUFJQSxFQUFFLElBQUksS0FBSUksQ0FBQyxHQUFFSCxDQUFDLEdBQUUsS0FBSUQsRUFBRSxJQUFJQyxHQUFFRyxDQUFDLEdBQUUsT0FBTSxLQUFLLE1BQU0sTUFBSUEsRUFBRSxFQUFFLEtBQUcsS0FBRyxLQUFLLE1BQU0sTUFBSUEsRUFBRSxFQUFFLEtBQUcsS0FBRyxLQUFLLE1BQU0sTUFBSUEsRUFBRSxFQUFFLEtBQUcsSUFBRSxLQUFLLE1BQU0sTUFBSUEsRUFBRSxFQUFFLEtBQUcsT0FBSyxFQUFDO0FBQUEsRUFBQztBQUFDLE1BQUlkLElBQUUsRUFBQyxTQUFRLENBQUNKLEdBQUVqQixNQUFJLENBQUNpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLElBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLElBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLEtBQUdqQixFQUFFLEtBQUdpQixFQUFFLE1BQUlqQixFQUFFLEtBQUdpQixFQUFFLE1BQUlqQixFQUFFLElBQUdpQixFQUFFLE1BQUlqQixFQUFFLEtBQUdpQixFQUFFLE1BQUlqQixFQUFFLEtBQUdpQixFQUFFLE1BQUlqQixFQUFFLEtBQUdpQixFQUFFLE1BQUlqQixFQUFFLEVBQUUsR0FBRSxLQUFJLENBQUNpQixHQUFFakIsTUFBSWlCLEVBQUUsS0FBR2pCLEVBQUUsS0FBR2lCLEVBQUUsS0FBR2pCLEVBQUUsS0FBR2lCLEVBQUUsS0FBR2pCLEVBQUUsS0FBR2lCLEVBQUUsS0FBR2pCLEVBQUUsSUFBRyxLQUFJLENBQUNpQixHQUFFakIsTUFBSSxDQUFDaUIsSUFBRWpCLEVBQUUsSUFBR2lCLElBQUVqQixFQUFFLElBQUdpQixJQUFFakIsRUFBRSxJQUFHaUIsSUFBRWpCLEVBQUUsRUFBRSxFQUFDO0FBQUUsRUFBQXlELEdBQUssU0FBTyxTQUFnQnhDLEdBQUVqQixHQUFFa0IsR0FBRUMsR0FBRUUsR0FBRUcsR0FBRUQsR0FBRTtBQUFDLElBQU1KLEtBQU4sU0FBVUEsSUFBRSxJQUFTSSxLQUFOLFNBQVVBLElBQUU7QUFBSSxVQUFNRSxJQUFFaUQsRUFBU3pELEdBQUVqQixHQUFFa0IsR0FBRUMsR0FBRSxDQUFDLElBQUcsSUFBRyxJQUFHLEdBQUVJLEdBQUUsRUFBRSxDQUFDO0FBQUUsV0FBT2tELEVBQVloRCxHQUFFLEVBQUUsR0FBRStDLEVBQU0vQyxHQUFFekIsR0FBRWtCLEdBQUVHLEdBQUVHLENBQUM7QUFBQSxFQUFDLEdBQUVpQyxHQUFLLFdBQVMsU0FBa0J4QyxHQUFFakIsR0FBRWtCLEdBQUVDLEdBQUVFLEdBQUVHLEdBQUVELEdBQUVFLEdBQUU7QUFBQyxVQUFNQyxJQUFFLEVBQUMsT0FBTSxLQUFNUCxLQUFILElBQUssSUFBRSxNQUFPRSxLQUFILElBQUssSUFBRSxJQUFHLE9BQU1HLEdBQUUsUUFBTyxDQUFBLEVBQUUsR0FBRUcsS0FBR1IsSUFBRUUsS0FBR0csR0FBRUssSUFBRUYsSUFBRTNCO0FBQUUsYUFBUW1CLElBQUUsR0FBRUEsSUFBRUYsRUFBRSxRQUFPRTtBQUFJLE1BQUFPLEVBQUUsT0FBTyxLQUFLLEVBQUMsTUFBSyxFQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsT0FBTTFCLEdBQUUsUUFBT2tCLEVBQUMsR0FBRSxLQUFJLElBQUksV0FBV0QsRUFBRUUsRUFBRSxHQUFFLE9BQU0sR0FBRSxTQUFRLEdBQUUsS0FBSSxLQUFLLEtBQUtRLElBQUUsQ0FBQyxHQUFFLEtBQUksS0FBSyxLQUFLRSxJQUFFLENBQUMsRUFBQyxDQUFDO0FBQUUsV0FBTzRDLEVBQVkvQyxHQUFFLEdBQUUsRUFBRSxHQUFFOEMsRUFBTTlDLEdBQUUxQixHQUFFa0IsR0FBRUssR0FBRUUsQ0FBQztBQUFBLEVBQUMsR0FBRWdDLEdBQUssT0FBTyxXQUFTaUIsR0FBU2pCLEdBQUssT0FBTyxTQUFPYyxHQUFPZCxHQUFLLFdBQVNvQixHQUFTcEIsR0FBSyxTQUFTLFlBQVVzQixHQUFVdEIsR0FBSyxTQUFTLGFBQVd1QjtBQUFVLEdBQUc7QUFBQyxNQUFNOUQsS0FBRSxFQUFDLGNBQWNELEdBQUVqQixHQUFFO0FBQUMsUUFBTW1CLElBQUVGLEVBQUUsT0FBTSxJQUFFQSxFQUFFLFFBQU9PLElBQUVMLEtBQUcsR0FBRUksSUFBRU4sRUFBRSxXQUFXLElBQUksRUFBRSxhQUFhLEdBQUUsR0FBRUUsR0FBRSxDQUFDLEdBQUVNLElBQUUsSUFBSSxZQUFZRixFQUFFLEtBQUssTUFBTSxHQUFFRyxLQUFHLEtBQUdQLElBQUUsTUFBSSxNQUFJLEdBQUVRLElBQUVELElBQUUsR0FBRUcsSUFBRSxNQUFJRixHQUFFRyxJQUFFLElBQUksWUFBWUQsQ0FBQyxHQUFFRSxJQUFFLElBQUksU0FBU0QsQ0FBQyxHQUFFRSxJQUFFLEtBQUc7QUFBRyxNQUFJQyxHQUFFLEdBQUVFLEdBQUVFLEdBQUV1QixJQUFFNUIsR0FBRU0sSUFBRSxHQUFFQyxJQUFFLEdBQUVDLElBQUU7QUFBRSxXQUFTOEMsRUFBTXJFLEdBQUU7QUFBQyxJQUFBYyxFQUFFLFVBQVVRLEdBQUV0QixHQUFFLEVBQUUsR0FBRXNCLEtBQUc7QUFBQSxFQUFDO0FBQUMsV0FBU2dELEVBQU10RSxHQUFFO0FBQUMsSUFBQWMsRUFBRSxVQUFVUSxHQUFFdEIsR0FBRSxFQUFFLEdBQUVzQixLQUFHO0FBQUEsRUFBQztBQUFDLFdBQVNpRCxFQUFLdkUsR0FBRTtBQUFDLElBQUFzQixLQUFHdEI7QUFBQSxFQUFDO0FBQUMsRUFBQXFFLEVBQU0sS0FBSyxHQUFFQyxFQUFNMUQsQ0FBQyxHQUFFMkQsRUFBSyxDQUFDLEdBQUVELEVBQU0sR0FBRyxHQUFFQSxFQUFNLEdBQUcsR0FBRUEsRUFBTXBFLENBQUMsR0FBRW9FLEVBQU0sQ0FBQyxNQUFJLENBQUMsR0FBRUQsRUFBTSxDQUFDLEdBQUVBLEVBQU0sRUFBRSxHQUFFQyxFQUFNLENBQUMsR0FBRUEsRUFBTTVELENBQUMsR0FBRTRELEVBQU0sSUFBSSxHQUFFQSxFQUFNLElBQUksR0FBRUMsRUFBSyxDQUFDLEdBQUVELEVBQU0sUUFBUSxHQUFFQSxFQUFNLEtBQUssR0FBRUEsRUFBTSxHQUFHLEdBQUVBLEVBQU0sVUFBVSxHQUFFQSxFQUFNLFVBQVUsR0FBRSxTQUFTRSxJQUFTO0FBQUMsV0FBS25ELElBQUUsS0FBR3NCLElBQUUsS0FBRztBQUFDLFdBQUl2QixJQUFFLE1BQUlDLElBQUVaLEdBQUVPLElBQUUsR0FBRUEsSUFBRVQ7QUFBRyxRQUFBb0MsS0FBSSxJQUFFbkMsRUFBRWUsTUFBS0wsSUFBRSxNQUFJLElBQUdKLEVBQUUsVUFBVU0sSUFBRUosR0FBRSxLQUFHLElBQUVFLENBQUMsR0FBRUYsS0FBRztBQUFFLE1BQUFLO0FBQUEsSUFBRztBQUFDLElBQUFFLElBQUVmLEVBQUUsVUFBUW1DLElBQUU1QixHQUFFLFdBQVd5RCxHQUFRdkUsR0FBRSxJQUFJLEtBQUdsQixFQUFFOEIsQ0FBQztBQUFBLEVBQUMsRUFBQztBQUFFLEdBQUUsT0FBT2IsR0FBRWpCLEdBQUU7QUFBQyxPQUFLLGNBQWNpQixHQUFHLENBQUFBLE1BQUc7QUFBQyxJQUFBakIsRUFBRSxJQUFJLEtBQUssQ0FBQ2lCLENBQUMsR0FBRSxFQUFDLE1BQUssWUFBVyxDQUFDLENBQUM7QUFBQSxFQUFDLENBQUc7QUFBQSxHQUFFLE1BQUssRUFBQztBQUFFLElBQUlFLEtBQUUsRUFBQyxRQUFPLFVBQVMsU0FBUSxXQUFVLGdCQUFlLGtCQUFpQixJQUFHLE1BQUssS0FBSSxPQUFNLEtBQUksTUFBSyxHQUFFRSxLQUFFLEVBQUMsQ0FBQ0YsR0FBRSxTQUFRLE9BQU0sQ0FBQ0EsR0FBRSxVQUFTLE9BQU0sQ0FBQ0EsR0FBRSxpQkFBZ0IsT0FBTSxDQUFDQSxHQUFFLEtBQUksTUFBSyxDQUFDQSxHQUFFLE1BQUssTUFBSyxDQUFDQSxHQUFFLE1BQUssS0FBSTtBQUFFLE1BQU1LLEtBQWUsT0FBTyxTQUFwQixLQUEyQkQsS0FBZSxPQUFPLG9CQUFwQixPQUF1QyxnQkFBZ0IsbUJBQWtCRSxLQUFFRCxNQUFHLE9BQU8sV0FBUyxPQUFPLFFBQVEsV0FBUyxPQUFPLFFBQVEsUUFBUSxzQkFBc0IsR0FBRWtFLE1BQVlsRSxNQUFHRCxRQUFLRSxNQUFHQSxHQUFFLGtCQUFrQixRQUFPLE1BQU0sS0FBZ0IsT0FBTyxPQUFwQixPQUEwQixPQUFNa0UsTUFBa0JuRSxNQUFHRCxRQUFLRSxNQUFHQSxHQUFFLGtCQUFrQixRQUFPLFlBQVksS0FBZ0IsT0FBTyxhQUFwQixPQUFnQztBQUFZLFNBQVNtRSxHQUFtQjNFLEdBQUVqQixHQUFFa0IsSUFBRSxLQUFLLElBQUssR0FBQztBQUFDLFNBQU8sSUFBSSxRQUFTLENBQUFDLE1BQUc7QUFBQyxVQUFNRSxJQUFFSixFQUFFLE1BQU0sR0FBRyxHQUFFTyxJQUFFSCxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsSUFBR0UsSUFBRSxXQUFXLEtBQUtGLEVBQUUsRUFBRTtBQUFFLFFBQUlJLElBQUVGLEVBQUU7QUFBTyxVQUFNRyxJQUFFLElBQUksV0FBV0QsQ0FBQztBQUFFLFdBQUtBO0FBQUssTUFBQUMsRUFBRUQsS0FBR0YsRUFBRSxXQUFXRSxDQUFDO0FBQUUsVUFBTUUsSUFBRSxJQUFJLEtBQUssQ0FBQ0QsQ0FBQyxHQUFFLEVBQUMsTUFBS0YsRUFBQyxDQUFDO0FBQUUsSUFBQUcsRUFBRSxPQUFLM0IsR0FBRTJCLEVBQUUsZUFBYVQsR0FBRUMsRUFBRVEsQ0FBQztBQUFBLEVBQUMsQ0FBQztBQUFFO0FBQUMsU0FBU2tFLEdBQW1CNUUsR0FBRTtBQUFDLFNBQU8sSUFBSSxRQUFTLENBQUNqQixHQUFFa0IsTUFBSTtBQUFDLFVBQU1DLElBQUUsSUFBSXdFO0FBQWlCLElBQUF4RSxFQUFFLFNBQU8sTUFBSW5CLEVBQUVtQixFQUFFLE1BQU0sR0FBRUEsRUFBRSxVQUFRLE9BQUdELEVBQUUsQ0FBQyxHQUFFQyxFQUFFLGNBQWNGLENBQUM7QUFBQSxFQUFDLENBQUM7QUFBRTtBQUFDLFNBQVM2RSxHQUFVN0UsR0FBRTtBQUFDLFNBQU8sSUFBSSxRQUFTLENBQUNqQixHQUFFa0IsTUFBSTtBQUFDLFVBQU1DLElBQUUsSUFBSTtBQUFNLElBQUFBLEVBQUUsU0FBTyxNQUFJbkIsRUFBRW1CLENBQUMsR0FBRUEsRUFBRSxVQUFRLE9BQUdELEVBQUUsQ0FBQyxHQUFFQyxFQUFFLE1BQUlGO0FBQUEsRUFBQyxDQUFDO0FBQUU7QUFBQyxTQUFTOEUsS0FBZ0I7QUFBQyxNQUFZQSxHQUFlLGlCQUF4QjtBQUFxQyxXQUFPQSxHQUFlO0FBQWEsTUFBSTlFLElBQUVFLEdBQUU7QUFBSSxRQUFLLEVBQUMsV0FBVW5CLEVBQUMsSUFBRTtBQUFVLFNBQU0sZ0JBQWdCLEtBQUtBLENBQUMsSUFBRWlCLElBQUVFLEdBQUUsU0FBTyxrQkFBa0IsS0FBS25CLENBQUMsS0FBRyxVQUFVLEtBQUtBLENBQUMsSUFBRWlCLElBQUVFLEdBQUUsTUFBSSxVQUFVLEtBQUtuQixDQUFDLElBQUVpQixJQUFFRSxHQUFFLGlCQUFlLFdBQVcsS0FBS25CLENBQUMsSUFBRWlCLElBQUVFLEdBQUUsV0FBUyxRQUFRLEtBQUtuQixDQUFDLEtBQU8sQ0FBQyxDQUFDLFNBQVMsa0JBQWdCaUIsSUFBRUUsR0FBRSxLQUFJNEUsR0FBZSxlQUFhOUUsR0FBRThFLEdBQWU7QUFBWTtBQUFDLFNBQVNDLEdBQTJDL0UsR0FBRWpCLEdBQUU7QUFBQyxRQUFNa0IsSUFBRTZFLEdBQWMsR0FBRzVFLElBQUVFLEdBQUVIO0FBQUcsTUFBSU0sSUFBRVAsR0FBRU0sSUFBRXZCLEdBQUV5QixJQUFFRCxJQUFFRDtBQUFFLFFBQU1HLElBQUVGLElBQUVELElBQUVBLElBQUVDLElBQUVBLElBQUVEO0FBQUUsU0FBS0UsSUFBRU4sSUFBRUEsS0FBRztBQUFDLFVBQU1GLEtBQUdFLElBQUVLLEtBQUcsR0FBRXhCLEtBQUdtQixJQUFFSSxLQUFHO0FBQUUsSUFBQU4sSUFBRWpCLEtBQUd1QixJQUFFdkIsR0FBRXdCLElBQUV4QixJQUFFMEIsTUFBSUgsSUFBRU4sSUFBRVMsR0FBRUYsSUFBRVAsSUFBR1EsSUFBRUQsSUFBRUQ7QUFBQSxFQUFDO0FBQUMsU0FBTSxFQUFDLE9BQU1DLEdBQUUsUUFBT0QsRUFBQztBQUFDO0FBQUMsU0FBUzBFLEdBQW1CaEYsR0FBRWpCLEdBQUU7QUFBQyxNQUFJa0IsR0FBRUM7QUFBRSxNQUFHO0FBQUMsUUFBR0QsSUFBRSxJQUFJLGdCQUFnQkQsR0FBRWpCLENBQUMsR0FBRW1CLElBQUVELEVBQUUsV0FBVyxJQUFJLEdBQVNDLE1BQVA7QUFBUyxZQUFNLElBQUksTUFBTSw0Q0FBNEM7QUFBQSxFQUFDLFFBQUM7QUFBUyxJQUFBRCxJQUFFLFNBQVMsY0FBYyxRQUFRLEdBQUVDLElBQUVELEVBQUUsV0FBVyxJQUFJO0FBQUEsRUFBQztBQUFDLFNBQU9BLEVBQUUsUUFBTUQsR0FBRUMsRUFBRSxTQUFPbEIsR0FBRSxDQUFDa0IsR0FBRUMsQ0FBQztBQUFDO0FBQUMsU0FBUytFLEdBQWtCakYsR0FBRWpCLEdBQUU7QUFBQyxRQUFLLEVBQUMsT0FBTWtCLEdBQUUsUUFBT0MsRUFBQyxJQUFFNkUsR0FBMkMvRSxFQUFFLE9BQU1BLEVBQUUsTUFBTSxHQUFFLENBQUNJLEdBQUVHLENBQUMsSUFBRXlFLEdBQW1CL0UsR0FBRUMsQ0FBQztBQUFFLFNBQU9uQixLQUFHLFFBQVEsS0FBS0EsQ0FBQyxNQUFJd0IsRUFBRSxZQUFVLFNBQVFBLEVBQUUsU0FBUyxHQUFFLEdBQUVILEVBQUUsT0FBTUEsRUFBRSxNQUFNLElBQUdHLEVBQUUsVUFBVVAsR0FBRSxHQUFFLEdBQUVJLEVBQUUsT0FBTUEsRUFBRSxNQUFNLEdBQUVBO0FBQUM7QUFBQyxTQUFTOEUsS0FBTztBQUFDLFNBQWdCQSxHQUFNLGlCQUFmLFdBQThCQSxHQUFNLGVBQWEsQ0FBQyxrQkFBaUIsb0JBQW1CLGtCQUFpQixRQUFPLFVBQVMsTUFBTSxFQUFFLFNBQVMsVUFBVSxRQUFRLEtBQUcsVUFBVSxVQUFVLFNBQVMsS0FBSyxLQUFnQixPQUFPLFdBQXBCLE9BQThCLGdCQUFlLFdBQVVBLEdBQU07QUFBWTtBQUFDLFNBQVNDLEdBQWlCbkYsR0FBRWpCLElBQUUsQ0FBQSxHQUFHO0FBQUMsU0FBTyxJQUFJLFFBQVMsU0FBU2tCLEdBQUUsR0FBRTtBQUFDLFFBQUlNLEdBQUVEO0FBQUUsUUFBSThFLElBQVksV0FBVTtBQUFDLFVBQUc7QUFBQyxlQUFPOUUsSUFBRTJFLEdBQWtCMUUsR0FBRXhCLEVBQUUsWUFBVWlCLEVBQUUsSUFBSSxHQUFFQyxFQUFFLENBQUNNLEdBQUVELENBQUMsQ0FBQztBQUFBLE1BQUMsU0FBT04sR0FBTjtBQUFTLGVBQU8sRUFBRUEsQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEdBQUVxRixJQUFhLFNBQVN0RyxHQUFFO0FBQUMsVUFBRztBQUFHLFlBQUl1RyxJQUFhLFNBQVN0RixHQUFFO0FBQUMsY0FBRztBQUFDLGtCQUFNQTtBQUFBLFVBQUMsU0FBT0EsR0FBTjtBQUFTLG1CQUFPLEVBQUVBLENBQUM7QUFBQSxVQUFDO0FBQUEsUUFBQztBQUFFLFlBQUc7QUFBQyxjQUFJakI7QUFBRSxpQkFBTzZGLEdBQW1CNUUsQ0FBQyxFQUFFLEtBQU0sU0FBU0EsR0FBRTtBQUFDLGdCQUFHO0FBQUMscUJBQU9qQixJQUFFaUIsR0FBRTZFLEdBQVU5RixDQUFDLEVBQUUsS0FBTSxTQUFTaUIsR0FBRTtBQUFDLG9CQUFHO0FBQUMseUJBQU9PLElBQUVQLEdBQUUsV0FBVTtBQUFDLHdCQUFHO0FBQUMsNkJBQU9vRixFQUFXO0FBQUEsb0JBQUUsU0FBT3BGLEdBQU47QUFBUyw2QkFBTyxFQUFFQSxDQUFDO0FBQUEsb0JBQUM7QUFBQSxrQkFBQyxFQUFDO0FBQUEsZ0JBQUUsU0FBT0EsR0FBTjtBQUFTLHlCQUFPc0YsRUFBYXRGLENBQUM7QUFBQSxnQkFBQztBQUFBLGNBQUMsR0FBR3NGLENBQVk7QUFBQSxZQUFDLFNBQU90RixHQUFOO0FBQVMscUJBQU9zRixFQUFhdEYsQ0FBQztBQUFBLFlBQUM7QUFBQSxVQUFDLEdBQUdzRixDQUFZO0FBQUEsUUFBQyxTQUFPdEYsR0FBTjtBQUFTLFVBQUFzRixFQUFhdEYsQ0FBQztBQUFBLFFBQUM7QUFBQSxNQUFDLFNBQU9BLEdBQU47QUFBUyxlQUFPLEVBQUVBLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFFLFFBQUc7QUFBQyxVQUFHa0YsR0FBSyxLQUFJLENBQUNoRixHQUFFLGdCQUFlQSxHQUFFLGFBQWEsRUFBRSxTQUFTNEUsR0FBZ0IsQ0FBQTtBQUFFLGNBQU0sSUFBSSxNQUFNLDBDQUEwQztBQUFFLGFBQU8sa0JBQWtCOUUsQ0FBQyxFQUFFLEtBQU0sU0FBU0EsR0FBRTtBQUFDLFlBQUc7QUFBQyxpQkFBT08sSUFBRVAsR0FBRW9GLEVBQWE7QUFBQSxRQUFBLFFBQUM7QUFBUyxpQkFBT0MsRUFBYztBQUFBLFFBQUE7QUFBQSxNQUFDLEdBQUdBLENBQVk7QUFBQSxJQUFDLFFBQUM7QUFBUyxNQUFBQSxFQUFZO0FBQUEsSUFBRTtBQUFBLEVBQUMsQ0FBRztBQUFBO0FBQUMsU0FBU0UsR0FBYXZGLEdBQUVqQixHQUFFbUIsR0FBRSxHQUFFSyxJQUFFLEdBQUU7QUFBQyxTQUFPLElBQUksUUFBUyxTQUFTRCxHQUFFRSxHQUFFO0FBQUMsUUFBSUM7QUFBRSxRQUFpQjFCLE1BQWQsYUFBZ0I7QUFBQyxVQUFJMkIsR0FBRUUsR0FBRUM7QUFBRSxhQUFPSCxJQUFFVixFQUFFLFdBQVcsSUFBSSxHQUFHLEVBQUMsTUFBS1ksRUFBQyxJQUFFRixFQUFFLGFBQWEsR0FBRSxHQUFFVixFQUFFLE9BQU1BLEVBQUUsTUFBTSxHQUFHYSxJQUFFMkIsR0FBSyxPQUFPLENBQUM1QixFQUFFLE1BQU0sR0FBRVosRUFBRSxPQUFNQSxFQUFFLFFBQU8sT0FBS08sQ0FBQyxHQUFFRSxJQUFFLElBQUksS0FBSyxDQUFDSSxDQUFDLEdBQUUsRUFBQyxNQUFLOUIsRUFBQyxDQUFDLEdBQUUwQixFQUFFLE9BQUtQLEdBQUVPLEVBQUUsZUFBYSxHQUFFK0UsRUFBTSxLQUFLLElBQUk7QUFBQSxJQUFDO0FBQUM7QUFBc2tCLFVBQVNDLElBQVQsV0FBZ0I7QUFBQyxlQUFPRCxFQUFNLEtBQUssSUFBSTtBQUFBLE1BQUM7QUFBL0IsVUFBQUM7QUFBOWtCLFVBQWlCMUcsTUFBZDtBQUFnQixlQUFPLElBQUksUUFBUyxDQUFBQSxNQUFHa0IsR0FBRSxPQUFPRCxHQUFFakIsQ0FBQyxDQUFHLEVBQUMsS0FBSyxTQUFTaUIsR0FBRTtBQUFDLGNBQUc7QUFBQyxtQkFBT1MsSUFBRVQsR0FBRVMsRUFBRSxPQUFLUCxHQUFFTyxFQUFFLGVBQWEsR0FBRWdGLEVBQU0sS0FBSyxJQUFJO0FBQUEsVUFBQyxTQUFPekYsR0FBTjtBQUFTLG1CQUFPUSxFQUFFUixDQUFDO0FBQUEsVUFBQztBQUFBLFFBQUMsRUFBRSxLQUFLLElBQUksR0FBRVEsQ0FBQztBQUFFO0FBQWlYLFlBQVNrRixJQUFULFdBQWdCO0FBQUMsaUJBQU9ELEVBQU0sS0FBSyxJQUFJO0FBQUEsUUFBQztBQUEvQixZQUFBQztBQUF6WCxZQUFlLE9BQU8sbUJBQW5CLGNBQW9DMUYsYUFBYTtBQUFnQixpQkFBT0EsRUFBRSxjQUFjLEVBQUMsTUFBS2pCLEdBQUUsU0FBUXdCLEVBQUMsQ0FBQyxFQUFFLEtBQUssU0FBU1AsR0FBRTtBQUFDLGdCQUFHO0FBQUMscUJBQU9TLElBQUVULEdBQUVTLEVBQUUsT0FBS1AsR0FBRU8sRUFBRSxlQUFhLEdBQUVpRixFQUFNLEtBQUssSUFBSTtBQUFBLFlBQUMsU0FBTzFGLEdBQU47QUFBUyxxQkFBT1EsRUFBRVIsQ0FBQztBQUFBLFlBQUM7QUFBQSxVQUFDLEVBQUUsS0FBSyxJQUFJLEdBQUVRLENBQUM7QUFBRTtBQUFDLGNBQUlNO0FBQUUsaUJBQU9BLElBQUVkLEVBQUUsVUFBVWpCLEdBQUV3QixDQUFDLEdBQUVvRSxHQUFtQjdELEdBQUVaLEdBQUUsQ0FBQyxFQUFFLEtBQUssU0FBU0YsR0FBRTtBQUFDLGdCQUFHO0FBQUMscUJBQU9TLElBQUVULEdBQUUwRixFQUFNLEtBQUssSUFBSTtBQUFBLFlBQUMsU0FBTzFGLEdBQU47QUFBUyxxQkFBT1EsRUFBRVIsQ0FBQztBQUFBLFlBQUM7QUFBQSxVQUFDLEVBQUUsS0FBSyxJQUFJLEdBQUVRLENBQUM7QUFBQSxRQUFDO0FBQUEsTUFBMEM7QUFBQSxJQUEwQztBQUFDLGFBQVNnRixJQUFPO0FBQUMsYUFBT2xGLEVBQUVHLENBQUM7QUFBQSxJQUFDO0FBQUEsRUFBQyxDQUFHO0FBQUE7QUFBQyxTQUFTa0YsR0FBb0IzRixHQUFFO0FBQUMsRUFBQUEsRUFBRSxRQUFNLEdBQUVBLEVBQUUsU0FBTztBQUFDO0FBQUMsU0FBUzRGLEtBQTRCO0FBQUMsU0FBTyxJQUFJLFFBQVMsU0FBUzVGLEdBQUVqQixHQUFFO0FBQUksUUFBR21CLEdBQUUsR0FBRUssR0FBRUQ7QUFBRSxXQUFnQnNGLEdBQTJCLGlCQUFwQyxTQUFpRDVGLEVBQUU0RixHQUEyQixZQUFZLElBQStaakIsR0FBbUIsMlpBQTBaLFlBQVcsS0FBSyxLQUFLLEVBQUUsS0FBTSxTQUFTMUUsR0FBRTtBQUFDLFVBQUc7QUFBQyxlQUFPQyxJQUFFRCxHQUFFa0YsR0FBaUJqRixDQUFDLEVBQUUsS0FBTSxTQUFTRCxHQUFFO0FBQUMsY0FBRztBQUFDLG1CQUFPLElBQUVBLEVBQUUsSUFBR3NGLEdBQWEsR0FBRXJGLEVBQUUsTUFBS0EsRUFBRSxNQUFLQSxFQUFFLFlBQVksRUFBRSxLQUFNLFNBQVNELEdBQUU7QUFBQyxrQkFBRztBQUFDLHVCQUFPTSxJQUFFTixHQUFFMEYsR0FBb0IsQ0FBQyxHQUFFUixHQUFpQjVFLENBQUMsRUFBRSxLQUFNLFNBQVNOLEdBQUU7QUFBQyxzQkFBRztBQUFDLDJCQUFPSyxJQUFFTCxFQUFFLElBQUcyRixHQUEyQixlQUFpQnRGLEVBQUUsVUFBTixLQUFpQkEsRUFBRSxXQUFOLEdBQWFOLEVBQUU0RixHQUEyQixZQUFZO0FBQUEsa0JBQUMsU0FBTzVGLEdBQU47QUFBUywyQkFBT2pCLEVBQUVpQixDQUFDO0FBQUEsa0JBQUM7QUFBQSxnQkFBQyxHQUFHakIsQ0FBQztBQUFBLGNBQUMsU0FBT2lCLEdBQU47QUFBUyx1QkFBT2pCLEVBQUVpQixDQUFDO0FBQUEsY0FBQztBQUFBLFlBQUMsR0FBR2pCLENBQUM7QUFBQSxVQUFDLFNBQU9pQixHQUFOO0FBQVMsbUJBQU9qQixFQUFFaUIsQ0FBQztBQUFBLFVBQUM7QUFBQSxRQUFDLEdBQUdqQixDQUFDO0FBQUEsTUFBQyxTQUFPaUIsR0FBTjtBQUFTLGVBQU9qQixFQUFFaUIsQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEdBQUdqQixDQUFDO0FBQUEsRUFBRSxDQUFDO0FBQUU7QUFBQyxTQUFTOEcsR0FBbUI3RixHQUFFO0FBQUMsU0FBTyxJQUFJLFFBQVMsQ0FBQ2pCLEdBQUVrQixNQUFJO0FBQUMsVUFBTUMsSUFBRSxJQUFJd0U7QUFBaUIsSUFBQXhFLEVBQUUsU0FBTyxPQUFHO0FBQUMsWUFBTUQsSUFBRSxJQUFJLFNBQVMsRUFBRSxPQUFPLE1BQU07QUFBRSxVQUFVQSxFQUFFLFVBQVUsR0FBRSxFQUFFLEtBQXZCO0FBQXlCLGVBQU9sQixFQUFFLEVBQUU7QUFBRSxZQUFNbUIsSUFBRUQsRUFBRTtBQUFXLFVBQUlHLElBQUU7QUFBRSxhQUFLQSxJQUFFRixLQUFHO0FBQUMsWUFBR0QsRUFBRSxVQUFVRyxJQUFFLEdBQUUsRUFBRSxLQUFHO0FBQUUsaUJBQU9yQixFQUFFLEVBQUU7QUFBRSxjQUFNaUIsSUFBRUMsRUFBRSxVQUFVRyxHQUFFLEVBQUU7QUFBRSxZQUFHQSxLQUFHLEdBQVNKLEtBQVAsT0FBUztBQUFDLGNBQWVDLEVBQUUsVUFBVUcsS0FBRyxHQUFFLEVBQUUsS0FBL0I7QUFBaUMsbUJBQU9yQixFQUFFLEVBQUU7QUFBRSxnQkFBTWlCLElBQVNDLEVBQUUsVUFBVUcsS0FBRyxHQUFFLEVBQUUsS0FBMUI7QUFBNEIsVUFBQUEsS0FBR0gsRUFBRSxVQUFVRyxJQUFFLEdBQUVKLENBQUM7QUFBRSxnQkFBTUUsSUFBRUQsRUFBRSxVQUFVRyxHQUFFSixDQUFDO0FBQUUsVUFBQUksS0FBRztBQUFFLG1CQUFRRyxJQUFFLEdBQUVBLElBQUVMLEdBQUVLO0FBQUksZ0JBQVFOLEVBQUUsVUFBVUcsSUFBRSxLQUFHRyxHQUFFUCxDQUFDLEtBQXpCO0FBQTJCLHFCQUFPakIsRUFBRWtCLEVBQUUsVUFBVUcsSUFBRSxLQUFHRyxJQUFFLEdBQUVQLENBQUMsQ0FBQztBQUFBLFFBQUMsT0FBSztBQUFDLGVBQVcsUUFBTUEsTUFBZDtBQUFpQjtBQUFNLFVBQUFJLEtBQUdILEVBQUUsVUFBVUcsR0FBRSxFQUFFO0FBQUEsUUFBQztBQUFBLE1BQUM7QUFBQyxhQUFPckIsRUFBRSxFQUFFO0FBQUEsSUFBQyxHQUFFbUIsRUFBRSxVQUFRLE9BQUdELEVBQUUsQ0FBQyxHQUFFQyxFQUFFLGtCQUFrQkYsQ0FBQztBQUFBLEVBQUMsQ0FBRztBQUFBO0FBQUMsU0FBUzhGLEdBQXVCOUYsR0FBRWpCLEdBQUU7QUFBQyxRQUFLLEVBQUMsT0FBTWtCLEVBQUMsSUFBRUQsR0FBRSxFQUFDLFFBQU9FLEVBQUMsSUFBRUYsR0FBRSxFQUFDLGtCQUFpQkksRUFBQyxJQUFFckI7QUFBRSxNQUFJd0IsR0FBRUQsSUFBRU47QUFBRSxTQUFPLFNBQVNJLENBQUMsTUFBSUgsSUFBRUcsS0FBR0YsSUFBRUUsT0FBSyxDQUFDRSxHQUFFQyxDQUFDLElBQUV5RSxHQUFtQi9FLEdBQUVDLENBQUMsR0FBRUQsSUFBRUMsS0FBR0ksRUFBRSxRQUFNRixHQUFFRSxFQUFFLFNBQU9KLElBQUVELElBQUVHLE1BQUlFLEVBQUUsUUFBTUwsSUFBRUMsSUFBRUUsR0FBRUUsRUFBRSxTQUFPRixJQUFHRyxFQUFFLFVBQVVQLEdBQUUsR0FBRSxHQUFFTSxFQUFFLE9BQU1BLEVBQUUsTUFBTSxHQUFFcUYsR0FBb0IzRixDQUFDLElBQUdNO0FBQUM7QUFBQyxTQUFTeUYsR0FBc0IvRixHQUFFakIsR0FBRTtBQUFDLFFBQUssRUFBQyxPQUFNa0IsRUFBQyxJQUFFRCxHQUFFLEVBQUMsUUFBT0UsRUFBQyxJQUFFRixHQUFFLENBQUNJLEdBQUVHLENBQUMsSUFBRXlFLEdBQW1CL0UsR0FBRUMsQ0FBQztBQUFFLFVBQU9uQixJQUFFLEtBQUdBLElBQUUsS0FBR3FCLEVBQUUsUUFBTUYsR0FBRUUsRUFBRSxTQUFPSCxNQUFJRyxFQUFFLFFBQU1ILEdBQUVHLEVBQUUsU0FBT0YsSUFBR25CLEdBQUc7QUFBQSxJQUFBLEtBQUs7QUFBRSxNQUFBd0IsRUFBRSxVQUFVLElBQUcsR0FBRSxHQUFFLEdBQUVOLEdBQUUsQ0FBQztBQUFFO0FBQUEsSUFBTSxLQUFLO0FBQUUsTUFBQU0sRUFBRSxVQUFVLElBQUcsR0FBRSxHQUFFLElBQUdOLEdBQUVDLENBQUM7QUFBRTtBQUFBLElBQU0sS0FBSztBQUFFLE1BQUFLLEVBQUUsVUFBVSxHQUFFLEdBQUUsR0FBRSxJQUFHLEdBQUVMLENBQUM7QUFBRTtBQUFBLElBQU0sS0FBSztBQUFFLE1BQUFLLEVBQUUsVUFBVSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQztBQUFFO0FBQUEsSUFBTSxLQUFLO0FBQUUsTUFBQUEsRUFBRSxVQUFVLEdBQUUsR0FBRSxJQUFHLEdBQUVMLEdBQUUsQ0FBQztBQUFFO0FBQUEsSUFBTSxLQUFLO0FBQUUsTUFBQUssRUFBRSxVQUFVLEdBQUUsSUFBRyxJQUFHLEdBQUVMLEdBQUVELENBQUM7QUFBRTtBQUFBLElBQU0sS0FBSztBQUFFLE1BQUFNLEVBQUUsVUFBVSxHQUFFLElBQUcsR0FBRSxHQUFFLEdBQUVOLENBQUM7QUFBQSxFQUFDO0FBQUMsU0FBT00sRUFBRSxVQUFVUCxHQUFFLEdBQUUsR0FBRUMsR0FBRUMsQ0FBQyxHQUFFeUYsR0FBb0IzRixDQUFDLEdBQUVJO0FBQUM7QUFBQyxTQUFTcUQsR0FBU3pELEdBQUVqQixHQUFFa0IsSUFBRSxHQUFFO0FBQUMsU0FBTyxJQUFJLFFBQVMsU0FBU0MsR0FBRUUsR0FBRTtBQUFDLFFBQUlHLEdBQUVELEdBQUVFLEdBQUVDLEdBQUVDLEdBQUVFLEdBQUVDLEdBQUVDLEdBQUVDLEdBQUVDLEdBQUVDLEdBQUVDLEdBQUVFLEdBQUV1QixHQUFFdEIsR0FBRUMsR0FBRUMsR0FBRUMsR0FBRUwsR0FBRU07QUFBRSxhQUFTdUUsRUFBWWhHLElBQUUsR0FBRTtBQUFDLFVBQUdqQixFQUFFLFVBQVFBLEVBQUUsT0FBTztBQUFRLGNBQU1BLEVBQUUsT0FBTztBQUFPLE1BQUF3QixLQUFHUCxHQUFFakIsRUFBRSxXQUFXLEtBQUssSUFBSXdCLEdBQUUsR0FBRyxDQUFDO0FBQUEsSUFBQztBQUFDLGFBQVMwRixFQUFZakcsR0FBRTtBQUFDLFVBQUdqQixFQUFFLFVBQVFBLEVBQUUsT0FBTztBQUFRLGNBQU1BLEVBQUUsT0FBTztBQUFPLE1BQUF3QixJQUFFLEtBQUssSUFBSSxLQUFLLElBQUlQLEdBQUVPLENBQUMsR0FBRSxHQUFHLEdBQUV4QixFQUFFLFdBQVd3QixDQUFDO0FBQUEsSUFBQztBQUFDLFdBQU9BLElBQUVOLEdBQUVLLElBQUV2QixFQUFFLGdCQUFjLElBQUd5QixJQUFFLE9BQUt6QixFQUFFLFlBQVUsTUFBS2lILEVBQWEsR0FBQ2IsR0FBaUJuRixHQUFFakIsQ0FBQyxFQUFFLEtBQUssU0FBU2tCLEdBQUU7QUFBQyxVQUFHO0FBQUMsZUFBTSxDQUFFLEVBQUFRLENBQUMsSUFBRVIsR0FBRStGLEVBQWEsR0FBQ3RGLElBQUVvRixHQUF1QnJGLEdBQUUxQixDQUFDLEdBQUVpSCxFQUFhLEdBQUMsSUFBSSxRQUFTLFNBQVMvRixHQUFFQyxHQUFFO0FBQUMsY0FBSUU7QUFBRSxjQUFHLEVBQUVBLElBQUVyQixFQUFFO0FBQWlCLG1CQUFPOEcsR0FBbUI3RixDQUFDLEVBQUUsS0FBSyxTQUFTQSxHQUFFO0FBQUMsa0JBQUc7QUFBQyx1QkFBT0ksSUFBRUosR0FBRWtHLEVBQU0sS0FBSyxJQUFJO0FBQUEsY0FBQyxTQUFPbEcsR0FBTjtBQUFTLHVCQUFPRSxFQUFFRixDQUFDO0FBQUEsY0FBQztBQUFBLFlBQUMsRUFBRSxLQUFLLElBQUksR0FBRUUsQ0FBQztBQUFFLG1CQUFTZ0csSUFBTztBQUFDLG1CQUFPakcsRUFBRUcsQ0FBQztBQUFBLFVBQUM7QUFBQyxpQkFBTzhGLEVBQU0sS0FBSyxJQUFJO0FBQUEsUUFBQyxDQUFHLEVBQUMsS0FBSyxTQUFTakcsR0FBRTtBQUFDLGNBQUc7QUFBQyxtQkFBT1csSUFBRVgsR0FBRStGLEVBQWEsR0FBQ0osR0FBMEIsRUFBRyxLQUFLLFNBQVMzRixHQUFFO0FBQUMsa0JBQUc7QUFBQyx1QkFBT1ksSUFBRVosSUFBRVMsSUFBRXFGLEdBQXNCckYsR0FBRUUsQ0FBQyxHQUFFb0YsRUFBVyxHQUFHbEYsSUFBRS9CLEVBQUUsa0JBQWdCLEdBQUVnQyxJQUFFaEMsRUFBRSxZQUFVaUIsRUFBRSxNQUFLdUYsR0FBYTFFLEdBQUVFLEdBQUVmLEVBQUUsTUFBS0EsRUFBRSxjQUFhYyxDQUFDLEVBQUUsS0FBSyxTQUFTYixHQUFFO0FBQUMsc0JBQUc7QUFBQztBQUEyRiwwQkFBU2tHLElBQVQsV0FBa0I7QUFBQyw0QkFBRzdGLFFBQU1lLElBQUViLEtBQUdhLElBQUVELElBQUc7QUFBQyw4QkFBSXJDLEdBQUVrQjtBQUFFLGlDQUFPbEIsSUFBRTBDLElBQUUsT0FBSU4sRUFBRSxRQUFNQSxFQUFFLE9BQU1sQixJQUFFd0IsSUFBRSxPQUFJTixFQUFFLFNBQU9BLEVBQUUsUUFBTyxDQUFDSSxHQUFFQyxDQUFDLElBQUV3RCxHQUFtQmpHLEdBQUVrQixDQUFDLEdBQUV1QixFQUFFLFVBQVVMLEdBQUUsR0FBRSxHQUFFcEMsR0FBRWtCLENBQUMsR0FBRWEsS0FBaUJDLE1BQWQsY0FBZ0IsT0FBSSxNQUFJd0UsR0FBYWhFLEdBQUVSLEdBQUVmLEVBQUUsTUFBS0EsRUFBRSxjQUFhYyxDQUFDLEVBQUUsS0FBTSxTQUFTZCxHQUFFO0FBQUMsZ0NBQUc7QUFBQyxxQ0FBT3NCLElBQUV0QixHQUFFMkYsR0FBb0J4RSxDQUFDLEdBQUVBLElBQUVJLEdBQUVGLElBQUVDLEVBQUUsTUFBSzJFLEVBQVksS0FBSyxJQUFJLElBQUcsS0FBSyxPQUFPdEQsSUFBRXRCLE1BQUlzQixJQUFFbkMsS0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFFMkY7QUFBQSw0QkFBTyxTQUFPbkcsR0FBTjtBQUFTLHFDQUFPSSxFQUFFSixDQUFDO0FBQUEsNEJBQUM7QUFBQSwwQkFBQyxHQUFHSSxDQUFDO0FBQUEsd0JBQUM7QUFBQywrQkFBTSxDQUFDLENBQUM7QUFBQSxzQkFBQyxHQUFnUmdHLElBQVQsV0FBdUI7QUFBQywrQkFBT1QsR0FBb0J4RSxDQUFDLEdBQUV3RSxHQUFvQnBFLENBQUMsR0FBRW9FLEdBQW9CakYsQ0FBQyxHQUFFaUYsR0FBb0I5RSxDQUFDLEdBQUU4RSxHQUFvQmxGLENBQUMsR0FBRXdGLEVBQVksR0FBRyxHQUFFL0YsRUFBRW9CLENBQUM7QUFBQSxzQkFBQztBQUE5eUIsMEJBQUE2RSxPQUFncEJDO0FBQW52QiwwQkFBR3BGLElBQUVmLEdBQUUrRixFQUFXLEdBQUcvRSxJQUFFRCxFQUFFLE9BQUtSLEdBQUVVLElBQUVGLEVBQUUsT0FBS2hCLEVBQUUsTUFBSyxDQUFDaUIsS0FBRyxDQUFDQztBQUFFLCtCQUFPK0UsRUFBWSxHQUFHLEdBQUUvRixFQUFFYyxDQUFDO0FBQUUsMEJBQUlUO0FBQTRZLDZCQUFPYSxJQUFFcEIsRUFBRSxNQUFLMkMsSUFBRTNCLEVBQUUsTUFBS0ssSUFBRXNCLEdBQUV4QixJQUFFTixHQUFFWSxJQUFFLENBQUMxQyxFQUFFLHdCQUFzQmtDLElBQUdWLElBQUUsU0FBU1AsR0FBRTtBQUFDLCtCQUFLQSxLQUFHO0FBQUMsOEJBQUdBLEVBQUU7QUFBSyxtQ0FBTyxLQUFLQSxFQUFFLEtBQUtPLEdBQUVILENBQUM7QUFBRSw4QkFBRztBQUFDLGdDQUFHSixFQUFFLEtBQUk7QUFBQyxrQ0FBR0EsRUFBRTtBQUFPLHVDQUFPQSxFQUFFLElBQUssSUFBQ29HLEVBQWEsS0FBSyxJQUFJLElBQUVwRztBQUFFLDhCQUFBQSxJQUFFbUc7QUFBQSw0QkFBTztBQUFNLDhCQUFBbkcsSUFBRUEsRUFBRSxLQUFLLElBQUk7QUFBQSwwQkFBQyxTQUFPQSxHQUFOO0FBQVMsbUNBQU9JLEVBQUVKLENBQUM7QUFBQSwwQkFBQztBQUFBLHdCQUFDO0FBQUEsc0JBQUMsRUFBRSxLQUFLLElBQUksR0FBR21HLENBQU87QUFBQSxvQkFBMEs7QUFBQSxrQkFBQyxTQUFPdkYsR0FBTjtBQUFTLDJCQUFPUixFQUFFUSxDQUFDO0FBQUEsa0JBQUM7QUFBQSxnQkFBQyxFQUFFLEtBQUssSUFBSSxHQUFFUixDQUFDO0FBQUEsY0FBQyxTQUFPSixHQUFOO0FBQVMsdUJBQU9JLEVBQUVKLENBQUM7QUFBQSxjQUFDO0FBQUEsWUFBQyxFQUFFLEtBQUssSUFBSSxHQUFFSSxDQUFDO0FBQUEsVUFBQyxTQUFPSixHQUFOO0FBQVMsbUJBQU9JLEVBQUVKLENBQUM7QUFBQSxVQUFDO0FBQUEsUUFBQyxFQUFFLEtBQUssSUFBSSxHQUFFSSxDQUFDO0FBQUEsTUFBQyxTQUFPSixHQUFOO0FBQVMsZUFBT0ksRUFBRUosQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEVBQUUsS0FBSyxJQUFJLEdBQUVJLENBQUM7QUFBQSxFQUFDLENBQUM7QUFBRTtBQUFDLE1BQU1LLEtBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFzc0IsSUFBSUM7QUFBRSxTQUFTMkYsR0FBb0JyRyxHQUFFakIsR0FBRTtBQUFDLFNBQU8sSUFBSSxRQUFTLENBQUNrQixHQUFFQyxNQUFJO0FBQUMsSUFBQVEsT0FBSUEsS0FBRSxTQUErQlYsR0FBRTtBQUFDLFlBQU1qQixJQUFFLENBQUE7QUFBRyxhQUFrQixPQUFPaUIsS0FBbkIsYUFBcUJqQixFQUFFLEtBQUssSUFBSWlCLE1BQU0sSUFBRWpCLEVBQUUsS0FBS2lCLENBQUMsR0FBRSxJQUFJLGdCQUFnQixJQUFJLEtBQUtqQixDQUFDLENBQUM7QUFBQSxJQUFDLEVBQUUwQixFQUFDO0FBQUcsVUFBTUwsSUFBRSxJQUFJLE9BQU9NLEVBQUM7QUFBRSxJQUFBTixFQUFFLGlCQUFpQixXQUFXLFNBQWlCSixHQUFFO0FBQUMsVUFBR2pCLEVBQUUsVUFBUUEsRUFBRSxPQUFPO0FBQVEsUUFBQXFCLEVBQUUsVUFBUztBQUFBLGVBQW9CSixFQUFFLEtBQUssYUFBaEIsUUFBeUI7QUFBQyxZQUFHQSxFQUFFLEtBQUs7QUFBTSxpQkFBT0UsRUFBRSxJQUFJLE1BQU1GLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRSxLQUFLSSxFQUFFLFVBQVM7QUFBRyxRQUFBSCxFQUFFRCxFQUFFLEtBQUssSUFBSSxHQUFFSSxFQUFFLFVBQVc7QUFBQSxNQUFBO0FBQU0sUUFBQXJCLEVBQUUsV0FBV2lCLEVBQUUsS0FBSyxRQUFRO0FBQUEsSUFBQyxDQUFHLEdBQUNJLEVBQUUsaUJBQWlCLFNBQVFGLENBQUMsR0FBRW5CLEVBQUUsVUFBUUEsRUFBRSxPQUFPLGlCQUFpQixTQUFTLE1BQUk7QUFBQyxNQUFBbUIsRUFBRW5CLEVBQUUsT0FBTyxNQUFNLEdBQUVxQixFQUFFLFVBQVc7QUFBQSxJQUFBLENBQUcsR0FBQ0EsRUFBRSxZQUFZLEVBQUMsTUFBS0osR0FBRSx3QkFBdUJqQixFQUFFLFFBQU8sU0FBUSxFQUFDLEdBQUdBLEdBQUUsWUFBVyxRQUFPLFFBQU8sT0FBTSxFQUFDLENBQUM7QUFBQSxFQUFDLENBQUM7QUFBRTtBQUFDLFNBQVN1SCxHQUFpQnRHLEdBQUVqQixHQUFFO0FBQUMsU0FBTyxJQUFJLFFBQVMsU0FBU2tCLEdBQUVDLEdBQUU7QUFBQyxRQUFJRSxHQUFFRyxHQUFFRCxHQUFFRSxHQUFFQyxHQUFFQztBQUFFLFFBQUdOLElBQUUsRUFBQyxHQUFHckIsRUFBQyxHQUFFdUIsSUFBRSxHQUFHLEVBQUMsWUFBV0UsRUFBQyxJQUFFSixHQUFHQSxFQUFFLFlBQVVBLEVBQUUsYUFBVyxPQUFPLG1CQUFrQkssSUFBYSxPQUFPTCxFQUFFLGdCQUFwQixhQUFrQ0EsRUFBRSxjQUFhLE9BQU9BLEVBQUUsY0FBYUEsRUFBRSxhQUFXLENBQUFKLE1BQUc7QUFBQyxNQUFBTSxJQUFFTixHQUFjLE9BQU9RLEtBQW5CLGNBQXNCQSxFQUFFRixDQUFDO0FBQUEsSUFBQyxHQUFFLEVBQUVOLGFBQWEsUUFBTUEsYUFBYXlFO0FBQVksYUFBT3ZFLEVBQUUsSUFBSSxNQUFNLG1EQUFtRCxDQUFDO0FBQUUsUUFBRyxDQUFDLFNBQVMsS0FBS0YsRUFBRSxJQUFJO0FBQUUsYUFBT0UsRUFBRSxJQUFJLE1BQU0sZ0NBQWdDLENBQUM7QUFBRSxRQUFHUSxJQUFlLE9BQU8sb0JBQXBCLE9BQXVDLGdCQUFnQixtQkFBa0IsQ0FBQ0QsS0FBZSxPQUFPLFVBQW5CLGNBQTJCQztBQUFFLGFBQU8rQyxHQUFTekQsR0FBRUksQ0FBQyxFQUFFLEtBQUssU0FBU0osR0FBRTtBQUFDLFlBQUc7QUFBQyxpQkFBT08sSUFBRVAsR0FBRXdGLEVBQU0sS0FBSyxJQUFJO0FBQUEsUUFBQyxTQUFPeEYsR0FBTjtBQUFTLGlCQUFPRSxFQUFFRixDQUFDO0FBQUEsUUFBQztBQUFBLE1BQUMsRUFBRSxLQUFLLElBQUksR0FBRUUsQ0FBQztBQUFFLFFBQUlVLElBQUUsV0FBVTtBQUFDLFVBQUc7QUFBQyxlQUFPNEUsRUFBTSxLQUFLLElBQUk7QUFBQSxNQUFDLFNBQU94RixHQUFOO0FBQVMsZUFBT0UsRUFBRUYsQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEVBQUUsS0FBSyxJQUFJLEdBQUV1RyxJQUFhLFNBQVN4SCxHQUFFO0FBQUMsVUFBRztBQUFDLGVBQU8wRSxHQUFTekQsR0FBRUksQ0FBQyxFQUFFLEtBQU0sU0FBU0osR0FBRTtBQUFDLGNBQUc7QUFBQyxtQkFBT08sSUFBRVAsR0FBRVksRUFBQztBQUFBLFVBQUUsU0FBT1osR0FBTjtBQUFTLG1CQUFPRSxFQUFFRixDQUFDO0FBQUEsVUFBQztBQUFBLFFBQUMsR0FBR0UsQ0FBQztBQUFBLE1BQUMsU0FBT0YsR0FBTjtBQUFTLGVBQU9FLEVBQUVGLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFFLFFBQUc7QUFBQyxhQUFPSSxFQUFFLFNBQU9BLEVBQUUsVUFBUSxrR0FBaUdpRyxHQUFvQnJHLEdBQUVJLENBQUMsRUFBRSxLQUFNLFNBQVNKLEdBQUU7QUFBQyxZQUFHO0FBQUMsaUJBQU9PLElBQUVQLEdBQUVZLEVBQUc7QUFBQSxRQUFBLFFBQUM7QUFBUyxpQkFBTzJGLEVBQVk7QUFBQSxRQUFFO0FBQUEsTUFBQyxHQUFHQSxDQUFZO0FBQUEsSUFBQyxRQUFDO0FBQVMsTUFBQUEsRUFBWTtBQUFBLElBQUU7QUFBQyxhQUFTZixJQUFPO0FBQUMsVUFBRztBQUFDLFFBQUFqRixFQUFFLE9BQUtQLEVBQUUsTUFBS08sRUFBRSxlQUFhUCxFQUFFO0FBQUEsTUFBWSxRQUFDO0FBQUEsTUFBUTtBQUFFLFVBQUc7QUFBQyxRQUFBSSxFQUFFLGdCQUE2QkosRUFBRSxTQUFqQixpQkFBd0IsQ0FBQ0ksRUFBRSxZQUFVQSxFQUFFLFlBQVVBLEVBQUUsYUFBV0osRUFBRSxVQUFRTyxJQUFFSixHQUEyQkgsR0FBRU8sQ0FBQztBQUFBLE1BQUUsUUFBQztBQUFBLE1BQVU7QUFBQSxhQUFPTixFQUFFTSxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUMsQ0FBQztBQUFFO0FBQUMrRixHQUFpQixxQkFBbUIxQixJQUFtQjBCLEdBQWlCLHFCQUFtQjNCLElBQW1CMkIsR0FBaUIsWUFBVXpCLElBQVV5QixHQUFpQixvQkFBa0JyQixJQUFrQnFCLEdBQWlCLG1CQUFpQm5CLElBQWlCbUIsR0FBaUIsZUFBYWYsSUFBYWUsR0FBaUIscUJBQW1CVCxJQUFtQlMsR0FBaUIseUJBQXVCUixJQUF1QlEsR0FBaUIsd0JBQXNCUCxJQUFzQk8sR0FBaUIsc0JBQW9CWCxJQUFvQlcsR0FBaUIsNkJBQTJCVixJQUEyQlUsR0FBaUIsNkNBQTJDdkIsSUFBMkN1QixHQUFpQiw2QkFBMkJuRyxJQUEyQm1HLEdBQWlCLGlCQUFleEIsSUFBZXdCLEdBQWlCLFVBQVE7QUNKM3d1RCxNQUFBRSxLQUFxQixPQUFPQyxNQUE0QjtBQUM3RCxRQUFBQyxJQUFXRCxLQUFrQkUsR0FBVyxnQkFBZ0I7QUFDMUQsTUFBQTtBQUVGLEtBRHVCLE1BQU05RyxHQUFBLEVBQTJCLE9BQU9mLElBQWU0SCxDQUFRLEdBQ25FLFdBQVcsT0FBSyxNQUFNN0csR0FBMkIsRUFBQSxnQkFBZ0JmLElBQWU0SCxHQUFVLENBQUUsQ0FBQTtBQUFBO0FBRTNHLFFBQUE7QUFDRixZQUFNN0csR0FBMkIsRUFBQSxnQkFBZ0JmLElBQWU0SCxHQUFVLENBQUUsQ0FBQTtBQUFBO0lBRzlFO0FBQUEsRUFDRjtBQUNGLEdBRWFFLEtBQWEsQ0FBQ0MsR0FBYUMsTUFFOUIsS0FBYyxTQUFTLElBQUksZUFBZUQsR0FBS0MsQ0FBSyxHQUdqREMsS0FBYyxNQUFNO0FBQUEsRUFDL0I7QUFBQSxJQUNFLEtBQUs7QUFBQSxJQUNMLFNBQVM7QUFBQSxNQUNQLE1BQU1oSSxHQUFFLGNBQWM7QUFBQSxNQUN0QixNQUFNQSxHQUFFLGtCQUFrQjtBQUFBLE1BQzFCLE1BQU07QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxNQUNSLGdCQUFnQjtBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFLEtBQUs7QUFBQSxJQUNMLFNBQVM7QUFBQSxNQUNQLE1BQU1BLEdBQUUsZ0JBQWdCO0FBQUEsTUFDeEIsTUFBTUEsR0FBRSxvQkFBb0I7QUFBQSxNQUM1QixNQUFNO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxPQUFPO0FBQUEsTUFDUCxRQUFRO0FBQUEsTUFDUixZQUFZO0FBQUEsTUFDWixVQUFVLE9BQU9pSSxNQUE4QjtBQUM3QyxjQUFNQyxJQUFrQjtBQUNwQixZQUFBUCxJQUFXTSxFQUFrQixRQUM3QkUsSUFBdUI7QUFFM0IsUUFBS1IsTUFDUUEsSUFBQU8sR0FDWUMsSUFBQSxLQUdkUixJQUFBQSxFQUFTLFFBQVEsUUFBUSxHQUFHLEdBQ25DTSxNQUFzQk4sTUFBaUNRLElBQUEsS0FFM0QsTUFBTVYsR0FBbUJFLENBQVEsR0FDN0JRLEtBQTRCLE1BQUFOLEdBQVcsa0JBQWtCRixDQUFRO0FBQUEsTUFDdkU7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGLEdBRWFTLEtBQWtCLENBQUNDLE1BRXRCLEtBQWMsU0FBUyxTQUFTLGVBQWVBLEVBQVEsS0FBS0EsRUFBUSxPQUFPLEdBR3hFVCxLQUFhLENBQUNFLE1BRWpCLEtBQWMsU0FBUyxJQUFJLGVBQWVBLENBQUcsR0MxRGpEUSxLQUFxQixDQUFDLGNBQWMsR0FDcENDLEtBQVksSUFBSTtBQUV0QixJQUFJQyxLQUE4QixDQUFBO0FBRWxDLE1BQU1DLEtBQWMsQ0FBQ0MsTUFBa0NBLEVBQUssUUFBUUEsRUFBSyxLQUFLLFdBQVcsUUFBUSxHQUUzRkMsS0FBWSxDQUFDQyxNQUFnQyxPQUFPQSxLQUFRLFlBQVlBLEVBQUksV0FBVyxPQUFPLEdBRTlGQyxLQUFzQixDQUFDRCxNQUFpQjtBQUN4QyxNQUFBLEVBQUNELEdBQVVDLENBQUc7QUFDZCxRQUFBO0FBQ0YsVUFBSSxnQkFBZ0JBLENBQUc7QUFBQTtJQUNBO0FBQzNCLEdBRU1FLEtBQXFCLENBQUMsRUFBQyxVQUFBQyxHQUFVLElBQUFDLEVBQStCLE1BQUF4SztBQUFBLEVBQ2xFLFlBQVl3SztBQUFBO0FBQUEsMkNBRTJCLE9BQU9ELENBQVEsV0FBVy9JLEdBQUUsbUJBQW1CO0FBQUE7QUFFMUYsR0FFTWlKLEtBQXlCLENBQUNDLEdBQXNCQyxHQUEwQkMsTUFBdUI7QUFhbEcsRUFBQW5LLEdBQUFpSyxHQUFjLFNBWlUsTUFBTTtBQUMvQixVQUFNRyxJQUFReEssR0FBSyxJQUFJc0ssRUFBVSxNQUFNQyxDQUFVO0FBT2pELElBTkE1SixHQUFPNkosQ0FBSyxHQUdSRixFQUFVLFFBQU1OLEdBQW9CTSxFQUFVLFFBQVEsR0FFMURYLEtBQWFBLEdBQVcsT0FBTyxDQUFDYyxNQUEyQkgsRUFBVSxPQUFPRyxFQUFRLEVBQUUsR0FDbEYsQ0FBQWQsR0FBVyxVQUVmakosR0FBUzZKLEdBQVksUUFBUTtBQUFBLEVBQUEsQ0FFYTtBQUM5QyxHQU1NRyxLQUFjLE9BQU9KLE1BQThDO0FBQ2pFLFFBQUFLLElBQW1CLENBQUNDLE1BQXNCO0FBQzlDLFVBQU0sRUFBQyxNQUFBQyxHQUFNLE1BQUFDLEdBQU0sSUFBQVgsRUFBQSxJQUFNUyxHQUNuQkcsS0FDRkQsS0FBQSxnQkFBQUEsRUFBTSxVQUFVQSxFQUFLLFlBQVksR0FBRyxHQUFHQSxFQUFLLGFBQzVDRCxLQUFBLGdCQUFBQSxFQUFNLFFBQVEsVUFBVSxTQUN4QjtBQUNKLFdBQU8sR0FBR1YsSUFBS1k7QUFBQSxFQUFBO0FBR2IsTUFBQTtBQUNJLFVBQUFDLElBQVVMLEVBQWlCTCxDQUFTLEdBRXBDVyxJQUFrQixNQUFNdkMsR0FBaUI0QixFQUFVLE1BQWM7QUFBQSxNQUNyRSxXQUFXO0FBQUEsTUFDWCxjQUFjO0FBQUEsTUFDZCxzQkFBc0I7QUFBQSxJQUFBLENBQ3ZCLEdBRUtZLElBQVcsSUFBSSxLQUFLLENBQUNELENBQXVCLEdBQUdELEdBQVMsRUFBQyxNQUFNVixFQUFVLEtBQUEsQ0FBSyxHQUU5RXpCLElBQWlCRSxHQUFXLGdCQUFnQixHQU01Q29DLElBQWdCLE1BSEgsSUFBS2xKLEtBR2U7QUFBQSxNQUNuQ2Y7QUFBQSxNQUNBMkg7QUFBQSxNQUNBcUM7QUFBQSxNQUNBLENBQUM7QUFBQSxNQUNELEVBQUMsUUFBUSxHQUFLO0FBQUEsSUFBQTtBQUdsQixXQUFJLENBQUNDLEtBQWlCLEVBQUVBLEtBQUEsUUFBQUEsRUFBMkMsUUFFMURiLEVBQVUsV0FFWGEsRUFBMEM7QUFBQTtBQUVsRCxXQUFPYixFQUFVO0FBQUEsRUFDbkI7QUFDRixHQUtNYyxLQUFrQixPQUFPZCxHQUEwQmUsTUFBb0I7QUFDckUsUUFBQWQsSUFBcUJ2SyxHQUFLLHdCQUF3QnFMLENBQU87QUFDM0QsTUFBQSxDQUFDZCxLQUFjLENBQUNBLEVBQVc7QUFBSTtBQUduQyxNQUFJRCxFQUFVLE1BQU07QUFDbEIsUUFBSSxDQUFDL0ksR0FBYztBQUFHO0FBR3RCLElBQUErSSxFQUFVLFdBQVcsSUFBSSxnQkFBZ0JBLEVBQVUsSUFBSTtBQUFBLEVBQ3pEO0FBRU0sUUFBQWdCLElBQWVyQixHQUFtQkssQ0FBUztBQUM3QyxNQUFBLENBQUNnQixLQUFnQixDQUFDQSxFQUFhO0FBQUk7QUFFdkMsRUFBQTlLLEdBQVkrSixHQUFZLFFBQVEsR0FDaENwSyxHQUFPb0ssR0FBWWUsQ0FBWSxHQUMvQjNCLEdBQVcsS0FBS1csQ0FBUztBQUVuQixRQUFBRCxJQUFlckssR0FBSyx5QkFBeUJzTCxDQUFZO0FBQ3hDLEVBQUFsQixHQUFBQyxHQUFjQyxHQUFXQyxDQUFVO0FBQzVELEdBRU1nQixLQUEwQixDQUFDMUIsR0FBWXdCLE1BQW9CLE9BQU9HLE1BQWdCO0FBRXRGLFFBQU1sQixJQUEyQixFQUFDLE1BQU1ULEVBQUssTUFBTSxNQUFNQSxFQUFLLE1BQU0sVUFBVSxJQUFJLElBQUl2SSxNQUFnQixNQUFBdUksRUFBSTtBQUNwRyxRQUFBdUIsR0FBZ0JkLEdBQVdlLENBQU87QUFDMUMsR0FFYUksS0FBb0IsQ0FBQ0MsR0FBMEJMLE1BQW9CO0FBQzlFLFdBQVMvSSxJQUFJLEdBQUdBLElBQUlvSixFQUFNLFFBQVFwSixLQUFLO0FBQ3JDLFVBQU11SCxJQUFhNkIsRUFBTXBKO0FBQ3JCLElBQUEsQ0FBQ3NILEdBQVlDLENBQUksS0FHaEIwQixHQUF3QjFCLEdBQU13QixDQUFPLEVBQUUsSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUFBLEVBQy9EO0FBQ0YsR0FFYU0sS0FBNEIsQ0FBQ0MsR0FBeUJQLE1BQW9CO0FBQy9FLFFBQUFRLElBQTBCLENBQUNDLE1BQXNDO0FBQy9ELFVBQUFsTSxJQUFPa00sRUFBRyxRQUFRLFdBQVc7QUFDbkMsUUFBSSxDQUFDbE07QUFBYSxhQUFBO0FBRWxCLFVBQU1tTSxJQUFTckMsR0FBVSxnQkFBZ0I5SixHQUFNLFdBQVcsRUFBRSxpQkFBaUIsS0FBSztBQUM5RSxRQUFBLENBQUNtTSxLQUFVLENBQUNBLEVBQU87QUFBZSxhQUFBO0FBR2hDLFVBQUFDLElBQVksQ0FBQyxHQUFHRCxDQUFNLEVBQUUsSUFBSSxDQUFDRSxNQUFRQSxFQUFJLEdBQWE7QUFFNUQsV0FEc0JELEVBQVUsS0FBSyxDQUFDRSxNQUFPekMsR0FBbUIsS0FBSyxDQUFDMEMsTUFBT0QsRUFBRyxTQUFTQyxDQUFFLENBQUMsQ0FBQyxJQUN0RSxPQUFPSDtBQUFBLEVBQUEsR0FHMUJJLElBQTJCLE9BQU9DLE1BQW1CO0FBQ3pELGFBQVMvSixJQUFJLEdBQUdBLElBQUkrSixFQUFLLFFBQVEvSixLQUFLO0FBRXBDLFlBQU1nSSxJQUEyQixFQUFDLFVBRHRCK0IsRUFBSy9KLElBQ2dDLElBQUloQjtBQUMvQyxZQUFBOEosR0FBZ0JkLEdBQVdlLENBQU87QUFBQSxJQUMxQztBQUFBLEVBQUEsR0FpQklLLEtBYjRCLENBQUNJLE1BQTZCO0FBQzlELFVBQU1RLElBQThCUixFQUFHLE9BQ2pDSixJQUFnQixDQUFBO0FBQ3RCLGFBQVNwSixJQUFJLEdBQUdBLElBQUlnSyxFQUFNLFFBQVFoSyxLQUFLO0FBQ3JDLFlBQU1pSyxJQUF5QkQsRUFBTWhLO0FBQ2pDLFVBQUEsQ0FBQ3NILEdBQVkyQyxDQUFJO0FBQUc7QUFDbEIsWUFBQTFDLElBQU8wQyxFQUFLO0FBQ2xCLE1BQUksQ0FBQzFDLEtBQ0w2QixFQUFNLEtBQUs3QixDQUFJO0FBQUEsSUFDakI7QUFDTzZCLFdBQUFBO0FBQUFBLEVBQUEsR0FHdUNFLENBQVM7QUFDekQsTUFBSUYsS0FBU0EsRUFBTTtBQUFlLFdBQUFELEdBQWtCQyxHQUFPTCxDQUFPO0FBRzVELFFBQUFnQixJQUF3QlIsRUFBd0JELENBQVM7QUFDL0QsTUFBSVMsS0FBUUEsRUFBSztBQUFlLFdBQUEsS0FBS0QsRUFBeUJDLENBQUk7QUFDcEUsR0FFYUcsS0FBZ0IsTUFBdUI3QyxJQU12QzhDLEtBQXNCLE9BQU9wQixNQUFvQjtBQUU1RCxXQUFTL0ksSUFBSSxHQUFHQSxJQUFJcUgsR0FBVyxRQUFRckgsS0FBSztBQUMxQyxVQUFNaUssSUFBTzVDLEdBQVdySDtBQUN4QixRQUFJLENBQUNpSyxFQUFLO0FBQU07QUFDaEIsVUFBTUcsSUFBU0gsRUFBSztBQUdoQixRQUFBLENBQUN6QyxHQUFVNEMsQ0FBTTtBQUFHO0FBRWxCLFVBQUFDLElBQWUsTUFBTWpDLEdBQVk2QixDQUFJO0FBQzNDLElBQUFBLEVBQUssV0FBV0ksR0FHaEIzQyxHQUFvQjBDLENBQU07QUFBQSxFQUM1QjtBQUNGLEdBRWFFLEtBQXFCLENBQUN2QixNQUFvQjtBQUNyRCxTQUFPMUIsR0FBVyxVQUFRO0FBQ2xCLFVBQUFrRCxJQUF1Q2xELEdBQVc7QUFDeEQsUUFBSSxDQUFDa0Q7QUFBVztBQUVoQixJQUFJQSxFQUFVLFFBQU03QyxHQUFvQjZDLEVBQVUsUUFBUTtBQUUxRCxVQUFNQyxJQUFlOU0sR0FBSyxJQUFJNk0sRUFBVSxNQUFNeEIsQ0FBTztBQUNyRCxJQUFBMUssR0FBT21NLENBQVk7QUFBQSxFQUNyQjtBQUVNLFFBQUF2QyxJQUFxQnZLLEdBQUssd0JBQXdCcUwsQ0FBTztBQUMvRCxFQUFBM0ssR0FBUzZKLEdBQVksUUFBUTtBQUMvQixHQzNOTXdDLEtBQW1CLE1BQ3ZCcE4sR0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUUsR0FHRXFOLEtBQWlCLENBQUMzQixNQUFvQjtBQUNqRCxRQUFNZCxJQUFhd0MsTUFHYkUsSUFBc0JqTixHQUFLLGlCQUFpQnFMLENBQU87QUFDckQsTUFBQTRCLEtBQWVBLEVBQVk7QUFDN0IsSUFBQXBOLEdBQU9vTixHQUFhMUMsQ0FBVTtBQUFBLE9BQ3pCO0FBRUMsVUFBQXRLLElBQVcrQixPQUFxQixtQkFBbUI7QUFDckQsUUFBQWtMLElBQWVsTixHQUFLQyxHQUFVb0wsQ0FBTztBQUd6QyxLQUFJLENBQUM2QixLQUFnQixDQUFDQSxFQUFhLFFBQ2pDQSxJQUFlbE4sR0FBS0MsQ0FBUSxJQUUxQmlOLEtBQWdCQSxFQUFhLE1BQy9Cck4sR0FBT3FOLEdBQWMzQyxDQUFVO0FBQUEsRUFFbkM7QUFHTSxRQUFBNEMsSUFBV25OLEdBQUssaUJBQWlCdUssQ0FBVTtBQUNqRCxFQUFBbkssR0FBRytNLEdBQVUsU0FBUyxNQUFNUCxHQUFtQnZCLENBQU8sQ0FBQztBQUN6RCxHQ2hDTStCLEtBQXFCLE1BQWN6TixHQUFPLGtDQUFrQ3dCLEdBQUUsbUJBQW1CLHNDQUFzQyxHQUV2SWtNLEtBQTBCLE1BQWMxTixHQUFPLGlGQUFpRixHQUVoSTJOLEtBQWMsQ0FBQ0MsR0FBc0JDLEdBQTJCbkMsTUFBb0I7QUFDbEYsUUFBQW9DLElBQXNDLENBQUNDLE1BQWU7QUFDMUQsVUFBTUMsSUFBa0NELEVBQUksZUFDdENoQyxJQUF5QmlDLEVBQWM7QUFDN0MsSUFBSSxDQUFDakMsTUFFTEQsR0FBa0JDLEdBQU9MLENBQU8sR0FDaENzQyxFQUFjLFFBQVE7QUFBQSxFQUFBLEdBRWxCQyxJQUFnQyxDQUFDRixNQUFlO0FBQ3BELElBQUFBLEVBQUksZUFBZSxHQUNuQm5OLEdBQVFpTixHQUFtQixPQUFPO0FBQUEsRUFBQTtBQUdqQyxFQUFBcE4sR0FBQW9OLEdBQW1CLFVBQVVDLENBQW1DLEdBQ2hFck4sR0FBQW1OLEdBQWMsU0FBU0ssQ0FBNkI7QUFDekQsR0FFYUMsS0FBbUIsQ0FBQ3hDLE1BQW9CO0FBQy9DLE1BQUEsQ0FBQ3RDLEdBQVcsY0FBYztBQUFHO0FBRTNCLFFBQUErRSxJQUF5QjlOLEdBQUssb0JBQW9CcUwsQ0FBTyxHQUN6RGtDLElBQXVCSCxNQUN2QkksSUFBNEJIO0FBRTlCLE1BQUEsRUFBQzlMLEdBQWMsRUFBSSxHQUV2QjtBQUFBLFFBQUl1TSxFQUFlO0FBQ2pCLE1BQUFwTixHQUFTb04sR0FBZ0IsdUJBQXVCLEdBQ2hEM04sR0FBTzJOLEdBQWdCUCxDQUFZLEdBQ25DcE4sR0FBTzJOLEdBQWdCTixDQUFpQjtBQUFBLFNBQ25DO0FBRUMsWUFBQU4sSUFBdUJsTixHQUFLLGtCQUFrQnFMLENBQU8sR0FDckQwQyxJQUFvQnBPLEdBQU8sMENBQTBDO0FBRTNFLE1BQUFRLEdBQU80TixHQUFtQlIsQ0FBWSxHQUN0Q3BOLEdBQU80TixHQUFtQlAsQ0FBaUIsR0FDM0NyTixHQUFPK00sR0FBY2EsQ0FBaUI7QUFBQSxJQUN4QztBQUVZLElBQUFULEdBQUFDLEdBQWNDLEdBQW1CbkMsQ0FBTztBQUFBO0FBQ3RELEdDaERNMkMsS0FBYSxDQUFDQyxHQUFjQyxNQUFvQjtBQUNwRCxNQUFJLENBQUNBLEdBQVE7QUFDTixJQUFBck4sR0FBQW9OLEdBQU0sWUFBWSxFQUFJO0FBQzNCO0FBQUEsRUFDRjtBQUNBLEVBQUFqTixHQUFXaU4sR0FBTSxVQUFVLEdBQzNCaE4sR0FBTWdOLENBQUk7QUFDWixHQUVNRSxLQUFnQixDQUFDQyxHQUFrQkYsTUFBb0I7QUFDM0QsUUFBTUcsSUFBWSxjQUNaQyxJQUFVdE8sR0FBSyxJQUFJcU8sS0FBYUQsQ0FBUTtBQUUxQyxNQUFBLENBQUNGLEtBQVVJLEVBQVEsSUFBSTtBQUN6QixJQUFBM04sR0FBTzJOLENBQU87QUFDZDtBQUFBLEVBQ0Y7QUFFSSxNQUFBSixLQUFVLENBQUNJLEVBQVEsSUFBSTtBQUNuQixVQUFBQyxJQUFhNU8sR0FBTyxZQUFZME8sV0FBbUI7QUFDekQsSUFBQWxPLEdBQU9pTyxHQUFVRyxDQUFVO0FBQUEsRUFDN0I7QUFDRixHQUVhQyxLQUFxQixDQUFDbkQsTUFBb0I7QUFDL0MsUUFBQW9ELElBQWdCek0sT0FBcUIsZUFBZSxjQUNwRG9NLElBQVdwTyxHQUFLeU8sR0FBZXBELENBQU8sR0FDdEM0QyxJQUFPak8sR0FBSyxpQkFBaUJxTCxDQUFPO0FBRW5DLFNBQUE7QUFBQSxJQUNMLEtBQUs7QUFDSCxNQUFBMkMsR0FBV0MsR0FBTSxFQUFLLEdBQ3RCRSxHQUFjQyxHQUFVLEVBQUk7QUFBQSxJQUM5QjtBQUFBLElBQ0EsTUFBTTtBQUNKLE1BQUFKLEdBQVdDLEdBQU0sRUFBSSxHQUNyQkUsR0FBY0MsR0FBVSxFQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUFBO0FBRUo7QUNyQ0EsSUFBSU0sS0FBWTtBQUVoQixNQUFNQyxLQUFnQixDQUFDQyxNQUFzQywyQ0FBMkNBLEVBQVcsa0JBQWtCQSxFQUFXLFFBQVF6TixHQUFFLG1CQUFtQixhQUV2SzBOLEtBQWtCLENBQUNsRixNQUVoQiwyQkFEMEJBLEVBQVcsSUFBSSxDQUFDaUYsTUFBc0NELEdBQWNDLENBQVUsQ0FBQyxFQUMvRCxLQUFLLEVBQUUsV0FHcERFLEtBQXFCLE1BQU07QUFDL0IsUUFBTUMsSUFBa0IvTSxHQUFpQixJQUNyQyxNQUFNLG9CQUFvQixNQUMxQixNQUFNLG1CQUFtQjtBQUN0QixTQUFBLE9BQU8rTSxJQUFvQixNQUFjQSxJQUFrQjtBQUNwRSxHQUVNQyxLQUEyQixDQUFDM0QsTUFBb0IsQ0FBQ3FDLE1BQWE7QUFDbEUsUUFBTXVCLElBQTRDdkIsRUFBSSxlQUNoRDlCLElBQWtDcUQsRUFBaUMsaUJBQWtCQSxFQUE0QjtBQUN2SCxFQUFJLENBQUNyRCxLQUVMRCxHQUEwQkMsR0FBV1AsQ0FBTztBQUM5QyxHQUVNNkQsS0FBZ0IsQ0FBQzdELE1BQW9CLE9BQU9xQyxNQUFhOztBQUN6RCxNQUFBZ0I7QUFBVztBQUVmLFFBQU0vRSxJQUFhNkM7QUFDbkIsTUFBSSxDQUFDN0MsRUFBVztBQUFRO0FBR3hCLEVBQUErRCxFQUFJLGVBQWUsR0FDbkJBLEVBQUksZ0JBQWdCLEdBRVJnQixLQUFBO0FBQ04sUUFBQVMsSUFBY1gsR0FBbUJuRCxDQUFPO0FBQzlDLEVBQUE4RCxFQUFZLEdBQUc7QUFFWCxNQUFBO0FBRUYsVUFBTTFDLEdBQW9CcEIsQ0FBTztBQUUzQixVQUFBK0QsSUFBUXBQLEdBQUssaUJBQWlCcUwsQ0FBTyxHQUNyQ2pLLElBQWVnTyxLQUFBLFFBQUFBLEVBQU8sTUFBTSxRQUFPL04sSUFBQStOLEVBQU0sSUFBSSxNQUFWLE9BQUEvTixJQUFlLEVBQUUsSUFBSSxJQUN4RGdPLElBQVVqTyxJQUNaLEdBQUd5TixHQUFnQmxGLENBQVUsMEJBQTBCdkksWUFDdkR5TixHQUFnQmxGLENBQVU7QUFFOUIsVUFBTSxZQUFZLE9BQU87QUFBQSxNQUN2QixTQUFBMEY7QUFBQSxNQUNBLE1BQU1QLEdBQW1CO0FBQUEsTUFDekIsTUFBTyxLQUFjO0FBQUEsSUFBQSxDQUN0QixHQUdHTSxLQUFBLFFBQUFBLEVBQU8sT0FBS0EsRUFBTSxJQUFJLEVBQUUsR0FFNUJ4QyxHQUFtQnZCLENBQU87QUFBQSxFQUFBLFVBQzFCO0FBQ0EsSUFBQThELEVBQVksSUFBSSxHQUNKVCxLQUFBO0FBQUEsRUFDZDtBQUNGLEdBRWFZLEtBQXVCLENBQUNqRSxNQUU1QixDQUFDLENBRFdyTCxHQUFLLHdCQUF3QnFMLENBQU8sRUFDbkMsUUFHVGtFLEtBQWtCLENBQUNsRSxNQUFvQjtBQUVsRCxFQUFBakwsR0FBR2lMLEdBQVMsY0FBYzJELEdBQXlCM0QsQ0FBTyxDQUFDO0FBR3JELFFBQUFvRCxJQUFnQnpNLE9BQXFCLGVBQWUsY0FDcERvTSxJQUFXcE8sR0FBS3lPLEdBQWVwRCxDQUFPO0FBQzVDLEVBQUFqTCxHQUFHZ08sR0FBVSxVQUFVYyxHQUFjN0QsQ0FBTyxDQUFDO0FBQy9DLEdDL0VhbUUsS0FBa0IsQ0FBQ3ZDLE1BQXdCO0FBQ2hELFFBQUFsQixJQUFTL0wsR0FBSyx5QkFBeUJpTixDQUFXO0FBQ3hELE1BQUksQ0FBQ2xCLEVBQU87QUFBSTtBQWNiLEVBQUEzTCxHQUFBMkwsR0FBUSxTQVpjLENBQUMyQixNQUFlO0FBQ2pDLFVBQUEzRCxJQUFPMkQsRUFBSSxPQUE0QixLQUN2QytCLElBQWF2TjtBQUVuQixJQUFJRixPQUVFLElBQUF5TixFQUFXLEVBQUUsS0FBQTFGLEdBQUssVUFBVSxJQUFPLFdBQVcsSUFBTSxFQUFFLE9BQU8sRUFBSSxJQUdqRSxJQUFBMEYsRUFBVzFGLEdBQUssRUFBRSxVQUFVLElBQU8sV0FBVyxJQUFNLEVBQUUsT0FBTyxFQUFJO0FBQUEsRUFDdkUsQ0FFa0M7QUFDdEMsR0NsQk0yRixLQUFtQiw2QkFDbkJDLEtBQVcsa0RBRVhoQixLQUFnQixDQUFDNUUsTUFBd0IsMkNBQTJDQSxXQUFhNUksR0FBRSxtQkFBbUIsYUFFL0d5TyxLQUFpQixDQUFDQyxNQUN4QkEsRUFBUSxNQUFNSCxFQUFnQixJQUU1QkcsRUFBUSxXQUFXSCxJQUFrQixDQUFDcE0sR0FBV3lHLE1BQ2pEQSxFQUFJLE1BQU00RixFQUFRLElBQ2hCaEIsR0FBYzVFLENBQUcsSUFEU3pHLENBRWxDLElBTDRDdU0sR0NFekNDLEtBQW1CLE1BQU07QUFFN0IsRUFEaUIzRyxLQUNSLFFBQVEsQ0FBQ0ssTUFBWUQsR0FBZ0JDLENBQU8sQ0FBQztBQUN4RDtBQUVBLE1BQU0sS0FBSyxRQUFRLFlBQVk7QUFDWixFQUFBc0csTUFDSEMsTUFFZCxNQUFNbkgsR0FBbUI7QUFDM0IsQ0FBQztBQUVELE1BQU1tSCxLQUFnQixNQUFNO0FBQzFCLE1BQUkvTixNQUFvQjtBQUN0QixVQUFNLEdBQUcseUJBQXlCLENBQUNnTyxHQUFXQyxNQUFvQztBQUMxRSxZQUFBaEQsSUFBY3ROLEdBQU9zUSxDQUFrQjtBQUc3QyxNQUFJLENBRGNqUSxHQUFLLHFCQUFxQmlOLENBQVcsRUFDeEMsTUFFZnVDLEdBQWdCdkMsQ0FBVztBQUFBLElBQUEsQ0FDNUI7QUFFSyxVQUFBaUQsSUFBYSxDQUFDN0UsTUFBb0I7QUFFdEMsTUFBSWlFLEdBQXFCakUsQ0FBTyxNQUVoQzJCLEdBQWUzQixDQUFPLEdBR3RCa0UsR0FBZ0JsRSxDQUFPO0FBQUEsSUFBQTtBQUd6QixVQUFNLEdBQUcsbUJBQW1CLENBQUNBLEdBQWM4RSxNQUF1QjtBQUNoRSxVQUFJLENBQUM5RSxLQUFXOEU7QUFBVztBQUUzQixZQUFNQyxJQUFpQi9FLEVBQVE7QUFJL0IsVUFISSxDQUFDK0UsS0FHRCxDQURtQkEsRUFBZSxjQUFjLGVBQWU7QUFDOUM7QUFFZixZQUFBQyxJQUFZLEVBQUVELENBQWM7QUFDbEMsTUFBQUYsRUFBV0csQ0FBUztBQUFBLElBQUEsQ0FDckIsR0FFSyxNQUFBLEdBQUcsbUJBQW1CLENBQUNDLE1BQWlCO0FBQzVDLFVBQUksQ0FBQ0E7QUFBUztBQUVkLFlBQU1DLElBQWlCRCxFQUFRO0FBSS9CLFVBSEksQ0FBQ0MsS0FHRCxDQURtQkEsRUFBZSxjQUFjLGVBQWU7QUFDOUM7QUFFZixZQUFBQyxJQUFZLEVBQUVELENBQWM7QUFDbEMsTUFBQUwsRUFBV00sQ0FBUztBQUFBLElBQUEsQ0FDckI7QUFBQSxFQUFBO0FBRUQsVUFBTSxHQUFHLHFCQUFxQixDQUFDUixHQUFXL0MsTUFBd0I7QUFFaEUsTUFBSSxDQURjak4sR0FBSyxxQkFBcUJpTixDQUFXLEVBQ3hDLE1BRWZ1QyxHQUFnQnZDLENBQVc7QUFBQSxJQUFBLENBQzVCLEdBRUQsTUFBTSxHQUFHLG9CQUFvQixDQUFDK0MsR0FBVzNFLE1BQW9CO0FBQzNELFlBQU0rRSxJQUFxQy9FLEVBQVE7QUFJbkQsTUFISSxDQUFDK0UsS0FHRCxDQURtQkEsRUFBZSxjQUFjLGVBQWUsTUFHbkVwRCxHQUFlM0IsQ0FBTyxHQUN0QndDLEdBQWlCeEMsQ0FBTyxHQUN4QmtFLEdBQWdCbEUsQ0FBTztBQUFBLElBQUEsQ0FDeEI7QUFHSCxRQUFNLEdBQUcsd0JBQXdCLENBQUM0QixHQUFrQndELEdBQW9CQyxNQUF3QjtBQUN4RixVQUFBQyxJQUEyQmYsR0FBZTNDLEVBQVksT0FBTztBQUNuRSxJQUFJQSxFQUFZLFlBQVkwRCxNQUU1QjFELEVBQVksVUFBVTBELEdBQ3RCMUQsRUFBWSxRQUFRLFVBQVUwRCxHQUM5QkQsRUFBZSxhQUFhO0FBQUEsRUFBQSxDQUM3QjtBQUNIOyJ9
